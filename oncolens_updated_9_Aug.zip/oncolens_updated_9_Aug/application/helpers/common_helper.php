<?php

function prd($data = array(), $die = 1) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    if ($die)
        die();
}

function day_details($days = 0) {
    if (!$days) {
        echo 'Today';
        return true;
    }
    //echo $case->case_submitted_within; 
    $convert = $days; // days you want to convert
    
    
 
    $years = ($convert / 365); // days / 365 days
    $years = floor($years); // Remove all decimals

    $month = ($convert % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
    $month = floor($month); // Remove all decimals

    $days = ($convert % 365) % 30.5; // the rest of days
    // Echo all information set
//                                                    echo 'DAYS RECEIVE : '.$convert.' days<br>';
//      
//                                                    
//                                                                                                  
//                                                                                                                                                                                              echo $years.' years - '.$month.' month - '.$days.' days';
    
    
    
    
    if ($years > 0) {
        echo $years . ' Year';
        echo $years > 1 ? 's ' : ' ';
    }
    if ($month > 0) {
        echo $month . ' Month';
        echo $month > 1 ? 's ' : ' ';
    }
    if ($days > 0) {
        echo $days . ' Day';
        echo $days > 1 ? 's ' : ' ';
    }
}

function day_details_find($days = 0) {
         
    
    return $days;
    
//    if($days>31){
//    $convert = $days; // days you want to convert
//
//    $years = ($convert / 365); // days / 365 days
//    $years = floor($years); // Remove all decimals
//
//    $month = ($convert % 365) / 30.5; // I choose 30.5 for Month (30,31) ;)
//    $month = floor($month); // Remove all decimals
//
//    $days = ($convert % 365) % 30.5; // the rest of days
//    // Echo all information set
////                                                    echo 'DAYS RECEIVE : '.$convert.' days<br>';
////                                                    echo $years.' years - '.$month.' month - '.$days.' days';
////    if ($years > 0) {
////        $string =  $years . ' Year';
////        $string.= $years > 1 ? 's ' : ' ';
////    }
////    if ($month > 0) {
////         $string = $month . ' Month';
////        $string.= $month > 1 ? 's ' : ' ';
////    }
////    if ($days > 0) {
////        $string = $days . ' Day';
////        $string.= $days > 1 ? 's ' : ' ';
////    }
//
//
//    if ($years > 1)
//        $yearString = " year";
//    else
//        $yearString = " year";
//    if ($month > 1)
//        $monthString = " month";
//    else
//        $monthString = " month";
//    if ($days > 1)
//        $dayString = " day";
//    else
//        $dayString = " day";
//    
//    
//    //echo "year=".$years."month=".$month."days=".$days;
//    //die;
//
//    if (($years == 0) && ($month == 0) && ($days == 0))
//        $ageString = '1' . $dayString . " old";
//    elseif(($years == 0) && ($month == 0) && ($days>0))
//        $ageString = $days . $dayString . " old";
//    elseif(($years == 0) && ($month>0))
//        $ageString = $month . $monthString . " old";
//    elseif(($years<20) && ($month>0))
//        $ageString = $years . $yearString . " and " . $month . $monthString . " old";
//    else
//        $ageString = $years . $yearString . " old";
//    
//    /*if (($years > 0) && ($month > 0) && ($days > 0))
//
//    if (($years > 0) && ($month > 0) && ($days >= 0))
//
//        if (($years >= 20 && $month > 0) || ($years >= 20 && $days > 0)) {
//            $ageString = $years . $yearString . " old";
//        } else {
//            $ageString = $years . $yearString . " and " . $month . $monthString . " old";
//        } 
//             
//        else if (($years == 0) && ($month == 0) && ($days > 0))
//        $ageString = $days . $dayString . " old";
//    else if (($years > 0) && ($month == 0) && ($days == 0))
//        $ageString = $years . $yearString . " old";
//    else if (($years > 0) && ($month > 0) && ($days == 0))
//        $ageString = $years . $yearString . " and " . $month . $monthString . " old";
//    else if (($years == 0) && ($month > 0) && ($days > 0))
//        $ageString = $month . $monthString . " old";
//    else if (($years > 0) && ($month == 0) && ($days > 0))
//        $ageString = $years . $yearString . " old";
//    else if (($years == 0) && ($month > 0) && ($days == 0))
//        $ageString = $month . $monthString . " old";
//    else if (($years == 0) && ($month == 0) && ($days == 0))
//        $ageString = '1' . $dayString . " old";
//*/
//    return $ageString;
//    }else{
//           if($days==0){
//              $days =1; 
//           } 
//           $dayString = " day"; 
//        return $days. $dayString . " old";
//    }
}
