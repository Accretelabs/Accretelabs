<?php

include_once 'mpdf.php';

$pdf = new mPDF('c');
$pdf->SetDisplayMode('fullpage');

$pdf->SetHeader();

$html = file_get_contents("test.html");
$pdf->WriteHTML($html);

$pdf->Output("test.pdf","D");