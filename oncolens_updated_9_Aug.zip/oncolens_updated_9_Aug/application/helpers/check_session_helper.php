<?php

//Get Current CI Instance
$CI = & get_instance();
//Use $CI instead of $this
//Check for session details here, here's an example
$CI->load->library('session');
$user = $CI->session->userdata('u_userid');
//Get current controller to avoid infinite loop
$controller = $CI->router->class;
$method = $CI->router->method;
$module = $CI->router->directory;

//Check if user session exists and you are not already on the login page
if (empty($user) && $controller!= "page" && strtolower($controller)!= "cronjob" && strtolower($controller)!= "cronjobdemo" && $controller!= "contactus" && $controller!= "admin" && $module!="admin/") {
    if($controller=='users'){
        if($method=='changepassword' || $method=='profile' || $method=='tumor_board_add' 
                || $method=='change_tumor_data' || $method=='tumorboardlist' || $method=='tumorboard_add'
                || $method=='tumor_board_delete' || $method=='unsubscribe' || $method=='update_unsubscribe'){
            redirect('/', 'refresh'); 
        }else{
           return true;
        }
     }
     else if(strtolower($controller)=='cronjob')
              {
                echo "sffvfhhfhs"; die;
                return true;
         
              }
     
    else{
       
        redirect('/', 'refresh');
    }
} else {
    return true;
}
?>