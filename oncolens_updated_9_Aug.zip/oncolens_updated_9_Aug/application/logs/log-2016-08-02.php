<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-02 00:44:15 --> 404 Page Not Found: Upcoming-in-person-tumor-boardshtml/index
ERROR - 2016-08-02 00:44:21 --> 404 Page Not Found: Upcoming-in-person-tumor-boardshtml/index
ERROR - 2016-08-02 00:44:23 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-08-02 05:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-02 18:40:21 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'bbcd59690ff64b0a92dd4fc2b37cada66a907e41', '/', 1470188421, '184.105.139.67', NULL, '')
