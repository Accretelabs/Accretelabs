<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-27 04:11:27 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '16bb9b60ac711d2009fbf555d947f63e7e4596b2', '/', 1469617887, '184.105.247.196', NULL, '')
ERROR - 2016-07-27 04:59:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 04:59:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 04:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 04:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 06:19:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 08:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 13:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 15:31:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 15:44:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 15:45:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 16:03:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-27 16:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 17:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 18:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 18:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 20:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-27 22:34:13 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '7916a3450135f996bae5d0be905498d086412993', '/', 1469684053, '184.105.139.68', NULL, '')
