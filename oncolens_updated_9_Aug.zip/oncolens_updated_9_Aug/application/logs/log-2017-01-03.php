<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-03 05:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-03 07:02:35 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-03 07:02:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-03 09:17:55 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-03 09:41:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-03 10:07:00 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-03 10:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-03 10:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-03 10:09:16 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-03 10:09:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-03 10:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-03 14:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-03 20:03:21 --> 404 Page Not Found: Robotstxt/index
