<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-03 16:02:42 --> Config Class Initialized
INFO - 2017-08-03 16:02:42 --> Hooks Class Initialized
DEBUG - 2017-08-03 16:02:42 --> UTF-8 Support Enabled
INFO - 2017-08-03 16:02:42 --> Utf8 Class Initialized
INFO - 2017-08-03 16:02:42 --> URI Class Initialized
INFO - 2017-08-03 16:02:42 --> Router Class Initialized
INFO - 2017-08-03 16:02:42 --> Output Class Initialized
INFO - 2017-08-03 16:02:42 --> Security Class Initialized
DEBUG - 2017-08-03 16:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 16:02:42 --> Input Class Initialized
INFO - 2017-08-03 16:02:42 --> Language Class Initialized
INFO - 2017-08-03 16:02:42 --> Loader Class Initialized
INFO - 2017-08-03 16:02:44 --> Helper loaded: url_helper
INFO - 2017-08-03 16:02:44 --> Helper loaded: form_helper
INFO - 2017-08-03 16:02:44 --> Helper loaded: security_helper
INFO - 2017-08-03 16:02:44 --> Helper loaded: path_helper
INFO - 2017-08-03 16:02:44 --> Helper loaded: common_helper
INFO - 2017-08-03 16:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 16:02:44 --> Helper loaded: check_session_helper
INFO - 2017-08-03 16:02:44 --> Database Driver Class Initialized
DEBUG - 2017-08-03 16:02:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 16:02:44 --> Email Class Initialized
INFO - 2017-08-03 16:02:44 --> Form Validation Class Initialized
INFO - 2017-08-03 16:02:44 --> Model Class Initialized
INFO - 2017-08-03 16:02:44 --> Model Class Initialized
INFO - 2017-08-03 16:02:44 --> Model Class Initialized
INFO - 2017-08-03 16:02:44 --> Model Class Initialized
INFO - 2017-08-03 16:02:44 --> Controller Class Initialized
INFO - 2017-08-03 16:02:44 --> Model Class Initialized
INFO - 2017-08-03 16:02:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-03 16:02:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-03 16:02:44 --> Final output sent to browser
DEBUG - 2017-08-03 16:02:44 --> Total execution time: 2.7899
DEBUG - 2017-08-03 16:02:44 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 16:02:45 --> Database Forge Class Initialized
INFO - 2017-08-03 16:02:45 --> User Agent Class Initialized
DEBUG - 2017-08-03 16:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 16:07:32 --> Config Class Initialized
INFO - 2017-08-03 16:07:32 --> Hooks Class Initialized
DEBUG - 2017-08-03 16:07:32 --> UTF-8 Support Enabled
INFO - 2017-08-03 16:07:32 --> Utf8 Class Initialized
INFO - 2017-08-03 16:07:32 --> URI Class Initialized
DEBUG - 2017-08-03 16:07:32 --> No URI present. Default controller set.
INFO - 2017-08-03 16:07:32 --> Router Class Initialized
INFO - 2017-08-03 16:07:32 --> Output Class Initialized
INFO - 2017-08-03 16:07:32 --> Security Class Initialized
DEBUG - 2017-08-03 16:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 16:07:32 --> Input Class Initialized
INFO - 2017-08-03 16:07:32 --> Language Class Initialized
INFO - 2017-08-03 16:07:32 --> Loader Class Initialized
INFO - 2017-08-03 16:07:32 --> Helper loaded: url_helper
INFO - 2017-08-03 16:07:32 --> Helper loaded: form_helper
INFO - 2017-08-03 16:07:32 --> Helper loaded: security_helper
INFO - 2017-08-03 16:07:32 --> Helper loaded: path_helper
INFO - 2017-08-03 16:07:32 --> Helper loaded: common_helper
INFO - 2017-08-03 16:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 16:07:32 --> Helper loaded: check_session_helper
INFO - 2017-08-03 16:07:32 --> Database Driver Class Initialized
DEBUG - 2017-08-03 16:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 16:07:32 --> Email Class Initialized
INFO - 2017-08-03 16:07:32 --> Form Validation Class Initialized
INFO - 2017-08-03 16:07:32 --> Model Class Initialized
INFO - 2017-08-03 16:07:32 --> Model Class Initialized
INFO - 2017-08-03 16:07:32 --> Model Class Initialized
INFO - 2017-08-03 16:07:32 --> Model Class Initialized
INFO - 2017-08-03 16:07:32 --> Controller Class Initialized
DEBUG - 2017-08-03 16:07:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 16:07:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-03 16:07:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-03 16:07:32 --> Final output sent to browser
DEBUG - 2017-08-03 16:07:32 --> Total execution time: 0.1607
DEBUG - 2017-08-03 16:07:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 16:07:32 --> Database Forge Class Initialized
INFO - 2017-08-03 16:07:32 --> User Agent Class Initialized
DEBUG - 2017-08-03 16:07:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:00 --> Config Class Initialized
INFO - 2017-08-03 17:46:00 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:46:00 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:46:00 --> Utf8 Class Initialized
INFO - 2017-08-03 17:46:00 --> URI Class Initialized
DEBUG - 2017-08-03 17:46:00 --> No URI present. Default controller set.
INFO - 2017-08-03 17:46:00 --> Router Class Initialized
INFO - 2017-08-03 17:46:00 --> Output Class Initialized
INFO - 2017-08-03 17:46:00 --> Security Class Initialized
DEBUG - 2017-08-03 17:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:46:00 --> Input Class Initialized
INFO - 2017-08-03 17:46:00 --> Language Class Initialized
INFO - 2017-08-03 17:46:00 --> Loader Class Initialized
INFO - 2017-08-03 17:46:00 --> Helper loaded: url_helper
INFO - 2017-08-03 17:46:00 --> Helper loaded: form_helper
INFO - 2017-08-03 17:46:00 --> Helper loaded: security_helper
INFO - 2017-08-03 17:46:00 --> Helper loaded: path_helper
INFO - 2017-08-03 17:46:00 --> Helper loaded: common_helper
INFO - 2017-08-03 17:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:46:01 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:46:01 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:01 --> Email Class Initialized
INFO - 2017-08-03 17:46:01 --> Form Validation Class Initialized
INFO - 2017-08-03 17:46:01 --> Model Class Initialized
INFO - 2017-08-03 17:46:01 --> Model Class Initialized
INFO - 2017-08-03 17:46:01 --> Model Class Initialized
INFO - 2017-08-03 17:46:01 --> Model Class Initialized
INFO - 2017-08-03 17:46:01 --> Controller Class Initialized
DEBUG - 2017-08-03 17:46:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-03 17:46:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-03 17:46:01 --> Final output sent to browser
DEBUG - 2017-08-03 17:46:01 --> Total execution time: 0.3579
DEBUG - 2017-08-03 17:46:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:46:01 --> Database Forge Class Initialized
INFO - 2017-08-03 17:46:01 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:46:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:53 --> Config Class Initialized
INFO - 2017-08-03 17:46:53 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:46:53 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:46:53 --> Utf8 Class Initialized
INFO - 2017-08-03 17:46:53 --> URI Class Initialized
DEBUG - 2017-08-03 17:46:53 --> No URI present. Default controller set.
INFO - 2017-08-03 17:46:53 --> Router Class Initialized
INFO - 2017-08-03 17:46:53 --> Output Class Initialized
INFO - 2017-08-03 17:46:53 --> Security Class Initialized
DEBUG - 2017-08-03 17:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:46:53 --> Input Class Initialized
INFO - 2017-08-03 17:46:53 --> Language Class Initialized
INFO - 2017-08-03 17:46:53 --> Loader Class Initialized
INFO - 2017-08-03 17:46:53 --> Helper loaded: url_helper
INFO - 2017-08-03 17:46:53 --> Helper loaded: form_helper
INFO - 2017-08-03 17:46:53 --> Helper loaded: security_helper
INFO - 2017-08-03 17:46:53 --> Helper loaded: path_helper
INFO - 2017-08-03 17:46:53 --> Helper loaded: common_helper
INFO - 2017-08-03 17:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:46:53 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:46:53 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:53 --> Email Class Initialized
INFO - 2017-08-03 17:46:53 --> Form Validation Class Initialized
INFO - 2017-08-03 17:46:53 --> Model Class Initialized
INFO - 2017-08-03 17:46:53 --> Model Class Initialized
INFO - 2017-08-03 17:46:53 --> Model Class Initialized
INFO - 2017-08-03 17:46:53 --> Model Class Initialized
INFO - 2017-08-03 17:46:53 --> Controller Class Initialized
DEBUG - 2017-08-03 17:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:46:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-03 17:46:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-03 17:46:53 --> Final output sent to browser
DEBUG - 2017-08-03 17:46:53 --> Total execution time: 0.0285
DEBUG - 2017-08-03 17:46:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:46:53 --> Database Forge Class Initialized
INFO - 2017-08-03 17:46:53 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:46:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:47:57 --> Config Class Initialized
INFO - 2017-08-03 17:47:57 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:47:57 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:47:57 --> Utf8 Class Initialized
INFO - 2017-08-03 17:47:57 --> URI Class Initialized
INFO - 2017-08-03 17:47:57 --> Router Class Initialized
INFO - 2017-08-03 17:47:57 --> Output Class Initialized
INFO - 2017-08-03 17:47:57 --> Security Class Initialized
DEBUG - 2017-08-03 17:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:47:57 --> Input Class Initialized
INFO - 2017-08-03 17:47:57 --> Language Class Initialized
INFO - 2017-08-03 17:47:57 --> Loader Class Initialized
INFO - 2017-08-03 17:47:57 --> Helper loaded: url_helper
INFO - 2017-08-03 17:47:57 --> Helper loaded: form_helper
INFO - 2017-08-03 17:47:57 --> Helper loaded: security_helper
INFO - 2017-08-03 17:47:57 --> Helper loaded: path_helper
INFO - 2017-08-03 17:47:57 --> Helper loaded: common_helper
INFO - 2017-08-03 17:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:47:57 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:47:57 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:47:57 --> Email Class Initialized
INFO - 2017-08-03 17:47:57 --> Form Validation Class Initialized
INFO - 2017-08-03 17:47:57 --> Model Class Initialized
INFO - 2017-08-03 17:47:57 --> Model Class Initialized
INFO - 2017-08-03 17:47:57 --> Model Class Initialized
INFO - 2017-08-03 17:47:57 --> Model Class Initialized
INFO - 2017-08-03 17:47:57 --> Controller Class Initialized
INFO - 2017-08-03 17:47:57 --> Model Class Initialized
INFO - 2017-08-03 17:47:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-03 17:47:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-03 17:47:57 --> Final output sent to browser
DEBUG - 2017-08-03 17:47:57 --> Total execution time: 0.0440
DEBUG - 2017-08-03 17:47:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:47:57 --> Database Forge Class Initialized
INFO - 2017-08-03 17:47:57 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:47:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:48:08 --> Config Class Initialized
INFO - 2017-08-03 17:48:08 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:48:08 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:48:08 --> Utf8 Class Initialized
INFO - 2017-08-03 17:48:08 --> URI Class Initialized
INFO - 2017-08-03 17:48:08 --> Router Class Initialized
INFO - 2017-08-03 17:48:08 --> Output Class Initialized
INFO - 2017-08-03 17:48:08 --> Security Class Initialized
DEBUG - 2017-08-03 17:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:48:08 --> Input Class Initialized
INFO - 2017-08-03 17:48:08 --> Language Class Initialized
ERROR - 2017-08-03 17:48:08 --> 404 Page Not Found: Page/assets
INFO - 2017-08-03 17:54:28 --> Config Class Initialized
INFO - 2017-08-03 17:54:28 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:54:28 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:54:28 --> Utf8 Class Initialized
INFO - 2017-08-03 17:54:28 --> URI Class Initialized
INFO - 2017-08-03 17:54:28 --> Router Class Initialized
INFO - 2017-08-03 17:54:28 --> Output Class Initialized
INFO - 2017-08-03 17:54:28 --> Security Class Initialized
DEBUG - 2017-08-03 17:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:54:28 --> Input Class Initialized
INFO - 2017-08-03 17:54:28 --> Language Class Initialized
INFO - 2017-08-03 17:54:28 --> Loader Class Initialized
INFO - 2017-08-03 17:54:28 --> Helper loaded: url_helper
INFO - 2017-08-03 17:54:28 --> Helper loaded: form_helper
INFO - 2017-08-03 17:54:28 --> Helper loaded: security_helper
INFO - 2017-08-03 17:54:28 --> Helper loaded: path_helper
INFO - 2017-08-03 17:54:28 --> Helper loaded: common_helper
INFO - 2017-08-03 17:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:54:28 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:54:28 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:28 --> Email Class Initialized
INFO - 2017-08-03 17:54:28 --> Form Validation Class Initialized
INFO - 2017-08-03 17:54:28 --> Model Class Initialized
INFO - 2017-08-03 17:54:28 --> Model Class Initialized
INFO - 2017-08-03 17:54:28 --> Model Class Initialized
INFO - 2017-08-03 17:54:28 --> Model Class Initialized
INFO - 2017-08-03 17:54:28 --> Controller Class Initialized
INFO - 2017-08-03 17:54:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-03 17:54:28 --> Final output sent to browser
DEBUG - 2017-08-03 17:54:28 --> Total execution time: 0.0444
DEBUG - 2017-08-03 17:54:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:54:28 --> Database Forge Class Initialized
INFO - 2017-08-03 17:54:28 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:30 --> Config Class Initialized
INFO - 2017-08-03 17:54:30 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:54:30 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:54:30 --> Utf8 Class Initialized
INFO - 2017-08-03 17:54:30 --> URI Class Initialized
INFO - 2017-08-03 17:54:30 --> Router Class Initialized
INFO - 2017-08-03 17:54:30 --> Output Class Initialized
INFO - 2017-08-03 17:54:30 --> Security Class Initialized
DEBUG - 2017-08-03 17:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:54:30 --> Input Class Initialized
INFO - 2017-08-03 17:54:30 --> Language Class Initialized
ERROR - 2017-08-03 17:54:30 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-03 17:54:31 --> Config Class Initialized
INFO - 2017-08-03 17:54:31 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:54:31 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:54:31 --> Utf8 Class Initialized
INFO - 2017-08-03 17:54:31 --> URI Class Initialized
INFO - 2017-08-03 17:54:31 --> Router Class Initialized
INFO - 2017-08-03 17:54:31 --> Output Class Initialized
INFO - 2017-08-03 17:54:31 --> Security Class Initialized
DEBUG - 2017-08-03 17:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:54:31 --> Input Class Initialized
INFO - 2017-08-03 17:54:31 --> Language Class Initialized
INFO - 2017-08-03 17:54:31 --> Loader Class Initialized
INFO - 2017-08-03 17:54:31 --> Helper loaded: url_helper
INFO - 2017-08-03 17:54:31 --> Helper loaded: form_helper
INFO - 2017-08-03 17:54:31 --> Helper loaded: security_helper
INFO - 2017-08-03 17:54:31 --> Helper loaded: path_helper
INFO - 2017-08-03 17:54:31 --> Helper loaded: common_helper
INFO - 2017-08-03 17:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:54:31 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:54:31 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:31 --> Email Class Initialized
INFO - 2017-08-03 17:54:31 --> Form Validation Class Initialized
INFO - 2017-08-03 17:54:31 --> Model Class Initialized
INFO - 2017-08-03 17:54:31 --> Model Class Initialized
INFO - 2017-08-03 17:54:31 --> Model Class Initialized
INFO - 2017-08-03 17:54:31 --> Model Class Initialized
INFO - 2017-08-03 17:54:31 --> Controller Class Initialized
INFO - 2017-08-03 17:54:32 --> Config Class Initialized
INFO - 2017-08-03 17:54:32 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:54:32 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:54:32 --> Utf8 Class Initialized
INFO - 2017-08-03 17:54:32 --> URI Class Initialized
INFO - 2017-08-03 17:54:32 --> Router Class Initialized
INFO - 2017-08-03 17:54:32 --> Output Class Initialized
INFO - 2017-08-03 17:54:32 --> Security Class Initialized
DEBUG - 2017-08-03 17:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:54:32 --> Input Class Initialized
INFO - 2017-08-03 17:54:32 --> Language Class Initialized
INFO - 2017-08-03 17:54:32 --> Loader Class Initialized
INFO - 2017-08-03 17:54:32 --> Helper loaded: url_helper
INFO - 2017-08-03 17:54:32 --> Helper loaded: form_helper
INFO - 2017-08-03 17:54:32 --> Helper loaded: security_helper
INFO - 2017-08-03 17:54:32 --> Helper loaded: path_helper
INFO - 2017-08-03 17:54:32 --> Helper loaded: common_helper
INFO - 2017-08-03 17:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:54:32 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:54:32 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:32 --> Email Class Initialized
INFO - 2017-08-03 17:54:32 --> Form Validation Class Initialized
INFO - 2017-08-03 17:54:32 --> Model Class Initialized
INFO - 2017-08-03 17:54:32 --> Model Class Initialized
INFO - 2017-08-03 17:54:32 --> Model Class Initialized
INFO - 2017-08-03 17:54:32 --> Model Class Initialized
INFO - 2017-08-03 17:54:32 --> Controller Class Initialized
INFO - 2017-08-03 17:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:54:32 --> Pagination Class Initialized
INFO - 2017-08-03 17:54:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:54:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:54:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:54:32 --> Final output sent to browser
DEBUG - 2017-08-03 17:54:32 --> Total execution time: 0.2019
DEBUG - 2017-08-03 17:54:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:54:32 --> Database Forge Class Initialized
INFO - 2017-08-03 17:54:32 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:42 --> Config Class Initialized
INFO - 2017-08-03 17:54:42 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:54:42 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:54:42 --> Utf8 Class Initialized
INFO - 2017-08-03 17:54:42 --> URI Class Initialized
INFO - 2017-08-03 17:54:42 --> Router Class Initialized
INFO - 2017-08-03 17:54:42 --> Output Class Initialized
INFO - 2017-08-03 17:54:42 --> Security Class Initialized
DEBUG - 2017-08-03 17:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:54:42 --> Input Class Initialized
INFO - 2017-08-03 17:54:42 --> Language Class Initialized
INFO - 2017-08-03 17:54:42 --> Loader Class Initialized
INFO - 2017-08-03 17:54:42 --> Helper loaded: url_helper
INFO - 2017-08-03 17:54:42 --> Helper loaded: form_helper
INFO - 2017-08-03 17:54:42 --> Helper loaded: security_helper
INFO - 2017-08-03 17:54:42 --> Helper loaded: path_helper
INFO - 2017-08-03 17:54:42 --> Helper loaded: common_helper
INFO - 2017-08-03 17:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:54:42 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:54:42 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:42 --> Email Class Initialized
INFO - 2017-08-03 17:54:42 --> Form Validation Class Initialized
INFO - 2017-08-03 17:54:42 --> Model Class Initialized
INFO - 2017-08-03 17:54:42 --> Model Class Initialized
INFO - 2017-08-03 17:54:42 --> Model Class Initialized
INFO - 2017-08-03 17:54:42 --> Model Class Initialized
INFO - 2017-08-03 17:54:42 --> Controller Class Initialized
DEBUG - 2017-08-03 17:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:54:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:54:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-03 17:54:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:54:42 --> Final output sent to browser
DEBUG - 2017-08-03 17:54:42 --> Total execution time: 0.0862
DEBUG - 2017-08-03 17:54:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:54:42 --> Database Forge Class Initialized
INFO - 2017-08-03 17:54:42 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:54:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:09 --> Config Class Initialized
INFO - 2017-08-03 17:55:09 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:09 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:09 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:09 --> URI Class Initialized
INFO - 2017-08-03 17:55:09 --> Router Class Initialized
INFO - 2017-08-03 17:55:09 --> Output Class Initialized
INFO - 2017-08-03 17:55:09 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:09 --> Input Class Initialized
INFO - 2017-08-03 17:55:09 --> Language Class Initialized
INFO - 2017-08-03 17:55:09 --> Loader Class Initialized
INFO - 2017-08-03 17:55:09 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:09 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:09 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:09 --> Email Class Initialized
INFO - 2017-08-03 17:55:09 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Controller Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-03 17:55:09 --> Config Class Initialized
INFO - 2017-08-03 17:55:09 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:09 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:09 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:09 --> URI Class Initialized
INFO - 2017-08-03 17:55:09 --> Router Class Initialized
INFO - 2017-08-03 17:55:09 --> Output Class Initialized
INFO - 2017-08-03 17:55:09 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:09 --> Input Class Initialized
INFO - 2017-08-03 17:55:09 --> Language Class Initialized
INFO - 2017-08-03 17:55:09 --> Loader Class Initialized
INFO - 2017-08-03 17:55:09 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:09 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:09 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:09 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:09 --> Email Class Initialized
INFO - 2017-08-03 17:55:09 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Model Class Initialized
INFO - 2017-08-03 17:55:09 --> Controller Class Initialized
INFO - 2017-08-03 17:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:55:09 --> Pagination Class Initialized
INFO - 2017-08-03 17:55:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:55:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:09 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:09 --> Total execution time: 0.0342
DEBUG - 2017-08-03 17:55:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:09 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:09 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:14 --> Config Class Initialized
INFO - 2017-08-03 17:55:14 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:14 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:14 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:14 --> URI Class Initialized
INFO - 2017-08-03 17:55:14 --> Router Class Initialized
INFO - 2017-08-03 17:55:14 --> Output Class Initialized
INFO - 2017-08-03 17:55:14 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:14 --> Input Class Initialized
INFO - 2017-08-03 17:55:14 --> Language Class Initialized
INFO - 2017-08-03 17:55:14 --> Loader Class Initialized
INFO - 2017-08-03 17:55:14 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:14 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:14 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:14 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:14 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:14 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:14 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:14 --> Email Class Initialized
INFO - 2017-08-03 17:55:14 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:14 --> Model Class Initialized
INFO - 2017-08-03 17:55:14 --> Model Class Initialized
INFO - 2017-08-03 17:55:14 --> Model Class Initialized
INFO - 2017-08-03 17:55:14 --> Model Class Initialized
INFO - 2017-08-03 17:55:14 --> Controller Class Initialized
DEBUG - 2017-08-03 17:55:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-03 17:55:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:14 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:14 --> Total execution time: 0.0308
DEBUG - 2017-08-03 17:55:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:14 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:14 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:24 --> Config Class Initialized
INFO - 2017-08-03 17:55:24 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:24 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:24 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:24 --> URI Class Initialized
INFO - 2017-08-03 17:55:24 --> Router Class Initialized
INFO - 2017-08-03 17:55:24 --> Output Class Initialized
INFO - 2017-08-03 17:55:24 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:24 --> Input Class Initialized
INFO - 2017-08-03 17:55:24 --> Language Class Initialized
INFO - 2017-08-03 17:55:24 --> Loader Class Initialized
INFO - 2017-08-03 17:55:24 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:24 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:24 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:24 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:24 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:24 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:24 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:24 --> Email Class Initialized
INFO - 2017-08-03 17:55:24 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:24 --> Model Class Initialized
INFO - 2017-08-03 17:55:24 --> Model Class Initialized
INFO - 2017-08-03 17:55:24 --> Model Class Initialized
INFO - 2017-08-03 17:55:24 --> Model Class Initialized
INFO - 2017-08-03 17:55:24 --> Controller Class Initialized
DEBUG - 2017-08-03 17:55:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-03 17:55:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:24 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:24 --> Total execution time: 0.0286
DEBUG - 2017-08-03 17:55:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:24 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:24 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:43 --> Config Class Initialized
INFO - 2017-08-03 17:55:43 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:43 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:43 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:43 --> URI Class Initialized
INFO - 2017-08-03 17:55:43 --> Router Class Initialized
INFO - 2017-08-03 17:55:43 --> Output Class Initialized
INFO - 2017-08-03 17:55:43 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:43 --> Input Class Initialized
INFO - 2017-08-03 17:55:43 --> Language Class Initialized
INFO - 2017-08-03 17:55:43 --> Loader Class Initialized
INFO - 2017-08-03 17:55:43 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:43 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:43 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:43 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:43 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:43 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:43 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:43 --> Email Class Initialized
INFO - 2017-08-03 17:55:43 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:43 --> Model Class Initialized
INFO - 2017-08-03 17:55:43 --> Model Class Initialized
INFO - 2017-08-03 17:55:43 --> Model Class Initialized
INFO - 2017-08-03 17:55:43 --> Model Class Initialized
INFO - 2017-08-03 17:55:43 --> Controller Class Initialized
INFO - 2017-08-03 17:55:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/usertrackingbackup.php
INFO - 2017-08-03 17:55:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:43 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:43 --> Total execution time: 0.0287
DEBUG - 2017-08-03 17:55:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:43 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:43 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:48 --> Config Class Initialized
INFO - 2017-08-03 17:55:48 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:48 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:48 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:48 --> URI Class Initialized
INFO - 2017-08-03 17:55:48 --> Router Class Initialized
INFO - 2017-08-03 17:55:48 --> Output Class Initialized
INFO - 2017-08-03 17:55:48 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:48 --> Input Class Initialized
INFO - 2017-08-03 17:55:48 --> Language Class Initialized
INFO - 2017-08-03 17:55:48 --> Loader Class Initialized
INFO - 2017-08-03 17:55:48 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:48 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:48 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:48 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:48 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:48 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:48 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:48 --> Email Class Initialized
INFO - 2017-08-03 17:55:48 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:48 --> Model Class Initialized
INFO - 2017-08-03 17:55:48 --> Model Class Initialized
INFO - 2017-08-03 17:55:48 --> Model Class Initialized
INFO - 2017-08-03 17:55:48 --> Model Class Initialized
INFO - 2017-08-03 17:55:48 --> Controller Class Initialized
INFO - 2017-08-03 17:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:55:48 --> Pagination Class Initialized
INFO - 2017-08-03 17:55:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:55:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:48 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:48 --> Total execution time: 0.0312
DEBUG - 2017-08-03 17:55:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:48 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:48 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:57 --> Config Class Initialized
INFO - 2017-08-03 17:55:57 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:55:57 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:55:57 --> Utf8 Class Initialized
INFO - 2017-08-03 17:55:57 --> URI Class Initialized
INFO - 2017-08-03 17:55:57 --> Router Class Initialized
INFO - 2017-08-03 17:55:57 --> Output Class Initialized
INFO - 2017-08-03 17:55:57 --> Security Class Initialized
DEBUG - 2017-08-03 17:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:55:57 --> Input Class Initialized
INFO - 2017-08-03 17:55:57 --> Language Class Initialized
INFO - 2017-08-03 17:55:57 --> Loader Class Initialized
INFO - 2017-08-03 17:55:57 --> Helper loaded: url_helper
INFO - 2017-08-03 17:55:57 --> Helper loaded: form_helper
INFO - 2017-08-03 17:55:57 --> Helper loaded: security_helper
INFO - 2017-08-03 17:55:57 --> Helper loaded: path_helper
INFO - 2017-08-03 17:55:57 --> Helper loaded: common_helper
INFO - 2017-08-03 17:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:55:57 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:55:57 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:55:57 --> Email Class Initialized
INFO - 2017-08-03 17:55:57 --> Form Validation Class Initialized
INFO - 2017-08-03 17:55:57 --> Model Class Initialized
INFO - 2017-08-03 17:55:57 --> Model Class Initialized
INFO - 2017-08-03 17:55:57 --> Model Class Initialized
INFO - 2017-08-03 17:55:57 --> Model Class Initialized
INFO - 2017-08-03 17:55:57 --> Controller Class Initialized
INFO - 2017-08-03 17:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:55:57 --> Pagination Class Initialized
INFO - 2017-08-03 17:55:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:55:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/logging_details.php
INFO - 2017-08-03 17:55:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:55:57 --> Final output sent to browser
DEBUG - 2017-08-03 17:55:57 --> Total execution time: 0.0408
DEBUG - 2017-08-03 17:55:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:55:57 --> Database Forge Class Initialized
INFO - 2017-08-03 17:55:57 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:24 --> Config Class Initialized
INFO - 2017-08-03 17:56:24 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:24 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:24 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:24 --> URI Class Initialized
INFO - 2017-08-03 17:56:24 --> Router Class Initialized
INFO - 2017-08-03 17:56:24 --> Output Class Initialized
INFO - 2017-08-03 17:56:24 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:24 --> Input Class Initialized
INFO - 2017-08-03 17:56:24 --> Language Class Initialized
INFO - 2017-08-03 17:56:24 --> Loader Class Initialized
INFO - 2017-08-03 17:56:24 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:24 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:24 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:24 --> Email Class Initialized
INFO - 2017-08-03 17:56:24 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Controller Class Initialized
INFO - 2017-08-03 17:56:24 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:24 --> Total execution time: 0.0287
DEBUG - 2017-08-03 17:56:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:24 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:24 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:24 --> Config Class Initialized
INFO - 2017-08-03 17:56:24 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:24 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:24 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:24 --> URI Class Initialized
INFO - 2017-08-03 17:56:24 --> Router Class Initialized
INFO - 2017-08-03 17:56:24 --> Output Class Initialized
INFO - 2017-08-03 17:56:24 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:24 --> Input Class Initialized
INFO - 2017-08-03 17:56:24 --> Language Class Initialized
INFO - 2017-08-03 17:56:24 --> Loader Class Initialized
INFO - 2017-08-03 17:56:24 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:24 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:24 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:24 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:24 --> Email Class Initialized
INFO - 2017-08-03 17:56:24 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Model Class Initialized
INFO - 2017-08-03 17:56:24 --> Controller Class Initialized
INFO - 2017-08-03 17:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:56:24 --> Pagination Class Initialized
INFO - 2017-08-03 17:56:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:56:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:56:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:56:24 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:24 --> Total execution time: 0.0291
DEBUG - 2017-08-03 17:56:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:24 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:24 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:29 --> Config Class Initialized
INFO - 2017-08-03 17:56:29 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:29 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:29 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:29 --> URI Class Initialized
INFO - 2017-08-03 17:56:29 --> Router Class Initialized
INFO - 2017-08-03 17:56:29 --> Output Class Initialized
INFO - 2017-08-03 17:56:29 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:29 --> Input Class Initialized
INFO - 2017-08-03 17:56:29 --> Language Class Initialized
INFO - 2017-08-03 17:56:29 --> Loader Class Initialized
INFO - 2017-08-03 17:56:29 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:29 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:29 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:29 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:29 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:29 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:29 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:29 --> Email Class Initialized
INFO - 2017-08-03 17:56:29 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:29 --> Model Class Initialized
INFO - 2017-08-03 17:56:29 --> Model Class Initialized
INFO - 2017-08-03 17:56:29 --> Model Class Initialized
INFO - 2017-08-03 17:56:29 --> Model Class Initialized
INFO - 2017-08-03 17:56:29 --> Controller Class Initialized
INFO - 2017-08-03 17:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:56:29 --> Pagination Class Initialized
INFO - 2017-08-03 17:56:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:56:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-08-03 17:56:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:56:30 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:30 --> Total execution time: 0.0697
DEBUG - 2017-08-03 17:56:30 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:30 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:30 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:42 --> Config Class Initialized
INFO - 2017-08-03 17:56:42 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:42 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:42 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:42 --> URI Class Initialized
INFO - 2017-08-03 17:56:42 --> Router Class Initialized
INFO - 2017-08-03 17:56:42 --> Output Class Initialized
INFO - 2017-08-03 17:56:42 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:42 --> Input Class Initialized
INFO - 2017-08-03 17:56:42 --> Language Class Initialized
INFO - 2017-08-03 17:56:42 --> Loader Class Initialized
INFO - 2017-08-03 17:56:42 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:42 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:42 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:42 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:42 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:42 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:42 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:42 --> Email Class Initialized
INFO - 2017-08-03 17:56:42 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:42 --> Model Class Initialized
INFO - 2017-08-03 17:56:42 --> Model Class Initialized
INFO - 2017-08-03 17:56:42 --> Model Class Initialized
INFO - 2017-08-03 17:56:42 --> Model Class Initialized
INFO - 2017-08-03 17:56:42 --> Controller Class Initialized
INFO - 2017-08-03 17:56:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:56:42 --> Pagination Class Initialized
INFO - 2017-08-03 17:56:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:56:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:56:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:56:42 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:42 --> Total execution time: 0.0280
DEBUG - 2017-08-03 17:56:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:42 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:42 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:45 --> Config Class Initialized
INFO - 2017-08-03 17:56:45 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:45 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:45 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:45 --> URI Class Initialized
INFO - 2017-08-03 17:56:45 --> Router Class Initialized
INFO - 2017-08-03 17:56:45 --> Output Class Initialized
INFO - 2017-08-03 17:56:45 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:45 --> Input Class Initialized
INFO - 2017-08-03 17:56:45 --> Language Class Initialized
INFO - 2017-08-03 17:56:45 --> Loader Class Initialized
INFO - 2017-08-03 17:56:45 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:45 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:45 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:45 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:45 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:45 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:45 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:45 --> Email Class Initialized
INFO - 2017-08-03 17:56:45 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:45 --> Model Class Initialized
INFO - 2017-08-03 17:56:45 --> Model Class Initialized
INFO - 2017-08-03 17:56:45 --> Model Class Initialized
INFO - 2017-08-03 17:56:45 --> Model Class Initialized
INFO - 2017-08-03 17:56:45 --> Controller Class Initialized
DEBUG - 2017-08-03 17:56:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:56:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-03 17:56:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:56:45 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:45 --> Total execution time: 0.0294
DEBUG - 2017-08-03 17:56:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:45 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:45 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:57 --> Config Class Initialized
INFO - 2017-08-03 17:56:57 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:56:57 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:56:57 --> Utf8 Class Initialized
INFO - 2017-08-03 17:56:57 --> URI Class Initialized
INFO - 2017-08-03 17:56:57 --> Router Class Initialized
INFO - 2017-08-03 17:56:57 --> Output Class Initialized
INFO - 2017-08-03 17:56:57 --> Security Class Initialized
DEBUG - 2017-08-03 17:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:56:57 --> Input Class Initialized
INFO - 2017-08-03 17:56:57 --> Language Class Initialized
INFO - 2017-08-03 17:56:57 --> Loader Class Initialized
INFO - 2017-08-03 17:56:57 --> Helper loaded: url_helper
INFO - 2017-08-03 17:56:57 --> Helper loaded: form_helper
INFO - 2017-08-03 17:56:57 --> Helper loaded: security_helper
INFO - 2017-08-03 17:56:57 --> Helper loaded: path_helper
INFO - 2017-08-03 17:56:57 --> Helper loaded: common_helper
INFO - 2017-08-03 17:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:56:57 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:56:57 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:56:57 --> Email Class Initialized
INFO - 2017-08-03 17:56:57 --> Form Validation Class Initialized
INFO - 2017-08-03 17:56:57 --> Model Class Initialized
INFO - 2017-08-03 17:56:57 --> Model Class Initialized
INFO - 2017-08-03 17:56:57 --> Model Class Initialized
INFO - 2017-08-03 17:56:57 --> Model Class Initialized
INFO - 2017-08-03 17:56:57 --> Controller Class Initialized
INFO - 2017-08-03 17:56:57 --> Final output sent to browser
DEBUG - 2017-08-03 17:56:57 --> Total execution time: 0.0265
DEBUG - 2017-08-03 17:56:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:56:57 --> Database Forge Class Initialized
INFO - 2017-08-03 17:56:57 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:21 --> Config Class Initialized
INFO - 2017-08-03 17:57:21 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:57:21 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:57:21 --> Utf8 Class Initialized
INFO - 2017-08-03 17:57:21 --> URI Class Initialized
INFO - 2017-08-03 17:57:21 --> Router Class Initialized
INFO - 2017-08-03 17:57:21 --> Output Class Initialized
INFO - 2017-08-03 17:57:21 --> Security Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:57:21 --> Input Class Initialized
INFO - 2017-08-03 17:57:21 --> Language Class Initialized
INFO - 2017-08-03 17:57:21 --> Loader Class Initialized
INFO - 2017-08-03 17:57:21 --> Helper loaded: url_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: form_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: security_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: path_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: common_helper
INFO - 2017-08-03 17:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:57:21 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:57:21 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:21 --> Email Class Initialized
INFO - 2017-08-03 17:57:21 --> Form Validation Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Controller Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-03 17:57:21 --> Severity: Warning --> is_readable(): open_basedir restriction in effect. File(/dev/urandom) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/libraries/Bcrypt.php 88
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Config Class Initialized
INFO - 2017-08-03 17:57:21 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:57:21 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:57:21 --> Utf8 Class Initialized
INFO - 2017-08-03 17:57:21 --> URI Class Initialized
INFO - 2017-08-03 17:57:21 --> Router Class Initialized
INFO - 2017-08-03 17:57:21 --> Output Class Initialized
INFO - 2017-08-03 17:57:21 --> Security Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:57:21 --> Input Class Initialized
INFO - 2017-08-03 17:57:21 --> Language Class Initialized
INFO - 2017-08-03 17:57:21 --> Loader Class Initialized
INFO - 2017-08-03 17:57:21 --> Helper loaded: url_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: form_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: security_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: path_helper
INFO - 2017-08-03 17:57:21 --> Helper loaded: common_helper
INFO - 2017-08-03 17:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:57:21 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:57:21 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:21 --> Email Class Initialized
INFO - 2017-08-03 17:57:21 --> Form Validation Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Model Class Initialized
INFO - 2017-08-03 17:57:21 --> Controller Class Initialized
INFO - 2017-08-03 17:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-03 17:57:21 --> Pagination Class Initialized
INFO - 2017-08-03 17:57:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:57:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-03 17:57:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:57:21 --> Final output sent to browser
DEBUG - 2017-08-03 17:57:21 --> Total execution time: 0.0276
DEBUG - 2017-08-03 17:57:21 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:57:21 --> Database Forge Class Initialized
INFO - 2017-08-03 17:57:21 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:57:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:28 --> Config Class Initialized
INFO - 2017-08-03 17:57:28 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:57:28 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:57:28 --> Utf8 Class Initialized
INFO - 2017-08-03 17:57:28 --> URI Class Initialized
INFO - 2017-08-03 17:57:28 --> Router Class Initialized
INFO - 2017-08-03 17:57:28 --> Output Class Initialized
INFO - 2017-08-03 17:57:28 --> Security Class Initialized
DEBUG - 2017-08-03 17:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:57:28 --> Input Class Initialized
INFO - 2017-08-03 17:57:28 --> Language Class Initialized
INFO - 2017-08-03 17:57:28 --> Loader Class Initialized
INFO - 2017-08-03 17:57:28 --> Helper loaded: url_helper
INFO - 2017-08-03 17:57:28 --> Helper loaded: form_helper
INFO - 2017-08-03 17:57:28 --> Helper loaded: security_helper
INFO - 2017-08-03 17:57:28 --> Helper loaded: path_helper
INFO - 2017-08-03 17:57:28 --> Helper loaded: common_helper
INFO - 2017-08-03 17:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:57:28 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:57:28 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:28 --> Email Class Initialized
INFO - 2017-08-03 17:57:28 --> Form Validation Class Initialized
INFO - 2017-08-03 17:57:28 --> Model Class Initialized
INFO - 2017-08-03 17:57:28 --> Model Class Initialized
INFO - 2017-08-03 17:57:28 --> Model Class Initialized
INFO - 2017-08-03 17:57:28 --> Model Class Initialized
INFO - 2017-08-03 17:57:28 --> Controller Class Initialized
INFO - 2017-08-03 17:57:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:57:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-03 17:57:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:57:28 --> Final output sent to browser
DEBUG - 2017-08-03 17:57:28 --> Total execution time: 0.0276
DEBUG - 2017-08-03 17:57:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:57:28 --> Database Forge Class Initialized
INFO - 2017-08-03 17:57:28 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:39 --> Config Class Initialized
INFO - 2017-08-03 17:57:39 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:57:39 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:57:39 --> Utf8 Class Initialized
INFO - 2017-08-03 17:57:39 --> URI Class Initialized
INFO - 2017-08-03 17:57:39 --> Router Class Initialized
INFO - 2017-08-03 17:57:39 --> Output Class Initialized
INFO - 2017-08-03 17:57:39 --> Security Class Initialized
DEBUG - 2017-08-03 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:57:39 --> Input Class Initialized
INFO - 2017-08-03 17:57:39 --> Language Class Initialized
INFO - 2017-08-03 17:57:39 --> Loader Class Initialized
INFO - 2017-08-03 17:57:39 --> Helper loaded: url_helper
INFO - 2017-08-03 17:57:39 --> Helper loaded: form_helper
INFO - 2017-08-03 17:57:39 --> Helper loaded: security_helper
INFO - 2017-08-03 17:57:39 --> Helper loaded: path_helper
INFO - 2017-08-03 17:57:39 --> Helper loaded: common_helper
INFO - 2017-08-03 17:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:57:39 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:57:39 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:39 --> Email Class Initialized
INFO - 2017-08-03 17:57:39 --> Form Validation Class Initialized
INFO - 2017-08-03 17:57:39 --> Model Class Initialized
INFO - 2017-08-03 17:57:39 --> Model Class Initialized
INFO - 2017-08-03 17:57:39 --> Model Class Initialized
INFO - 2017-08-03 17:57:39 --> Model Class Initialized
INFO - 2017-08-03 17:57:39 --> Controller Class Initialized
DEBUG - 2017-08-03 17:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:57:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:57:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 17:57:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:57:39 --> Final output sent to browser
DEBUG - 2017-08-03 17:57:39 --> Total execution time: 0.0470
DEBUG - 2017-08-03 17:57:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:57:39 --> Database Forge Class Initialized
INFO - 2017-08-03 17:57:39 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:57:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:58:29 --> Config Class Initialized
INFO - 2017-08-03 17:58:29 --> Hooks Class Initialized
DEBUG - 2017-08-03 17:58:29 --> UTF-8 Support Enabled
INFO - 2017-08-03 17:58:29 --> Utf8 Class Initialized
INFO - 2017-08-03 17:58:29 --> URI Class Initialized
INFO - 2017-08-03 17:58:29 --> Router Class Initialized
INFO - 2017-08-03 17:58:29 --> Output Class Initialized
INFO - 2017-08-03 17:58:29 --> Security Class Initialized
DEBUG - 2017-08-03 17:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 17:58:29 --> Input Class Initialized
INFO - 2017-08-03 17:58:29 --> Language Class Initialized
INFO - 2017-08-03 17:58:29 --> Loader Class Initialized
INFO - 2017-08-03 17:58:29 --> Helper loaded: url_helper
INFO - 2017-08-03 17:58:29 --> Helper loaded: form_helper
INFO - 2017-08-03 17:58:29 --> Helper loaded: security_helper
INFO - 2017-08-03 17:58:29 --> Helper loaded: path_helper
INFO - 2017-08-03 17:58:29 --> Helper loaded: common_helper
INFO - 2017-08-03 17:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 17:58:29 --> Helper loaded: check_session_helper
INFO - 2017-08-03 17:58:29 --> Database Driver Class Initialized
DEBUG - 2017-08-03 17:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:58:29 --> Email Class Initialized
INFO - 2017-08-03 17:58:29 --> Form Validation Class Initialized
INFO - 2017-08-03 17:58:29 --> Model Class Initialized
INFO - 2017-08-03 17:58:29 --> Model Class Initialized
INFO - 2017-08-03 17:58:29 --> Model Class Initialized
INFO - 2017-08-03 17:58:29 --> Model Class Initialized
INFO - 2017-08-03 17:58:29 --> Controller Class Initialized
DEBUG - 2017-08-03 17:58:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 17:58:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 17:58:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 17:58:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 17:58:29 --> Final output sent to browser
DEBUG - 2017-08-03 17:58:29 --> Total execution time: 0.0305
DEBUG - 2017-08-03 17:58:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 17:58:29 --> Database Forge Class Initialized
INFO - 2017-08-03 17:58:29 --> User Agent Class Initialized
DEBUG - 2017-08-03 17:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:07 --> Config Class Initialized
INFO - 2017-08-03 18:01:07 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:01:07 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:01:07 --> Utf8 Class Initialized
INFO - 2017-08-03 18:01:07 --> URI Class Initialized
INFO - 2017-08-03 18:01:07 --> Router Class Initialized
INFO - 2017-08-03 18:01:07 --> Output Class Initialized
INFO - 2017-08-03 18:01:07 --> Security Class Initialized
DEBUG - 2017-08-03 18:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:01:07 --> Input Class Initialized
INFO - 2017-08-03 18:01:07 --> Language Class Initialized
INFO - 2017-08-03 18:01:07 --> Loader Class Initialized
INFO - 2017-08-03 18:01:07 --> Helper loaded: url_helper
INFO - 2017-08-03 18:01:07 --> Helper loaded: form_helper
INFO - 2017-08-03 18:01:07 --> Helper loaded: security_helper
INFO - 2017-08-03 18:01:07 --> Helper loaded: path_helper
INFO - 2017-08-03 18:01:07 --> Helper loaded: common_helper
INFO - 2017-08-03 18:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:01:07 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:01:07 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:07 --> Email Class Initialized
INFO - 2017-08-03 18:01:07 --> Form Validation Class Initialized
INFO - 2017-08-03 18:01:07 --> Model Class Initialized
INFO - 2017-08-03 18:01:07 --> Model Class Initialized
INFO - 2017-08-03 18:01:07 --> Model Class Initialized
INFO - 2017-08-03 18:01:07 --> Model Class Initialized
INFO - 2017-08-03 18:01:07 --> Controller Class Initialized
INFO - 2017-08-03 18:01:07 --> Model Class Initialized
INFO - 2017-08-03 18:01:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:01:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/email_templates.php
INFO - 2017-08-03 18:01:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:01:07 --> Final output sent to browser
DEBUG - 2017-08-03 18:01:07 --> Total execution time: 0.0305
DEBUG - 2017-08-03 18:01:07 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:01:07 --> Database Forge Class Initialized
INFO - 2017-08-03 18:01:07 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:14 --> Config Class Initialized
INFO - 2017-08-03 18:01:14 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:01:14 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:01:14 --> Utf8 Class Initialized
INFO - 2017-08-03 18:01:14 --> URI Class Initialized
INFO - 2017-08-03 18:01:14 --> Router Class Initialized
INFO - 2017-08-03 18:01:14 --> Output Class Initialized
INFO - 2017-08-03 18:01:14 --> Security Class Initialized
DEBUG - 2017-08-03 18:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:01:14 --> Input Class Initialized
INFO - 2017-08-03 18:01:14 --> Language Class Initialized
INFO - 2017-08-03 18:01:14 --> Loader Class Initialized
INFO - 2017-08-03 18:01:14 --> Helper loaded: url_helper
INFO - 2017-08-03 18:01:14 --> Helper loaded: form_helper
INFO - 2017-08-03 18:01:14 --> Helper loaded: security_helper
INFO - 2017-08-03 18:01:14 --> Helper loaded: path_helper
INFO - 2017-08-03 18:01:14 --> Helper loaded: common_helper
INFO - 2017-08-03 18:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:01:14 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:01:14 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:14 --> Email Class Initialized
INFO - 2017-08-03 18:01:14 --> Form Validation Class Initialized
INFO - 2017-08-03 18:01:14 --> Model Class Initialized
INFO - 2017-08-03 18:01:14 --> Model Class Initialized
INFO - 2017-08-03 18:01:14 --> Model Class Initialized
INFO - 2017-08-03 18:01:14 --> Model Class Initialized
INFO - 2017-08-03 18:01:14 --> Controller Class Initialized
INFO - 2017-08-03 18:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/notification_form.php
INFO - 2017-08-03 18:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:01:14 --> Final output sent to browser
DEBUG - 2017-08-03 18:01:14 --> Total execution time: 0.0514
DEBUG - 2017-08-03 18:01:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:01:14 --> Database Forge Class Initialized
INFO - 2017-08-03 18:01:14 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:27 --> Config Class Initialized
INFO - 2017-08-03 18:01:27 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:01:27 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:01:27 --> Utf8 Class Initialized
INFO - 2017-08-03 18:01:27 --> URI Class Initialized
INFO - 2017-08-03 18:01:27 --> Router Class Initialized
INFO - 2017-08-03 18:01:27 --> Output Class Initialized
INFO - 2017-08-03 18:01:27 --> Security Class Initialized
DEBUG - 2017-08-03 18:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:01:27 --> Input Class Initialized
INFO - 2017-08-03 18:01:27 --> Language Class Initialized
INFO - 2017-08-03 18:01:27 --> Loader Class Initialized
INFO - 2017-08-03 18:01:27 --> Helper loaded: url_helper
INFO - 2017-08-03 18:01:27 --> Helper loaded: form_helper
INFO - 2017-08-03 18:01:27 --> Helper loaded: security_helper
INFO - 2017-08-03 18:01:27 --> Helper loaded: path_helper
INFO - 2017-08-03 18:01:27 --> Helper loaded: common_helper
INFO - 2017-08-03 18:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:01:27 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:01:27 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:27 --> Email Class Initialized
INFO - 2017-08-03 18:01:27 --> Form Validation Class Initialized
INFO - 2017-08-03 18:01:27 --> Model Class Initialized
INFO - 2017-08-03 18:01:27 --> Model Class Initialized
INFO - 2017-08-03 18:01:27 --> Model Class Initialized
INFO - 2017-08-03 18:01:27 --> Model Class Initialized
INFO - 2017-08-03 18:01:27 --> Controller Class Initialized
INFO - 2017-08-03 18:01:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:01:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/usertrackingbackup.php
INFO - 2017-08-03 18:01:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:01:27 --> Final output sent to browser
DEBUG - 2017-08-03 18:01:27 --> Total execution time: 0.0305
DEBUG - 2017-08-03 18:01:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:01:27 --> Database Forge Class Initialized
INFO - 2017-08-03 18:01:27 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:34 --> Config Class Initialized
INFO - 2017-08-03 18:01:34 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:01:34 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:01:34 --> Utf8 Class Initialized
INFO - 2017-08-03 18:01:34 --> URI Class Initialized
INFO - 2017-08-03 18:01:34 --> Router Class Initialized
INFO - 2017-08-03 18:01:34 --> Output Class Initialized
INFO - 2017-08-03 18:01:34 --> Security Class Initialized
DEBUG - 2017-08-03 18:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:01:34 --> Input Class Initialized
INFO - 2017-08-03 18:01:34 --> Language Class Initialized
INFO - 2017-08-03 18:01:34 --> Loader Class Initialized
INFO - 2017-08-03 18:01:34 --> Helper loaded: url_helper
INFO - 2017-08-03 18:01:34 --> Helper loaded: form_helper
INFO - 2017-08-03 18:01:34 --> Helper loaded: security_helper
INFO - 2017-08-03 18:01:34 --> Helper loaded: path_helper
INFO - 2017-08-03 18:01:34 --> Helper loaded: common_helper
INFO - 2017-08-03 18:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:01:34 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:01:34 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:01:34 --> Email Class Initialized
INFO - 2017-08-03 18:01:34 --> Form Validation Class Initialized
INFO - 2017-08-03 18:01:34 --> Model Class Initialized
INFO - 2017-08-03 18:01:34 --> Model Class Initialized
INFO - 2017-08-03 18:01:34 --> Model Class Initialized
INFO - 2017-08-03 18:01:34 --> Model Class Initialized
INFO - 2017-08-03 18:01:34 --> Controller Class Initialized
INFO - 2017-08-03 18:01:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:01:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-03 18:01:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:01:34 --> Final output sent to browser
DEBUG - 2017-08-03 18:01:34 --> Total execution time: 0.0277
DEBUG - 2017-08-03 18:01:34 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:01:34 --> Database Forge Class Initialized
INFO - 2017-08-03 18:01:34 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:01:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:04:43 --> Config Class Initialized
INFO - 2017-08-03 18:04:43 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:04:43 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:04:43 --> Utf8 Class Initialized
INFO - 2017-08-03 18:04:43 --> URI Class Initialized
INFO - 2017-08-03 18:04:43 --> Router Class Initialized
INFO - 2017-08-03 18:04:43 --> Output Class Initialized
INFO - 2017-08-03 18:04:43 --> Security Class Initialized
DEBUG - 2017-08-03 18:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:04:43 --> Input Class Initialized
INFO - 2017-08-03 18:04:43 --> Language Class Initialized
INFO - 2017-08-03 18:04:43 --> Loader Class Initialized
INFO - 2017-08-03 18:04:43 --> Helper loaded: url_helper
INFO - 2017-08-03 18:04:43 --> Helper loaded: form_helper
INFO - 2017-08-03 18:04:43 --> Helper loaded: security_helper
INFO - 2017-08-03 18:04:43 --> Helper loaded: path_helper
INFO - 2017-08-03 18:04:43 --> Helper loaded: common_helper
INFO - 2017-08-03 18:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:04:43 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:04:43 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:04:43 --> Email Class Initialized
INFO - 2017-08-03 18:04:43 --> Form Validation Class Initialized
INFO - 2017-08-03 18:04:43 --> Model Class Initialized
INFO - 2017-08-03 18:04:43 --> Model Class Initialized
INFO - 2017-08-03 18:04:43 --> Model Class Initialized
INFO - 2017-08-03 18:04:43 --> Model Class Initialized
INFO - 2017-08-03 18:04:43 --> Controller Class Initialized
DEBUG - 2017-08-03 18:04:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:04:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:04:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 18:04:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:04:43 --> Final output sent to browser
DEBUG - 2017-08-03 18:04:43 --> Total execution time: 0.0294
DEBUG - 2017-08-03 18:04:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:04:43 --> Database Forge Class Initialized
INFO - 2017-08-03 18:04:43 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:04:45 --> Config Class Initialized
INFO - 2017-08-03 18:04:45 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:04:45 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:04:45 --> Utf8 Class Initialized
INFO - 2017-08-03 18:04:45 --> URI Class Initialized
INFO - 2017-08-03 18:04:45 --> Router Class Initialized
INFO - 2017-08-03 18:04:45 --> Output Class Initialized
INFO - 2017-08-03 18:04:45 --> Security Class Initialized
DEBUG - 2017-08-03 18:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:04:45 --> Input Class Initialized
INFO - 2017-08-03 18:04:45 --> Language Class Initialized
ERROR - 2017-08-03 18:04:45 --> 404 Page Not Found: admin/Page/assets
INFO - 2017-08-03 18:08:09 --> Config Class Initialized
INFO - 2017-08-03 18:08:09 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:08:09 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:08:09 --> Utf8 Class Initialized
INFO - 2017-08-03 18:08:09 --> URI Class Initialized
INFO - 2017-08-03 18:08:09 --> Router Class Initialized
INFO - 2017-08-03 18:08:09 --> Output Class Initialized
INFO - 2017-08-03 18:08:09 --> Security Class Initialized
DEBUG - 2017-08-03 18:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:08:09 --> Input Class Initialized
INFO - 2017-08-03 18:08:09 --> Language Class Initialized
INFO - 2017-08-03 18:08:09 --> Loader Class Initialized
INFO - 2017-08-03 18:08:09 --> Helper loaded: url_helper
INFO - 2017-08-03 18:08:09 --> Helper loaded: form_helper
INFO - 2017-08-03 18:08:09 --> Helper loaded: security_helper
INFO - 2017-08-03 18:08:09 --> Helper loaded: path_helper
INFO - 2017-08-03 18:08:09 --> Helper loaded: common_helper
INFO - 2017-08-03 18:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:08:09 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:08:09 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:08:09 --> Email Class Initialized
INFO - 2017-08-03 18:08:09 --> Form Validation Class Initialized
INFO - 2017-08-03 18:08:09 --> Model Class Initialized
INFO - 2017-08-03 18:08:09 --> Model Class Initialized
INFO - 2017-08-03 18:08:09 --> Model Class Initialized
INFO - 2017-08-03 18:08:09 --> Model Class Initialized
INFO - 2017-08-03 18:08:09 --> Controller Class Initialized
INFO - 2017-08-03 18:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-03 18:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:08:09 --> Final output sent to browser
DEBUG - 2017-08-03 18:08:09 --> Total execution time: 0.0288
DEBUG - 2017-08-03 18:08:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:08:09 --> Database Forge Class Initialized
INFO - 2017-08-03 18:08:09 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:08:48 --> Config Class Initialized
INFO - 2017-08-03 18:08:48 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:08:48 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:08:48 --> Utf8 Class Initialized
INFO - 2017-08-03 18:08:48 --> URI Class Initialized
INFO - 2017-08-03 18:08:48 --> Router Class Initialized
INFO - 2017-08-03 18:08:48 --> Output Class Initialized
INFO - 2017-08-03 18:08:48 --> Security Class Initialized
DEBUG - 2017-08-03 18:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:08:48 --> Input Class Initialized
INFO - 2017-08-03 18:08:48 --> Language Class Initialized
INFO - 2017-08-03 18:08:48 --> Loader Class Initialized
INFO - 2017-08-03 18:08:48 --> Helper loaded: url_helper
INFO - 2017-08-03 18:08:48 --> Helper loaded: form_helper
INFO - 2017-08-03 18:08:48 --> Helper loaded: security_helper
INFO - 2017-08-03 18:08:48 --> Helper loaded: path_helper
INFO - 2017-08-03 18:08:48 --> Helper loaded: common_helper
INFO - 2017-08-03 18:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:08:48 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:08:48 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:08:48 --> Email Class Initialized
INFO - 2017-08-03 18:08:48 --> Form Validation Class Initialized
INFO - 2017-08-03 18:08:48 --> Model Class Initialized
INFO - 2017-08-03 18:08:48 --> Model Class Initialized
INFO - 2017-08-03 18:08:48 --> Model Class Initialized
INFO - 2017-08-03 18:08:48 --> Model Class Initialized
INFO - 2017-08-03 18:08:48 --> Controller Class Initialized
DEBUG - 2017-08-03 18:08:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:08:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:08:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 18:08:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:08:48 --> Final output sent to browser
DEBUG - 2017-08-03 18:08:48 --> Total execution time: 0.0260
DEBUG - 2017-08-03 18:08:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:08:48 --> Database Forge Class Initialized
INFO - 2017-08-03 18:08:48 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:03 --> Config Class Initialized
INFO - 2017-08-03 18:10:03 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:10:03 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:10:03 --> Utf8 Class Initialized
INFO - 2017-08-03 18:10:03 --> URI Class Initialized
INFO - 2017-08-03 18:10:03 --> Router Class Initialized
INFO - 2017-08-03 18:10:03 --> Output Class Initialized
INFO - 2017-08-03 18:10:03 --> Security Class Initialized
DEBUG - 2017-08-03 18:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:10:03 --> Input Class Initialized
INFO - 2017-08-03 18:10:03 --> Language Class Initialized
INFO - 2017-08-03 18:10:03 --> Loader Class Initialized
INFO - 2017-08-03 18:10:03 --> Helper loaded: url_helper
INFO - 2017-08-03 18:10:03 --> Helper loaded: form_helper
INFO - 2017-08-03 18:10:03 --> Helper loaded: security_helper
INFO - 2017-08-03 18:10:03 --> Helper loaded: path_helper
INFO - 2017-08-03 18:10:03 --> Helper loaded: common_helper
INFO - 2017-08-03 18:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:10:03 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:10:03 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:03 --> Email Class Initialized
INFO - 2017-08-03 18:10:03 --> Form Validation Class Initialized
INFO - 2017-08-03 18:10:03 --> Model Class Initialized
INFO - 2017-08-03 18:10:03 --> Model Class Initialized
INFO - 2017-08-03 18:10:03 --> Model Class Initialized
INFO - 2017-08-03 18:10:03 --> Model Class Initialized
INFO - 2017-08-03 18:10:03 --> Controller Class Initialized
DEBUG - 2017-08-03 18:10:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:10:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 18:10:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:10:03 --> Final output sent to browser
DEBUG - 2017-08-03 18:10:03 --> Total execution time: 0.0314
DEBUG - 2017-08-03 18:10:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:10:03 --> Database Forge Class Initialized
INFO - 2017-08-03 18:10:03 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:10 --> Config Class Initialized
INFO - 2017-08-03 18:10:10 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:10:10 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:10:10 --> Utf8 Class Initialized
INFO - 2017-08-03 18:10:10 --> URI Class Initialized
INFO - 2017-08-03 18:10:10 --> Router Class Initialized
INFO - 2017-08-03 18:10:10 --> Output Class Initialized
INFO - 2017-08-03 18:10:10 --> Security Class Initialized
DEBUG - 2017-08-03 18:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:10:10 --> Input Class Initialized
INFO - 2017-08-03 18:10:10 --> Language Class Initialized
INFO - 2017-08-03 18:10:10 --> Loader Class Initialized
INFO - 2017-08-03 18:10:10 --> Helper loaded: url_helper
INFO - 2017-08-03 18:10:10 --> Helper loaded: form_helper
INFO - 2017-08-03 18:10:10 --> Helper loaded: security_helper
INFO - 2017-08-03 18:10:10 --> Helper loaded: path_helper
INFO - 2017-08-03 18:10:10 --> Helper loaded: common_helper
INFO - 2017-08-03 18:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:10:10 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:10:10 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:10 --> Email Class Initialized
INFO - 2017-08-03 18:10:10 --> Form Validation Class Initialized
INFO - 2017-08-03 18:10:10 --> Model Class Initialized
INFO - 2017-08-03 18:10:10 --> Model Class Initialized
INFO - 2017-08-03 18:10:10 --> Model Class Initialized
INFO - 2017-08-03 18:10:10 --> Model Class Initialized
INFO - 2017-08-03 18:10:10 --> Controller Class Initialized
INFO - 2017-08-03 18:10:10 --> Model Class Initialized
INFO - 2017-08-03 18:10:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-03 18:10:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-03 18:10:10 --> Final output sent to browser
DEBUG - 2017-08-03 18:10:10 --> Total execution time: 0.0265
DEBUG - 2017-08-03 18:10:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:10:10 --> Database Forge Class Initialized
INFO - 2017-08-03 18:10:10 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:10:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:10:23 --> Config Class Initialized
INFO - 2017-08-03 18:10:23 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:10:23 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:10:23 --> Utf8 Class Initialized
INFO - 2017-08-03 18:10:23 --> URI Class Initialized
INFO - 2017-08-03 18:10:23 --> Router Class Initialized
INFO - 2017-08-03 18:10:23 --> Output Class Initialized
INFO - 2017-08-03 18:10:23 --> Security Class Initialized
DEBUG - 2017-08-03 18:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:10:23 --> Input Class Initialized
INFO - 2017-08-03 18:10:23 --> Language Class Initialized
ERROR - 2017-08-03 18:10:23 --> 404 Page Not Found: Page/assets
INFO - 2017-08-03 18:14:14 --> Config Class Initialized
INFO - 2017-08-03 18:14:14 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:14:14 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:14:14 --> Utf8 Class Initialized
INFO - 2017-08-03 18:14:14 --> URI Class Initialized
INFO - 2017-08-03 18:14:14 --> Router Class Initialized
INFO - 2017-08-03 18:14:14 --> Output Class Initialized
INFO - 2017-08-03 18:14:14 --> Security Class Initialized
DEBUG - 2017-08-03 18:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:14:14 --> Input Class Initialized
INFO - 2017-08-03 18:14:14 --> Language Class Initialized
INFO - 2017-08-03 18:14:14 --> Loader Class Initialized
INFO - 2017-08-03 18:14:14 --> Helper loaded: url_helper
INFO - 2017-08-03 18:14:14 --> Helper loaded: form_helper
INFO - 2017-08-03 18:14:14 --> Helper loaded: security_helper
INFO - 2017-08-03 18:14:14 --> Helper loaded: path_helper
INFO - 2017-08-03 18:14:14 --> Helper loaded: common_helper
INFO - 2017-08-03 18:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:14:14 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:14:14 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:14:14 --> Email Class Initialized
INFO - 2017-08-03 18:14:14 --> Form Validation Class Initialized
INFO - 2017-08-03 18:14:14 --> Model Class Initialized
INFO - 2017-08-03 18:14:14 --> Model Class Initialized
INFO - 2017-08-03 18:14:14 --> Model Class Initialized
INFO - 2017-08-03 18:14:14 --> Model Class Initialized
INFO - 2017-08-03 18:14:14 --> Controller Class Initialized
DEBUG - 2017-08-03 18:14:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:14:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-03 18:14:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-03 18:14:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-03 18:14:14 --> Final output sent to browser
DEBUG - 2017-08-03 18:14:14 --> Total execution time: 0.0300
DEBUG - 2017-08-03 18:14:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:14:14 --> Database Forge Class Initialized
INFO - 2017-08-03 18:14:14 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:14:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:14:15 --> Config Class Initialized
INFO - 2017-08-03 18:14:15 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:14:15 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:14:15 --> Utf8 Class Initialized
INFO - 2017-08-03 18:14:15 --> URI Class Initialized
INFO - 2017-08-03 18:14:15 --> Router Class Initialized
INFO - 2017-08-03 18:14:15 --> Output Class Initialized
INFO - 2017-08-03 18:14:15 --> Security Class Initialized
DEBUG - 2017-08-03 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:14:15 --> Input Class Initialized
INFO - 2017-08-03 18:14:15 --> Language Class Initialized
ERROR - 2017-08-03 18:14:15 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-03 18:49:43 --> Config Class Initialized
INFO - 2017-08-03 18:49:43 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:49:43 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:49:43 --> Utf8 Class Initialized
INFO - 2017-08-03 18:49:43 --> URI Class Initialized
DEBUG - 2017-08-03 18:49:43 --> No URI present. Default controller set.
INFO - 2017-08-03 18:49:43 --> Router Class Initialized
INFO - 2017-08-03 18:49:43 --> Output Class Initialized
INFO - 2017-08-03 18:49:43 --> Security Class Initialized
DEBUG - 2017-08-03 18:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:49:43 --> Input Class Initialized
INFO - 2017-08-03 18:49:43 --> Language Class Initialized
INFO - 2017-08-03 18:49:43 --> Loader Class Initialized
INFO - 2017-08-03 18:49:43 --> Helper loaded: url_helper
INFO - 2017-08-03 18:49:43 --> Helper loaded: form_helper
INFO - 2017-08-03 18:49:43 --> Helper loaded: security_helper
INFO - 2017-08-03 18:49:43 --> Helper loaded: path_helper
INFO - 2017-08-03 18:49:43 --> Helper loaded: common_helper
INFO - 2017-08-03 18:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:49:43 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:49:43 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:49:43 --> Email Class Initialized
INFO - 2017-08-03 18:49:43 --> Form Validation Class Initialized
INFO - 2017-08-03 18:49:43 --> Model Class Initialized
INFO - 2017-08-03 18:49:43 --> Model Class Initialized
INFO - 2017-08-03 18:49:43 --> Model Class Initialized
INFO - 2017-08-03 18:49:43 --> Model Class Initialized
INFO - 2017-08-03 18:49:43 --> Controller Class Initialized
DEBUG - 2017-08-03 18:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:49:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-03 18:49:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-03 18:49:43 --> Final output sent to browser
DEBUG - 2017-08-03 18:49:43 --> Total execution time: 0.0477
DEBUG - 2017-08-03 18:49:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:49:43 --> Database Forge Class Initialized
INFO - 2017-08-03 18:49:43 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:49:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:50:08 --> Config Class Initialized
INFO - 2017-08-03 18:50:08 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:50:08 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:50:08 --> Utf8 Class Initialized
INFO - 2017-08-03 18:50:08 --> URI Class Initialized
INFO - 2017-08-03 18:50:08 --> Router Class Initialized
INFO - 2017-08-03 18:50:08 --> Output Class Initialized
INFO - 2017-08-03 18:50:08 --> Security Class Initialized
DEBUG - 2017-08-03 18:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:50:08 --> Input Class Initialized
INFO - 2017-08-03 18:50:08 --> Language Class Initialized
INFO - 2017-08-03 18:50:08 --> Loader Class Initialized
INFO - 2017-08-03 18:50:08 --> Helper loaded: url_helper
INFO - 2017-08-03 18:50:08 --> Helper loaded: form_helper
INFO - 2017-08-03 18:50:08 --> Helper loaded: security_helper
INFO - 2017-08-03 18:50:08 --> Helper loaded: path_helper
INFO - 2017-08-03 18:50:08 --> Helper loaded: common_helper
INFO - 2017-08-03 18:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:50:08 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:50:08 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:50:08 --> Email Class Initialized
INFO - 2017-08-03 18:50:08 --> Form Validation Class Initialized
INFO - 2017-08-03 18:50:08 --> Model Class Initialized
INFO - 2017-08-03 18:50:08 --> Model Class Initialized
INFO - 2017-08-03 18:50:08 --> Model Class Initialized
INFO - 2017-08-03 18:50:08 --> Model Class Initialized
INFO - 2017-08-03 18:50:08 --> Controller Class Initialized
INFO - 2017-08-03 18:50:08 --> Model Class Initialized
INFO - 2017-08-03 18:50:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-03 18:50:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-03 18:50:08 --> Final output sent to browser
DEBUG - 2017-08-03 18:50:08 --> Total execution time: 0.0268
DEBUG - 2017-08-03 18:50:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:50:08 --> Database Forge Class Initialized
INFO - 2017-08-03 18:50:08 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:51:00 --> Config Class Initialized
INFO - 2017-08-03 18:51:00 --> Hooks Class Initialized
DEBUG - 2017-08-03 18:51:00 --> UTF-8 Support Enabled
INFO - 2017-08-03 18:51:00 --> Utf8 Class Initialized
INFO - 2017-08-03 18:51:00 --> URI Class Initialized
DEBUG - 2017-08-03 18:51:00 --> No URI present. Default controller set.
INFO - 2017-08-03 18:51:00 --> Router Class Initialized
INFO - 2017-08-03 18:51:00 --> Output Class Initialized
INFO - 2017-08-03 18:51:00 --> Security Class Initialized
DEBUG - 2017-08-03 18:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-03 18:51:00 --> Input Class Initialized
INFO - 2017-08-03 18:51:00 --> Language Class Initialized
INFO - 2017-08-03 18:51:00 --> Loader Class Initialized
INFO - 2017-08-03 18:51:00 --> Helper loaded: url_helper
INFO - 2017-08-03 18:51:00 --> Helper loaded: form_helper
INFO - 2017-08-03 18:51:00 --> Helper loaded: security_helper
INFO - 2017-08-03 18:51:00 --> Helper loaded: path_helper
INFO - 2017-08-03 18:51:00 --> Helper loaded: common_helper
INFO - 2017-08-03 18:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-03 18:51:00 --> Helper loaded: check_session_helper
INFO - 2017-08-03 18:51:00 --> Database Driver Class Initialized
DEBUG - 2017-08-03 18:51:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:51:00 --> Email Class Initialized
INFO - 2017-08-03 18:51:00 --> Form Validation Class Initialized
INFO - 2017-08-03 18:51:00 --> Model Class Initialized
INFO - 2017-08-03 18:51:00 --> Model Class Initialized
INFO - 2017-08-03 18:51:00 --> Model Class Initialized
INFO - 2017-08-03 18:51:00 --> Model Class Initialized
INFO - 2017-08-03 18:51:00 --> Controller Class Initialized
DEBUG - 2017-08-03 18:51:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-03 18:51:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-03 18:51:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-03 18:51:00 --> Final output sent to browser
DEBUG - 2017-08-03 18:51:00 --> Total execution time: 0.0292
DEBUG - 2017-08-03 18:51:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-03 18:51:00 --> Database Forge Class Initialized
INFO - 2017-08-03 18:51:00 --> User Agent Class Initialized
DEBUG - 2017-08-03 18:51:00 --> Session class already loaded. Second attempt ignored.
