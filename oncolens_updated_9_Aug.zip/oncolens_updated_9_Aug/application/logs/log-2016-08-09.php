<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-09 00:06:32 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'ae502b40dc87a3b40b5be83f0c376541dd64aa24', '/?', 1470726392, '10.85.0.229', NULL, '')
ERROR - 2016-08-09 00:06:36 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '0875e11d34c13789da5adcf7619ae54881d68853', '/?', 1470726396, '10.85.0.229', NULL, '')
ERROR - 2016-08-09 00:07:46 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '721d45c906f270a89f0db1ffa8a0ee89db1ffa26', '/?', 1470726466, '10.85.0.229', NULL, '')
ERROR - 2016-08-09 01:32:16 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'd4fb864631d43f9a698cc6dc09af1f0bc758dbe4', '/', 1470731536, '184.105.247.194', NULL, '')
ERROR - 2016-08-09 02:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-09 02:37:16 --> 404 Page Not Found: /index
ERROR - 2016-08-09 14:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-09 15:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-09 15:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-09 16:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-09 18:16:45 --> 404 Page Not Found: Webcalendar/install
ERROR - 2016-08-09 18:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-09 23:02:16 --> 404 Page Not Found: Calendar/install
