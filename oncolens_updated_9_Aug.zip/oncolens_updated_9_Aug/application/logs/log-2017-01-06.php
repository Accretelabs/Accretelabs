<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-06 00:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 03:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 03:01:22 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2017-01-06 04:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 06:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 10:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-06 10:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-06 10:56:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-06 11:09:18 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:10:15 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:11:07 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:11:40 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:12:19 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:12:51 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-06 11:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-06 11:16:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-06 11:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-06 12:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-06 15:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 15:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 20:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 20:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-06 23:10:01 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2017-01-06 23:10:01 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2017-01-06 23:10:02 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
