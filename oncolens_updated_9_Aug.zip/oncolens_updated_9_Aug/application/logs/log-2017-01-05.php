<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-05 08:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-05 13:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-05 14:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-05 14:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-05 15:28:16 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-05 18:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-05 21:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-05 22:10:37 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2017-01-05 23:30:27 --> 404 Page Not Found: Dkxqnbyhfhtml/index
