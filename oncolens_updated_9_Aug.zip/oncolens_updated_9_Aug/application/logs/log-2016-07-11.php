<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-11 01:38:23 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-11 14:27:27 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 14:27:50 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 14:28:09 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 14:39:19 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 15:07:41 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 16:18:30 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-11 16:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home3/rich/public_html/oncolensphp/application/views/case_list_page.php 38
ERROR - 2016-07-11 17:11:59 --> 404 Page Not Found: Page/assets
