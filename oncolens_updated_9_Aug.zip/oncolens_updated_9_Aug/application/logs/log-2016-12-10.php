<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-10 03:24:55 --> 404 Page Not Found: Rqmcjbfrqsdeoshtml/index
ERROR - 2016-12-10 09:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-10 09:08:23 --> 404 Page Not Found: M/page
ERROR - 2016-12-10 09:45:08 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '2ed639c3cc26607ea1bfad1f80fcb7fe6085eeb7', '/', 1481391908, '169.56.71.57', NULL, '')
ERROR - 2016-12-10 15:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-10 15:41:30 --> 404 Page Not Found: Faviconico/index
