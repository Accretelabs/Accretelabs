<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-07 17:47:58 --> Config Class Initialized
INFO - 2017-08-07 17:47:58 --> Hooks Class Initialized
DEBUG - 2017-08-07 17:47:58 --> UTF-8 Support Enabled
INFO - 2017-08-07 17:47:58 --> Utf8 Class Initialized
INFO - 2017-08-07 17:47:58 --> URI Class Initialized
DEBUG - 2017-08-07 17:47:58 --> No URI present. Default controller set.
INFO - 2017-08-07 17:47:58 --> Router Class Initialized
INFO - 2017-08-07 17:47:58 --> Output Class Initialized
INFO - 2017-08-07 17:47:58 --> Security Class Initialized
DEBUG - 2017-08-07 17:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-07 17:47:58 --> Input Class Initialized
INFO - 2017-08-07 17:47:58 --> Language Class Initialized
INFO - 2017-08-07 17:47:58 --> Loader Class Initialized
INFO - 2017-08-07 17:47:58 --> Helper loaded: url_helper
INFO - 2017-08-07 17:47:58 --> Helper loaded: form_helper
INFO - 2017-08-07 17:47:58 --> Helper loaded: security_helper
INFO - 2017-08-07 17:47:58 --> Helper loaded: path_helper
INFO - 2017-08-07 17:47:58 --> Helper loaded: common_helper
INFO - 2017-08-07 17:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-07 17:47:58 --> Helper loaded: check_session_helper
INFO - 2017-08-07 17:47:58 --> Database Driver Class Initialized
DEBUG - 2017-08-07 17:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:47:58 --> Email Class Initialized
INFO - 2017-08-07 17:47:58 --> Form Validation Class Initialized
INFO - 2017-08-07 17:47:58 --> Model Class Initialized
INFO - 2017-08-07 17:47:58 --> Model Class Initialized
INFO - 2017-08-07 17:47:58 --> Model Class Initialized
INFO - 2017-08-07 17:47:58 --> Model Class Initialized
INFO - 2017-08-07 17:47:58 --> Controller Class Initialized
DEBUG - 2017-08-07 17:47:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:47:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-07 17:47:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-07 17:47:58 --> Final output sent to browser
DEBUG - 2017-08-07 17:47:58 --> Total execution time: 0.6268
DEBUG - 2017-08-07 17:47:58 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-07 17:47:58 --> Database Forge Class Initialized
INFO - 2017-08-07 17:47:58 --> User Agent Class Initialized
DEBUG - 2017-08-07 17:47:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:13 --> Config Class Initialized
INFO - 2017-08-07 17:49:13 --> Hooks Class Initialized
DEBUG - 2017-08-07 17:49:13 --> UTF-8 Support Enabled
INFO - 2017-08-07 17:49:13 --> Utf8 Class Initialized
INFO - 2017-08-07 17:49:13 --> URI Class Initialized
INFO - 2017-08-07 17:49:13 --> Router Class Initialized
INFO - 2017-08-07 17:49:13 --> Output Class Initialized
INFO - 2017-08-07 17:49:13 --> Security Class Initialized
DEBUG - 2017-08-07 17:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-07 17:49:13 --> Input Class Initialized
INFO - 2017-08-07 17:49:13 --> Language Class Initialized
INFO - 2017-08-07 17:49:13 --> Loader Class Initialized
INFO - 2017-08-07 17:49:13 --> Helper loaded: url_helper
INFO - 2017-08-07 17:49:13 --> Helper loaded: form_helper
INFO - 2017-08-07 17:49:13 --> Helper loaded: security_helper
INFO - 2017-08-07 17:49:13 --> Helper loaded: path_helper
INFO - 2017-08-07 17:49:13 --> Helper loaded: common_helper
INFO - 2017-08-07 17:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-07 17:49:13 --> Helper loaded: check_session_helper
INFO - 2017-08-07 17:49:13 --> Database Driver Class Initialized
DEBUG - 2017-08-07 17:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:13 --> Email Class Initialized
INFO - 2017-08-07 17:49:13 --> Form Validation Class Initialized
INFO - 2017-08-07 17:49:13 --> Model Class Initialized
INFO - 2017-08-07 17:49:13 --> Model Class Initialized
INFO - 2017-08-07 17:49:13 --> Model Class Initialized
INFO - 2017-08-07 17:49:13 --> Model Class Initialized
INFO - 2017-08-07 17:49:13 --> Controller Class Initialized
INFO - 2017-08-07 17:49:14 --> Model Class Initialized
INFO - 2017-08-07 17:49:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-07 17:49:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-07 17:49:17 --> Final output sent to browser
DEBUG - 2017-08-07 17:49:17 --> Total execution time: 4.7187
DEBUG - 2017-08-07 17:49:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-07 17:49:17 --> Database Forge Class Initialized
INFO - 2017-08-07 17:49:17 --> User Agent Class Initialized
DEBUG - 2017-08-07 17:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:37 --> Config Class Initialized
INFO - 2017-08-07 17:49:37 --> Hooks Class Initialized
DEBUG - 2017-08-07 17:49:37 --> UTF-8 Support Enabled
INFO - 2017-08-07 17:49:37 --> Utf8 Class Initialized
INFO - 2017-08-07 17:49:37 --> URI Class Initialized
INFO - 2017-08-07 17:49:37 --> Router Class Initialized
INFO - 2017-08-07 17:49:37 --> Output Class Initialized
INFO - 2017-08-07 17:49:37 --> Security Class Initialized
DEBUG - 2017-08-07 17:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-07 17:49:37 --> Input Class Initialized
INFO - 2017-08-07 17:49:37 --> Language Class Initialized
INFO - 2017-08-07 17:49:37 --> Loader Class Initialized
INFO - 2017-08-07 17:49:37 --> Helper loaded: url_helper
INFO - 2017-08-07 17:49:37 --> Helper loaded: form_helper
INFO - 2017-08-07 17:49:37 --> Helper loaded: security_helper
INFO - 2017-08-07 17:49:37 --> Helper loaded: path_helper
INFO - 2017-08-07 17:49:37 --> Helper loaded: common_helper
INFO - 2017-08-07 17:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-07 17:49:37 --> Helper loaded: check_session_helper
INFO - 2017-08-07 17:49:37 --> Database Driver Class Initialized
DEBUG - 2017-08-07 17:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:37 --> Email Class Initialized
INFO - 2017-08-07 17:49:37 --> Form Validation Class Initialized
INFO - 2017-08-07 17:49:37 --> Model Class Initialized
INFO - 2017-08-07 17:49:37 --> Model Class Initialized
INFO - 2017-08-07 17:49:37 --> Model Class Initialized
INFO - 2017-08-07 17:49:37 --> Model Class Initialized
INFO - 2017-08-07 17:49:37 --> Controller Class Initialized
INFO - 2017-08-07 17:49:37 --> Helper loaded: captcha_helper
INFO - 2017-08-07 17:49:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-08-07 17:49:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-07 17:49:37 --> Final output sent to browser
DEBUG - 2017-08-07 17:49:37 --> Total execution time: 0.0828
DEBUG - 2017-08-07 17:49:37 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-07 17:49:37 --> Database Forge Class Initialized
INFO - 2017-08-07 17:49:37 --> User Agent Class Initialized
DEBUG - 2017-08-07 17:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:55 --> Config Class Initialized
INFO - 2017-08-07 17:49:55 --> Hooks Class Initialized
DEBUG - 2017-08-07 17:49:55 --> UTF-8 Support Enabled
INFO - 2017-08-07 17:49:55 --> Utf8 Class Initialized
INFO - 2017-08-07 17:49:55 --> URI Class Initialized
INFO - 2017-08-07 17:49:55 --> Router Class Initialized
INFO - 2017-08-07 17:49:55 --> Output Class Initialized
INFO - 2017-08-07 17:49:55 --> Security Class Initialized
DEBUG - 2017-08-07 17:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-07 17:49:55 --> Input Class Initialized
INFO - 2017-08-07 17:49:55 --> Language Class Initialized
INFO - 2017-08-07 17:49:55 --> Loader Class Initialized
INFO - 2017-08-07 17:49:55 --> Helper loaded: url_helper
INFO - 2017-08-07 17:49:55 --> Helper loaded: form_helper
INFO - 2017-08-07 17:49:55 --> Helper loaded: security_helper
INFO - 2017-08-07 17:49:55 --> Helper loaded: path_helper
INFO - 2017-08-07 17:49:55 --> Helper loaded: common_helper
INFO - 2017-08-07 17:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-07 17:49:55 --> Helper loaded: check_session_helper
INFO - 2017-08-07 17:49:55 --> Database Driver Class Initialized
DEBUG - 2017-08-07 17:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-07 17:49:55 --> Email Class Initialized
INFO - 2017-08-07 17:49:55 --> Form Validation Class Initialized
INFO - 2017-08-07 17:49:55 --> Model Class Initialized
INFO - 2017-08-07 17:49:55 --> Model Class Initialized
INFO - 2017-08-07 17:49:55 --> Model Class Initialized
INFO - 2017-08-07 17:49:55 --> Model Class Initialized
INFO - 2017-08-07 17:49:55 --> Controller Class Initialized
INFO - 2017-08-07 17:49:55 --> Model Class Initialized
INFO - 2017-08-07 17:49:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-07 17:49:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-07 17:49:55 --> Final output sent to browser
DEBUG - 2017-08-07 17:49:55 --> Total execution time: 0.0330
DEBUG - 2017-08-07 17:49:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-07 17:49:55 --> Database Forge Class Initialized
INFO - 2017-08-07 17:49:55 --> User Agent Class Initialized
DEBUG - 2017-08-07 17:49:55 --> Session class already loaded. Second attempt ignored.
