<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-13 01:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-13 05:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-13 06:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-13 08:00:53 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2016-08-13 08:00:54 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-13 08:00:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-13 08:00:54 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2016-08-13 08:00:55 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-13 08:57:27 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2016-08-13 08:57:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-13 14:32:21 --> 404 Page Not Found: CFIDE/administrator
ERROR - 2016-08-13 23:54:29 --> 404 Page Not Found: Robotstxt/index
