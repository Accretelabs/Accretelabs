<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-27 02:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-27 04:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-27 05:12:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-27 05:14:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-27 05:18:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-27 06:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-27 14:40:49 --> 404 Page Not Found: Robotstxt/index
