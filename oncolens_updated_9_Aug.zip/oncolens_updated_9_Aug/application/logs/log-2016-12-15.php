<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-15 03:43:23 --> 404 Page Not Found: Js/mage
ERROR - 2016-12-15 06:10:36 --> 404 Page Not Found: Page/assets
ERROR - 2016-12-15 06:18:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-15 06:19:01 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-15 06:19:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-15 06:23:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-15 06:23:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-15 06:24:23 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-15 06:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-15 06:26:48 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-15 06:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-15 06:26:57 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-15 06:27:59 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-15 07:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-15 07:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-15 15:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-15 15:33:16 --> 404 Page Not Found: Robotstxt/index
