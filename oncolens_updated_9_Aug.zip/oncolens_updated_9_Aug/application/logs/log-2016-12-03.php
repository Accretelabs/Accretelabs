<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-03 01:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-03 01:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-03 04:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-03 04:29:50 --> 404 Page Not Found: Nztabzxzfhtml/index
ERROR - 2016-12-03 08:26:51 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '9b8bf973dd2f7268d4065ecf8878de3e9024e4c2', '/', 1480782411, '216.218.206.67', NULL, '')
ERROR - 2016-12-03 15:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-03 16:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-03 19:23:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-03 19:26:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-03 19:40:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-03 19:41:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-03 19:42:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-03 19:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-03 23:12:23 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '335d01f3b657c512b1651a54b561afdc8a813fd7', '/', 1480835543, '198.20.69.98', NULL, '')
