<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-05 03:28:32 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'ddf8c898515da58246e2190ff576e05d21368e4d', '/', 1480937312, '216.218.206.68', NULL, '')
ERROR - 2016-12-05 04:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-05 05:09:20 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-05 05:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-05 05:09:36 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-05 05:09:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-05 05:16:50 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-05 05:38:18 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-05 05:38:19 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-05 05:38:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-05 05:38:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-05 05:43:00 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 05:43:00 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 05:43:00 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 05:43:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-05 06:28:06 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-05 06:28:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-05 06:28:13 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-05 08:54:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-05 08:54:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-05 08:54:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-05 09:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-05 09:03:52 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 09:03:52 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 09:03:52 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-05 09:09:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-05 09:10:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-05 13:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-05 16:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-05 18:02:00 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '524b96ba4a96c1f159ca38a738c4168ea83ad5f3', '/', 1480989720, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:00 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'd71d31aae05df1c079a55cd8a53b81722daa5687', '/', 1480989720, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:06 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'cbc0306164cc20e6e81f28d419f29949aaaa69dd', '/', 1480989726, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:07 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '56b81f7a7e35a3e7fdaacb2673333d6c2964dde2', '/', 1480989727, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:08 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '36e7f4aceeb68af95936215622067a18cea8ed10', '/', 1480989728, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:10 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'e5a5e3e55e74bf78170d40974d5a334de07b36ae', '/', 1480989730, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:17 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '7fbfb491e8a5a17b961e4d033f26292a2e5b55fc', '/', 1480989737, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:24 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '7870f7f3114de11c3ec95623da570fa795d8bdc5', '/', 1480989744, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:24 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'd44ea7fb1003aee92a23d2e212996be59d8e5d59', '/', 1480989744, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:27 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'da239c6da0dfdc62baea63601bf7f112fc10484e', '/', 1480989747, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 18:02:28 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '8a91035b44b877211c1e2e196c20427433e2d622', '/', 1480989748, '139.59.150.77', NULL, '')
ERROR - 2016-12-05 20:46:39 --> 404 Page Not Found: Robotstxt/index
