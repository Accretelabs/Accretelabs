<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-13 02:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-13 05:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 07:04:45 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-13 07:04:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 07:04:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 07:05:10 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-13 07:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-13 08:20:02 --> 404 Page Not Found: Page/assets
ERROR - 2017-01-13 09:10:57 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-13 09:10:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 09:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-13 09:26:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 09:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-13 09:28:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-13 10:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-13 11:24:39 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-13 14:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-13 22:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-13 22:21:28 --> 404 Page Not Found: Cqrfdxjilzhtml/index
