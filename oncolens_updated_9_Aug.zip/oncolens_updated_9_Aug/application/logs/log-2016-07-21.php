<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-21 17:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 17:54:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 17:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 17:58:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 17:58:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:00:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:01:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:01:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/user_add.php 81
ERROR - 2016-07-21 18:01:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:02:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:03:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:03:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 18:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 18:07:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:07:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:11:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:12:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:13:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/user_add.php 81
ERROR - 2016-07-21 18:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 18:24:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 18:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:27:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:28:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:30:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 18:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 18:30:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:31:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:33:04 --> 404 Page Not Found: 
ERROR - 2016-07-21 18:33:05 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:10 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:10 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:29 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:29 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:29 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:33:29 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:34:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:34:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/audit_log.php 110
ERROR - 2016-07-21 18:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/user_add.php 81
ERROR - 2016-07-21 18:34:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/admin/users.php 178
ERROR - 2016-07-21 18:35:43 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:35:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:36:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:36:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:37:04 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:37:07 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-21 18:37:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:37:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 18:39:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:13:37 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 06:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 06:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:24:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:24:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:27:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 06:27:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:39:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:56:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 06:56:04 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 06:56:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 06:56:25 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 06:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 06:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:09:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 07:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 07:11:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 07:12:01 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:12:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:12:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:23:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 07:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 07:25:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:37:57 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 07:37:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:39:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:39:05 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:39:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:39:21 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:39:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:39:31 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 934
ERROR - 2016-07-21 07:39:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 1028
ERROR - 2016-07-21 07:39:37 --> Severity: Warning --> array_filter() expects parameter 1 to be array, boolean given /var/www/html/application/models/Musers.php 1110
ERROR - 2016-07-21 07:39:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:39:41 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:43:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:43:10 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:43:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:43:15 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 934
ERROR - 2016-07-21 07:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 1028
ERROR - 2016-07-21 07:43:20 --> Severity: Warning --> array_filter() expects parameter 1 to be array, boolean given /var/www/html/application/models/Musers.php 1110
ERROR - 2016-07-21 07:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:50:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:50:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:50:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 07:56:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:56:13 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:56:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:56:23 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:56:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:56:56 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:57:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 07:57:01 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 07:59:01 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 07:59:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:00:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:02:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:02:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:03:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:04:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:05:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:05:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:06:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 08:06:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 08:10:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:10:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:10:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:12:00 --> 404 Page Not Found: Postcase/assets
ERROR - 2016-07-21 08:27:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 08:27:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:28:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 08:28:00 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 08:38:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 08:38:20 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 08:38:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 08:38:55 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 08:42:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:42:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 08:47:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 08:47:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 08:47:40 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '1e29bc0c9e9025015adc83da97afa73611fe9e3b', '/', 1469116060, '10.85.1.18', NULL, '')
ERROR - 2016-07-21 08:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 08:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 08:47:49 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'b94d300568db3cdad71eac053a001ac6aced6b8a', '/', 1469116069, '10.85.1.18', NULL, '')
ERROR - 2016-07-21 08:47:50 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '3023a9c3329c67c7dab5cf7ecc2fdb8ed3de7775', '/', 1469116070, '10.85.1.18', NULL, '')
ERROR - 2016-07-21 08:48:48 --> 404 Page Not Found: Postcase/assets
ERROR - 2016-07-21 09:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 09:00:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 09:02:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 09:03:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 09:08:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 09:09:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 09:09:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 09:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 09:14:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 09:22:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 09:22:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 09:38:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-07-21 09:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-07-21 09:38:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-07-21 09:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-07-21 10:21:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 10:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 10:21:37 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 10:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 10:22:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 10:22:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 10:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 10:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 10:23:05 --> 404 Page Not Found: admin/Cronjobphp/index
ERROR - 2016-07-21 10:23:09 --> 404 Page Not Found: admin/Cronjob/index
ERROR - 2016-07-21 10:26:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-07-21 10:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-07-21 10:37:31 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-07-21 10:37:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-07-21 10:39:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 10:39:34 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 10:39:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 10:39:40 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 10:39:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 10:39:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 10:39:59 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 10:40:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 10:40:05 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 10:42:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 11:26:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 11:26:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 11:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-07-21 11:51:52 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-21 11:51:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 11:52:03 --> 404 Page Not Found: Dashboard/index
ERROR - 2016-07-21 15:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-21 16:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-21 19:34:06 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 19:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 19:34:25 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-07-21 19:34:26 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-07-21 19:34:32 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-07-21 19:34:33 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-07-21 19:35:21 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-07-21 19:35:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-07-21 19:47:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 20:10:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:10:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:11:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 20:11:03 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 20:11:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 20:11:09 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 20:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 934
ERROR - 2016-07-21 20:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Musers.php 1028
ERROR - 2016-07-21 20:11:36 --> Severity: Warning --> array_filter() expects parameter 1 to be array, boolean given /var/www/html/application/models/Musers.php 1110
ERROR - 2016-07-21 20:28:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:29:13 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:31:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:31:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:32:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:32:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:32:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:32:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:33:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:33:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:33:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:33:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:33:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:33:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:33:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:34:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:36:30 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:36:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:37:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 20:54:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 20:54:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:54:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:54:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:55:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:55:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 20:55:11 --> Query error: Unknown column 'assets' in 'where clause' - Invalid query: select *, AES_DECRYPT(case_description, 'Oncolens') AS case_description, AES_DECRYPT(name,'Oncolens') as name, AES_DECRYPT(dob,'Oncolens') as dob,AES_DECRYPT(race,'Oncolens') as race from case_history where case_entered_by=3 and  id=assets
ERROR - 2016-07-21 20:55:11 --> Severity: Error --> Call to a member function num_rows() on boolean /var/www/html/application/models/Mcustom.php 200
ERROR - 2016-07-21 20:59:17 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '0317af94e136b77ea4ededf6b00b441dcbdb42a8', '/', 1469159957, '184.105.247.195', NULL, '')
ERROR - 2016-07-21 20:59:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 21:09:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:11:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 21:11:54 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 21:12:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:12:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:13:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:14:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:14:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:14:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:15:58 --> Severity: Notice --> Undefined property: stdClass::$CaseId /var/www/html/application/models/Musers.php 1041
ERROR - 2016-07-21 21:15:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 21:15:58 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1052
ERROR - 2016-07-21 21:15:58 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1059
ERROR - 2016-07-21 21:15:58 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1073
ERROR - 2016-07-21 21:15:58 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 21:18:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 21:18:21 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 21:18:49 --> Severity: Notice --> Undefined property: stdClass::$CaseId /var/www/html/application/models/Musers.php 1041
ERROR - 2016-07-21 21:18:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 21:18:49 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1052
ERROR - 2016-07-21 21:18:49 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1059
ERROR - 2016-07-21 21:18:49 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1073
ERROR - 2016-07-21 21:18:49 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 21:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-21 21:20:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:23:00 --> 404 Page Not Found: Postcase/assets
ERROR - 2016-07-21 21:23:19 --> Severity: Notice --> Undefined property: stdClass::$CaseId /var/www/html/application/models/Musers.php 1041
ERROR - 2016-07-21 21:23:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=
ERROR - 2016-07-21 21:23:19 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1052
ERROR - 2016-07-21 21:23:19 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1059
ERROR - 2016-07-21 21:23:19 --> Severity: Notice --> Undefined property: stdClass::$CaseHistory /var/www/html/application/models/Musers.php 1073
ERROR - 2016-07-21 21:23:19 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Musers.php 1103
ERROR - 2016-07-21 21:34:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:34:09 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 21:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 21:37:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 21:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 21:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 21:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 22:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Madmins.php 1322
ERROR - 2016-07-21 22:07:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 22:14:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 22:21:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 22:21:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 22:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 22:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 22:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:37:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:37:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:37:06 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:37:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 22:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:40:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-21 22:54:08 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '10c4a37527ce44651acc4ddb75b4a4a347defdb3', '/', 1469166848, '81.94.192.235', NULL, '')
ERROR - 2016-07-21 22:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 22:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-21 23:00:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:00:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:01:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:01:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:02:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:03:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:04:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:04:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:05:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:05:07 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:05:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:05:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:05:52 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:09:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:19:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:21:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:21:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:22:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:22:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:23:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:23:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:30:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:30:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:33:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:35:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:35:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:35:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:38:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-21 23:38:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-21 23:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-21 23:45:50 --> Severity: Warning --> array_filter() expects parameter 1 to be array, boolean given /var/www/html/application/models/Musers.php 1108
ERROR - 2016-07-21 23:53:25 --> 404 Page Not Found: Robotstxt/index
