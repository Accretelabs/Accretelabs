<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-07 04:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-07 04:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-07 08:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-07 21:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-07 22:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-07 23:46:40 --> 404 Page Not Found: Robotstxt/index
