<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-28 05:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-28 05:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-28 06:44:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-28 06:44:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-28 06:51:19 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-28 06:51:19 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-28 06:51:19 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-28 06:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-28 18:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-28 18:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-28 21:21:25 --> 404 Page Not Found: Robotstxt/index
