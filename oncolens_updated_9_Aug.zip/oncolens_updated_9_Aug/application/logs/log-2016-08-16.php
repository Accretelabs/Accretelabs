<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-16 00:13:51 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '2a2bb02fbfc0c5c58aeefe28b182be13fbab9efa', '/', 1471331631, '216.218.206.68', NULL, '')
ERROR - 2016-08-16 01:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 01:44:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 01:44:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 03:24:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 03:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:36:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:42:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:42:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 03:43:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:43:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 03:44:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:44:59 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:45:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 03:45:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 03:48:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:48:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:50:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:50:21 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:51:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:56:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:57:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 03:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 03:59:45 --> 404 Page Not Found: Redirectaspx/index
ERROR - 2016-08-16 04:01:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:03:59 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:05:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:05:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:08:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:08:44 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:08:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:09:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:09:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:09:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:09:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 04:11:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:12:10 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:12:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 04:12:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:12:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:12:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:12:33 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:13:01 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:13:09 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:18:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:18:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 04:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 04:19:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:19:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:22:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:29:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:29:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:29:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:30:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:30:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:32:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:32:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:33:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:33:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:35:18 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:35:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:36:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:37:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:38:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:51:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:51:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:55:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 04:55:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 05:50:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 05:53:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 05:53:11 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 05:58:22 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-16 05:58:22 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-16 05:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-16 05:58:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 05:58:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 06:01:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:01:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-16 06:04:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:06:13 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:15:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 06:15:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 06:42:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 06:42:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 06:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 06:42:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:42:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 06:42:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 06:42:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:43:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-16 06:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-16 09:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-16 10:01:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:01:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:03:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:04:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:05:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:06:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:06:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-16 10:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-16 15:11:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-16 20:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-16 21:22:46 --> 404 Page Not Found: Faviconico/index
