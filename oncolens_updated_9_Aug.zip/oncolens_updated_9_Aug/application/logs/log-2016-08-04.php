<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-04 01:25:34 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-08-04 09:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-04 15:03:45 --> 404 Page Not Found: Robotstxt/index
