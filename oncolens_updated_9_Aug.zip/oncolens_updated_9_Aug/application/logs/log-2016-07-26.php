<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-26 02:03:00 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-26 02:03:01 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-26 05:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-26 05:34:21 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2016-07-26 07:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-26 09:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-26 14:05:20 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2016-07-26 15:01:12 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-07-26 21:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-26 21:30:32 --> 404 Page Not Found: Well-known/apple-app-site-association
ERROR - 2016-07-26 22:37:42 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-07-26 23:17:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-26 23:17:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-26 23:20:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-26 23:20:06 --> 404 Page Not Found: Faviconico/index
