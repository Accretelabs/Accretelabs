<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-23 03:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 08:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 09:10:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-23 11:42:50 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:42:59 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:43:04 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:50:38 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:50:40 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:50:44 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 11:51:43 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-23 16:08:18 --> 404 Page Not Found: Administrator/index.php
ERROR - 2016-07-23 17:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 19:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 20:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 21:07:53 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'fa84c3d24d156633ec7f8335f405167bff0d5b11', '/', 1469333273, '216.218.206.66', NULL, '')
ERROR - 2016-07-23 22:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 22:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 22:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-23 23:31:53 --> 404 Page Not Found: Robotstxt/index
