<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-24 02:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-24 02:58:37 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2016-07-24 11:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-24 11:32:26 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-07-24 14:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-24 23:50:58 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '6d2ca7e7333709a2405485b673dfb06bc26e2733', '/', 1469429458, '66.240.192.138', NULL, '')
