<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:38:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-06 05:38:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 05:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-12-06 07:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-06 07:14:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-06 07:14:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-06 07:22:33 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1476412558_6_44_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4918
ERROR - 2016-12-06 07:22:33 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1476412558_6_44_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4918
ERROR - 2016-12-06 07:25:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-06 07:25:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-06 08:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-06 08:50:01 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2016-12-06 08:50:01 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2016-12-06 08:50:01 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
ERROR - 2016-12-06 09:16:04 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'f14c75c9b5f9e3fb8b3c2986448a0964d6fcf8a5', '/', 1481044564, '74.82.47.5', NULL, '')
ERROR - 2016-12-06 10:18:48 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-06 10:18:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-06 10:28:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1476412558_6_44_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4918
ERROR - 2016-12-06 20:35:16 --> 404 Page Not Found: Robotstxt/index
