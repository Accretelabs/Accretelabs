<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-24 11:18:25 --> Config Class Initialized
INFO - 2017-07-24 11:18:25 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:18:25 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:18:25 --> Utf8 Class Initialized
INFO - 2017-07-24 11:18:25 --> URI Class Initialized
DEBUG - 2017-07-24 11:18:25 --> No URI present. Default controller set.
INFO - 2017-07-24 11:18:25 --> Router Class Initialized
INFO - 2017-07-24 11:18:25 --> Output Class Initialized
INFO - 2017-07-24 11:18:25 --> Security Class Initialized
DEBUG - 2017-07-24 11:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:18:25 --> Input Class Initialized
INFO - 2017-07-24 11:18:25 --> Language Class Initialized
INFO - 2017-07-24 11:18:25 --> Loader Class Initialized
INFO - 2017-07-24 11:18:25 --> Helper loaded: url_helper
INFO - 2017-07-24 11:18:25 --> Helper loaded: form_helper
INFO - 2017-07-24 11:18:25 --> Helper loaded: security_helper
INFO - 2017-07-24 11:18:25 --> Helper loaded: path_helper
INFO - 2017-07-24 11:18:25 --> Helper loaded: common_helper
INFO - 2017-07-24 11:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:18:25 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:18:42 --> Config Class Initialized
INFO - 2017-07-24 11:18:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:18:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:18:42 --> Utf8 Class Initialized
INFO - 2017-07-24 11:18:42 --> URI Class Initialized
DEBUG - 2017-07-24 11:18:42 --> No URI present. Default controller set.
INFO - 2017-07-24 11:18:42 --> Router Class Initialized
INFO - 2017-07-24 11:18:42 --> Output Class Initialized
INFO - 2017-07-24 11:18:42 --> Security Class Initialized
DEBUG - 2017-07-24 11:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:18:42 --> Input Class Initialized
INFO - 2017-07-24 11:18:42 --> Language Class Initialized
INFO - 2017-07-24 11:18:42 --> Loader Class Initialized
INFO - 2017-07-24 11:18:42 --> Helper loaded: url_helper
INFO - 2017-07-24 11:18:42 --> Helper loaded: form_helper
INFO - 2017-07-24 11:18:42 --> Helper loaded: security_helper
INFO - 2017-07-24 11:18:42 --> Helper loaded: path_helper
INFO - 2017-07-24 11:18:42 --> Helper loaded: common_helper
INFO - 2017-07-24 11:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:18:42 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:18:42 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:18:42 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:42 --> Unable to connect to the database
DEBUG - 2017-07-24 11:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:18:43 --> Email Class Initialized
INFO - 2017-07-24 11:18:43 --> Form Validation Class Initialized
INFO - 2017-07-24 11:18:43 --> Model Class Initialized
INFO - 2017-07-24 11:18:43 --> Model Class Initialized
INFO - 2017-07-24 11:18:43 --> Model Class Initialized
INFO - 2017-07-24 11:18:43 --> Model Class Initialized
INFO - 2017-07-24 11:18:43 --> Controller Class Initialized
DEBUG - 2017-07-24 11:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:18:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 11:18:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 11:18:43 --> Final output sent to browser
DEBUG - 2017-07-24 11:18:43 --> Total execution time: 0.9690
DEBUG - 2017-07-24 11:18:43 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:18:43 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:18:43 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:43 --> Unable to connect to the database
INFO - 2017-07-24 11:18:43 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:18:43 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:18:43 --> Unable to connect to the database
ERROR - 2017-07-24 11:18:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:18:44 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:19:14 --> Config Class Initialized
INFO - 2017-07-24 11:19:14 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:19:14 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:19:14 --> Utf8 Class Initialized
INFO - 2017-07-24 11:19:14 --> URI Class Initialized
DEBUG - 2017-07-24 11:19:14 --> No URI present. Default controller set.
INFO - 2017-07-24 11:19:14 --> Router Class Initialized
INFO - 2017-07-24 11:19:14 --> Output Class Initialized
INFO - 2017-07-24 11:19:14 --> Security Class Initialized
DEBUG - 2017-07-24 11:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:19:14 --> Input Class Initialized
INFO - 2017-07-24 11:19:14 --> Language Class Initialized
INFO - 2017-07-24 11:19:14 --> Loader Class Initialized
INFO - 2017-07-24 11:19:14 --> Helper loaded: url_helper
INFO - 2017-07-24 11:19:14 --> Helper loaded: form_helper
INFO - 2017-07-24 11:19:14 --> Helper loaded: security_helper
INFO - 2017-07-24 11:19:14 --> Helper loaded: path_helper
INFO - 2017-07-24 11:19:14 --> Helper loaded: common_helper
INFO - 2017-07-24 11:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:19:14 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:19:14 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Unable to connect to the database
DEBUG - 2017-07-24 11:19:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:19:14 --> Email Class Initialized
INFO - 2017-07-24 11:19:14 --> Form Validation Class Initialized
INFO - 2017-07-24 11:19:14 --> Model Class Initialized
INFO - 2017-07-24 11:19:14 --> Model Class Initialized
INFO - 2017-07-24 11:19:14 --> Model Class Initialized
INFO - 2017-07-24 11:19:14 --> Model Class Initialized
INFO - 2017-07-24 11:19:14 --> Controller Class Initialized
DEBUG - 2017-07-24 11:19:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:19:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 11:19:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 11:19:14 --> Final output sent to browser
DEBUG - 2017-07-24 11:19:14 --> Total execution time: 0.1520
DEBUG - 2017-07-24 11:19:14 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:19:14 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Unable to connect to the database
INFO - 2017-07-24 11:19:14 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:19:14 --> Unable to connect to the database
ERROR - 2017-07-24 11:19:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:19:14 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:20:06 --> Config Class Initialized
INFO - 2017-07-24 11:20:06 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:20:06 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:20:06 --> Utf8 Class Initialized
INFO - 2017-07-24 11:20:06 --> URI Class Initialized
INFO - 2017-07-24 11:20:06 --> Router Class Initialized
INFO - 2017-07-24 11:20:06 --> Output Class Initialized
INFO - 2017-07-24 11:20:06 --> Security Class Initialized
DEBUG - 2017-07-24 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:20:06 --> Input Class Initialized
INFO - 2017-07-24 11:20:06 --> Language Class Initialized
INFO - 2017-07-24 11:20:06 --> Loader Class Initialized
INFO - 2017-07-24 11:20:06 --> Helper loaded: url_helper
INFO - 2017-07-24 11:20:06 --> Helper loaded: form_helper
INFO - 2017-07-24 11:20:06 --> Helper loaded: security_helper
INFO - 2017-07-24 11:20:06 --> Helper loaded: path_helper
INFO - 2017-07-24 11:20:06 --> Helper loaded: common_helper
INFO - 2017-07-24 11:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:20:06 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:20:06 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Unable to connect to the database
DEBUG - 2017-07-24 11:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:06 --> Email Class Initialized
INFO - 2017-07-24 11:20:06 --> Form Validation Class Initialized
INFO - 2017-07-24 11:20:06 --> Model Class Initialized
INFO - 2017-07-24 11:20:06 --> Model Class Initialized
INFO - 2017-07-24 11:20:06 --> Model Class Initialized
INFO - 2017-07-24 11:20:06 --> Model Class Initialized
INFO - 2017-07-24 11:20:06 --> Controller Class Initialized
DEBUG - 2017-07-24 11:20:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:06 --> Helper loaded: string_helper
INFO - 2017-07-24 11:20:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\forgot_password.php
INFO - 2017-07-24 11:20:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 11:20:06 --> Final output sent to browser
DEBUG - 2017-07-24 11:20:06 --> Total execution time: 0.1270
DEBUG - 2017-07-24 11:20:06 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:20:06 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Unable to connect to the database
INFO - 2017-07-24 11:20:06 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:06 --> Unable to connect to the database
ERROR - 2017-07-24 11:20:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:20:06 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:20:12 --> Config Class Initialized
INFO - 2017-07-24 11:20:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:20:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:20:12 --> Utf8 Class Initialized
INFO - 2017-07-24 11:20:12 --> URI Class Initialized
INFO - 2017-07-24 11:20:12 --> Router Class Initialized
INFO - 2017-07-24 11:20:12 --> Output Class Initialized
INFO - 2017-07-24 11:20:12 --> Security Class Initialized
DEBUG - 2017-07-24 11:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:20:12 --> Input Class Initialized
INFO - 2017-07-24 11:20:12 --> Language Class Initialized
INFO - 2017-07-24 11:20:12 --> Loader Class Initialized
INFO - 2017-07-24 11:20:12 --> Helper loaded: url_helper
INFO - 2017-07-24 11:20:12 --> Helper loaded: form_helper
INFO - 2017-07-24 11:20:12 --> Helper loaded: security_helper
INFO - 2017-07-24 11:20:12 --> Helper loaded: path_helper
INFO - 2017-07-24 11:20:12 --> Helper loaded: common_helper
INFO - 2017-07-24 11:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:20:12 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:20:12 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:12 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:12 --> Unable to connect to the database
DEBUG - 2017-07-24 11:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:12 --> Email Class Initialized
INFO - 2017-07-24 11:20:12 --> Form Validation Class Initialized
INFO - 2017-07-24 11:20:12 --> Model Class Initialized
INFO - 2017-07-24 11:20:12 --> Model Class Initialized
INFO - 2017-07-24 11:20:12 --> Model Class Initialized
INFO - 2017-07-24 11:20:12 --> Model Class Initialized
INFO - 2017-07-24 11:20:12 --> Controller Class Initialized
INFO - 2017-07-24 11:20:12 --> Model Class Initialized
ERROR - 2017-07-24 11:20:12 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:20:17 --> Config Class Initialized
INFO - 2017-07-24 11:20:17 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:20:17 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:20:17 --> Utf8 Class Initialized
INFO - 2017-07-24 11:20:17 --> URI Class Initialized
INFO - 2017-07-24 11:20:17 --> Router Class Initialized
INFO - 2017-07-24 11:20:17 --> Output Class Initialized
INFO - 2017-07-24 11:20:17 --> Security Class Initialized
DEBUG - 2017-07-24 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:20:17 --> Input Class Initialized
INFO - 2017-07-24 11:20:17 --> Language Class Initialized
INFO - 2017-07-24 11:20:17 --> Loader Class Initialized
INFO - 2017-07-24 11:20:17 --> Helper loaded: url_helper
INFO - 2017-07-24 11:20:17 --> Helper loaded: form_helper
INFO - 2017-07-24 11:20:17 --> Helper loaded: security_helper
INFO - 2017-07-24 11:20:17 --> Helper loaded: path_helper
INFO - 2017-07-24 11:20:17 --> Helper loaded: common_helper
INFO - 2017-07-24 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:20:17 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:20:17 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:17 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:17 --> Unable to connect to the database
DEBUG - 2017-07-24 11:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:17 --> Email Class Initialized
INFO - 2017-07-24 11:20:17 --> Form Validation Class Initialized
INFO - 2017-07-24 11:20:17 --> Model Class Initialized
INFO - 2017-07-24 11:20:17 --> Model Class Initialized
INFO - 2017-07-24 11:20:17 --> Model Class Initialized
INFO - 2017-07-24 11:20:17 --> Model Class Initialized
INFO - 2017-07-24 11:20:17 --> Controller Class Initialized
INFO - 2017-07-24 11:20:17 --> Model Class Initialized
ERROR - 2017-07-24 11:20:17 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:20:25 --> Config Class Initialized
INFO - 2017-07-24 11:20:25 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:20:25 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:20:25 --> Utf8 Class Initialized
INFO - 2017-07-24 11:20:25 --> URI Class Initialized
INFO - 2017-07-24 11:20:25 --> Router Class Initialized
INFO - 2017-07-24 11:20:25 --> Output Class Initialized
INFO - 2017-07-24 11:20:25 --> Security Class Initialized
DEBUG - 2017-07-24 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:20:25 --> Input Class Initialized
INFO - 2017-07-24 11:20:25 --> Language Class Initialized
INFO - 2017-07-24 11:20:25 --> Loader Class Initialized
INFO - 2017-07-24 11:20:25 --> Helper loaded: url_helper
INFO - 2017-07-24 11:20:25 --> Helper loaded: form_helper
INFO - 2017-07-24 11:20:25 --> Helper loaded: security_helper
INFO - 2017-07-24 11:20:25 --> Helper loaded: path_helper
INFO - 2017-07-24 11:20:25 --> Helper loaded: common_helper
INFO - 2017-07-24 11:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:20:25 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:20:25 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Unable to connect to the database
DEBUG - 2017-07-24 11:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:25 --> Email Class Initialized
INFO - 2017-07-24 11:20:25 --> Form Validation Class Initialized
INFO - 2017-07-24 11:20:25 --> Model Class Initialized
INFO - 2017-07-24 11:20:25 --> Model Class Initialized
INFO - 2017-07-24 11:20:25 --> Model Class Initialized
INFO - 2017-07-24 11:20:25 --> Model Class Initialized
INFO - 2017-07-24 11:20:25 --> Controller Class Initialized
INFO - 2017-07-24 11:20:25 --> Helper loaded: captcha_helper
INFO - 2017-07-24 11:20:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\contact_us.php
INFO - 2017-07-24 11:20:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 11:20:25 --> Final output sent to browser
DEBUG - 2017-07-24 11:20:25 --> Total execution time: 0.2420
DEBUG - 2017-07-24 11:20:25 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:20:25 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Unable to connect to the database
INFO - 2017-07-24 11:20:25 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:25 --> Unable to connect to the database
ERROR - 2017-07-24 11:20:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:20:26 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:20:37 --> Config Class Initialized
INFO - 2017-07-24 11:20:37 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:20:37 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:20:37 --> Utf8 Class Initialized
INFO - 2017-07-24 11:20:37 --> URI Class Initialized
INFO - 2017-07-24 11:20:37 --> Router Class Initialized
INFO - 2017-07-24 11:20:37 --> Output Class Initialized
INFO - 2017-07-24 11:20:37 --> Security Class Initialized
DEBUG - 2017-07-24 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:20:37 --> Input Class Initialized
INFO - 2017-07-24 11:20:37 --> Language Class Initialized
INFO - 2017-07-24 11:20:37 --> Loader Class Initialized
INFO - 2017-07-24 11:20:37 --> Helper loaded: url_helper
INFO - 2017-07-24 11:20:37 --> Helper loaded: form_helper
INFO - 2017-07-24 11:20:37 --> Helper loaded: security_helper
INFO - 2017-07-24 11:20:37 --> Helper loaded: path_helper
INFO - 2017-07-24 11:20:37 --> Helper loaded: common_helper
INFO - 2017-07-24 11:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:20:37 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:20:37 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:20:37 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:20:37 --> Unable to connect to the database
DEBUG - 2017-07-24 11:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:20:37 --> Email Class Initialized
INFO - 2017-07-24 11:20:37 --> Form Validation Class Initialized
INFO - 2017-07-24 11:20:37 --> Model Class Initialized
INFO - 2017-07-24 11:20:37 --> Model Class Initialized
INFO - 2017-07-24 11:20:37 --> Model Class Initialized
INFO - 2017-07-24 11:20:37 --> Model Class Initialized
INFO - 2017-07-24 11:20:37 --> Controller Class Initialized
INFO - 2017-07-24 11:20:37 --> Model Class Initialized
ERROR - 2017-07-24 11:20:37 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:21:51 --> Config Class Initialized
INFO - 2017-07-24 11:21:51 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:21:51 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:21:51 --> Utf8 Class Initialized
INFO - 2017-07-24 11:21:51 --> URI Class Initialized
INFO - 2017-07-24 11:21:51 --> Router Class Initialized
INFO - 2017-07-24 11:21:51 --> Output Class Initialized
INFO - 2017-07-24 11:21:51 --> Security Class Initialized
DEBUG - 2017-07-24 11:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:21:51 --> Input Class Initialized
INFO - 2017-07-24 11:21:51 --> Language Class Initialized
INFO - 2017-07-24 11:21:51 --> Loader Class Initialized
INFO - 2017-07-24 11:21:51 --> Helper loaded: url_helper
INFO - 2017-07-24 11:21:51 --> Helper loaded: form_helper
INFO - 2017-07-24 11:21:51 --> Helper loaded: security_helper
INFO - 2017-07-24 11:21:51 --> Helper loaded: path_helper
INFO - 2017-07-24 11:21:51 --> Helper loaded: common_helper
INFO - 2017-07-24 11:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:21:51 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:21:51 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:21:51 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:21:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:21:51 --> Unable to connect to the database
DEBUG - 2017-07-24 11:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:21:51 --> Email Class Initialized
INFO - 2017-07-24 11:21:51 --> Form Validation Class Initialized
INFO - 2017-07-24 11:21:51 --> Model Class Initialized
INFO - 2017-07-24 11:21:51 --> Model Class Initialized
INFO - 2017-07-24 11:21:51 --> Model Class Initialized
INFO - 2017-07-24 11:21:51 --> Model Class Initialized
INFO - 2017-07-24 11:21:51 --> Controller Class Initialized
INFO - 2017-07-24 11:21:51 --> Model Class Initialized
ERROR - 2017-07-24 11:21:51 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:21:52 --> Config Class Initialized
INFO - 2017-07-24 11:21:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:21:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:21:52 --> Utf8 Class Initialized
INFO - 2017-07-24 11:21:52 --> URI Class Initialized
INFO - 2017-07-24 11:21:52 --> Router Class Initialized
INFO - 2017-07-24 11:21:52 --> Output Class Initialized
INFO - 2017-07-24 11:21:52 --> Security Class Initialized
DEBUG - 2017-07-24 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:21:52 --> Input Class Initialized
INFO - 2017-07-24 11:21:52 --> Language Class Initialized
INFO - 2017-07-24 11:21:52 --> Loader Class Initialized
INFO - 2017-07-24 11:21:52 --> Helper loaded: url_helper
INFO - 2017-07-24 11:21:52 --> Helper loaded: form_helper
INFO - 2017-07-24 11:21:52 --> Helper loaded: security_helper
INFO - 2017-07-24 11:21:52 --> Helper loaded: path_helper
INFO - 2017-07-24 11:21:52 --> Helper loaded: common_helper
INFO - 2017-07-24 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:21:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:21:52 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:21:52 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:21:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:21:52 --> Unable to connect to the database
DEBUG - 2017-07-24 11:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:21:52 --> Email Class Initialized
INFO - 2017-07-24 11:21:52 --> Form Validation Class Initialized
INFO - 2017-07-24 11:21:52 --> Model Class Initialized
INFO - 2017-07-24 11:21:52 --> Model Class Initialized
INFO - 2017-07-24 11:21:52 --> Model Class Initialized
INFO - 2017-07-24 11:21:52 --> Model Class Initialized
INFO - 2017-07-24 11:21:52 --> Controller Class Initialized
INFO - 2017-07-24 11:21:52 --> Model Class Initialized
ERROR - 2017-07-24 11:21:52 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:22:36 --> Config Class Initialized
INFO - 2017-07-24 11:22:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:22:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:22:36 --> Utf8 Class Initialized
INFO - 2017-07-24 11:22:36 --> URI Class Initialized
INFO - 2017-07-24 11:22:36 --> Router Class Initialized
INFO - 2017-07-24 11:22:36 --> Output Class Initialized
INFO - 2017-07-24 11:22:36 --> Security Class Initialized
DEBUG - 2017-07-24 11:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:22:36 --> Input Class Initialized
INFO - 2017-07-24 11:22:36 --> Language Class Initialized
INFO - 2017-07-24 11:22:36 --> Loader Class Initialized
INFO - 2017-07-24 11:22:36 --> Helper loaded: url_helper
INFO - 2017-07-24 11:22:36 --> Helper loaded: form_helper
INFO - 2017-07-24 11:22:36 --> Helper loaded: security_helper
INFO - 2017-07-24 11:22:36 --> Helper loaded: path_helper
INFO - 2017-07-24 11:22:36 --> Helper loaded: common_helper
INFO - 2017-07-24 11:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:22:36 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:22:36 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Unable to connect to the database
DEBUG - 2017-07-24 11:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:36 --> Email Class Initialized
INFO - 2017-07-24 11:22:36 --> Form Validation Class Initialized
INFO - 2017-07-24 11:22:36 --> Model Class Initialized
INFO - 2017-07-24 11:22:36 --> Model Class Initialized
INFO - 2017-07-24 11:22:36 --> Model Class Initialized
INFO - 2017-07-24 11:22:36 --> Model Class Initialized
INFO - 2017-07-24 11:22:36 --> Controller Class Initialized
INFO - 2017-07-24 11:22:36 --> Helper loaded: captcha_helper
INFO - 2017-07-24 11:22:36 --> File loaded: E:\xampp\htdocs\oncolens\application\views\contact_us.php
INFO - 2017-07-24 11:22:36 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 11:22:36 --> Final output sent to browser
DEBUG - 2017-07-24 11:22:36 --> Total execution time: 0.0650
DEBUG - 2017-07-24 11:22:36 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:22:36 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Unable to connect to the database
INFO - 2017-07-24 11:22:36 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:36 --> Unable to connect to the database
ERROR - 2017-07-24 11:22:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:22:36 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:22:39 --> Config Class Initialized
INFO - 2017-07-24 11:22:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:22:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:22:39 --> Utf8 Class Initialized
INFO - 2017-07-24 11:22:39 --> URI Class Initialized
INFO - 2017-07-24 11:22:39 --> Router Class Initialized
INFO - 2017-07-24 11:22:39 --> Output Class Initialized
INFO - 2017-07-24 11:22:39 --> Security Class Initialized
DEBUG - 2017-07-24 11:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:22:39 --> Input Class Initialized
INFO - 2017-07-24 11:22:39 --> Language Class Initialized
INFO - 2017-07-24 11:22:39 --> Loader Class Initialized
INFO - 2017-07-24 11:22:39 --> Helper loaded: url_helper
INFO - 2017-07-24 11:22:39 --> Helper loaded: form_helper
INFO - 2017-07-24 11:22:39 --> Helper loaded: security_helper
INFO - 2017-07-24 11:22:39 --> Helper loaded: path_helper
INFO - 2017-07-24 11:22:39 --> Helper loaded: common_helper
INFO - 2017-07-24 11:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:22:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:22:39 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:39 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:39 --> Unable to connect to the database
DEBUG - 2017-07-24 11:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:39 --> Email Class Initialized
INFO - 2017-07-24 11:22:39 --> Form Validation Class Initialized
INFO - 2017-07-24 11:22:39 --> Model Class Initialized
INFO - 2017-07-24 11:22:39 --> Model Class Initialized
INFO - 2017-07-24 11:22:39 --> Model Class Initialized
INFO - 2017-07-24 11:22:39 --> Model Class Initialized
INFO - 2017-07-24 11:22:39 --> Controller Class Initialized
INFO - 2017-07-24 11:22:39 --> Model Class Initialized
ERROR - 2017-07-24 11:22:39 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 11:22:41 --> Config Class Initialized
INFO - 2017-07-24 11:22:41 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:22:41 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:22:41 --> Utf8 Class Initialized
INFO - 2017-07-24 11:22:41 --> URI Class Initialized
INFO - 2017-07-24 11:22:41 --> Router Class Initialized
INFO - 2017-07-24 11:22:41 --> Output Class Initialized
INFO - 2017-07-24 11:22:41 --> Security Class Initialized
DEBUG - 2017-07-24 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:22:41 --> Input Class Initialized
INFO - 2017-07-24 11:22:41 --> Language Class Initialized
INFO - 2017-07-24 11:22:41 --> Loader Class Initialized
INFO - 2017-07-24 11:22:41 --> Helper loaded: url_helper
INFO - 2017-07-24 11:22:41 --> Helper loaded: form_helper
INFO - 2017-07-24 11:22:41 --> Helper loaded: security_helper
INFO - 2017-07-24 11:22:41 --> Helper loaded: path_helper
INFO - 2017-07-24 11:22:41 --> Helper loaded: common_helper
INFO - 2017-07-24 11:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:22:41 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:22:41 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Unable to connect to the database
DEBUG - 2017-07-24 11:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:41 --> Email Class Initialized
INFO - 2017-07-24 11:22:41 --> Form Validation Class Initialized
INFO - 2017-07-24 11:22:41 --> Model Class Initialized
INFO - 2017-07-24 11:22:41 --> Model Class Initialized
INFO - 2017-07-24 11:22:41 --> Model Class Initialized
INFO - 2017-07-24 11:22:41 --> Model Class Initialized
INFO - 2017-07-24 11:22:41 --> Controller Class Initialized
INFO - 2017-07-24 11:22:41 --> Helper loaded: captcha_helper
INFO - 2017-07-24 11:22:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\contact_us.php
INFO - 2017-07-24 11:22:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 11:22:41 --> Final output sent to browser
DEBUG - 2017-07-24 11:22:41 --> Total execution time: 0.0630
DEBUG - 2017-07-24 11:22:41 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:22:41 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Unable to connect to the database
INFO - 2017-07-24 11:22:41 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:41 --> Unable to connect to the database
ERROR - 2017-07-24 11:22:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:22:41 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:22:44 --> Config Class Initialized
INFO - 2017-07-24 11:22:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:22:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:22:44 --> Utf8 Class Initialized
INFO - 2017-07-24 11:22:44 --> URI Class Initialized
INFO - 2017-07-24 11:22:44 --> Router Class Initialized
INFO - 2017-07-24 11:22:44 --> Output Class Initialized
INFO - 2017-07-24 11:22:44 --> Security Class Initialized
DEBUG - 2017-07-24 11:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:22:44 --> Input Class Initialized
INFO - 2017-07-24 11:22:44 --> Language Class Initialized
INFO - 2017-07-24 11:22:44 --> Loader Class Initialized
INFO - 2017-07-24 11:22:44 --> Helper loaded: url_helper
INFO - 2017-07-24 11:22:44 --> Helper loaded: form_helper
INFO - 2017-07-24 11:22:44 --> Helper loaded: security_helper
INFO - 2017-07-24 11:22:44 --> Helper loaded: path_helper
INFO - 2017-07-24 11:22:44 --> Helper loaded: common_helper
INFO - 2017-07-24 11:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:22:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:22:44 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Unable to connect to the database
DEBUG - 2017-07-24 11:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:44 --> Email Class Initialized
INFO - 2017-07-24 11:22:44 --> Form Validation Class Initialized
INFO - 2017-07-24 11:22:44 --> Model Class Initialized
INFO - 2017-07-24 11:22:44 --> Model Class Initialized
INFO - 2017-07-24 11:22:44 --> Model Class Initialized
INFO - 2017-07-24 11:22:44 --> Model Class Initialized
INFO - 2017-07-24 11:22:44 --> Controller Class Initialized
INFO - 2017-07-24 11:22:44 --> Helper loaded: captcha_helper
INFO - 2017-07-24 11:22:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\contact_us.php
INFO - 2017-07-24 11:22:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 11:22:44 --> Final output sent to browser
DEBUG - 2017-07-24 11:22:44 --> Total execution time: 0.0690
DEBUG - 2017-07-24 11:22:44 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:22:44 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Unable to connect to the database
INFO - 2017-07-24 11:22:44 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:44 --> Unable to connect to the database
ERROR - 2017-07-24 11:22:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:22:44 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:22:45 --> Config Class Initialized
INFO - 2017-07-24 11:22:45 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:22:45 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:22:45 --> Utf8 Class Initialized
INFO - 2017-07-24 11:22:45 --> URI Class Initialized
DEBUG - 2017-07-24 11:22:45 --> No URI present. Default controller set.
INFO - 2017-07-24 11:22:45 --> Router Class Initialized
INFO - 2017-07-24 11:22:45 --> Output Class Initialized
INFO - 2017-07-24 11:22:45 --> Security Class Initialized
DEBUG - 2017-07-24 11:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:22:45 --> Input Class Initialized
INFO - 2017-07-24 11:22:45 --> Language Class Initialized
INFO - 2017-07-24 11:22:45 --> Loader Class Initialized
INFO - 2017-07-24 11:22:45 --> Helper loaded: url_helper
INFO - 2017-07-24 11:22:45 --> Helper loaded: form_helper
INFO - 2017-07-24 11:22:45 --> Helper loaded: security_helper
INFO - 2017-07-24 11:22:45 --> Helper loaded: path_helper
INFO - 2017-07-24 11:22:45 --> Helper loaded: common_helper
INFO - 2017-07-24 11:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:22:45 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:22:45 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Unable to connect to the database
DEBUG - 2017-07-24 11:22:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:45 --> Email Class Initialized
INFO - 2017-07-24 11:22:45 --> Form Validation Class Initialized
INFO - 2017-07-24 11:22:45 --> Model Class Initialized
INFO - 2017-07-24 11:22:45 --> Model Class Initialized
INFO - 2017-07-24 11:22:45 --> Model Class Initialized
INFO - 2017-07-24 11:22:45 --> Model Class Initialized
INFO - 2017-07-24 11:22:45 --> Controller Class Initialized
DEBUG - 2017-07-24 11:22:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:22:45 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 11:22:45 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 11:22:45 --> Final output sent to browser
DEBUG - 2017-07-24 11:22:45 --> Total execution time: 0.0630
DEBUG - 2017-07-24 11:22:45 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:22:45 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Unable to connect to the database
INFO - 2017-07-24 11:22:45 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:22:45 --> Unable to connect to the database
ERROR - 2017-07-24 11:22:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 11:22:45 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 11:23:00 --> Config Class Initialized
INFO - 2017-07-24 11:23:00 --> Hooks Class Initialized
DEBUG - 2017-07-24 11:23:00 --> UTF-8 Support Enabled
INFO - 2017-07-24 11:23:00 --> Utf8 Class Initialized
INFO - 2017-07-24 11:23:00 --> URI Class Initialized
INFO - 2017-07-24 11:23:00 --> Router Class Initialized
INFO - 2017-07-24 11:23:00 --> Output Class Initialized
INFO - 2017-07-24 11:23:00 --> Security Class Initialized
DEBUG - 2017-07-24 11:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 11:23:00 --> Input Class Initialized
INFO - 2017-07-24 11:23:00 --> Language Class Initialized
INFO - 2017-07-24 11:23:00 --> Loader Class Initialized
INFO - 2017-07-24 11:23:00 --> Helper loaded: url_helper
INFO - 2017-07-24 11:23:00 --> Helper loaded: form_helper
INFO - 2017-07-24 11:23:00 --> Helper loaded: security_helper
INFO - 2017-07-24 11:23:00 --> Helper loaded: path_helper
INFO - 2017-07-24 11:23:00 --> Helper loaded: common_helper
INFO - 2017-07-24 11:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 11:23:00 --> Helper loaded: check_session_helper
INFO - 2017-07-24 11:23:00 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Unable to connect to the database
DEBUG - 2017-07-24 11:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 11:23:00 --> Email Class Initialized
INFO - 2017-07-24 11:23:00 --> Form Validation Class Initialized
INFO - 2017-07-24 11:23:00 --> Model Class Initialized
INFO - 2017-07-24 11:23:00 --> Model Class Initialized
INFO - 2017-07-24 11:23:00 --> Model Class Initialized
INFO - 2017-07-24 11:23:00 --> Model Class Initialized
INFO - 2017-07-24 11:23:00 --> Controller Class Initialized
INFO - 2017-07-24 11:23:00 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 11:23:00 --> Final output sent to browser
DEBUG - 2017-07-24 11:23:00 --> Total execution time: 0.1250
DEBUG - 2017-07-24 11:23:00 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 11:23:00 --> Database Driver Class Initialized
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Unable to connect to the database
INFO - 2017-07-24 11:23:00 --> Database Forge Class Initialized
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 11:23:00 --> Unable to connect to the database
ERROR - 2017-07-24 11:23:00 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 12:02:25 --> Config Class Initialized
INFO - 2017-07-24 12:02:25 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:02:25 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:02:25 --> Utf8 Class Initialized
INFO - 2017-07-24 12:02:25 --> URI Class Initialized
INFO - 2017-07-24 12:02:25 --> Router Class Initialized
INFO - 2017-07-24 12:02:25 --> Output Class Initialized
INFO - 2017-07-24 12:02:25 --> Security Class Initialized
DEBUG - 2017-07-24 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:02:25 --> Input Class Initialized
INFO - 2017-07-24 12:02:25 --> Language Class Initialized
INFO - 2017-07-24 12:02:25 --> Loader Class Initialized
INFO - 2017-07-24 12:02:25 --> Helper loaded: url_helper
INFO - 2017-07-24 12:02:25 --> Helper loaded: form_helper
INFO - 2017-07-24 12:02:25 --> Helper loaded: security_helper
INFO - 2017-07-24 12:02:25 --> Helper loaded: path_helper
INFO - 2017-07-24 12:02:25 --> Helper loaded: common_helper
INFO - 2017-07-24 12:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:02:25 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:02:25 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:02:28 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:28 --> Unable to connect to the database
DEBUG - 2017-07-24 12:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:02:28 --> Email Class Initialized
INFO - 2017-07-24 12:02:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:02:28 --> Model Class Initialized
INFO - 2017-07-24 12:02:28 --> Model Class Initialized
INFO - 2017-07-24 12:02:28 --> Model Class Initialized
INFO - 2017-07-24 12:02:28 --> Model Class Initialized
INFO - 2017-07-24 12:02:28 --> Controller Class Initialized
INFO - 2017-07-24 12:02:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:02:28 --> Final output sent to browser
DEBUG - 2017-07-24 12:02:28 --> Total execution time: 2.7801
DEBUG - 2017-07-24 12:02:28 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:02:28 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:02:30 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:30 --> Unable to connect to the database
INFO - 2017-07-24 12:02:30 --> Database Forge Class Initialized
ERROR - 2017-07-24 12:02:33 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:02:33 --> Unable to connect to the database
ERROR - 2017-07-24 12:02:33 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 12:04:03 --> Config Class Initialized
INFO - 2017-07-24 12:04:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:04:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:04:03 --> Utf8 Class Initialized
INFO - 2017-07-24 12:04:03 --> URI Class Initialized
INFO - 2017-07-24 12:04:03 --> Router Class Initialized
INFO - 2017-07-24 12:04:03 --> Output Class Initialized
INFO - 2017-07-24 12:04:03 --> Security Class Initialized
DEBUG - 2017-07-24 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:04:03 --> Input Class Initialized
INFO - 2017-07-24 12:04:03 --> Language Class Initialized
INFO - 2017-07-24 12:04:03 --> Loader Class Initialized
INFO - 2017-07-24 12:04:03 --> Helper loaded: url_helper
INFO - 2017-07-24 12:04:03 --> Helper loaded: form_helper
INFO - 2017-07-24 12:04:03 --> Helper loaded: security_helper
INFO - 2017-07-24 12:04:03 --> Helper loaded: path_helper
INFO - 2017-07-24 12:04:03 --> Helper loaded: common_helper
INFO - 2017-07-24 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:04:03 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:04:03 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:04:05 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:05 --> Unable to connect to the database
DEBUG - 2017-07-24 12:04:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:04:05 --> Email Class Initialized
INFO - 2017-07-24 12:04:05 --> Form Validation Class Initialized
INFO - 2017-07-24 12:04:05 --> Model Class Initialized
INFO - 2017-07-24 12:04:05 --> Model Class Initialized
INFO - 2017-07-24 12:04:05 --> Model Class Initialized
INFO - 2017-07-24 12:04:05 --> Model Class Initialized
INFO - 2017-07-24 12:04:05 --> Controller Class Initialized
INFO - 2017-07-24 12:04:38 --> Config Class Initialized
INFO - 2017-07-24 12:04:38 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:04:38 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:04:38 --> Utf8 Class Initialized
INFO - 2017-07-24 12:04:38 --> URI Class Initialized
INFO - 2017-07-24 12:04:38 --> Router Class Initialized
INFO - 2017-07-24 12:04:38 --> Output Class Initialized
INFO - 2017-07-24 12:04:38 --> Security Class Initialized
DEBUG - 2017-07-24 12:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:04:38 --> Input Class Initialized
INFO - 2017-07-24 12:04:38 --> Language Class Initialized
INFO - 2017-07-24 12:04:38 --> Loader Class Initialized
INFO - 2017-07-24 12:04:38 --> Helper loaded: url_helper
INFO - 2017-07-24 12:04:38 --> Helper loaded: form_helper
INFO - 2017-07-24 12:04:38 --> Helper loaded: security_helper
INFO - 2017-07-24 12:04:38 --> Helper loaded: path_helper
INFO - 2017-07-24 12:04:38 --> Helper loaded: common_helper
INFO - 2017-07-24 12:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:04:38 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:04:38 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:04:41 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:41 --> Unable to connect to the database
DEBUG - 2017-07-24 12:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:04:41 --> Email Class Initialized
INFO - 2017-07-24 12:04:41 --> Form Validation Class Initialized
INFO - 2017-07-24 12:04:41 --> Model Class Initialized
INFO - 2017-07-24 12:04:41 --> Model Class Initialized
INFO - 2017-07-24 12:04:41 --> Model Class Initialized
INFO - 2017-07-24 12:04:41 --> Model Class Initialized
INFO - 2017-07-24 12:04:41 --> Controller Class Initialized
INFO - 2017-07-24 12:04:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:04:41 --> Final output sent to browser
DEBUG - 2017-07-24 12:04:41 --> Total execution time: 2.7711
DEBUG - 2017-07-24 12:04:41 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:04:41 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:04:46 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:46 --> Unable to connect to the database
INFO - 2017-07-24 12:04:46 --> Database Forge Class Initialized
ERROR - 2017-07-24 12:04:49 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:49 --> Unable to connect to the database
ERROR - 2017-07-24 12:04:49 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 12:04:56 --> Config Class Initialized
INFO - 2017-07-24 12:04:56 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:04:56 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:04:56 --> Utf8 Class Initialized
INFO - 2017-07-24 12:04:56 --> URI Class Initialized
INFO - 2017-07-24 12:04:56 --> Router Class Initialized
INFO - 2017-07-24 12:04:56 --> Output Class Initialized
INFO - 2017-07-24 12:04:56 --> Security Class Initialized
DEBUG - 2017-07-24 12:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:04:56 --> Input Class Initialized
INFO - 2017-07-24 12:04:56 --> Language Class Initialized
INFO - 2017-07-24 12:04:56 --> Loader Class Initialized
INFO - 2017-07-24 12:04:56 --> Helper loaded: url_helper
INFO - 2017-07-24 12:04:56 --> Helper loaded: form_helper
INFO - 2017-07-24 12:04:56 --> Helper loaded: security_helper
INFO - 2017-07-24 12:04:56 --> Helper loaded: path_helper
INFO - 2017-07-24 12:04:56 --> Helper loaded: common_helper
INFO - 2017-07-24 12:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:04:56 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:04:56 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:04:59 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:04:59 --> Unable to connect to the database
DEBUG - 2017-07-24 12:04:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:04:59 --> Email Class Initialized
INFO - 2017-07-24 12:04:59 --> Form Validation Class Initialized
INFO - 2017-07-24 12:04:59 --> Model Class Initialized
INFO - 2017-07-24 12:04:59 --> Model Class Initialized
INFO - 2017-07-24 12:04:59 --> Model Class Initialized
INFO - 2017-07-24 12:04:59 --> Model Class Initialized
INFO - 2017-07-24 12:04:59 --> Controller Class Initialized
ERROR - 2017-07-24 12:04:59 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 12:05:19 --> Config Class Initialized
INFO - 2017-07-24 12:05:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:05:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:05:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:05:19 --> URI Class Initialized
INFO - 2017-07-24 12:05:19 --> Router Class Initialized
INFO - 2017-07-24 12:05:19 --> Output Class Initialized
INFO - 2017-07-24 12:05:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:05:19 --> Input Class Initialized
INFO - 2017-07-24 12:05:19 --> Language Class Initialized
INFO - 2017-07-24 12:05:19 --> Loader Class Initialized
INFO - 2017-07-24 12:05:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:05:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:05:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:05:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:05:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:05:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:05:19 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:05:21 --> Unable to connect to the database
DEBUG - 2017-07-24 12:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:05:21 --> Email Class Initialized
INFO - 2017-07-24 12:05:21 --> Form Validation Class Initialized
INFO - 2017-07-24 12:05:21 --> Model Class Initialized
INFO - 2017-07-24 12:05:21 --> Model Class Initialized
INFO - 2017-07-24 12:05:21 --> Model Class Initialized
INFO - 2017-07-24 12:05:21 --> Model Class Initialized
INFO - 2017-07-24 12:05:21 --> Controller Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 12:05:46 --> Config Class Initialized
INFO - 2017-07-24 12:05:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:05:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:05:46 --> Utf8 Class Initialized
INFO - 2017-07-24 12:05:46 --> URI Class Initialized
INFO - 2017-07-24 12:05:46 --> Router Class Initialized
INFO - 2017-07-24 12:05:46 --> Output Class Initialized
INFO - 2017-07-24 12:05:46 --> Security Class Initialized
DEBUG - 2017-07-24 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:05:46 --> Input Class Initialized
INFO - 2017-07-24 12:05:46 --> Language Class Initialized
INFO - 2017-07-24 12:05:46 --> Loader Class Initialized
INFO - 2017-07-24 12:05:46 --> Helper loaded: url_helper
INFO - 2017-07-24 12:05:46 --> Helper loaded: form_helper
INFO - 2017-07-24 12:05:46 --> Helper loaded: security_helper
INFO - 2017-07-24 12:05:46 --> Helper loaded: path_helper
INFO - 2017-07-24 12:05:46 --> Helper loaded: common_helper
INFO - 2017-07-24 12:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:05:46 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:05:46 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:05:46 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:49 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:49 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:05:49 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:05:49 --> Unable to connect to the database
DEBUG - 2017-07-24 12:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:05:49 --> Email Class Initialized
INFO - 2017-07-24 12:05:49 --> Form Validation Class Initialized
INFO - 2017-07-24 12:05:49 --> Model Class Initialized
INFO - 2017-07-24 12:05:49 --> Model Class Initialized
INFO - 2017-07-24 12:05:49 --> Model Class Initialized
INFO - 2017-07-24 12:05:49 --> Model Class Initialized
INFO - 2017-07-24 12:05:49 --> Controller Class Initialized
ERROR - 2017-07-24 12:05:49 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-07-24 12:05:49 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-07-24 12:05:49 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:51 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:51 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:51 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:05:51 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:05:51 --> Unable to connect to the database
ERROR - 2017-07-24 12:05:51 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 245
ERROR - 2017-07-24 12:05:51 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_result.php 63
INFO - 2017-07-24 12:05:51 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:05:51 --> Final output sent to browser
DEBUG - 2017-07-24 12:05:51 --> Total execution time: 5.2361
DEBUG - 2017-07-24 12:05:51 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:05:51 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:05:51 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:54 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:54 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:05:54 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:05:54 --> Unable to connect to the database
INFO - 2017-07-24 12:05:54 --> Database Forge Class Initialized
ERROR - 2017-07-24 12:05:54 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:56 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:56 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:56 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:05:56 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:05:56 --> Unable to connect to the database
ERROR - 2017-07-24 12:05:56 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 245
ERROR - 2017-07-24 12:05:56 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_result.php 63
INFO - 2017-07-24 12:05:56 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:05:56 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:59 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:59 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:05:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:05:59 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:05:59 --> Unable to connect to the database
INFO - 2017-07-24 12:05:59 --> Database Forge Class Initialized
ERROR - 2017-07-24 12:05:59 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:06:02 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:06:02 --> Severity: Warning --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-07-24 12:06:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-07-24 12:06:02 --> Unable to select database: oncolens
ERROR - 2017-07-24 12:06:02 --> Unable to connect to the database
ERROR - 2017-07-24 12:06:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given E:\xampp\htdocs\oncolens\system\database\drivers\mysql\mysql_driver.php 245
INFO - 2017-07-24 12:06:02 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:06:04 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:04 --> Unable to connect to the database
INFO - 2017-07-24 12:06:04 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:06:04 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:06:07 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:07 --> Unable to connect to the database
ERROR - 2017-07-24 12:06:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Exceptions.php:272) E:\xampp\htdocs\oncolens\system\core\Common.php 569
ERROR - 2017-07-24 12:06:07 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 12:06:38 --> Config Class Initialized
INFO - 2017-07-24 12:06:38 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:06:38 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:06:38 --> Utf8 Class Initialized
INFO - 2017-07-24 12:06:38 --> URI Class Initialized
INFO - 2017-07-24 12:06:38 --> Router Class Initialized
INFO - 2017-07-24 12:06:38 --> Output Class Initialized
INFO - 2017-07-24 12:06:38 --> Security Class Initialized
DEBUG - 2017-07-24 12:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:06:38 --> Input Class Initialized
INFO - 2017-07-24 12:06:38 --> Language Class Initialized
INFO - 2017-07-24 12:06:38 --> Loader Class Initialized
INFO - 2017-07-24 12:06:38 --> Helper loaded: url_helper
INFO - 2017-07-24 12:06:38 --> Helper loaded: form_helper
INFO - 2017-07-24 12:06:38 --> Helper loaded: security_helper
INFO - 2017-07-24 12:06:38 --> Helper loaded: path_helper
INFO - 2017-07-24 12:06:38 --> Helper loaded: common_helper
INFO - 2017-07-24 12:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:06:38 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:06:38 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:06:40 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:06:40 --> Unable to connect to the database
DEBUG - 2017-07-24 12:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:06:41 --> Email Class Initialized
INFO - 2017-07-24 12:06:41 --> Form Validation Class Initialized
INFO - 2017-07-24 12:06:41 --> Model Class Initialized
INFO - 2017-07-24 12:06:41 --> Model Class Initialized
INFO - 2017-07-24 12:06:41 --> Model Class Initialized
INFO - 2017-07-24 12:06:41 --> Model Class Initialized
INFO - 2017-07-24 12:06:41 --> Controller Class Initialized
ERROR - 2017-07-24 12:06:41 --> Severity: Error --> Call to a member function real_escape_string() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 331
INFO - 2017-07-24 12:07:40 --> Config Class Initialized
INFO - 2017-07-24 12:07:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:07:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:07:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:07:40 --> URI Class Initialized
INFO - 2017-07-24 12:07:40 --> Router Class Initialized
INFO - 2017-07-24 12:07:40 --> Output Class Initialized
INFO - 2017-07-24 12:07:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:07:40 --> Input Class Initialized
INFO - 2017-07-24 12:07:40 --> Language Class Initialized
INFO - 2017-07-24 12:07:40 --> Loader Class Initialized
INFO - 2017-07-24 12:07:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:07:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:07:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:07:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:07:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:07:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:07:40 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:07:43 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:43 --> Unable to connect to the database
DEBUG - 2017-07-24 12:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:07:43 --> Email Class Initialized
INFO - 2017-07-24 12:07:43 --> Form Validation Class Initialized
INFO - 2017-07-24 12:07:43 --> Model Class Initialized
INFO - 2017-07-24 12:07:43 --> Model Class Initialized
INFO - 2017-07-24 12:07:43 --> Model Class Initialized
INFO - 2017-07-24 12:07:43 --> Model Class Initialized
INFO - 2017-07-24 12:07:43 --> Controller Class Initialized
INFO - 2017-07-24 12:07:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:07:43 --> Final output sent to browser
DEBUG - 2017-07-24 12:07:43 --> Total execution time: 2.6491
DEBUG - 2017-07-24 12:07:43 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:07:43 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:07:46 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:46 --> Unable to connect to the database
INFO - 2017-07-24 12:07:46 --> Database Forge Class Initialized
ERROR - 2017-07-24 12:07:48 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:07:48 --> Unable to connect to the database
ERROR - 2017-07-24 12:07:48 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 12:08:21 --> Config Class Initialized
INFO - 2017-07-24 12:08:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:08:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:08:21 --> Utf8 Class Initialized
INFO - 2017-07-24 12:08:21 --> URI Class Initialized
INFO - 2017-07-24 12:08:21 --> Router Class Initialized
INFO - 2017-07-24 12:08:21 --> Output Class Initialized
INFO - 2017-07-24 12:08:21 --> Security Class Initialized
DEBUG - 2017-07-24 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:08:21 --> Input Class Initialized
INFO - 2017-07-24 12:08:21 --> Language Class Initialized
INFO - 2017-07-24 12:08:21 --> Loader Class Initialized
INFO - 2017-07-24 12:08:21 --> Helper loaded: url_helper
INFO - 2017-07-24 12:08:21 --> Helper loaded: form_helper
INFO - 2017-07-24 12:08:21 --> Helper loaded: security_helper
INFO - 2017-07-24 12:08:21 --> Helper loaded: path_helper
INFO - 2017-07-24 12:08:21 --> Helper loaded: common_helper
INFO - 2017-07-24 12:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:08:21 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:08:21 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:08:24 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:08:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:08:24 --> Unable to connect to the database
DEBUG - 2017-07-24 12:08:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:08:24 --> Email Class Initialized
INFO - 2017-07-24 12:08:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:08:24 --> Model Class Initialized
INFO - 2017-07-24 12:08:24 --> Model Class Initialized
INFO - 2017-07-24 12:08:24 --> Model Class Initialized
INFO - 2017-07-24 12:08:24 --> Model Class Initialized
INFO - 2017-07-24 12:08:24 --> Controller Class Initialized
ERROR - 2017-07-24 12:08:26 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:08:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:08:26 --> Unable to connect to the database
ERROR - 2017-07-24 12:08:26 --> Severity: Error --> Call to a member function query() on a non-object E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 221
INFO - 2017-07-24 12:09:22 --> Config Class Initialized
INFO - 2017-07-24 12:09:22 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:09:22 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:09:22 --> Utf8 Class Initialized
INFO - 2017-07-24 12:09:22 --> URI Class Initialized
INFO - 2017-07-24 12:09:22 --> Router Class Initialized
INFO - 2017-07-24 12:09:22 --> Output Class Initialized
INFO - 2017-07-24 12:09:22 --> Security Class Initialized
DEBUG - 2017-07-24 12:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:09:22 --> Input Class Initialized
INFO - 2017-07-24 12:09:22 --> Language Class Initialized
INFO - 2017-07-24 12:09:22 --> Loader Class Initialized
INFO - 2017-07-24 12:09:22 --> Helper loaded: url_helper
INFO - 2017-07-24 12:09:22 --> Helper loaded: form_helper
INFO - 2017-07-24 12:09:22 --> Helper loaded: security_helper
INFO - 2017-07-24 12:09:22 --> Helper loaded: path_helper
INFO - 2017-07-24 12:09:22 --> Helper loaded: common_helper
INFO - 2017-07-24 12:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:09:22 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:09:22 --> Database Driver Class Initialized
ERROR - 2017-07-24 12:09:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:09:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\xampp\htdocs\oncolens\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-07-24 12:09:25 --> Unable to connect to the database
INFO - 2017-07-24 12:09:25 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:09:46 --> Config Class Initialized
INFO - 2017-07-24 12:09:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:09:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:09:46 --> Utf8 Class Initialized
INFO - 2017-07-24 12:09:46 --> URI Class Initialized
INFO - 2017-07-24 12:09:46 --> Router Class Initialized
INFO - 2017-07-24 12:09:46 --> Output Class Initialized
INFO - 2017-07-24 12:09:46 --> Security Class Initialized
DEBUG - 2017-07-24 12:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:09:46 --> Input Class Initialized
INFO - 2017-07-24 12:09:46 --> Language Class Initialized
INFO - 2017-07-24 12:09:46 --> Loader Class Initialized
INFO - 2017-07-24 12:09:46 --> Helper loaded: url_helper
INFO - 2017-07-24 12:09:46 --> Helper loaded: form_helper
INFO - 2017-07-24 12:09:46 --> Helper loaded: security_helper
INFO - 2017-07-24 12:09:46 --> Helper loaded: path_helper
INFO - 2017-07-24 12:09:46 --> Helper loaded: common_helper
INFO - 2017-07-24 12:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:09:46 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:09:46 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:09:46 --> Email Class Initialized
INFO - 2017-07-24 12:09:46 --> Form Validation Class Initialized
INFO - 2017-07-24 12:09:46 --> Model Class Initialized
INFO - 2017-07-24 12:09:46 --> Model Class Initialized
INFO - 2017-07-24 12:09:46 --> Model Class Initialized
INFO - 2017-07-24 12:09:46 --> Model Class Initialized
INFO - 2017-07-24 12:09:46 --> Controller Class Initialized
INFO - 2017-07-24 12:10:00 --> Config Class Initialized
INFO - 2017-07-24 12:10:00 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:10:00 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:10:00 --> Utf8 Class Initialized
INFO - 2017-07-24 12:10:00 --> URI Class Initialized
INFO - 2017-07-24 12:10:00 --> Router Class Initialized
INFO - 2017-07-24 12:10:00 --> Output Class Initialized
INFO - 2017-07-24 12:10:00 --> Security Class Initialized
DEBUG - 2017-07-24 12:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:10:00 --> Input Class Initialized
INFO - 2017-07-24 12:10:00 --> Language Class Initialized
INFO - 2017-07-24 12:10:00 --> Loader Class Initialized
INFO - 2017-07-24 12:10:00 --> Helper loaded: url_helper
INFO - 2017-07-24 12:10:00 --> Helper loaded: form_helper
INFO - 2017-07-24 12:10:00 --> Helper loaded: security_helper
INFO - 2017-07-24 12:10:00 --> Helper loaded: path_helper
INFO - 2017-07-24 12:10:00 --> Helper loaded: common_helper
INFO - 2017-07-24 12:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:10:00 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:10:00 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:10:00 --> Email Class Initialized
INFO - 2017-07-24 12:10:00 --> Form Validation Class Initialized
INFO - 2017-07-24 12:10:00 --> Model Class Initialized
INFO - 2017-07-24 12:10:00 --> Model Class Initialized
INFO - 2017-07-24 12:10:00 --> Model Class Initialized
INFO - 2017-07-24 12:10:00 --> Model Class Initialized
INFO - 2017-07-24 12:10:00 --> Controller Class Initialized
INFO - 2017-07-24 12:10:00 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:10:00 --> Final output sent to browser
DEBUG - 2017-07-24 12:10:00 --> Total execution time: 0.1350
DEBUG - 2017-07-24 12:10:00 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:10:00 --> Database Forge Class Initialized
INFO - 2017-07-24 12:10:00 --> Database Forge Class Initialized
INFO - 2017-07-24 12:10:00 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:10:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:10:00 --> Query error: Unknown column 'user_type' in 'field list' - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891000, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:10:00 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:11:58 --> Config Class Initialized
INFO - 2017-07-24 12:11:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:11:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:11:58 --> Utf8 Class Initialized
INFO - 2017-07-24 12:11:58 --> URI Class Initialized
INFO - 2017-07-24 12:11:58 --> Router Class Initialized
INFO - 2017-07-24 12:11:58 --> Output Class Initialized
INFO - 2017-07-24 12:11:58 --> Security Class Initialized
DEBUG - 2017-07-24 12:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:11:58 --> Input Class Initialized
INFO - 2017-07-24 12:11:58 --> Language Class Initialized
INFO - 2017-07-24 12:11:58 --> Loader Class Initialized
INFO - 2017-07-24 12:11:58 --> Helper loaded: url_helper
INFO - 2017-07-24 12:11:58 --> Helper loaded: form_helper
INFO - 2017-07-24 12:11:58 --> Helper loaded: security_helper
INFO - 2017-07-24 12:11:58 --> Helper loaded: path_helper
INFO - 2017-07-24 12:11:58 --> Helper loaded: common_helper
INFO - 2017-07-24 12:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:11:58 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:11:58 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:11:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:11:58 --> Email Class Initialized
INFO - 2017-07-24 12:11:58 --> Form Validation Class Initialized
INFO - 2017-07-24 12:11:58 --> Model Class Initialized
INFO - 2017-07-24 12:11:58 --> Model Class Initialized
INFO - 2017-07-24 12:11:58 --> Model Class Initialized
INFO - 2017-07-24 12:11:58 --> Model Class Initialized
INFO - 2017-07-24 12:11:58 --> Controller Class Initialized
INFO - 2017-07-24 12:11:58 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:11:58 --> Final output sent to browser
DEBUG - 2017-07-24 12:11:58 --> Total execution time: 0.1140
DEBUG - 2017-07-24 12:11:58 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:11:58 --> Database Forge Class Initialized
INFO - 2017-07-24 12:11:58 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:11:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:11:58 --> Query error: Unknown column 'user_type' in 'field list' - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891118, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:11:58 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:12:21 --> Config Class Initialized
INFO - 2017-07-24 12:12:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:12:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:12:21 --> Utf8 Class Initialized
INFO - 2017-07-24 12:12:21 --> URI Class Initialized
INFO - 2017-07-24 12:12:21 --> Router Class Initialized
INFO - 2017-07-24 12:12:21 --> Output Class Initialized
INFO - 2017-07-24 12:12:21 --> Security Class Initialized
DEBUG - 2017-07-24 12:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:12:21 --> Input Class Initialized
INFO - 2017-07-24 12:12:21 --> Language Class Initialized
INFO - 2017-07-24 12:12:21 --> Loader Class Initialized
INFO - 2017-07-24 12:12:21 --> Helper loaded: url_helper
INFO - 2017-07-24 12:12:21 --> Helper loaded: form_helper
INFO - 2017-07-24 12:12:21 --> Helper loaded: security_helper
INFO - 2017-07-24 12:12:21 --> Helper loaded: path_helper
INFO - 2017-07-24 12:12:21 --> Helper loaded: common_helper
INFO - 2017-07-24 12:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:12:21 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:12:21 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:12:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:12:21 --> Email Class Initialized
INFO - 2017-07-24 12:12:21 --> Form Validation Class Initialized
INFO - 2017-07-24 12:12:21 --> Model Class Initialized
INFO - 2017-07-24 12:12:21 --> Model Class Initialized
INFO - 2017-07-24 12:12:21 --> Model Class Initialized
INFO - 2017-07-24 12:12:21 --> Model Class Initialized
INFO - 2017-07-24 12:12:21 --> Controller Class Initialized
INFO - 2017-07-24 12:12:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:12:21 --> Final output sent to browser
DEBUG - 2017-07-24 12:12:21 --> Total execution time: 0.0660
DEBUG - 2017-07-24 12:12:21 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:12:21 --> Database Forge Class Initialized
INFO - 2017-07-24 12:12:21 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:12:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:12:21 --> Query error: Column 'user_identifier' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891141, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:12:21 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:12:54 --> Config Class Initialized
INFO - 2017-07-24 12:12:54 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:12:54 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:12:54 --> Utf8 Class Initialized
INFO - 2017-07-24 12:12:54 --> URI Class Initialized
INFO - 2017-07-24 12:12:54 --> Router Class Initialized
INFO - 2017-07-24 12:12:54 --> Output Class Initialized
INFO - 2017-07-24 12:12:54 --> Security Class Initialized
DEBUG - 2017-07-24 12:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:12:54 --> Input Class Initialized
INFO - 2017-07-24 12:12:54 --> Language Class Initialized
INFO - 2017-07-24 12:12:54 --> Loader Class Initialized
INFO - 2017-07-24 12:12:54 --> Helper loaded: url_helper
INFO - 2017-07-24 12:12:54 --> Helper loaded: form_helper
INFO - 2017-07-24 12:12:54 --> Helper loaded: security_helper
INFO - 2017-07-24 12:12:54 --> Helper loaded: path_helper
INFO - 2017-07-24 12:12:54 --> Helper loaded: common_helper
INFO - 2017-07-24 12:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:12:54 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:12:54 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:12:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:12:54 --> Email Class Initialized
INFO - 2017-07-24 12:12:54 --> Form Validation Class Initialized
INFO - 2017-07-24 12:12:54 --> Model Class Initialized
INFO - 2017-07-24 12:12:54 --> Model Class Initialized
INFO - 2017-07-24 12:12:54 --> Model Class Initialized
INFO - 2017-07-24 12:12:54 --> Model Class Initialized
INFO - 2017-07-24 12:12:54 --> Controller Class Initialized
INFO - 2017-07-24 12:12:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:12:54 --> Final output sent to browser
DEBUG - 2017-07-24 12:12:54 --> Total execution time: 0.0720
DEBUG - 2017-07-24 12:12:54 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:12:54 --> Database Forge Class Initialized
INFO - 2017-07-24 12:12:54 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:12:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:12:54 --> Query error: Column 'user_identifier' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891174, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:12:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:12:55 --> Config Class Initialized
INFO - 2017-07-24 12:12:55 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:12:55 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:12:55 --> Utf8 Class Initialized
INFO - 2017-07-24 12:12:55 --> URI Class Initialized
INFO - 2017-07-24 12:12:55 --> Router Class Initialized
INFO - 2017-07-24 12:12:55 --> Output Class Initialized
INFO - 2017-07-24 12:12:55 --> Security Class Initialized
DEBUG - 2017-07-24 12:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:12:55 --> Input Class Initialized
INFO - 2017-07-24 12:12:55 --> Language Class Initialized
INFO - 2017-07-24 12:12:55 --> Loader Class Initialized
INFO - 2017-07-24 12:12:55 --> Helper loaded: url_helper
INFO - 2017-07-24 12:12:55 --> Helper loaded: form_helper
INFO - 2017-07-24 12:12:55 --> Helper loaded: security_helper
INFO - 2017-07-24 12:12:55 --> Helper loaded: path_helper
INFO - 2017-07-24 12:12:55 --> Helper loaded: common_helper
INFO - 2017-07-24 12:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:12:55 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:12:55 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:12:55 --> Email Class Initialized
INFO - 2017-07-24 12:12:56 --> Form Validation Class Initialized
INFO - 2017-07-24 12:12:56 --> Model Class Initialized
INFO - 2017-07-24 12:12:56 --> Model Class Initialized
INFO - 2017-07-24 12:12:56 --> Model Class Initialized
INFO - 2017-07-24 12:12:56 --> Model Class Initialized
INFO - 2017-07-24 12:12:56 --> Controller Class Initialized
INFO - 2017-07-24 12:12:56 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:12:56 --> Final output sent to browser
DEBUG - 2017-07-24 12:12:56 --> Total execution time: 0.0740
DEBUG - 2017-07-24 12:12:56 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:12:56 --> Database Forge Class Initialized
INFO - 2017-07-24 12:12:56 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:12:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:12:56 --> Query error: Column 'user_identifier' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891176, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:12:56 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:13:32 --> Config Class Initialized
INFO - 2017-07-24 12:13:32 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:13:32 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:13:32 --> Utf8 Class Initialized
INFO - 2017-07-24 12:13:32 --> URI Class Initialized
INFO - 2017-07-24 12:13:32 --> Router Class Initialized
INFO - 2017-07-24 12:13:32 --> Output Class Initialized
INFO - 2017-07-24 12:13:32 --> Security Class Initialized
DEBUG - 2017-07-24 12:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:13:32 --> Input Class Initialized
INFO - 2017-07-24 12:13:32 --> Language Class Initialized
INFO - 2017-07-24 12:13:32 --> Loader Class Initialized
INFO - 2017-07-24 12:13:32 --> Helper loaded: url_helper
INFO - 2017-07-24 12:13:32 --> Helper loaded: form_helper
INFO - 2017-07-24 12:13:32 --> Helper loaded: security_helper
INFO - 2017-07-24 12:13:32 --> Helper loaded: path_helper
INFO - 2017-07-24 12:13:32 --> Helper loaded: common_helper
INFO - 2017-07-24 12:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:13:32 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:13:32 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:13:32 --> Email Class Initialized
INFO - 2017-07-24 12:13:32 --> Form Validation Class Initialized
INFO - 2017-07-24 12:13:32 --> Model Class Initialized
INFO - 2017-07-24 12:13:32 --> Model Class Initialized
INFO - 2017-07-24 12:13:32 --> Model Class Initialized
INFO - 2017-07-24 12:13:32 --> Model Class Initialized
INFO - 2017-07-24 12:13:32 --> Controller Class Initialized
INFO - 2017-07-24 12:13:32 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:13:32 --> Final output sent to browser
DEBUG - 2017-07-24 12:13:32 --> Total execution time: 0.1370
DEBUG - 2017-07-24 12:13:32 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:13:32 --> Database Forge Class Initialized
INFO - 2017-07-24 12:13:32 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:13:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:13:32 --> Query error: Column 'user_identifier' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin', 1500891212, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', '')
INFO - 2017-07-24 12:13:32 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:13:39 --> Config Class Initialized
INFO - 2017-07-24 12:13:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:13:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:13:39 --> Utf8 Class Initialized
INFO - 2017-07-24 12:13:39 --> URI Class Initialized
INFO - 2017-07-24 12:13:39 --> Router Class Initialized
INFO - 2017-07-24 12:13:39 --> Output Class Initialized
INFO - 2017-07-24 12:13:39 --> Security Class Initialized
DEBUG - 2017-07-24 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:13:39 --> Input Class Initialized
INFO - 2017-07-24 12:13:39 --> Language Class Initialized
INFO - 2017-07-24 12:13:39 --> Loader Class Initialized
INFO - 2017-07-24 12:13:39 --> Helper loaded: url_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: form_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: security_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: path_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: common_helper
INFO - 2017-07-24 12:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:13:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:13:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:13:39 --> Email Class Initialized
INFO - 2017-07-24 12:13:39 --> Form Validation Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Controller Class Initialized
INFO - 2017-07-24 12:13:39 --> Config Class Initialized
INFO - 2017-07-24 12:13:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:13:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:13:39 --> Utf8 Class Initialized
INFO - 2017-07-24 12:13:39 --> URI Class Initialized
INFO - 2017-07-24 12:13:39 --> Router Class Initialized
INFO - 2017-07-24 12:13:39 --> Output Class Initialized
INFO - 2017-07-24 12:13:39 --> Security Class Initialized
DEBUG - 2017-07-24 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:13:39 --> Input Class Initialized
INFO - 2017-07-24 12:13:39 --> Language Class Initialized
INFO - 2017-07-24 12:13:39 --> Loader Class Initialized
INFO - 2017-07-24 12:13:39 --> Helper loaded: url_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: form_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: security_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: path_helper
INFO - 2017-07-24 12:13:39 --> Helper loaded: common_helper
INFO - 2017-07-24 12:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:13:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:13:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:13:39 --> Email Class Initialized
INFO - 2017-07-24 12:13:39 --> Form Validation Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Model Class Initialized
INFO - 2017-07-24 12:13:39 --> Controller Class Initialized
INFO - 2017-07-24 12:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:13:39 --> Pagination Class Initialized
ERROR - 2017-07-24 12:13:39 --> Query error: Table 'oncolens.hospital_doctor' doesn't exist - Invalid query: SELECT u.*,GROUP_CONCAT(hn.`hospital_network`SEPARATOR ', ') AS hospital FROM users u LEFT JOIN `hospital_doctor` h ON u.id=h.`doctor_id` LEFT JOIN `hospital_network` hn ON hn.`id`=h.`hospital_id` and hn.is_active='1'  where u.is_active='1' and h.is_active='1'   GROUP BY u.id limit 0,10
INFO - 2017-07-24 12:13:39 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:17:12 --> Config Class Initialized
INFO - 2017-07-24 12:17:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:17:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:17:12 --> Utf8 Class Initialized
INFO - 2017-07-24 12:17:12 --> URI Class Initialized
INFO - 2017-07-24 12:17:12 --> Router Class Initialized
INFO - 2017-07-24 12:17:12 --> Output Class Initialized
INFO - 2017-07-24 12:17:12 --> Security Class Initialized
DEBUG - 2017-07-24 12:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:17:12 --> Input Class Initialized
INFO - 2017-07-24 12:17:12 --> Language Class Initialized
INFO - 2017-07-24 12:17:12 --> Loader Class Initialized
INFO - 2017-07-24 12:17:12 --> Helper loaded: url_helper
INFO - 2017-07-24 12:17:12 --> Helper loaded: form_helper
INFO - 2017-07-24 12:17:12 --> Helper loaded: security_helper
INFO - 2017-07-24 12:17:12 --> Helper loaded: path_helper
INFO - 2017-07-24 12:17:12 --> Helper loaded: common_helper
INFO - 2017-07-24 12:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:17:12 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:17:12 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:17:12 --> Email Class Initialized
INFO - 2017-07-24 12:17:12 --> Form Validation Class Initialized
INFO - 2017-07-24 12:17:12 --> Model Class Initialized
INFO - 2017-07-24 12:17:12 --> Model Class Initialized
INFO - 2017-07-24 12:17:12 --> Model Class Initialized
INFO - 2017-07-24 12:17:12 --> Model Class Initialized
INFO - 2017-07-24 12:17:12 --> Controller Class Initialized
INFO - 2017-07-24 12:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:17:12 --> Pagination Class Initialized
ERROR - 2017-07-24 12:17:12 --> Query error: Unknown column 'h.is_active' in 'where clause' - Invalid query: SELECT u.*,GROUP_CONCAT(hn.`hospital_network`SEPARATOR ', ') AS hospital FROM users u LEFT JOIN `hospital_doctor` h ON u.id=h.`doctor_id` LEFT JOIN `hospital_network` hn ON hn.`id`=h.`hospital_id` and hn.is_active='1'  where u.is_active='1' and h.is_active='1'   GROUP BY u.id limit 0,10
INFO - 2017-07-24 12:17:12 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:17:44 --> Config Class Initialized
INFO - 2017-07-24 12:17:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:17:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:17:44 --> Utf8 Class Initialized
INFO - 2017-07-24 12:17:44 --> URI Class Initialized
INFO - 2017-07-24 12:17:44 --> Router Class Initialized
INFO - 2017-07-24 12:17:44 --> Output Class Initialized
INFO - 2017-07-24 12:17:44 --> Security Class Initialized
DEBUG - 2017-07-24 12:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:17:44 --> Input Class Initialized
INFO - 2017-07-24 12:17:44 --> Language Class Initialized
INFO - 2017-07-24 12:17:44 --> Loader Class Initialized
INFO - 2017-07-24 12:17:44 --> Helper loaded: url_helper
INFO - 2017-07-24 12:17:44 --> Helper loaded: form_helper
INFO - 2017-07-24 12:17:44 --> Helper loaded: security_helper
INFO - 2017-07-24 12:17:44 --> Helper loaded: path_helper
INFO - 2017-07-24 12:17:44 --> Helper loaded: common_helper
INFO - 2017-07-24 12:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:17:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:17:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:17:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:17:44 --> Email Class Initialized
INFO - 2017-07-24 12:17:44 --> Form Validation Class Initialized
INFO - 2017-07-24 12:17:44 --> Model Class Initialized
INFO - 2017-07-24 12:17:44 --> Model Class Initialized
INFO - 2017-07-24 12:17:44 --> Model Class Initialized
INFO - 2017-07-24 12:17:44 --> Model Class Initialized
INFO - 2017-07-24 12:17:44 --> Controller Class Initialized
INFO - 2017-07-24 12:17:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:17:44 --> Pagination Class Initialized
INFO - 2017-07-24 12:17:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\users.php 179
INFO - 2017-07-24 12:17:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:17:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:17:44 --> Final output sent to browser
DEBUG - 2017-07-24 12:17:44 --> Total execution time: 0.1690
DEBUG - 2017-07-24 12:17:44 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:17:44 --> Database Forge Class Initialized
INFO - 2017-07-24 12:17:44 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:17:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:17:44 --> Query error: Column 'user_identifier' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '49ba6f87249290e07b1b1a001d53aa900e991e96', '/oncolens/admin/user', 1500891464, 0, 'Mozilla/5.0 (Windows NT 6.1; rv:43.0) Gecko/20100101 Firefox/43.0', 'http://localhost/oncolens/admin')
INFO - 2017-07-24 12:17:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2017-07-24 12:17:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\oncolens\system\core\Output.php:528) E:\xampp\htdocs\oncolens\system\core\Common.php 569
INFO - 2017-07-24 12:18:22 --> Config Class Initialized
INFO - 2017-07-24 12:18:22 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:22 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:22 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:22 --> URI Class Initialized
INFO - 2017-07-24 12:18:22 --> Router Class Initialized
INFO - 2017-07-24 12:18:22 --> Output Class Initialized
INFO - 2017-07-24 12:18:22 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:22 --> Input Class Initialized
INFO - 2017-07-24 12:18:22 --> Language Class Initialized
INFO - 2017-07-24 12:18:22 --> Loader Class Initialized
INFO - 2017-07-24 12:18:22 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:22 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:22 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:22 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:22 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:22 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:22 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:22 --> Email Class Initialized
INFO - 2017-07-24 12:18:22 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:22 --> Model Class Initialized
INFO - 2017-07-24 12:18:22 --> Model Class Initialized
INFO - 2017-07-24 12:18:22 --> Model Class Initialized
INFO - 2017-07-24 12:18:22 --> Model Class Initialized
INFO - 2017-07-24 12:18:22 --> Controller Class Initialized
INFO - 2017-07-24 12:18:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:18:22 --> Pagination Class Initialized
INFO - 2017-07-24 12:18:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:18:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\users.php 179
INFO - 2017-07-24 12:18:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:18:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:18:22 --> Final output sent to browser
DEBUG - 2017-07-24 12:18:22 --> Total execution time: 0.0810
DEBUG - 2017-07-24 12:18:22 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:18:22 --> Database Forge Class Initialized
INFO - 2017-07-24 12:18:22 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:37 --> Config Class Initialized
INFO - 2017-07-24 12:18:37 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:37 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:37 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:37 --> URI Class Initialized
INFO - 2017-07-24 12:18:37 --> Router Class Initialized
INFO - 2017-07-24 12:18:37 --> Output Class Initialized
INFO - 2017-07-24 12:18:37 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:37 --> Input Class Initialized
INFO - 2017-07-24 12:18:37 --> Language Class Initialized
INFO - 2017-07-24 12:18:37 --> Loader Class Initialized
INFO - 2017-07-24 12:18:37 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:37 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:37 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:37 --> Email Class Initialized
INFO - 2017-07-24 12:18:37 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Controller Class Initialized
INFO - 2017-07-24 12:18:37 --> Config Class Initialized
INFO - 2017-07-24 12:18:37 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:37 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:37 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:37 --> URI Class Initialized
INFO - 2017-07-24 12:18:37 --> Router Class Initialized
INFO - 2017-07-24 12:18:37 --> Output Class Initialized
INFO - 2017-07-24 12:18:37 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:37 --> Input Class Initialized
INFO - 2017-07-24 12:18:37 --> Language Class Initialized
INFO - 2017-07-24 12:18:37 --> Loader Class Initialized
INFO - 2017-07-24 12:18:37 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:37 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:37 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:37 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:37 --> Email Class Initialized
INFO - 2017-07-24 12:18:37 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Model Class Initialized
INFO - 2017-07-24 12:18:37 --> Controller Class Initialized
INFO - 2017-07-24 12:18:37 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:18:37 --> Final output sent to browser
DEBUG - 2017-07-24 12:18:37 --> Total execution time: 0.1340
DEBUG - 2017-07-24 12:18:37 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:18:37 --> Database Forge Class Initialized
INFO - 2017-07-24 12:18:37 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:39 --> Config Class Initialized
INFO - 2017-07-24 12:18:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:39 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:39 --> URI Class Initialized
INFO - 2017-07-24 12:18:39 --> Router Class Initialized
INFO - 2017-07-24 12:18:39 --> Output Class Initialized
INFO - 2017-07-24 12:18:39 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:39 --> Input Class Initialized
INFO - 2017-07-24 12:18:39 --> Language Class Initialized
INFO - 2017-07-24 12:18:39 --> Loader Class Initialized
INFO - 2017-07-24 12:18:39 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:39 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:39 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:40 --> Email Class Initialized
INFO - 2017-07-24 12:18:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Controller Class Initialized
INFO - 2017-07-24 12:18:40 --> Config Class Initialized
INFO - 2017-07-24 12:18:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:40 --> URI Class Initialized
INFO - 2017-07-24 12:18:40 --> Router Class Initialized
INFO - 2017-07-24 12:18:40 --> Output Class Initialized
INFO - 2017-07-24 12:18:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:40 --> Input Class Initialized
INFO - 2017-07-24 12:18:40 --> Language Class Initialized
INFO - 2017-07-24 12:18:40 --> Loader Class Initialized
INFO - 2017-07-24 12:18:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:40 --> Email Class Initialized
INFO - 2017-07-24 12:18:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Model Class Initialized
INFO - 2017-07-24 12:18:40 --> Controller Class Initialized
INFO - 2017-07-24 12:18:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:18:40 --> Final output sent to browser
DEBUG - 2017-07-24 12:18:40 --> Total execution time: 0.0840
DEBUG - 2017-07-24 12:18:40 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:18:40 --> Database Forge Class Initialized
INFO - 2017-07-24 12:18:40 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:47 --> Config Class Initialized
INFO - 2017-07-24 12:18:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:47 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:47 --> URI Class Initialized
INFO - 2017-07-24 12:18:47 --> Router Class Initialized
INFO - 2017-07-24 12:18:47 --> Output Class Initialized
INFO - 2017-07-24 12:18:47 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:47 --> Input Class Initialized
INFO - 2017-07-24 12:18:47 --> Language Class Initialized
INFO - 2017-07-24 12:18:47 --> Loader Class Initialized
INFO - 2017-07-24 12:18:47 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:47 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:47 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:47 --> Email Class Initialized
INFO - 2017-07-24 12:18:47 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Controller Class Initialized
INFO - 2017-07-24 12:18:47 --> Config Class Initialized
INFO - 2017-07-24 12:18:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:47 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:47 --> URI Class Initialized
INFO - 2017-07-24 12:18:47 --> Router Class Initialized
INFO - 2017-07-24 12:18:47 --> Output Class Initialized
INFO - 2017-07-24 12:18:47 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:47 --> Input Class Initialized
INFO - 2017-07-24 12:18:47 --> Language Class Initialized
INFO - 2017-07-24 12:18:47 --> Loader Class Initialized
INFO - 2017-07-24 12:18:47 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:47 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:47 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:47 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:47 --> Email Class Initialized
INFO - 2017-07-24 12:18:47 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Model Class Initialized
INFO - 2017-07-24 12:18:47 --> Controller Class Initialized
INFO - 2017-07-24 12:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:18:47 --> Pagination Class Initialized
INFO - 2017-07-24 12:18:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:18:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\users.php 179
INFO - 2017-07-24 12:18:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:18:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:18:47 --> Final output sent to browser
DEBUG - 2017-07-24 12:18:47 --> Total execution time: 0.0790
DEBUG - 2017-07-24 12:18:47 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:18:47 --> Database Forge Class Initialized
INFO - 2017-07-24 12:18:47 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:49 --> Config Class Initialized
INFO - 2017-07-24 12:18:49 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:18:50 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:18:50 --> Utf8 Class Initialized
INFO - 2017-07-24 12:18:50 --> URI Class Initialized
INFO - 2017-07-24 12:18:50 --> Router Class Initialized
INFO - 2017-07-24 12:18:50 --> Output Class Initialized
INFO - 2017-07-24 12:18:50 --> Security Class Initialized
DEBUG - 2017-07-24 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:18:50 --> Input Class Initialized
INFO - 2017-07-24 12:18:50 --> Language Class Initialized
INFO - 2017-07-24 12:18:50 --> Loader Class Initialized
INFO - 2017-07-24 12:18:50 --> Helper loaded: url_helper
INFO - 2017-07-24 12:18:50 --> Helper loaded: form_helper
INFO - 2017-07-24 12:18:50 --> Helper loaded: security_helper
INFO - 2017-07-24 12:18:50 --> Helper loaded: path_helper
INFO - 2017-07-24 12:18:50 --> Helper loaded: common_helper
INFO - 2017-07-24 12:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:18:50 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:18:50 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:18:50 --> Email Class Initialized
INFO - 2017-07-24 12:18:50 --> Form Validation Class Initialized
INFO - 2017-07-24 12:18:50 --> Model Class Initialized
INFO - 2017-07-24 12:18:50 --> Model Class Initialized
INFO - 2017-07-24 12:18:50 --> Model Class Initialized
INFO - 2017-07-24 12:18:50 --> Model Class Initialized
INFO - 2017-07-24 12:18:50 --> Controller Class Initialized
DEBUG - 2017-07-24 12:18:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:18:50 --> Query error: Table 'oncolens.speciality' doesn't exist - Invalid query: SELECT *
FROM `speciality`
WHERE `is_deleted` = '0'
INFO - 2017-07-24 12:18:50 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:19:01 --> Config Class Initialized
INFO - 2017-07-24 12:19:01 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:01 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:01 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:01 --> URI Class Initialized
INFO - 2017-07-24 12:19:01 --> Router Class Initialized
INFO - 2017-07-24 12:19:01 --> Output Class Initialized
INFO - 2017-07-24 12:19:01 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:01 --> Input Class Initialized
INFO - 2017-07-24 12:19:01 --> Language Class Initialized
INFO - 2017-07-24 12:19:01 --> Loader Class Initialized
INFO - 2017-07-24 12:19:01 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:01 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:01 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:01 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:01 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:01 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:01 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:01 --> Email Class Initialized
INFO - 2017-07-24 12:19:01 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:01 --> Model Class Initialized
INFO - 2017-07-24 12:19:01 --> Model Class Initialized
INFO - 2017-07-24 12:19:01 --> Model Class Initialized
INFO - 2017-07-24 12:19:01 --> Model Class Initialized
INFO - 2017-07-24 12:19:01 --> Controller Class Initialized
INFO - 2017-07-24 12:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:19:01 --> Pagination Class Initialized
INFO - 2017-07-24 12:19:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:19:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\users.php 179
INFO - 2017-07-24 12:19:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:19:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:19:01 --> Final output sent to browser
DEBUG - 2017-07-24 12:19:01 --> Total execution time: 0.0790
DEBUG - 2017-07-24 12:19:01 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:19:01 --> Database Forge Class Initialized
INFO - 2017-07-24 12:19:01 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:07 --> Config Class Initialized
INFO - 2017-07-24 12:19:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:07 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:07 --> URI Class Initialized
INFO - 2017-07-24 12:19:07 --> Router Class Initialized
INFO - 2017-07-24 12:19:07 --> Output Class Initialized
INFO - 2017-07-24 12:19:07 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:07 --> Input Class Initialized
INFO - 2017-07-24 12:19:07 --> Language Class Initialized
INFO - 2017-07-24 12:19:07 --> Loader Class Initialized
INFO - 2017-07-24 12:19:07 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:07 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:07 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:07 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:07 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:07 --> Email Class Initialized
INFO - 2017-07-24 12:19:07 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:07 --> Model Class Initialized
INFO - 2017-07-24 12:19:07 --> Model Class Initialized
INFO - 2017-07-24 12:19:07 --> Model Class Initialized
INFO - 2017-07-24 12:19:07 --> Model Class Initialized
INFO - 2017-07-24 12:19:07 --> Controller Class Initialized
INFO - 2017-07-24 12:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:19:07 --> Pagination Class Initialized
INFO - 2017-07-24 12:19:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\audit_log.php 110
INFO - 2017-07-24 12:19:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/audit_log.php
INFO - 2017-07-24 12:19:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:19:07 --> Final output sent to browser
DEBUG - 2017-07-24 12:19:07 --> Total execution time: 0.1870
DEBUG - 2017-07-24 12:19:07 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:19:07 --> Database Forge Class Initialized
INFO - 2017-07-24 12:19:07 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:19:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:19 --> Config Class Initialized
INFO - 2017-07-24 12:19:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:19 --> URI Class Initialized
INFO - 2017-07-24 12:19:19 --> Router Class Initialized
INFO - 2017-07-24 12:19:19 --> Output Class Initialized
INFO - 2017-07-24 12:19:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:19 --> Input Class Initialized
INFO - 2017-07-24 12:19:19 --> Language Class Initialized
INFO - 2017-07-24 12:19:19 --> Loader Class Initialized
INFO - 2017-07-24 12:19:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:19 --> Email Class Initialized
INFO - 2017-07-24 12:19:19 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:19 --> Model Class Initialized
INFO - 2017-07-24 12:19:19 --> Model Class Initialized
INFO - 2017-07-24 12:19:19 --> Model Class Initialized
INFO - 2017-07-24 12:19:19 --> Model Class Initialized
INFO - 2017-07-24 12:19:19 --> Controller Class Initialized
ERROR - 2017-07-24 12:19:19 --> Query error: Table 'oncolens.page' doesn't exist - Invalid query: SELECT *
FROM `page`
INFO - 2017-07-24 12:19:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:19:24 --> Config Class Initialized
INFO - 2017-07-24 12:19:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:24 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:24 --> URI Class Initialized
INFO - 2017-07-24 12:19:24 --> Router Class Initialized
INFO - 2017-07-24 12:19:24 --> Output Class Initialized
INFO - 2017-07-24 12:19:24 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:24 --> Input Class Initialized
INFO - 2017-07-24 12:19:24 --> Language Class Initialized
INFO - 2017-07-24 12:19:24 --> Loader Class Initialized
INFO - 2017-07-24 12:19:24 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:24 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:24 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:24 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:24 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:24 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:24 --> Email Class Initialized
INFO - 2017-07-24 12:19:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:24 --> Model Class Initialized
INFO - 2017-07-24 12:19:24 --> Model Class Initialized
INFO - 2017-07-24 12:19:24 --> Model Class Initialized
INFO - 2017-07-24 12:19:24 --> Model Class Initialized
INFO - 2017-07-24 12:19:24 --> Controller Class Initialized
INFO - 2017-07-24 12:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:19:24 --> Pagination Class Initialized
INFO - 2017-07-24 12:19:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\audit_log.php 110
INFO - 2017-07-24 12:19:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/audit_log.php
INFO - 2017-07-24 12:19:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:19:24 --> Final output sent to browser
DEBUG - 2017-07-24 12:19:24 --> Total execution time: 0.0900
DEBUG - 2017-07-24 12:19:24 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:19:24 --> Database Forge Class Initialized
INFO - 2017-07-24 12:19:24 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:40 --> Config Class Initialized
INFO - 2017-07-24 12:19:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:40 --> URI Class Initialized
INFO - 2017-07-24 12:19:40 --> Router Class Initialized
INFO - 2017-07-24 12:19:40 --> Output Class Initialized
INFO - 2017-07-24 12:19:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:40 --> Input Class Initialized
INFO - 2017-07-24 12:19:40 --> Language Class Initialized
INFO - 2017-07-24 12:19:40 --> Loader Class Initialized
INFO - 2017-07-24 12:19:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:40 --> Email Class Initialized
INFO - 2017-07-24 12:19:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:40 --> Model Class Initialized
INFO - 2017-07-24 12:19:40 --> Model Class Initialized
INFO - 2017-07-24 12:19:40 --> Model Class Initialized
INFO - 2017-07-24 12:19:40 --> Model Class Initialized
INFO - 2017-07-24 12:19:40 --> Controller Class Initialized
ERROR - 2017-07-24 12:19:40 --> Query error: Table 'oncolens.page' doesn't exist - Invalid query: SELECT *
FROM `page`
INFO - 2017-07-24 12:19:40 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:19:42 --> Config Class Initialized
INFO - 2017-07-24 12:19:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:42 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:42 --> URI Class Initialized
INFO - 2017-07-24 12:19:42 --> Router Class Initialized
INFO - 2017-07-24 12:19:42 --> Output Class Initialized
INFO - 2017-07-24 12:19:42 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:42 --> Input Class Initialized
INFO - 2017-07-24 12:19:42 --> Language Class Initialized
INFO - 2017-07-24 12:19:42 --> Loader Class Initialized
INFO - 2017-07-24 12:19:42 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:42 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:42 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:42 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:42 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:42 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:42 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:42 --> Email Class Initialized
INFO - 2017-07-24 12:19:42 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:42 --> Model Class Initialized
INFO - 2017-07-24 12:19:42 --> Model Class Initialized
INFO - 2017-07-24 12:19:42 --> Model Class Initialized
INFO - 2017-07-24 12:19:42 --> Model Class Initialized
INFO - 2017-07-24 12:19:42 --> Controller Class Initialized
INFO - 2017-07-24 12:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:19:42 --> Pagination Class Initialized
INFO - 2017-07-24 12:19:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\audit_log.php 110
INFO - 2017-07-24 12:19:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/audit_log.php
INFO - 2017-07-24 12:19:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:19:42 --> Final output sent to browser
DEBUG - 2017-07-24 12:19:42 --> Total execution time: 0.1560
DEBUG - 2017-07-24 12:19:42 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:19:42 --> Database Forge Class Initialized
INFO - 2017-07-24 12:19:42 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:44 --> Config Class Initialized
INFO - 2017-07-24 12:19:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:44 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:44 --> URI Class Initialized
INFO - 2017-07-24 12:19:44 --> Router Class Initialized
INFO - 2017-07-24 12:19:44 --> Output Class Initialized
INFO - 2017-07-24 12:19:44 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:44 --> Input Class Initialized
INFO - 2017-07-24 12:19:44 --> Language Class Initialized
INFO - 2017-07-24 12:19:44 --> Loader Class Initialized
INFO - 2017-07-24 12:19:44 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:44 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:44 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:44 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:44 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:44 --> Email Class Initialized
INFO - 2017-07-24 12:19:44 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:44 --> Model Class Initialized
INFO - 2017-07-24 12:19:44 --> Model Class Initialized
INFO - 2017-07-24 12:19:44 --> Model Class Initialized
INFO - 2017-07-24 12:19:44 --> Model Class Initialized
INFO - 2017-07-24 12:19:44 --> Controller Class Initialized
INFO - 2017-07-24 12:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:19:44 --> Pagination Class Initialized
INFO - 2017-07-24 12:19:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:19:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\users.php 179
INFO - 2017-07-24 12:19:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:19:44 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:19:44 --> Final output sent to browser
DEBUG - 2017-07-24 12:19:44 --> Total execution time: 0.0750
DEBUG - 2017-07-24 12:19:44 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:19:44 --> Database Forge Class Initialized
INFO - 2017-07-24 12:19:44 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:47 --> Config Class Initialized
INFO - 2017-07-24 12:19:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:19:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:19:47 --> Utf8 Class Initialized
INFO - 2017-07-24 12:19:47 --> URI Class Initialized
INFO - 2017-07-24 12:19:47 --> Router Class Initialized
INFO - 2017-07-24 12:19:47 --> Output Class Initialized
INFO - 2017-07-24 12:19:47 --> Security Class Initialized
DEBUG - 2017-07-24 12:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:19:47 --> Input Class Initialized
INFO - 2017-07-24 12:19:47 --> Language Class Initialized
INFO - 2017-07-24 12:19:47 --> Loader Class Initialized
INFO - 2017-07-24 12:19:47 --> Helper loaded: url_helper
INFO - 2017-07-24 12:19:47 --> Helper loaded: form_helper
INFO - 2017-07-24 12:19:47 --> Helper loaded: security_helper
INFO - 2017-07-24 12:19:47 --> Helper loaded: path_helper
INFO - 2017-07-24 12:19:47 --> Helper loaded: common_helper
INFO - 2017-07-24 12:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:19:47 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:19:47 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:19:47 --> Email Class Initialized
INFO - 2017-07-24 12:19:47 --> Form Validation Class Initialized
INFO - 2017-07-24 12:19:47 --> Model Class Initialized
INFO - 2017-07-24 12:19:47 --> Model Class Initialized
INFO - 2017-07-24 12:19:47 --> Model Class Initialized
INFO - 2017-07-24 12:19:47 --> Model Class Initialized
INFO - 2017-07-24 12:19:47 --> Controller Class Initialized
DEBUG - 2017-07-24 12:19:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:19:47 --> Query error: Table 'oncolens.speciality' doesn't exist - Invalid query: SELECT *
FROM `speciality`
WHERE `is_deleted` = '0'
INFO - 2017-07-24 12:19:47 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:23:09 --> Config Class Initialized
INFO - 2017-07-24 12:23:09 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:23:09 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:23:09 --> Utf8 Class Initialized
INFO - 2017-07-24 12:23:09 --> URI Class Initialized
INFO - 2017-07-24 12:23:09 --> Router Class Initialized
INFO - 2017-07-24 12:23:09 --> Output Class Initialized
INFO - 2017-07-24 12:23:09 --> Security Class Initialized
DEBUG - 2017-07-24 12:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:23:09 --> Input Class Initialized
INFO - 2017-07-24 12:23:09 --> Language Class Initialized
INFO - 2017-07-24 12:23:09 --> Loader Class Initialized
INFO - 2017-07-24 12:23:09 --> Helper loaded: url_helper
INFO - 2017-07-24 12:23:09 --> Helper loaded: form_helper
INFO - 2017-07-24 12:23:09 --> Helper loaded: security_helper
INFO - 2017-07-24 12:23:09 --> Helper loaded: path_helper
INFO - 2017-07-24 12:23:09 --> Helper loaded: common_helper
INFO - 2017-07-24 12:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:23:09 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:23:09 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:23:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:09 --> Email Class Initialized
INFO - 2017-07-24 12:23:09 --> Form Validation Class Initialized
INFO - 2017-07-24 12:23:09 --> Model Class Initialized
INFO - 2017-07-24 12:23:09 --> Model Class Initialized
INFO - 2017-07-24 12:23:09 --> Model Class Initialized
INFO - 2017-07-24 12:23:09 --> Model Class Initialized
INFO - 2017-07-24 12:23:09 --> Controller Class Initialized
DEBUG - 2017-07-24 12:23:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:23:09 --> Query error: Unknown column 'is_deleted' in 'where clause' - Invalid query: SELECT *
FROM `speciality`
WHERE `is_deleted` = '0'
INFO - 2017-07-24 12:23:09 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:23:31 --> Config Class Initialized
INFO - 2017-07-24 12:23:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:23:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:23:31 --> Utf8 Class Initialized
INFO - 2017-07-24 12:23:31 --> URI Class Initialized
INFO - 2017-07-24 12:23:31 --> Router Class Initialized
INFO - 2017-07-24 12:23:31 --> Output Class Initialized
INFO - 2017-07-24 12:23:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:23:31 --> Input Class Initialized
INFO - 2017-07-24 12:23:31 --> Language Class Initialized
INFO - 2017-07-24 12:23:31 --> Loader Class Initialized
INFO - 2017-07-24 12:23:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:23:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:23:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:23:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:23:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:23:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:23:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:31 --> Email Class Initialized
INFO - 2017-07-24 12:23:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:23:31 --> Model Class Initialized
INFO - 2017-07-24 12:23:31 --> Model Class Initialized
INFO - 2017-07-24 12:23:31 --> Model Class Initialized
INFO - 2017-07-24 12:23:31 --> Model Class Initialized
INFO - 2017-07-24 12:23:31 --> Controller Class Initialized
DEBUG - 2017-07-24 12:23:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\user_add.php 63
ERROR - 2017-07-24 12:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\user_add.php 81
INFO - 2017-07-24 12:23:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:23:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:23:31 --> Final output sent to browser
DEBUG - 2017-07-24 12:23:31 --> Total execution time: 0.0820
DEBUG - 2017-07-24 12:23:31 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:23:31 --> Database Forge Class Initialized
INFO - 2017-07-24 12:23:31 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:42 --> Config Class Initialized
INFO - 2017-07-24 12:23:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:23:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:23:42 --> Utf8 Class Initialized
INFO - 2017-07-24 12:23:42 --> URI Class Initialized
INFO - 2017-07-24 12:23:42 --> Router Class Initialized
INFO - 2017-07-24 12:23:42 --> Output Class Initialized
INFO - 2017-07-24 12:23:42 --> Security Class Initialized
DEBUG - 2017-07-24 12:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:23:42 --> Input Class Initialized
INFO - 2017-07-24 12:23:42 --> Language Class Initialized
INFO - 2017-07-24 12:23:42 --> Loader Class Initialized
INFO - 2017-07-24 12:23:42 --> Helper loaded: url_helper
INFO - 2017-07-24 12:23:42 --> Helper loaded: form_helper
INFO - 2017-07-24 12:23:42 --> Helper loaded: security_helper
INFO - 2017-07-24 12:23:42 --> Helper loaded: path_helper
INFO - 2017-07-24 12:23:42 --> Helper loaded: common_helper
INFO - 2017-07-24 12:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:23:42 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:23:42 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:42 --> Email Class Initialized
INFO - 2017-07-24 12:23:42 --> Form Validation Class Initialized
INFO - 2017-07-24 12:23:42 --> Model Class Initialized
INFO - 2017-07-24 12:23:42 --> Model Class Initialized
INFO - 2017-07-24 12:23:42 --> Model Class Initialized
INFO - 2017-07-24 12:23:42 --> Model Class Initialized
INFO - 2017-07-24 12:23:42 --> Controller Class Initialized
INFO - 2017-07-24 12:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:23:42 --> Pagination Class Initialized
INFO - 2017-07-24 12:23:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:23:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managehospitals.php
INFO - 2017-07-24 12:23:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:23:42 --> Final output sent to browser
DEBUG - 2017-07-24 12:23:42 --> Total execution time: 0.1180
DEBUG - 2017-07-24 12:23:42 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:23:42 --> Database Forge Class Initialized
INFO - 2017-07-24 12:23:42 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:45 --> Config Class Initialized
INFO - 2017-07-24 12:23:45 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:23:45 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:23:45 --> Utf8 Class Initialized
INFO - 2017-07-24 12:23:45 --> URI Class Initialized
INFO - 2017-07-24 12:23:45 --> Router Class Initialized
INFO - 2017-07-24 12:23:45 --> Output Class Initialized
INFO - 2017-07-24 12:23:45 --> Security Class Initialized
DEBUG - 2017-07-24 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:23:45 --> Input Class Initialized
INFO - 2017-07-24 12:23:45 --> Language Class Initialized
INFO - 2017-07-24 12:23:45 --> Loader Class Initialized
INFO - 2017-07-24 12:23:45 --> Helper loaded: url_helper
INFO - 2017-07-24 12:23:45 --> Helper loaded: form_helper
INFO - 2017-07-24 12:23:45 --> Helper loaded: security_helper
INFO - 2017-07-24 12:23:45 --> Helper loaded: path_helper
INFO - 2017-07-24 12:23:45 --> Helper loaded: common_helper
INFO - 2017-07-24 12:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:23:45 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:23:45 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:45 --> Email Class Initialized
INFO - 2017-07-24 12:23:45 --> Form Validation Class Initialized
INFO - 2017-07-24 12:23:45 --> Model Class Initialized
INFO - 2017-07-24 12:23:45 --> Model Class Initialized
INFO - 2017-07-24 12:23:45 --> Model Class Initialized
INFO - 2017-07-24 12:23:45 --> Model Class Initialized
INFO - 2017-07-24 12:23:45 --> Controller Class Initialized
DEBUG - 2017-07-24 12:23:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:45 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:23:45 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/hospital_add.php
INFO - 2017-07-24 12:23:45 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:23:45 --> Final output sent to browser
DEBUG - 2017-07-24 12:23:45 --> Total execution time: 0.1570
DEBUG - 2017-07-24 12:23:45 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:23:45 --> Database Forge Class Initialized
INFO - 2017-07-24 12:23:45 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:59 --> Config Class Initialized
INFO - 2017-07-24 12:23:59 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:23:59 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:23:59 --> Utf8 Class Initialized
INFO - 2017-07-24 12:23:59 --> URI Class Initialized
INFO - 2017-07-24 12:23:59 --> Router Class Initialized
INFO - 2017-07-24 12:23:59 --> Output Class Initialized
INFO - 2017-07-24 12:23:59 --> Security Class Initialized
DEBUG - 2017-07-24 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:23:59 --> Input Class Initialized
INFO - 2017-07-24 12:23:59 --> Language Class Initialized
INFO - 2017-07-24 12:23:59 --> Loader Class Initialized
INFO - 2017-07-24 12:23:59 --> Helper loaded: url_helper
INFO - 2017-07-24 12:23:59 --> Helper loaded: form_helper
INFO - 2017-07-24 12:23:59 --> Helper loaded: security_helper
INFO - 2017-07-24 12:23:59 --> Helper loaded: path_helper
INFO - 2017-07-24 12:23:59 --> Helper loaded: common_helper
INFO - 2017-07-24 12:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:23:59 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:23:59 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:23:59 --> Email Class Initialized
INFO - 2017-07-24 12:23:59 --> Form Validation Class Initialized
INFO - 2017-07-24 12:23:59 --> Model Class Initialized
INFO - 2017-07-24 12:23:59 --> Model Class Initialized
INFO - 2017-07-24 12:23:59 --> Model Class Initialized
INFO - 2017-07-24 12:23:59 --> Model Class Initialized
INFO - 2017-07-24 12:23:59 --> Controller Class Initialized
DEBUG - 2017-07-24 12:23:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:23:59 --> Query error: Unknown column 'added_on' in 'field list' - Invalid query: INSERT INTO `hospital_network` (`hospital_network`, `hospital_address`, `added_on`, `is_active`) VALUES ('Test Hospital', 'Jaipur', '2017-07-24 : 12:23:59', '1')
INFO - 2017-07-24 12:23:59 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:13 --> Config Class Initialized
INFO - 2017-07-24 12:25:13 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:13 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:13 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:13 --> URI Class Initialized
INFO - 2017-07-24 12:25:14 --> Router Class Initialized
INFO - 2017-07-24 12:25:14 --> Output Class Initialized
INFO - 2017-07-24 12:25:14 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:14 --> Input Class Initialized
INFO - 2017-07-24 12:25:14 --> Language Class Initialized
INFO - 2017-07-24 12:25:14 --> Loader Class Initialized
INFO - 2017-07-24 12:25:14 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:14 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:14 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:14 --> Email Class Initialized
INFO - 2017-07-24 12:25:14 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Controller Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:14 --> Config Class Initialized
INFO - 2017-07-24 12:25:14 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:14 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:14 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:14 --> URI Class Initialized
INFO - 2017-07-24 12:25:14 --> Router Class Initialized
INFO - 2017-07-24 12:25:14 --> Output Class Initialized
INFO - 2017-07-24 12:25:14 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:14 --> Input Class Initialized
INFO - 2017-07-24 12:25:14 --> Language Class Initialized
INFO - 2017-07-24 12:25:14 --> Loader Class Initialized
INFO - 2017-07-24 12:25:14 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:14 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:14 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:14 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:14 --> Email Class Initialized
INFO - 2017-07-24 12:25:14 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Model Class Initialized
INFO - 2017-07-24 12:25:14 --> Controller Class Initialized
INFO - 2017-07-24 12:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:25:14 --> Pagination Class Initialized
INFO - 2017-07-24 12:25:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managehospitals.php
INFO - 2017-07-24 12:25:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:14 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:14 --> Total execution time: 0.1250
DEBUG - 2017-07-24 12:25:14 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:14 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:14 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:24 --> Config Class Initialized
INFO - 2017-07-24 12:25:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:24 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:24 --> URI Class Initialized
INFO - 2017-07-24 12:25:24 --> Router Class Initialized
INFO - 2017-07-24 12:25:24 --> Output Class Initialized
INFO - 2017-07-24 12:25:24 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:24 --> Input Class Initialized
INFO - 2017-07-24 12:25:24 --> Language Class Initialized
INFO - 2017-07-24 12:25:24 --> Loader Class Initialized
INFO - 2017-07-24 12:25:24 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:24 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:24 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:24 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:24 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:24 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:24 --> Email Class Initialized
INFO - 2017-07-24 12:25:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:24 --> Model Class Initialized
INFO - 2017-07-24 12:25:24 --> Model Class Initialized
INFO - 2017-07-24 12:25:24 --> Model Class Initialized
INFO - 2017-07-24 12:25:24 --> Model Class Initialized
INFO - 2017-07-24 12:25:24 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:24 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:24 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:26 --> Config Class Initialized
INFO - 2017-07-24 12:25:26 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:26 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:26 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:26 --> URI Class Initialized
INFO - 2017-07-24 12:25:26 --> Router Class Initialized
INFO - 2017-07-24 12:25:26 --> Output Class Initialized
INFO - 2017-07-24 12:25:26 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:26 --> Input Class Initialized
INFO - 2017-07-24 12:25:26 --> Language Class Initialized
INFO - 2017-07-24 12:25:26 --> Loader Class Initialized
INFO - 2017-07-24 12:25:26 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:26 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:26 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:26 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:26 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:26 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:26 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:26 --> Email Class Initialized
INFO - 2017-07-24 12:25:26 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:26 --> Model Class Initialized
INFO - 2017-07-24 12:25:26 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:27 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:27 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:27 --> Config Class Initialized
INFO - 2017-07-24 12:25:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:27 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:27 --> URI Class Initialized
INFO - 2017-07-24 12:25:27 --> Router Class Initialized
INFO - 2017-07-24 12:25:27 --> Output Class Initialized
INFO - 2017-07-24 12:25:27 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:27 --> Input Class Initialized
INFO - 2017-07-24 12:25:27 --> Language Class Initialized
INFO - 2017-07-24 12:25:27 --> Loader Class Initialized
INFO - 2017-07-24 12:25:27 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:27 --> Email Class Initialized
INFO - 2017-07-24 12:25:27 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:27 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:27 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:27 --> Config Class Initialized
INFO - 2017-07-24 12:25:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:27 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:27 --> URI Class Initialized
INFO - 2017-07-24 12:25:27 --> Router Class Initialized
INFO - 2017-07-24 12:25:27 --> Output Class Initialized
INFO - 2017-07-24 12:25:27 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:27 --> Input Class Initialized
INFO - 2017-07-24 12:25:27 --> Language Class Initialized
INFO - 2017-07-24 12:25:27 --> Loader Class Initialized
INFO - 2017-07-24 12:25:27 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:27 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:27 --> Email Class Initialized
INFO - 2017-07-24 12:25:27 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Model Class Initialized
INFO - 2017-07-24 12:25:27 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:27 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:27 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:28 --> Config Class Initialized
INFO - 2017-07-24 12:25:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:28 --> URI Class Initialized
INFO - 2017-07-24 12:25:28 --> Router Class Initialized
INFO - 2017-07-24 12:25:28 --> Output Class Initialized
INFO - 2017-07-24 12:25:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:28 --> Input Class Initialized
INFO - 2017-07-24 12:25:28 --> Language Class Initialized
INFO - 2017-07-24 12:25:28 --> Loader Class Initialized
INFO - 2017-07-24 12:25:28 --> Config Class Initialized
INFO - 2017-07-24 12:25:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:28 --> URI Class Initialized
INFO - 2017-07-24 12:25:28 --> Router Class Initialized
INFO - 2017-07-24 12:25:28 --> Output Class Initialized
INFO - 2017-07-24 12:25:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:28 --> Input Class Initialized
INFO - 2017-07-24 12:25:28 --> Language Class Initialized
INFO - 2017-07-24 12:25:28 --> Loader Class Initialized
INFO - 2017-07-24 12:25:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:28 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:28 --> Database Driver Class Initialized
INFO - 2017-07-24 12:25:28 --> Config Class Initialized
INFO - 2017-07-24 12:25:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:28 --> URI Class Initialized
INFO - 2017-07-24 12:25:28 --> Router Class Initialized
INFO - 2017-07-24 12:25:28 --> Output Class Initialized
INFO - 2017-07-24 12:25:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:28 --> Input Class Initialized
INFO - 2017-07-24 12:25:28 --> Language Class Initialized
INFO - 2017-07-24 12:25:28 --> Loader Class Initialized
INFO - 2017-07-24 12:25:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:28 --> Helper loaded: common_helper
DEBUG - 2017-07-24 12:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:28 --> Email Class Initialized
INFO - 2017-07-24 12:25:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:28 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:28 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:28 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:28 --> Email Class Initialized
INFO - 2017-07-24 12:25:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:28 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:28 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:28 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:28 --> Email Class Initialized
INFO - 2017-07-24 12:25:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Model Class Initialized
INFO - 2017-07-24 12:25:28 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:28 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:28 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:29 --> Config Class Initialized
INFO - 2017-07-24 12:25:29 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:29 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:29 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:29 --> URI Class Initialized
INFO - 2017-07-24 12:25:29 --> Router Class Initialized
INFO - 2017-07-24 12:25:29 --> Output Class Initialized
INFO - 2017-07-24 12:25:29 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:29 --> Input Class Initialized
INFO - 2017-07-24 12:25:29 --> Language Class Initialized
INFO - 2017-07-24 12:25:29 --> Loader Class Initialized
INFO - 2017-07-24 12:25:29 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:29 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:29 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:29 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:29 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:29 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:29 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:29 --> Email Class Initialized
INFO - 2017-07-24 12:25:29 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:29 --> Model Class Initialized
INFO - 2017-07-24 12:25:29 --> Model Class Initialized
INFO - 2017-07-24 12:25:29 --> Model Class Initialized
INFO - 2017-07-24 12:25:29 --> Model Class Initialized
INFO - 2017-07-24 12:25:29 --> Controller Class Initialized
DEBUG - 2017-07-24 12:25:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/hospital_add.php
INFO - 2017-07-24 12:25:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:29 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:29 --> Total execution time: 0.0680
DEBUG - 2017-07-24 12:25:29 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:29 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:29 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:32 --> Config Class Initialized
INFO - 2017-07-24 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:32 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:32 --> URI Class Initialized
INFO - 2017-07-24 12:25:32 --> Router Class Initialized
INFO - 2017-07-24 12:25:32 --> Output Class Initialized
INFO - 2017-07-24 12:25:32 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:32 --> Input Class Initialized
INFO - 2017-07-24 12:25:32 --> Language Class Initialized
INFO - 2017-07-24 12:25:32 --> Loader Class Initialized
INFO - 2017-07-24 12:25:32 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:32 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:32 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:32 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:32 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:32 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:32 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:32 --> Email Class Initialized
INFO - 2017-07-24 12:25:32 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:32 --> Model Class Initialized
INFO - 2017-07-24 12:25:32 --> Model Class Initialized
INFO - 2017-07-24 12:25:32 --> Model Class Initialized
INFO - 2017-07-24 12:25:32 --> Model Class Initialized
INFO - 2017-07-24 12:25:32 --> Controller Class Initialized
DEBUG - 2017-07-24 12:25:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:33 --> Config Class Initialized
INFO - 2017-07-24 12:25:33 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:33 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:33 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:33 --> URI Class Initialized
INFO - 2017-07-24 12:25:33 --> Router Class Initialized
INFO - 2017-07-24 12:25:33 --> Output Class Initialized
INFO - 2017-07-24 12:25:33 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:33 --> Input Class Initialized
INFO - 2017-07-24 12:25:33 --> Language Class Initialized
INFO - 2017-07-24 12:25:33 --> Loader Class Initialized
INFO - 2017-07-24 12:25:33 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:33 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:33 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:33 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:33 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:33 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:33 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:33 --> Email Class Initialized
INFO - 2017-07-24 12:25:33 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:33 --> Model Class Initialized
INFO - 2017-07-24 12:25:33 --> Model Class Initialized
INFO - 2017-07-24 12:25:33 --> Model Class Initialized
INFO - 2017-07-24 12:25:33 --> Model Class Initialized
INFO - 2017-07-24 12:25:33 --> Controller Class Initialized
INFO - 2017-07-24 12:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:25:33 --> Pagination Class Initialized
INFO - 2017-07-24 12:25:33 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:33 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managehospitals.php
INFO - 2017-07-24 12:25:33 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:33 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:33 --> Total execution time: 0.0730
DEBUG - 2017-07-24 12:25:33 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:33 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:33 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:36 --> Config Class Initialized
INFO - 2017-07-24 12:25:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:36 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:36 --> URI Class Initialized
INFO - 2017-07-24 12:25:36 --> Router Class Initialized
INFO - 2017-07-24 12:25:36 --> Output Class Initialized
INFO - 2017-07-24 12:25:36 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:36 --> Input Class Initialized
INFO - 2017-07-24 12:25:36 --> Language Class Initialized
INFO - 2017-07-24 12:25:36 --> Loader Class Initialized
INFO - 2017-07-24 12:25:36 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:36 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:36 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:36 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:36 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:36 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:36 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:36 --> Email Class Initialized
INFO - 2017-07-24 12:25:36 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:36 --> Model Class Initialized
INFO - 2017-07-24 12:25:36 --> Model Class Initialized
INFO - 2017-07-24 12:25:36 --> Model Class Initialized
INFO - 2017-07-24 12:25:36 --> Model Class Initialized
INFO - 2017-07-24 12:25:36 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:36 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:40 --> Config Class Initialized
INFO - 2017-07-24 12:25:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:40 --> URI Class Initialized
INFO - 2017-07-24 12:25:40 --> Router Class Initialized
INFO - 2017-07-24 12:25:40 --> Output Class Initialized
INFO - 2017-07-24 12:25:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:40 --> Input Class Initialized
INFO - 2017-07-24 12:25:40 --> Language Class Initialized
INFO - 2017-07-24 12:25:40 --> Loader Class Initialized
INFO - 2017-07-24 12:25:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:40 --> Email Class Initialized
INFO - 2017-07-24 12:25:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:40 --> Model Class Initialized
INFO - 2017-07-24 12:25:40 --> Model Class Initialized
INFO - 2017-07-24 12:25:40 --> Model Class Initialized
INFO - 2017-07-24 12:25:40 --> Model Class Initialized
INFO - 2017-07-24 12:25:40 --> Controller Class Initialized
DEBUG - 2017-07-24 12:25:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/hospital_add.php
INFO - 2017-07-24 12:25:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:40 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:40 --> Total execution time: 0.0860
DEBUG - 2017-07-24 12:25:40 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:40 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:40 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:42 --> Config Class Initialized
INFO - 2017-07-24 12:25:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:42 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:42 --> URI Class Initialized
INFO - 2017-07-24 12:25:42 --> Router Class Initialized
INFO - 2017-07-24 12:25:42 --> Output Class Initialized
INFO - 2017-07-24 12:25:42 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:42 --> Input Class Initialized
INFO - 2017-07-24 12:25:42 --> Language Class Initialized
INFO - 2017-07-24 12:25:42 --> Loader Class Initialized
INFO - 2017-07-24 12:25:42 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:42 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:42 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:42 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:42 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:43 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:43 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:43 --> Email Class Initialized
INFO - 2017-07-24 12:25:43 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:43 --> Model Class Initialized
INFO - 2017-07-24 12:25:43 --> Model Class Initialized
INFO - 2017-07-24 12:25:43 --> Model Class Initialized
INFO - 2017-07-24 12:25:43 --> Model Class Initialized
INFO - 2017-07-24 12:25:43 --> Controller Class Initialized
INFO - 2017-07-24 12:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:25:43 --> Pagination Class Initialized
INFO - 2017-07-24 12:25:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managehospitals.php
INFO - 2017-07-24 12:25:43 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:43 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:43 --> Total execution time: 0.0800
DEBUG - 2017-07-24 12:25:43 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:43 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:43 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:51 --> Config Class Initialized
INFO - 2017-07-24 12:25:51 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:51 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:51 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:51 --> URI Class Initialized
INFO - 2017-07-24 12:25:51 --> Router Class Initialized
INFO - 2017-07-24 12:25:51 --> Output Class Initialized
INFO - 2017-07-24 12:25:51 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:51 --> Input Class Initialized
INFO - 2017-07-24 12:25:51 --> Language Class Initialized
INFO - 2017-07-24 12:25:51 --> Loader Class Initialized
INFO - 2017-07-24 12:25:51 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:51 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:51 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:51 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:51 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:51 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:51 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:51 --> Email Class Initialized
INFO - 2017-07-24 12:25:51 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:51 --> Model Class Initialized
INFO - 2017-07-24 12:25:51 --> Model Class Initialized
INFO - 2017-07-24 12:25:51 --> Model Class Initialized
INFO - 2017-07-24 12:25:51 --> Model Class Initialized
INFO - 2017-07-24 12:25:51 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:51 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:51 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:52 --> Config Class Initialized
INFO - 2017-07-24 12:25:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:52 --> URI Class Initialized
INFO - 2017-07-24 12:25:52 --> Router Class Initialized
INFO - 2017-07-24 12:25:52 --> Output Class Initialized
INFO - 2017-07-24 12:25:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:52 --> Input Class Initialized
INFO - 2017-07-24 12:25:52 --> Language Class Initialized
INFO - 2017-07-24 12:25:52 --> Loader Class Initialized
INFO - 2017-07-24 12:25:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:52 --> Email Class Initialized
INFO - 2017-07-24 12:25:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:52 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:52 --> Config Class Initialized
INFO - 2017-07-24 12:25:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:52 --> URI Class Initialized
INFO - 2017-07-24 12:25:52 --> Router Class Initialized
INFO - 2017-07-24 12:25:52 --> Output Class Initialized
INFO - 2017-07-24 12:25:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:52 --> Input Class Initialized
INFO - 2017-07-24 12:25:52 --> Language Class Initialized
INFO - 2017-07-24 12:25:52 --> Loader Class Initialized
INFO - 2017-07-24 12:25:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:52 --> Email Class Initialized
INFO - 2017-07-24 12:25:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:52 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:52 --> Config Class Initialized
INFO - 2017-07-24 12:25:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:52 --> URI Class Initialized
INFO - 2017-07-24 12:25:52 --> Router Class Initialized
INFO - 2017-07-24 12:25:52 --> Output Class Initialized
INFO - 2017-07-24 12:25:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:52 --> Input Class Initialized
INFO - 2017-07-24 12:25:52 --> Language Class Initialized
INFO - 2017-07-24 12:25:52 --> Loader Class Initialized
INFO - 2017-07-24 12:25:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:52 --> Email Class Initialized
INFO - 2017-07-24 12:25:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:52 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:52 --> Config Class Initialized
INFO - 2017-07-24 12:25:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:52 --> URI Class Initialized
INFO - 2017-07-24 12:25:52 --> Router Class Initialized
INFO - 2017-07-24 12:25:52 --> Output Class Initialized
INFO - 2017-07-24 12:25:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:52 --> Input Class Initialized
INFO - 2017-07-24 12:25:52 --> Language Class Initialized
INFO - 2017-07-24 12:25:52 --> Loader Class Initialized
INFO - 2017-07-24 12:25:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:52 --> Email Class Initialized
INFO - 2017-07-24 12:25:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:52 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:52 --> Config Class Initialized
INFO - 2017-07-24 12:25:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:52 --> URI Class Initialized
INFO - 2017-07-24 12:25:52 --> Router Class Initialized
INFO - 2017-07-24 12:25:52 --> Output Class Initialized
INFO - 2017-07-24 12:25:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:52 --> Input Class Initialized
INFO - 2017-07-24 12:25:52 --> Language Class Initialized
INFO - 2017-07-24 12:25:52 --> Loader Class Initialized
INFO - 2017-07-24 12:25:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:52 --> Email Class Initialized
INFO - 2017-07-24 12:25:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Model Class Initialized
INFO - 2017-07-24 12:25:52 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:52 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:53 --> Config Class Initialized
INFO - 2017-07-24 12:25:53 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:53 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:53 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:53 --> URI Class Initialized
INFO - 2017-07-24 12:25:53 --> Router Class Initialized
INFO - 2017-07-24 12:25:53 --> Output Class Initialized
INFO - 2017-07-24 12:25:53 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:53 --> Input Class Initialized
INFO - 2017-07-24 12:25:53 --> Language Class Initialized
INFO - 2017-07-24 12:25:53 --> Loader Class Initialized
INFO - 2017-07-24 12:25:53 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:53 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:53 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:53 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:53 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:53 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:53 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:53 --> Email Class Initialized
INFO - 2017-07-24 12:25:53 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:53 --> Model Class Initialized
INFO - 2017-07-24 12:25:53 --> Model Class Initialized
INFO - 2017-07-24 12:25:53 --> Model Class Initialized
INFO - 2017-07-24 12:25:53 --> Model Class Initialized
INFO - 2017-07-24 12:25:53 --> Controller Class Initialized
ERROR - 2017-07-24 12:25:53 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT `hn`.`id`, COUNT(DISTINCT(hd.doctor_id)) as doctor, COUNT(DISTINCT(htb.tumor_id)) as tumor_board
FROM `hospital_network` `hn`
INNER JOIN `hospital_doctor` `hd` ON `hd`.`hospital_id`  =  `hn`.`id`
INNER JOIN `hospital_tumor_board` `htb` ON `htb`.`hospital_id`  =  `hn`.`id`
WHERE `hn`.`id` = '1'
INFO - 2017-07-24 12:25:53 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:25:55 --> Config Class Initialized
INFO - 2017-07-24 12:25:55 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:55 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:55 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:55 --> URI Class Initialized
INFO - 2017-07-24 12:25:55 --> Router Class Initialized
INFO - 2017-07-24 12:25:55 --> Output Class Initialized
INFO - 2017-07-24 12:25:55 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:55 --> Input Class Initialized
INFO - 2017-07-24 12:25:55 --> Language Class Initialized
INFO - 2017-07-24 12:25:55 --> Loader Class Initialized
INFO - 2017-07-24 12:25:55 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:55 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:55 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:55 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:55 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:55 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:55 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:55 --> Email Class Initialized
INFO - 2017-07-24 12:25:55 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:55 --> Model Class Initialized
INFO - 2017-07-24 12:25:55 --> Model Class Initialized
INFO - 2017-07-24 12:25:55 --> Model Class Initialized
INFO - 2017-07-24 12:25:55 --> Model Class Initialized
INFO - 2017-07-24 12:25:55 --> Controller Class Initialized
INFO - 2017-07-24 12:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:25:55 --> Pagination Class Initialized
INFO - 2017-07-24 12:25:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:25:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:25:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:55 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:55 --> Total execution time: 0.1070
DEBUG - 2017-07-24 12:25:55 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:55 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:55 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:57 --> Config Class Initialized
INFO - 2017-07-24 12:25:57 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:25:57 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:25:57 --> Utf8 Class Initialized
INFO - 2017-07-24 12:25:57 --> URI Class Initialized
INFO - 2017-07-24 12:25:57 --> Router Class Initialized
INFO - 2017-07-24 12:25:57 --> Output Class Initialized
INFO - 2017-07-24 12:25:57 --> Security Class Initialized
DEBUG - 2017-07-24 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:25:57 --> Input Class Initialized
INFO - 2017-07-24 12:25:57 --> Language Class Initialized
INFO - 2017-07-24 12:25:57 --> Loader Class Initialized
INFO - 2017-07-24 12:25:57 --> Helper loaded: url_helper
INFO - 2017-07-24 12:25:57 --> Helper loaded: form_helper
INFO - 2017-07-24 12:25:57 --> Helper loaded: security_helper
INFO - 2017-07-24 12:25:57 --> Helper loaded: path_helper
INFO - 2017-07-24 12:25:57 --> Helper loaded: common_helper
INFO - 2017-07-24 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:25:57 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:25:57 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:57 --> Email Class Initialized
INFO - 2017-07-24 12:25:57 --> Form Validation Class Initialized
INFO - 2017-07-24 12:25:57 --> Model Class Initialized
INFO - 2017-07-24 12:25:57 --> Model Class Initialized
INFO - 2017-07-24 12:25:57 --> Model Class Initialized
INFO - 2017-07-24 12:25:57 --> Model Class Initialized
INFO - 2017-07-24 12:25:57 --> Controller Class Initialized
DEBUG - 2017-07-24 12:25:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:25:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\user_add.php 63
INFO - 2017-07-24 12:25:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:25:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:25:57 --> Final output sent to browser
DEBUG - 2017-07-24 12:25:57 --> Total execution time: 0.1190
DEBUG - 2017-07-24 12:25:57 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:25:57 --> Database Forge Class Initialized
INFO - 2017-07-24 12:25:57 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:26:02 --> Config Class Initialized
INFO - 2017-07-24 12:26:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:26:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:26:02 --> Utf8 Class Initialized
INFO - 2017-07-24 12:26:02 --> URI Class Initialized
INFO - 2017-07-24 12:26:02 --> Router Class Initialized
INFO - 2017-07-24 12:26:02 --> Output Class Initialized
INFO - 2017-07-24 12:26:02 --> Security Class Initialized
DEBUG - 2017-07-24 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:26:02 --> Input Class Initialized
INFO - 2017-07-24 12:26:02 --> Language Class Initialized
INFO - 2017-07-24 12:26:02 --> Loader Class Initialized
INFO - 2017-07-24 12:26:02 --> Helper loaded: url_helper
INFO - 2017-07-24 12:26:02 --> Helper loaded: form_helper
INFO - 2017-07-24 12:26:02 --> Helper loaded: security_helper
INFO - 2017-07-24 12:26:02 --> Helper loaded: path_helper
INFO - 2017-07-24 12:26:02 --> Helper loaded: common_helper
INFO - 2017-07-24 12:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:26:02 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:26:02 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:26:02 --> Email Class Initialized
INFO - 2017-07-24 12:26:02 --> Form Validation Class Initialized
INFO - 2017-07-24 12:26:02 --> Model Class Initialized
INFO - 2017-07-24 12:26:02 --> Model Class Initialized
INFO - 2017-07-24 12:26:02 --> Model Class Initialized
INFO - 2017-07-24 12:26:02 --> Model Class Initialized
INFO - 2017-07-24 12:26:02 --> Controller Class Initialized
INFO - 2017-07-24 12:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:26:02 --> Pagination Class Initialized
ERROR - 2017-07-24 12:26:02 --> Query error: Table 'oncolens.hospital_tumor_board' doesn't exist - Invalid query: SELECT *
FROM `hospital_tumor_board`
INNER JOIN `hospital_network` ON `hospital_network`.`id`  =  `hospital_tumor_board`.`hospital_id`
INNER JOIN `tumor_board` ON `tumor_board`.`tumor_id`  =  `hospital_tumor_board`.`tumor_id`
INFO - 2017-07-24 12:26:02 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:28:03 --> Config Class Initialized
INFO - 2017-07-24 12:28:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:28:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:28:03 --> Utf8 Class Initialized
INFO - 2017-07-24 12:28:03 --> URI Class Initialized
INFO - 2017-07-24 12:28:03 --> Router Class Initialized
INFO - 2017-07-24 12:28:03 --> Output Class Initialized
INFO - 2017-07-24 12:28:03 --> Security Class Initialized
DEBUG - 2017-07-24 12:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:28:03 --> Input Class Initialized
INFO - 2017-07-24 12:28:03 --> Language Class Initialized
INFO - 2017-07-24 12:28:03 --> Loader Class Initialized
INFO - 2017-07-24 12:28:03 --> Helper loaded: url_helper
INFO - 2017-07-24 12:28:03 --> Helper loaded: form_helper
INFO - 2017-07-24 12:28:03 --> Helper loaded: security_helper
INFO - 2017-07-24 12:28:03 --> Helper loaded: path_helper
INFO - 2017-07-24 12:28:03 --> Helper loaded: common_helper
INFO - 2017-07-24 12:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:28:03 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:28:03 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:28:04 --> Email Class Initialized
INFO - 2017-07-24 12:28:04 --> Form Validation Class Initialized
INFO - 2017-07-24 12:28:04 --> Model Class Initialized
INFO - 2017-07-24 12:28:04 --> Model Class Initialized
INFO - 2017-07-24 12:28:04 --> Model Class Initialized
INFO - 2017-07-24 12:28:04 --> Model Class Initialized
INFO - 2017-07-24 12:28:04 --> Controller Class Initialized
INFO - 2017-07-24 12:28:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:28:04 --> Pagination Class Initialized
ERROR - 2017-07-24 12:28:04 --> Query error: Unknown column 'tumor_board.tumor_id' in 'on clause' - Invalid query: SELECT *
FROM `hospital_tumor_board`
INNER JOIN `hospital_network` ON `hospital_network`.`id`  =  `hospital_tumor_board`.`hospital_id`
INNER JOIN `tumor_board` ON `tumor_board`.`tumor_id`  =  `hospital_tumor_board`.`tumor_id`
INFO - 2017-07-24 12:28:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:28:28 --> Config Class Initialized
INFO - 2017-07-24 12:28:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:28:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:28:28 --> URI Class Initialized
INFO - 2017-07-24 12:28:28 --> Router Class Initialized
INFO - 2017-07-24 12:28:28 --> Output Class Initialized
INFO - 2017-07-24 12:28:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:28:28 --> Input Class Initialized
INFO - 2017-07-24 12:28:28 --> Language Class Initialized
INFO - 2017-07-24 12:28:28 --> Loader Class Initialized
INFO - 2017-07-24 12:28:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:28:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:28:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:28:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:28:28 --> Helper loaded: common_helper
INFO - 2017-07-24 12:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:28:28 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:28:28 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:28:28 --> Email Class Initialized
INFO - 2017-07-24 12:28:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:28:28 --> Model Class Initialized
INFO - 2017-07-24 12:28:28 --> Model Class Initialized
INFO - 2017-07-24 12:28:28 --> Model Class Initialized
INFO - 2017-07-24 12:28:28 --> Model Class Initialized
INFO - 2017-07-24 12:28:28 --> Controller Class Initialized
INFO - 2017-07-24 12:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:28:28 --> Pagination Class Initialized
INFO - 2017-07-24 12:28:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:28:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managetumorboards.php
INFO - 2017-07-24 12:28:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:28:28 --> Final output sent to browser
DEBUG - 2017-07-24 12:28:28 --> Total execution time: 0.0980
DEBUG - 2017-07-24 12:28:28 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:28:28 --> Database Forge Class Initialized
INFO - 2017-07-24 12:28:28 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:28:31 --> Config Class Initialized
INFO - 2017-07-24 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:28:31 --> Utf8 Class Initialized
INFO - 2017-07-24 12:28:31 --> URI Class Initialized
INFO - 2017-07-24 12:28:31 --> Router Class Initialized
INFO - 2017-07-24 12:28:31 --> Output Class Initialized
INFO - 2017-07-24 12:28:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:28:31 --> Input Class Initialized
INFO - 2017-07-24 12:28:31 --> Language Class Initialized
INFO - 2017-07-24 12:28:31 --> Loader Class Initialized
INFO - 2017-07-24 12:28:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:28:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:28:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:28:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:28:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:28:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:28:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:28:31 --> Email Class Initialized
INFO - 2017-07-24 12:28:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:28:31 --> Model Class Initialized
INFO - 2017-07-24 12:28:31 --> Model Class Initialized
INFO - 2017-07-24 12:28:31 --> Model Class Initialized
INFO - 2017-07-24 12:28:31 --> Model Class Initialized
INFO - 2017-07-24 12:28:31 --> Controller Class Initialized
DEBUG - 2017-07-24 12:28:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:28:31 --> Query error: Table 'oncolens.cancercategories' doesn't exist - Invalid query: SELECT *
FROM `cancercategories`
INFO - 2017-07-24 12:28:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:30:04 --> Config Class Initialized
INFO - 2017-07-24 12:30:04 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:30:04 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:30:04 --> Utf8 Class Initialized
INFO - 2017-07-24 12:30:04 --> URI Class Initialized
INFO - 2017-07-24 12:30:04 --> Router Class Initialized
INFO - 2017-07-24 12:30:04 --> Output Class Initialized
INFO - 2017-07-24 12:30:04 --> Security Class Initialized
DEBUG - 2017-07-24 12:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:30:04 --> Input Class Initialized
INFO - 2017-07-24 12:30:04 --> Language Class Initialized
INFO - 2017-07-24 12:30:04 --> Loader Class Initialized
INFO - 2017-07-24 12:30:04 --> Helper loaded: url_helper
INFO - 2017-07-24 12:30:04 --> Helper loaded: form_helper
INFO - 2017-07-24 12:30:04 --> Helper loaded: security_helper
INFO - 2017-07-24 12:30:04 --> Helper loaded: path_helper
INFO - 2017-07-24 12:30:04 --> Helper loaded: common_helper
INFO - 2017-07-24 12:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:30:04 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:30:04 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:04 --> Email Class Initialized
INFO - 2017-07-24 12:30:04 --> Form Validation Class Initialized
INFO - 2017-07-24 12:30:04 --> Model Class Initialized
INFO - 2017-07-24 12:30:04 --> Model Class Initialized
INFO - 2017-07-24 12:30:04 --> Model Class Initialized
INFO - 2017-07-24 12:30:04 --> Model Class Initialized
INFO - 2017-07-24 12:30:04 --> Controller Class Initialized
DEBUG - 2017-07-24 12:30:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:04 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:30:04 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\tumorboard_add.php 49
INFO - 2017-07-24 12:30:04 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/tumorboard_add.php
INFO - 2017-07-24 12:30:04 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:30:04 --> Final output sent to browser
DEBUG - 2017-07-24 12:30:04 --> Total execution time: 0.1360
DEBUG - 2017-07-24 12:30:04 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:30:04 --> Database Forge Class Initialized
INFO - 2017-07-24 12:30:04 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:30:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:19 --> Config Class Initialized
INFO - 2017-07-24 12:30:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:30:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:30:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:30:19 --> URI Class Initialized
INFO - 2017-07-24 12:30:19 --> Router Class Initialized
INFO - 2017-07-24 12:30:19 --> Output Class Initialized
INFO - 2017-07-24 12:30:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:30:19 --> Input Class Initialized
INFO - 2017-07-24 12:30:19 --> Language Class Initialized
INFO - 2017-07-24 12:30:19 --> Loader Class Initialized
INFO - 2017-07-24 12:30:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:30:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:30:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:19 --> Email Class Initialized
INFO - 2017-07-24 12:30:19 --> Form Validation Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Controller Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:30:19 --> Config Class Initialized
INFO - 2017-07-24 12:30:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:30:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:30:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:30:19 --> URI Class Initialized
INFO - 2017-07-24 12:30:19 --> Router Class Initialized
INFO - 2017-07-24 12:30:19 --> Output Class Initialized
INFO - 2017-07-24 12:30:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:30:19 --> Input Class Initialized
INFO - 2017-07-24 12:30:19 --> Language Class Initialized
INFO - 2017-07-24 12:30:19 --> Loader Class Initialized
INFO - 2017-07-24 12:30:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:30:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:30:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:30:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:19 --> Email Class Initialized
INFO - 2017-07-24 12:30:19 --> Form Validation Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Model Class Initialized
INFO - 2017-07-24 12:30:19 --> Controller Class Initialized
INFO - 2017-07-24 12:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:30:19 --> Pagination Class Initialized
INFO - 2017-07-24 12:30:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:30:19 --> Severity: Notice --> Undefined property: stdClass::$cancer_type E:\xampp\htdocs\oncolens\application\views\admin\managetumorboards.php 86
INFO - 2017-07-24 12:30:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/managetumorboards.php
INFO - 2017-07-24 12:30:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:30:19 --> Final output sent to browser
DEBUG - 2017-07-24 12:30:19 --> Total execution time: 0.0810
DEBUG - 2017-07-24 12:30:19 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:30:19 --> Database Forge Class Initialized
INFO - 2017-07-24 12:30:19 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:24 --> Config Class Initialized
INFO - 2017-07-24 12:30:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:30:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:30:24 --> Utf8 Class Initialized
INFO - 2017-07-24 12:30:24 --> URI Class Initialized
INFO - 2017-07-24 12:30:24 --> Router Class Initialized
INFO - 2017-07-24 12:30:24 --> Output Class Initialized
INFO - 2017-07-24 12:30:24 --> Security Class Initialized
DEBUG - 2017-07-24 12:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:30:24 --> Input Class Initialized
INFO - 2017-07-24 12:30:24 --> Language Class Initialized
INFO - 2017-07-24 12:30:24 --> Loader Class Initialized
INFO - 2017-07-24 12:30:24 --> Helper loaded: url_helper
INFO - 2017-07-24 12:30:24 --> Helper loaded: form_helper
INFO - 2017-07-24 12:30:24 --> Helper loaded: security_helper
INFO - 2017-07-24 12:30:24 --> Helper loaded: path_helper
INFO - 2017-07-24 12:30:24 --> Helper loaded: common_helper
INFO - 2017-07-24 12:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:30:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:30:24 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:30:24 --> Email Class Initialized
INFO - 2017-07-24 12:30:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:30:24 --> Model Class Initialized
INFO - 2017-07-24 12:30:24 --> Model Class Initialized
INFO - 2017-07-24 12:30:24 --> Model Class Initialized
INFO - 2017-07-24 12:30:24 --> Model Class Initialized
INFO - 2017-07-24 12:30:24 --> Controller Class Initialized
ERROR - 2017-07-24 12:30:24 --> Query error: Table 'oncolens.page' doesn't exist - Invalid query: SELECT *
FROM `page`
INFO - 2017-07-24 12:30:24 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:32:27 --> Config Class Initialized
INFO - 2017-07-24 12:32:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:32:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:32:27 --> Utf8 Class Initialized
INFO - 2017-07-24 12:32:27 --> URI Class Initialized
INFO - 2017-07-24 12:32:27 --> Router Class Initialized
INFO - 2017-07-24 12:32:27 --> Output Class Initialized
INFO - 2017-07-24 12:32:27 --> Security Class Initialized
DEBUG - 2017-07-24 12:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:32:27 --> Input Class Initialized
INFO - 2017-07-24 12:32:27 --> Language Class Initialized
INFO - 2017-07-24 12:32:27 --> Loader Class Initialized
INFO - 2017-07-24 12:32:27 --> Helper loaded: url_helper
INFO - 2017-07-24 12:32:27 --> Helper loaded: form_helper
INFO - 2017-07-24 12:32:27 --> Helper loaded: security_helper
INFO - 2017-07-24 12:32:27 --> Helper loaded: path_helper
INFO - 2017-07-24 12:32:27 --> Helper loaded: common_helper
INFO - 2017-07-24 12:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:32:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:32:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:32:27 --> Email Class Initialized
INFO - 2017-07-24 12:32:27 --> Form Validation Class Initialized
INFO - 2017-07-24 12:32:27 --> Model Class Initialized
INFO - 2017-07-24 12:32:27 --> Model Class Initialized
INFO - 2017-07-24 12:32:27 --> Model Class Initialized
INFO - 2017-07-24 12:32:27 --> Model Class Initialized
INFO - 2017-07-24 12:32:27 --> Controller Class Initialized
INFO - 2017-07-24 12:32:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:32:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/page.php
INFO - 2017-07-24 12:32:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:32:27 --> Final output sent to browser
DEBUG - 2017-07-24 12:32:27 --> Total execution time: 0.4610
DEBUG - 2017-07-24 12:32:27 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:32:27 --> Database Forge Class Initialized
INFO - 2017-07-24 12:32:27 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:32:44 --> Config Class Initialized
INFO - 2017-07-24 12:32:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:32:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:32:44 --> Utf8 Class Initialized
INFO - 2017-07-24 12:32:44 --> URI Class Initialized
INFO - 2017-07-24 12:32:44 --> Router Class Initialized
INFO - 2017-07-24 12:32:44 --> Output Class Initialized
INFO - 2017-07-24 12:32:44 --> Security Class Initialized
DEBUG - 2017-07-24 12:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:32:44 --> Input Class Initialized
INFO - 2017-07-24 12:32:44 --> Language Class Initialized
INFO - 2017-07-24 12:32:44 --> Loader Class Initialized
INFO - 2017-07-24 12:32:44 --> Helper loaded: url_helper
INFO - 2017-07-24 12:32:44 --> Helper loaded: form_helper
INFO - 2017-07-24 12:32:44 --> Helper loaded: security_helper
INFO - 2017-07-24 12:32:44 --> Helper loaded: path_helper
INFO - 2017-07-24 12:32:44 --> Helper loaded: common_helper
INFO - 2017-07-24 12:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:32:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:32:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:32:44 --> Email Class Initialized
INFO - 2017-07-24 12:32:44 --> Form Validation Class Initialized
INFO - 2017-07-24 12:32:44 --> Model Class Initialized
INFO - 2017-07-24 12:32:44 --> Model Class Initialized
INFO - 2017-07-24 12:32:44 --> Model Class Initialized
INFO - 2017-07-24 12:32:44 --> Model Class Initialized
INFO - 2017-07-24 12:32:44 --> Controller Class Initialized
INFO - 2017-07-24 12:32:44 --> Model Class Initialized
ERROR - 2017-07-24 12:32:44 --> Query error: Table 'oncolens.email_template' doesn't exist - Invalid query: SELECT *
FROM `email_template`
INFO - 2017-07-24 12:32:44 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:34:19 --> Config Class Initialized
INFO - 2017-07-24 12:34:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:34:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:34:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:34:19 --> URI Class Initialized
INFO - 2017-07-24 12:34:19 --> Router Class Initialized
INFO - 2017-07-24 12:34:19 --> Output Class Initialized
INFO - 2017-07-24 12:34:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:34:19 --> Input Class Initialized
INFO - 2017-07-24 12:34:19 --> Language Class Initialized
INFO - 2017-07-24 12:34:19 --> Loader Class Initialized
INFO - 2017-07-24 12:34:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:34:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:34:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:34:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:34:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:34:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:34:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:19 --> Email Class Initialized
INFO - 2017-07-24 12:34:19 --> Form Validation Class Initialized
INFO - 2017-07-24 12:34:19 --> Model Class Initialized
INFO - 2017-07-24 12:34:19 --> Model Class Initialized
INFO - 2017-07-24 12:34:19 --> Model Class Initialized
INFO - 2017-07-24 12:34:19 --> Model Class Initialized
INFO - 2017-07-24 12:34:19 --> Controller Class Initialized
INFO - 2017-07-24 12:34:19 --> Model Class Initialized
INFO - 2017-07-24 12:34:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:34:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/email_templates.php
INFO - 2017-07-24 12:34:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:34:19 --> Final output sent to browser
DEBUG - 2017-07-24 12:34:19 --> Total execution time: 0.3100
DEBUG - 2017-07-24 12:34:19 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:34:19 --> Database Forge Class Initialized
INFO - 2017-07-24 12:34:19 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:35 --> Config Class Initialized
INFO - 2017-07-24 12:34:35 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:34:35 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:34:35 --> Utf8 Class Initialized
INFO - 2017-07-24 12:34:35 --> URI Class Initialized
INFO - 2017-07-24 12:34:35 --> Router Class Initialized
INFO - 2017-07-24 12:34:35 --> Output Class Initialized
INFO - 2017-07-24 12:34:35 --> Security Class Initialized
DEBUG - 2017-07-24 12:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:34:35 --> Input Class Initialized
INFO - 2017-07-24 12:34:35 --> Language Class Initialized
INFO - 2017-07-24 12:34:35 --> Loader Class Initialized
INFO - 2017-07-24 12:34:35 --> Helper loaded: url_helper
INFO - 2017-07-24 12:34:35 --> Helper loaded: form_helper
INFO - 2017-07-24 12:34:35 --> Helper loaded: security_helper
INFO - 2017-07-24 12:34:35 --> Helper loaded: path_helper
INFO - 2017-07-24 12:34:35 --> Helper loaded: common_helper
INFO - 2017-07-24 12:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:34:35 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:34:35 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:35 --> Email Class Initialized
INFO - 2017-07-24 12:34:35 --> Form Validation Class Initialized
INFO - 2017-07-24 12:34:35 --> Model Class Initialized
INFO - 2017-07-24 12:34:35 --> Model Class Initialized
INFO - 2017-07-24 12:34:35 --> Model Class Initialized
INFO - 2017-07-24 12:34:35 --> Model Class Initialized
INFO - 2017-07-24 12:34:35 --> Controller Class Initialized
INFO - 2017-07-24 12:34:35 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:34:35 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/report.php
INFO - 2017-07-24 12:34:35 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:34:35 --> Final output sent to browser
DEBUG - 2017-07-24 12:34:35 --> Total execution time: 0.0740
DEBUG - 2017-07-24 12:34:35 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:34:35 --> Database Forge Class Initialized
INFO - 2017-07-24 12:34:35 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:34:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:39 --> Config Class Initialized
INFO - 2017-07-24 12:34:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:34:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:34:39 --> Utf8 Class Initialized
INFO - 2017-07-24 12:34:39 --> URI Class Initialized
INFO - 2017-07-24 12:34:39 --> Router Class Initialized
INFO - 2017-07-24 12:34:39 --> Output Class Initialized
INFO - 2017-07-24 12:34:39 --> Security Class Initialized
DEBUG - 2017-07-24 12:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:34:39 --> Input Class Initialized
INFO - 2017-07-24 12:34:39 --> Language Class Initialized
INFO - 2017-07-24 12:34:39 --> Loader Class Initialized
INFO - 2017-07-24 12:34:39 --> Helper loaded: url_helper
INFO - 2017-07-24 12:34:39 --> Helper loaded: form_helper
INFO - 2017-07-24 12:34:39 --> Helper loaded: security_helper
INFO - 2017-07-24 12:34:39 --> Helper loaded: path_helper
INFO - 2017-07-24 12:34:39 --> Helper loaded: common_helper
INFO - 2017-07-24 12:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:34:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:34:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:39 --> Email Class Initialized
INFO - 2017-07-24 12:34:39 --> Form Validation Class Initialized
INFO - 2017-07-24 12:34:39 --> Model Class Initialized
INFO - 2017-07-24 12:34:39 --> Model Class Initialized
INFO - 2017-07-24 12:34:39 --> Model Class Initialized
INFO - 2017-07-24 12:34:39 --> Model Class Initialized
INFO - 2017-07-24 12:34:39 --> Controller Class Initialized
INFO - 2017-07-24 12:34:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:34:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/completereport.php
INFO - 2017-07-24 12:34:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:34:39 --> Final output sent to browser
DEBUG - 2017-07-24 12:34:39 --> Total execution time: 0.0840
DEBUG - 2017-07-24 12:34:39 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:34:39 --> Database Forge Class Initialized
INFO - 2017-07-24 12:34:40 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:44 --> Config Class Initialized
INFO - 2017-07-24 12:34:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:34:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:34:44 --> Utf8 Class Initialized
INFO - 2017-07-24 12:34:44 --> URI Class Initialized
INFO - 2017-07-24 12:34:44 --> Router Class Initialized
INFO - 2017-07-24 12:34:44 --> Output Class Initialized
INFO - 2017-07-24 12:34:44 --> Security Class Initialized
DEBUG - 2017-07-24 12:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:34:44 --> Input Class Initialized
INFO - 2017-07-24 12:34:44 --> Language Class Initialized
INFO - 2017-07-24 12:34:44 --> Loader Class Initialized
INFO - 2017-07-24 12:34:44 --> Helper loaded: url_helper
INFO - 2017-07-24 12:34:44 --> Helper loaded: form_helper
INFO - 2017-07-24 12:34:44 --> Helper loaded: security_helper
INFO - 2017-07-24 12:34:44 --> Helper loaded: path_helper
INFO - 2017-07-24 12:34:44 --> Helper loaded: common_helper
INFO - 2017-07-24 12:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:34:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:34:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:34:44 --> Email Class Initialized
INFO - 2017-07-24 12:34:44 --> Form Validation Class Initialized
INFO - 2017-07-24 12:34:44 --> Model Class Initialized
INFO - 2017-07-24 12:34:44 --> Model Class Initialized
INFO - 2017-07-24 12:34:44 --> Model Class Initialized
INFO - 2017-07-24 12:34:44 --> Model Class Initialized
INFO - 2017-07-24 12:34:44 --> Controller Class Initialized
ERROR - 2017-07-24 12:34:44 --> Query error: Table 'oncolens.hospital_doctor_tumor_board' doesn't exist - Invalid query: SELECT GROUP_CONCAT(DISTINCT h.hospital_network  ORDER BY h.hospital_network  SEPARATOR ', ') AS Hospital,GROUP_CONCAT( DISTINCT CONCAT(`tumor_board_name`),'(',h.hospital_network,')'  ORDER BY h.hospital_network ) AS 'Tumor Boards',s.`speciality_name` AS 'Specialty',DATE_FORMAT(u.date,'%m/%d/%Y') AS 'Date Created',IF(u.is_active='1','Active','Inactive')  AS Status, u.`fname` AS 'First Name',u.`lname` AS 'Last Name',u.`email` AS 'Email Id' FROM users u left JOIN `hospital_doctor` hd ON (u.id=hd.`doctor_id` and hd.is_active='1') left JOIN `hospital_network` h ON (h.id=hd.`hospital_id` and h.is_active='1') left JOIN  `hospital_tumor_board` ht ON ht.`hospital_id`=h.`id` left JOIN (SELECT hdtd.`hospital_doctor_id`,t1.* FROM `hospital_doctor_tumor_board` hdtd INNER JOIN    `tumor_board` t1  ON hdtd.`tumor_id`=t1.`tumor_id` AND hdtd.`is_active`='1' AND t1.`is_active`='1')t ON (t.`tumor_id`=ht.`tumor_id` and t.is_active='1'  AND hd.`hospital_doctor_id`=t.hospital_doctor_id) left JOIN `speciality` s ON s.`speciality_id`=u.`speciality_id`  WHERE u.is_active='1'       GROUP BY u.id  
INFO - 2017-07-24 12:34:44 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:35:01 --> Config Class Initialized
INFO - 2017-07-24 12:35:01 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:35:01 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:35:01 --> Utf8 Class Initialized
INFO - 2017-07-24 12:35:01 --> URI Class Initialized
INFO - 2017-07-24 12:35:01 --> Router Class Initialized
INFO - 2017-07-24 12:35:01 --> Output Class Initialized
INFO - 2017-07-24 12:35:01 --> Security Class Initialized
DEBUG - 2017-07-24 12:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:35:01 --> Input Class Initialized
INFO - 2017-07-24 12:35:01 --> Language Class Initialized
INFO - 2017-07-24 12:35:01 --> Loader Class Initialized
INFO - 2017-07-24 12:35:01 --> Helper loaded: url_helper
INFO - 2017-07-24 12:35:01 --> Helper loaded: form_helper
INFO - 2017-07-24 12:35:01 --> Helper loaded: security_helper
INFO - 2017-07-24 12:35:01 --> Helper loaded: path_helper
INFO - 2017-07-24 12:35:01 --> Helper loaded: common_helper
INFO - 2017-07-24 12:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:35:01 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:35:01 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:35:01 --> Email Class Initialized
INFO - 2017-07-24 12:35:01 --> Form Validation Class Initialized
INFO - 2017-07-24 12:35:01 --> Model Class Initialized
INFO - 2017-07-24 12:35:01 --> Model Class Initialized
INFO - 2017-07-24 12:35:01 --> Model Class Initialized
INFO - 2017-07-24 12:35:01 --> Model Class Initialized
INFO - 2017-07-24 12:35:01 --> Controller Class Initialized
INFO - 2017-07-24 12:35:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:35:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/completereport.php
INFO - 2017-07-24 12:35:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:35:01 --> Final output sent to browser
DEBUG - 2017-07-24 12:35:01 --> Total execution time: 0.0860
DEBUG - 2017-07-24 12:35:01 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:35:01 --> Database Forge Class Initialized
INFO - 2017-07-24 12:35:01 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:35:03 --> Config Class Initialized
INFO - 2017-07-24 12:35:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:35:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:35:03 --> Utf8 Class Initialized
INFO - 2017-07-24 12:35:03 --> URI Class Initialized
INFO - 2017-07-24 12:35:03 --> Router Class Initialized
INFO - 2017-07-24 12:35:03 --> Output Class Initialized
INFO - 2017-07-24 12:35:03 --> Security Class Initialized
DEBUG - 2017-07-24 12:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:35:03 --> Input Class Initialized
INFO - 2017-07-24 12:35:03 --> Language Class Initialized
INFO - 2017-07-24 12:35:03 --> Loader Class Initialized
INFO - 2017-07-24 12:35:03 --> Helper loaded: url_helper
INFO - 2017-07-24 12:35:03 --> Helper loaded: form_helper
INFO - 2017-07-24 12:35:03 --> Helper loaded: security_helper
INFO - 2017-07-24 12:35:04 --> Helper loaded: path_helper
INFO - 2017-07-24 12:35:04 --> Helper loaded: common_helper
INFO - 2017-07-24 12:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:35:04 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:35:04 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:35:04 --> Email Class Initialized
INFO - 2017-07-24 12:35:04 --> Form Validation Class Initialized
INFO - 2017-07-24 12:35:04 --> Model Class Initialized
INFO - 2017-07-24 12:35:04 --> Model Class Initialized
INFO - 2017-07-24 12:35:04 --> Model Class Initialized
INFO - 2017-07-24 12:35:04 --> Model Class Initialized
INFO - 2017-07-24 12:35:04 --> Controller Class Initialized
ERROR - 2017-07-24 12:35:04 --> Query error: Table 'oncolens.mst_notification' doesn't exist - Invalid query: SELECT *
FROM `mst_notification`
INFO - 2017-07-24 12:35:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:36:53 --> Config Class Initialized
INFO - 2017-07-24 12:36:53 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:36:53 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:36:53 --> Utf8 Class Initialized
INFO - 2017-07-24 12:36:53 --> URI Class Initialized
INFO - 2017-07-24 12:36:53 --> Router Class Initialized
INFO - 2017-07-24 12:36:53 --> Output Class Initialized
INFO - 2017-07-24 12:36:53 --> Security Class Initialized
DEBUG - 2017-07-24 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:36:53 --> Input Class Initialized
INFO - 2017-07-24 12:36:53 --> Language Class Initialized
INFO - 2017-07-24 12:36:53 --> Loader Class Initialized
INFO - 2017-07-24 12:36:53 --> Helper loaded: url_helper
INFO - 2017-07-24 12:36:53 --> Helper loaded: form_helper
INFO - 2017-07-24 12:36:53 --> Helper loaded: security_helper
INFO - 2017-07-24 12:36:53 --> Helper loaded: path_helper
INFO - 2017-07-24 12:36:53 --> Helper loaded: common_helper
INFO - 2017-07-24 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:36:53 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:36:53 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:36:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:36:54 --> Email Class Initialized
INFO - 2017-07-24 12:36:54 --> Form Validation Class Initialized
INFO - 2017-07-24 12:36:54 --> Model Class Initialized
INFO - 2017-07-24 12:36:54 --> Model Class Initialized
INFO - 2017-07-24 12:36:54 --> Model Class Initialized
INFO - 2017-07-24 12:36:54 --> Model Class Initialized
INFO - 2017-07-24 12:36:54 --> Controller Class Initialized
ERROR - 2017-07-24 12:36:54 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\oncolens\application\controllers\admin\User.php 334
INFO - 2017-07-24 12:36:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:36:54 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\oncolens\application\views\admin\notification_form.php 41
ERROR - 2017-07-24 12:36:54 --> Severity: Notice --> Undefined index:  E:\xampp\htdocs\oncolens\application\views\admin\notification_form.php 41
INFO - 2017-07-24 12:36:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/notification_form.php
INFO - 2017-07-24 12:36:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:36:54 --> Final output sent to browser
DEBUG - 2017-07-24 12:36:54 --> Total execution time: 1.0451
DEBUG - 2017-07-24 12:36:54 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:36:54 --> Database Forge Class Initialized
INFO - 2017-07-24 12:36:54 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:36:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:11 --> Config Class Initialized
INFO - 2017-07-24 12:37:11 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:37:11 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:37:11 --> Utf8 Class Initialized
INFO - 2017-07-24 12:37:11 --> URI Class Initialized
INFO - 2017-07-24 12:37:11 --> Router Class Initialized
INFO - 2017-07-24 12:37:11 --> Output Class Initialized
INFO - 2017-07-24 12:37:11 --> Security Class Initialized
DEBUG - 2017-07-24 12:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:37:11 --> Input Class Initialized
INFO - 2017-07-24 12:37:11 --> Language Class Initialized
INFO - 2017-07-24 12:37:11 --> Loader Class Initialized
INFO - 2017-07-24 12:37:11 --> Helper loaded: url_helper
INFO - 2017-07-24 12:37:11 --> Helper loaded: form_helper
INFO - 2017-07-24 12:37:11 --> Helper loaded: security_helper
INFO - 2017-07-24 12:37:11 --> Helper loaded: path_helper
INFO - 2017-07-24 12:37:11 --> Helper loaded: common_helper
INFO - 2017-07-24 12:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:37:11 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:37:11 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:11 --> Email Class Initialized
INFO - 2017-07-24 12:37:11 --> Form Validation Class Initialized
INFO - 2017-07-24 12:37:11 --> Model Class Initialized
INFO - 2017-07-24 12:37:11 --> Model Class Initialized
INFO - 2017-07-24 12:37:11 --> Model Class Initialized
INFO - 2017-07-24 12:37:11 --> Model Class Initialized
INFO - 2017-07-24 12:37:11 --> Controller Class Initialized
INFO - 2017-07-24 12:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:37:11 --> Pagination Class Initialized
INFO - 2017-07-24 12:37:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:37:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\audit_log.php 110
INFO - 2017-07-24 12:37:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/audit_log.php
INFO - 2017-07-24 12:37:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:37:11 --> Final output sent to browser
DEBUG - 2017-07-24 12:37:11 --> Total execution time: 0.1060
DEBUG - 2017-07-24 12:37:11 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:37:11 --> Database Forge Class Initialized
INFO - 2017-07-24 12:37:11 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:15 --> Config Class Initialized
INFO - 2017-07-24 12:37:15 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:37:15 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:37:15 --> Utf8 Class Initialized
INFO - 2017-07-24 12:37:15 --> URI Class Initialized
INFO - 2017-07-24 12:37:15 --> Router Class Initialized
INFO - 2017-07-24 12:37:15 --> Output Class Initialized
INFO - 2017-07-24 12:37:15 --> Security Class Initialized
DEBUG - 2017-07-24 12:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:37:15 --> Input Class Initialized
INFO - 2017-07-24 12:37:15 --> Language Class Initialized
INFO - 2017-07-24 12:37:15 --> Loader Class Initialized
INFO - 2017-07-24 12:37:15 --> Helper loaded: url_helper
INFO - 2017-07-24 12:37:15 --> Helper loaded: form_helper
INFO - 2017-07-24 12:37:15 --> Helper loaded: security_helper
INFO - 2017-07-24 12:37:15 --> Helper loaded: path_helper
INFO - 2017-07-24 12:37:15 --> Helper loaded: common_helper
INFO - 2017-07-24 12:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:37:15 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:37:15 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:15 --> Email Class Initialized
INFO - 2017-07-24 12:37:15 --> Form Validation Class Initialized
INFO - 2017-07-24 12:37:15 --> Model Class Initialized
INFO - 2017-07-24 12:37:15 --> Model Class Initialized
INFO - 2017-07-24 12:37:15 --> Model Class Initialized
INFO - 2017-07-24 12:37:15 --> Model Class Initialized
INFO - 2017-07-24 12:37:15 --> Controller Class Initialized
INFO - 2017-07-24 12:37:15 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:37:15 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/usertrackingbackup.php
INFO - 2017-07-24 12:37:15 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:37:15 --> Final output sent to browser
DEBUG - 2017-07-24 12:37:15 --> Total execution time: 0.1500
DEBUG - 2017-07-24 12:37:15 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:37:15 --> Database Forge Class Initialized
INFO - 2017-07-24 12:37:16 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:37:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:19 --> Config Class Initialized
INFO - 2017-07-24 12:37:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:37:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:37:19 --> Utf8 Class Initialized
INFO - 2017-07-24 12:37:19 --> URI Class Initialized
INFO - 2017-07-24 12:37:19 --> Router Class Initialized
INFO - 2017-07-24 12:37:19 --> Output Class Initialized
INFO - 2017-07-24 12:37:19 --> Security Class Initialized
DEBUG - 2017-07-24 12:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:37:19 --> Input Class Initialized
INFO - 2017-07-24 12:37:19 --> Language Class Initialized
INFO - 2017-07-24 12:37:19 --> Loader Class Initialized
INFO - 2017-07-24 12:37:19 --> Helper loaded: url_helper
INFO - 2017-07-24 12:37:19 --> Helper loaded: form_helper
INFO - 2017-07-24 12:37:19 --> Helper loaded: security_helper
INFO - 2017-07-24 12:37:19 --> Helper loaded: path_helper
INFO - 2017-07-24 12:37:19 --> Helper loaded: common_helper
INFO - 2017-07-24 12:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:37:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:37:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:19 --> Email Class Initialized
INFO - 2017-07-24 12:37:19 --> Form Validation Class Initialized
INFO - 2017-07-24 12:37:19 --> Model Class Initialized
INFO - 2017-07-24 12:37:19 --> Model Class Initialized
INFO - 2017-07-24 12:37:19 --> Model Class Initialized
INFO - 2017-07-24 12:37:19 --> Model Class Initialized
INFO - 2017-07-24 12:37:19 --> Controller Class Initialized
INFO - 2017-07-24 12:37:19 --> Model Class Initialized
ERROR - 2017-07-24 12:37:19 --> Query error: Unknown column 'is_admin_display' in 'where clause' - Invalid query: SELECT *
FROM `cancercategories`
WHERE `is_admin_display` = '1'
ORDER BY `order_id`
INFO - 2017-07-24 12:37:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:37:54 --> Config Class Initialized
INFO - 2017-07-24 12:37:54 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:37:54 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:37:54 --> Utf8 Class Initialized
INFO - 2017-07-24 12:37:54 --> URI Class Initialized
INFO - 2017-07-24 12:37:54 --> Router Class Initialized
INFO - 2017-07-24 12:37:54 --> Output Class Initialized
INFO - 2017-07-24 12:37:54 --> Security Class Initialized
DEBUG - 2017-07-24 12:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:37:54 --> Input Class Initialized
INFO - 2017-07-24 12:37:54 --> Language Class Initialized
INFO - 2017-07-24 12:37:54 --> Loader Class Initialized
INFO - 2017-07-24 12:37:54 --> Helper loaded: url_helper
INFO - 2017-07-24 12:37:54 --> Helper loaded: form_helper
INFO - 2017-07-24 12:37:54 --> Helper loaded: security_helper
INFO - 2017-07-24 12:37:54 --> Helper loaded: path_helper
INFO - 2017-07-24 12:37:54 --> Helper loaded: common_helper
INFO - 2017-07-24 12:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:37:54 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:37:54 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:37:54 --> Email Class Initialized
INFO - 2017-07-24 12:37:54 --> Form Validation Class Initialized
INFO - 2017-07-24 12:37:54 --> Model Class Initialized
INFO - 2017-07-24 12:37:54 --> Model Class Initialized
INFO - 2017-07-24 12:37:54 --> Model Class Initialized
INFO - 2017-07-24 12:37:54 --> Model Class Initialized
INFO - 2017-07-24 12:37:54 --> Controller Class Initialized
INFO - 2017-07-24 12:37:54 --> Model Class Initialized
ERROR - 2017-07-24 12:37:54 --> Query error: Unknown column 'order_id' in 'order clause' - Invalid query: SELECT *
FROM `cancercategories`
WHERE `is_admin_display` = '1'
ORDER BY `order_id`
INFO - 2017-07-24 12:37:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:38:13 --> Config Class Initialized
INFO - 2017-07-24 12:38:13 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:38:13 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:38:13 --> Utf8 Class Initialized
INFO - 2017-07-24 12:38:13 --> URI Class Initialized
INFO - 2017-07-24 12:38:13 --> Router Class Initialized
INFO - 2017-07-24 12:38:13 --> Output Class Initialized
INFO - 2017-07-24 12:38:13 --> Security Class Initialized
DEBUG - 2017-07-24 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:38:13 --> Input Class Initialized
INFO - 2017-07-24 12:38:13 --> Language Class Initialized
INFO - 2017-07-24 12:38:13 --> Loader Class Initialized
INFO - 2017-07-24 12:38:13 --> Helper loaded: url_helper
INFO - 2017-07-24 12:38:13 --> Helper loaded: form_helper
INFO - 2017-07-24 12:38:13 --> Helper loaded: security_helper
INFO - 2017-07-24 12:38:13 --> Helper loaded: path_helper
INFO - 2017-07-24 12:38:13 --> Helper loaded: common_helper
INFO - 2017-07-24 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:38:13 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:38:13 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:38:13 --> Email Class Initialized
INFO - 2017-07-24 12:38:13 --> Form Validation Class Initialized
INFO - 2017-07-24 12:38:13 --> Model Class Initialized
INFO - 2017-07-24 12:38:13 --> Model Class Initialized
INFO - 2017-07-24 12:38:13 --> Model Class Initialized
INFO - 2017-07-24 12:38:13 --> Model Class Initialized
INFO - 2017-07-24 12:38:13 --> Controller Class Initialized
INFO - 2017-07-24 12:38:13 --> Model Class Initialized
INFO - 2017-07-24 12:38:13 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:38:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\regimens.php 57
INFO - 2017-07-24 12:38:13 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/regimens.php
INFO - 2017-07-24 12:38:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:38:14 --> Final output sent to browser
DEBUG - 2017-07-24 12:38:14 --> Total execution time: 0.2310
DEBUG - 2017-07-24 12:38:14 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:38:14 --> Database Forge Class Initialized
INFO - 2017-07-24 12:38:14 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:38:27 --> Config Class Initialized
INFO - 2017-07-24 12:38:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:38:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:38:27 --> Utf8 Class Initialized
INFO - 2017-07-24 12:38:27 --> URI Class Initialized
INFO - 2017-07-24 12:38:27 --> Router Class Initialized
INFO - 2017-07-24 12:38:27 --> Output Class Initialized
INFO - 2017-07-24 12:38:27 --> Security Class Initialized
DEBUG - 2017-07-24 12:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:38:27 --> Input Class Initialized
INFO - 2017-07-24 12:38:27 --> Language Class Initialized
INFO - 2017-07-24 12:38:27 --> Loader Class Initialized
INFO - 2017-07-24 12:38:27 --> Helper loaded: url_helper
INFO - 2017-07-24 12:38:27 --> Helper loaded: form_helper
INFO - 2017-07-24 12:38:27 --> Helper loaded: security_helper
INFO - 2017-07-24 12:38:27 --> Helper loaded: path_helper
INFO - 2017-07-24 12:38:27 --> Helper loaded: common_helper
INFO - 2017-07-24 12:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:38:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:38:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:38:27 --> Email Class Initialized
INFO - 2017-07-24 12:38:27 --> Form Validation Class Initialized
INFO - 2017-07-24 12:38:27 --> Model Class Initialized
INFO - 2017-07-24 12:38:27 --> Model Class Initialized
INFO - 2017-07-24 12:38:27 --> Model Class Initialized
INFO - 2017-07-24 12:38:27 --> Model Class Initialized
INFO - 2017-07-24 12:38:27 --> Controller Class Initialized
INFO - 2017-07-24 12:38:27 --> Model Class Initialized
ERROR - 2017-07-24 12:38:27 --> Query error: Unknown column 'cancer_status' in 'where clause' - Invalid query: SELECT *
FROM `cancercategories`
WHERE `cancer_status` = '1'
ORDER BY `order_id`
INFO - 2017-07-24 12:38:27 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:38:46 --> Config Class Initialized
INFO - 2017-07-24 12:38:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:38:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:38:46 --> Utf8 Class Initialized
INFO - 2017-07-24 12:38:46 --> URI Class Initialized
INFO - 2017-07-24 12:38:46 --> Router Class Initialized
INFO - 2017-07-24 12:38:46 --> Output Class Initialized
INFO - 2017-07-24 12:38:46 --> Security Class Initialized
DEBUG - 2017-07-24 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:38:46 --> Input Class Initialized
INFO - 2017-07-24 12:38:46 --> Language Class Initialized
INFO - 2017-07-24 12:38:46 --> Loader Class Initialized
INFO - 2017-07-24 12:38:46 --> Helper loaded: url_helper
INFO - 2017-07-24 12:38:46 --> Helper loaded: form_helper
INFO - 2017-07-24 12:38:46 --> Helper loaded: security_helper
INFO - 2017-07-24 12:38:46 --> Helper loaded: path_helper
INFO - 2017-07-24 12:38:46 --> Helper loaded: common_helper
INFO - 2017-07-24 12:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:38:46 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:38:46 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:38:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:38:46 --> Email Class Initialized
INFO - 2017-07-24 12:38:46 --> Form Validation Class Initialized
INFO - 2017-07-24 12:38:46 --> Model Class Initialized
INFO - 2017-07-24 12:38:46 --> Model Class Initialized
INFO - 2017-07-24 12:38:46 --> Model Class Initialized
INFO - 2017-07-24 12:38:46 --> Model Class Initialized
INFO - 2017-07-24 12:38:46 --> Controller Class Initialized
INFO - 2017-07-24 12:38:46 --> Model Class Initialized
ERROR - 2017-07-24 12:38:46 --> Query error: Table 'oncolens.cancersubcategories' doesn't exist - Invalid query: SELECT *
FROM `cancersubcategories` `cs`
LEFT JOIN `cancercategories` `cc` ON `cc`.`cancer_id`=`cs`.`cancer_id`
WHERE `cs`.`is_active` = '1'
AND `cc`.`cancer_status` = '1'
 LIMIT 10
INFO - 2017-07-24 12:38:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:41:44 --> Config Class Initialized
INFO - 2017-07-24 12:41:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:41:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:41:44 --> Utf8 Class Initialized
INFO - 2017-07-24 12:41:44 --> URI Class Initialized
INFO - 2017-07-24 12:41:44 --> Router Class Initialized
INFO - 2017-07-24 12:41:44 --> Output Class Initialized
INFO - 2017-07-24 12:41:44 --> Security Class Initialized
DEBUG - 2017-07-24 12:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:41:44 --> Input Class Initialized
INFO - 2017-07-24 12:41:44 --> Language Class Initialized
INFO - 2017-07-24 12:41:44 --> Loader Class Initialized
INFO - 2017-07-24 12:41:44 --> Helper loaded: url_helper
INFO - 2017-07-24 12:41:44 --> Helper loaded: form_helper
INFO - 2017-07-24 12:41:44 --> Helper loaded: security_helper
INFO - 2017-07-24 12:41:44 --> Helper loaded: path_helper
INFO - 2017-07-24 12:41:44 --> Helper loaded: common_helper
INFO - 2017-07-24 12:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:41:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:41:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:41:45 --> Email Class Initialized
INFO - 2017-07-24 12:41:45 --> Form Validation Class Initialized
INFO - 2017-07-24 12:41:45 --> Model Class Initialized
INFO - 2017-07-24 12:41:45 --> Model Class Initialized
INFO - 2017-07-24 12:41:45 --> Model Class Initialized
INFO - 2017-07-24 12:41:45 --> Model Class Initialized
INFO - 2017-07-24 12:41:45 --> Controller Class Initialized
INFO - 2017-07-24 12:41:45 --> Model Class Initialized
ERROR - 2017-07-24 12:41:45 --> Query error: Unknown column 'cs.is_active' in 'where clause' - Invalid query: SELECT *
FROM `cancersubcategories` `cs`
LEFT JOIN `cancercategories` `cc` ON `cc`.`cancer_id`=`cs`.`cancer_id`
WHERE `cs`.`is_active` = '1'
AND `cc`.`cancer_status` = '1'
 LIMIT 10
INFO - 2017-07-24 12:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:42:08 --> Config Class Initialized
INFO - 2017-07-24 12:42:08 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:42:08 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:42:08 --> Utf8 Class Initialized
INFO - 2017-07-24 12:42:08 --> URI Class Initialized
INFO - 2017-07-24 12:42:08 --> Router Class Initialized
INFO - 2017-07-24 12:42:08 --> Output Class Initialized
INFO - 2017-07-24 12:42:08 --> Security Class Initialized
DEBUG - 2017-07-24 12:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:42:08 --> Input Class Initialized
INFO - 2017-07-24 12:42:08 --> Language Class Initialized
INFO - 2017-07-24 12:42:08 --> Loader Class Initialized
INFO - 2017-07-24 12:42:08 --> Helper loaded: url_helper
INFO - 2017-07-24 12:42:08 --> Helper loaded: form_helper
INFO - 2017-07-24 12:42:08 --> Helper loaded: security_helper
INFO - 2017-07-24 12:42:08 --> Helper loaded: path_helper
INFO - 2017-07-24 12:42:08 --> Helper loaded: common_helper
INFO - 2017-07-24 12:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:42:08 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:42:08 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:42:08 --> Email Class Initialized
INFO - 2017-07-24 12:42:08 --> Form Validation Class Initialized
INFO - 2017-07-24 12:42:08 --> Model Class Initialized
INFO - 2017-07-24 12:42:08 --> Model Class Initialized
INFO - 2017-07-24 12:42:08 --> Model Class Initialized
INFO - 2017-07-24 12:42:08 --> Model Class Initialized
INFO - 2017-07-24 12:42:08 --> Controller Class Initialized
INFO - 2017-07-24 12:42:08 --> Model Class Initialized
INFO - 2017-07-24 12:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:42:08 --> Pagination Class Initialized
INFO - 2017-07-24 12:42:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\pathlogy.php 53
INFO - 2017-07-24 12:42:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/pathlogy.php
INFO - 2017-07-24 12:42:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:42:08 --> Final output sent to browser
DEBUG - 2017-07-24 12:42:08 --> Total execution time: 0.1770
DEBUG - 2017-07-24 12:42:08 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:42:08 --> Database Forge Class Initialized
INFO - 2017-07-24 12:42:08 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:42:12 --> Config Class Initialized
INFO - 2017-07-24 12:42:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:42:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:42:12 --> Utf8 Class Initialized
INFO - 2017-07-24 12:42:12 --> URI Class Initialized
INFO - 2017-07-24 12:42:12 --> Router Class Initialized
INFO - 2017-07-24 12:42:12 --> Output Class Initialized
INFO - 2017-07-24 12:42:12 --> Security Class Initialized
DEBUG - 2017-07-24 12:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:42:12 --> Input Class Initialized
INFO - 2017-07-24 12:42:12 --> Language Class Initialized
INFO - 2017-07-24 12:42:12 --> Loader Class Initialized
INFO - 2017-07-24 12:42:12 --> Helper loaded: url_helper
INFO - 2017-07-24 12:42:12 --> Helper loaded: form_helper
INFO - 2017-07-24 12:42:12 --> Helper loaded: security_helper
INFO - 2017-07-24 12:42:12 --> Helper loaded: path_helper
INFO - 2017-07-24 12:42:12 --> Helper loaded: common_helper
INFO - 2017-07-24 12:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:42:12 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:42:12 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:42:12 --> Email Class Initialized
INFO - 2017-07-24 12:42:12 --> Form Validation Class Initialized
INFO - 2017-07-24 12:42:12 --> Model Class Initialized
INFO - 2017-07-24 12:42:12 --> Model Class Initialized
INFO - 2017-07-24 12:42:12 --> Model Class Initialized
INFO - 2017-07-24 12:42:12 --> Model Class Initialized
INFO - 2017-07-24 12:42:12 --> Controller Class Initialized
INFO - 2017-07-24 12:42:12 --> Model Class Initialized
INFO - 2017-07-24 12:42:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:42:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\pathlogy_form.php 50
INFO - 2017-07-24 12:42:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/pathlogy_form.php
INFO - 2017-07-24 12:42:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:42:12 --> Final output sent to browser
DEBUG - 2017-07-24 12:42:12 --> Total execution time: 0.1400
DEBUG - 2017-07-24 12:42:13 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:42:13 --> Database Forge Class Initialized
INFO - 2017-07-24 12:42:13 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:42:23 --> Config Class Initialized
INFO - 2017-07-24 12:42:23 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:42:23 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:42:23 --> Utf8 Class Initialized
INFO - 2017-07-24 12:42:23 --> URI Class Initialized
INFO - 2017-07-24 12:42:23 --> Router Class Initialized
INFO - 2017-07-24 12:42:23 --> Output Class Initialized
INFO - 2017-07-24 12:42:23 --> Security Class Initialized
DEBUG - 2017-07-24 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:42:23 --> Input Class Initialized
INFO - 2017-07-24 12:42:23 --> Language Class Initialized
INFO - 2017-07-24 12:42:23 --> Loader Class Initialized
INFO - 2017-07-24 12:42:23 --> Helper loaded: url_helper
INFO - 2017-07-24 12:42:23 --> Helper loaded: form_helper
INFO - 2017-07-24 12:42:23 --> Helper loaded: security_helper
INFO - 2017-07-24 12:42:23 --> Helper loaded: path_helper
INFO - 2017-07-24 12:42:23 --> Helper loaded: common_helper
INFO - 2017-07-24 12:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:42:23 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:42:23 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:42:23 --> Email Class Initialized
INFO - 2017-07-24 12:42:23 --> Form Validation Class Initialized
INFO - 2017-07-24 12:42:23 --> Model Class Initialized
INFO - 2017-07-24 12:42:23 --> Model Class Initialized
INFO - 2017-07-24 12:42:23 --> Model Class Initialized
INFO - 2017-07-24 12:42:23 --> Model Class Initialized
INFO - 2017-07-24 12:42:23 --> Controller Class Initialized
INFO - 2017-07-24 12:42:23 --> Model Class Initialized
ERROR - 2017-07-24 12:42:23 --> Query error: Table 'oncolens.specificanswer' doesn't exist - Invalid query: SELECT *
FROM `speciality` `s`
JOIN `specificanswer` `sa` ON `sa`.`speciality_id` = `s`.`speciality_id`
WHERE `s`.`is_deleted` = '0'
AND  `s`.`speciality_id` in  (1,3,4)
GROUP BY `s`.`speciality_id`
INFO - 2017-07-24 12:42:23 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:44:03 --> Config Class Initialized
INFO - 2017-07-24 12:44:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:44:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:44:03 --> Utf8 Class Initialized
INFO - 2017-07-24 12:44:03 --> URI Class Initialized
INFO - 2017-07-24 12:44:03 --> Router Class Initialized
INFO - 2017-07-24 12:44:03 --> Output Class Initialized
INFO - 2017-07-24 12:44:03 --> Security Class Initialized
DEBUG - 2017-07-24 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:44:03 --> Input Class Initialized
INFO - 2017-07-24 12:44:03 --> Language Class Initialized
INFO - 2017-07-24 12:44:03 --> Loader Class Initialized
INFO - 2017-07-24 12:44:03 --> Helper loaded: url_helper
INFO - 2017-07-24 12:44:03 --> Helper loaded: form_helper
INFO - 2017-07-24 12:44:03 --> Helper loaded: security_helper
INFO - 2017-07-24 12:44:03 --> Helper loaded: path_helper
INFO - 2017-07-24 12:44:03 --> Helper loaded: common_helper
INFO - 2017-07-24 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:44:03 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:44:03 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:44:03 --> Email Class Initialized
INFO - 2017-07-24 12:44:03 --> Form Validation Class Initialized
INFO - 2017-07-24 12:44:03 --> Model Class Initialized
INFO - 2017-07-24 12:44:03 --> Model Class Initialized
INFO - 2017-07-24 12:44:03 --> Model Class Initialized
INFO - 2017-07-24 12:44:03 --> Model Class Initialized
INFO - 2017-07-24 12:44:03 --> Controller Class Initialized
INFO - 2017-07-24 12:44:03 --> Model Class Initialized
ERROR - 2017-07-24 12:44:03 --> Query error: Unknown column 'cs.is_active' in 'where clause' - Invalid query: SELECT *
FROM `specificanswer` `cs`
LEFT JOIN `cancercategories` `cc` ON `cc`.`cancer_id`=`cs`.`cancer_id`
LEFT JOIN `speciality` `s` ON `s`.`speciality_id`=`cs`.`speciality_id`
WHERE `cs`.`is_active` = '1'
ORDER BY `cs`.`id` DESC
 LIMIT 10
INFO - 2017-07-24 12:44:03 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:44:31 --> Config Class Initialized
INFO - 2017-07-24 12:44:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:44:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:44:31 --> Utf8 Class Initialized
INFO - 2017-07-24 12:44:31 --> URI Class Initialized
INFO - 2017-07-24 12:44:31 --> Router Class Initialized
INFO - 2017-07-24 12:44:31 --> Output Class Initialized
INFO - 2017-07-24 12:44:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:44:31 --> Input Class Initialized
INFO - 2017-07-24 12:44:31 --> Language Class Initialized
INFO - 2017-07-24 12:44:31 --> Loader Class Initialized
INFO - 2017-07-24 12:44:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:44:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:44:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:44:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:44:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:44:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:44:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:44:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:44:31 --> Email Class Initialized
INFO - 2017-07-24 12:44:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:44:31 --> Model Class Initialized
INFO - 2017-07-24 12:44:31 --> Model Class Initialized
INFO - 2017-07-24 12:44:31 --> Model Class Initialized
INFO - 2017-07-24 12:44:31 --> Model Class Initialized
INFO - 2017-07-24 12:44:31 --> Controller Class Initialized
INFO - 2017-07-24 12:44:31 --> Model Class Initialized
ERROR - 2017-07-24 12:44:31 --> Query error: Unknown column 'cs.cancer_id' in 'on clause' - Invalid query: SELECT *
FROM `specificanswer` `cs`
LEFT JOIN `cancercategories` `cc` ON `cc`.`cancer_id`=`cs`.`cancer_id`
LEFT JOIN `speciality` `s` ON `s`.`speciality_id`=`cs`.`speciality_id`
WHERE `cs`.`is_active` = '1'
ORDER BY `cs`.`id` DESC
 LIMIT 10
INFO - 2017-07-24 12:44:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:44:46 --> Config Class Initialized
INFO - 2017-07-24 12:44:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:44:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:44:46 --> Utf8 Class Initialized
INFO - 2017-07-24 12:44:46 --> URI Class Initialized
INFO - 2017-07-24 12:44:46 --> Router Class Initialized
INFO - 2017-07-24 12:44:46 --> Output Class Initialized
INFO - 2017-07-24 12:44:46 --> Security Class Initialized
DEBUG - 2017-07-24 12:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:44:46 --> Input Class Initialized
INFO - 2017-07-24 12:44:46 --> Language Class Initialized
INFO - 2017-07-24 12:44:46 --> Loader Class Initialized
INFO - 2017-07-24 12:44:46 --> Helper loaded: url_helper
INFO - 2017-07-24 12:44:46 --> Helper loaded: form_helper
INFO - 2017-07-24 12:44:46 --> Helper loaded: security_helper
INFO - 2017-07-24 12:44:46 --> Helper loaded: path_helper
INFO - 2017-07-24 12:44:46 --> Helper loaded: common_helper
INFO - 2017-07-24 12:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:44:46 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:44:46 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:44:46 --> Email Class Initialized
INFO - 2017-07-24 12:44:46 --> Form Validation Class Initialized
INFO - 2017-07-24 12:44:46 --> Model Class Initialized
INFO - 2017-07-24 12:44:46 --> Model Class Initialized
INFO - 2017-07-24 12:44:46 --> Model Class Initialized
INFO - 2017-07-24 12:44:46 --> Model Class Initialized
INFO - 2017-07-24 12:44:46 --> Controller Class Initialized
INFO - 2017-07-24 12:44:46 --> Model Class Initialized
INFO - 2017-07-24 12:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:44:46 --> Pagination Class Initialized
INFO - 2017-07-24 12:44:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 48
ERROR - 2017-07-24 12:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 63
INFO - 2017-07-24 12:44:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/case_answer.php
INFO - 2017-07-24 12:44:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:44:46 --> Final output sent to browser
DEBUG - 2017-07-24 12:44:46 --> Total execution time: 0.2790
DEBUG - 2017-07-24 12:44:46 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:44:46 --> Database Forge Class Initialized
INFO - 2017-07-24 12:44:46 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:44:52 --> Config Class Initialized
INFO - 2017-07-24 12:44:52 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:44:52 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:44:52 --> Utf8 Class Initialized
INFO - 2017-07-24 12:44:52 --> URI Class Initialized
INFO - 2017-07-24 12:44:52 --> Router Class Initialized
INFO - 2017-07-24 12:44:52 --> Output Class Initialized
INFO - 2017-07-24 12:44:52 --> Security Class Initialized
DEBUG - 2017-07-24 12:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:44:52 --> Input Class Initialized
INFO - 2017-07-24 12:44:52 --> Language Class Initialized
INFO - 2017-07-24 12:44:52 --> Loader Class Initialized
INFO - 2017-07-24 12:44:52 --> Helper loaded: url_helper
INFO - 2017-07-24 12:44:52 --> Helper loaded: form_helper
INFO - 2017-07-24 12:44:52 --> Helper loaded: security_helper
INFO - 2017-07-24 12:44:52 --> Helper loaded: path_helper
INFO - 2017-07-24 12:44:52 --> Helper loaded: common_helper
INFO - 2017-07-24 12:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:44:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:44:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:44:52 --> Email Class Initialized
INFO - 2017-07-24 12:44:52 --> Form Validation Class Initialized
INFO - 2017-07-24 12:44:52 --> Model Class Initialized
INFO - 2017-07-24 12:44:52 --> Model Class Initialized
INFO - 2017-07-24 12:44:52 --> Model Class Initialized
INFO - 2017-07-24 12:44:52 --> Model Class Initialized
INFO - 2017-07-24 12:44:52 --> Controller Class Initialized
INFO - 2017-07-24 12:44:52 --> Model Class Initialized
INFO - 2017-07-24 12:44:52 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\specific_answer_form.php 48
ERROR - 2017-07-24 12:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\specific_answer_form.php 63
INFO - 2017-07-24 12:44:52 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/specific_answer_form.php
INFO - 2017-07-24 12:44:52 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:44:52 --> Final output sent to browser
DEBUG - 2017-07-24 12:44:52 --> Total execution time: 0.1800
DEBUG - 2017-07-24 12:44:52 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:44:52 --> Database Forge Class Initialized
INFO - 2017-07-24 12:44:52 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:44:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:06 --> Config Class Initialized
INFO - 2017-07-24 12:45:06 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:06 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:06 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:06 --> URI Class Initialized
INFO - 2017-07-24 12:45:06 --> Router Class Initialized
INFO - 2017-07-24 12:45:06 --> Output Class Initialized
INFO - 2017-07-24 12:45:06 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:06 --> Input Class Initialized
INFO - 2017-07-24 12:45:06 --> Language Class Initialized
INFO - 2017-07-24 12:45:06 --> Loader Class Initialized
INFO - 2017-07-24 12:45:06 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:06 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:06 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:06 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:06 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:06 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:06 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:06 --> Email Class Initialized
INFO - 2017-07-24 12:45:06 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:06 --> Model Class Initialized
INFO - 2017-07-24 12:45:06 --> Model Class Initialized
INFO - 2017-07-24 12:45:06 --> Model Class Initialized
INFO - 2017-07-24 12:45:06 --> Model Class Initialized
INFO - 2017-07-24 12:45:06 --> Controller Class Initialized
INFO - 2017-07-24 12:45:06 --> Model Class Initialized
INFO - 2017-07-24 12:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:45:06 --> Pagination Class Initialized
INFO - 2017-07-24 12:45:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:45:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 48
ERROR - 2017-07-24 12:45:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 63
INFO - 2017-07-24 12:45:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/case_answer.php
INFO - 2017-07-24 12:45:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:06 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:06 --> Total execution time: 0.0890
DEBUG - 2017-07-24 12:45:06 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:06 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:06 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:08 --> Config Class Initialized
INFO - 2017-07-24 12:45:08 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:08 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:08 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:08 --> URI Class Initialized
INFO - 2017-07-24 12:45:08 --> Router Class Initialized
INFO - 2017-07-24 12:45:08 --> Output Class Initialized
INFO - 2017-07-24 12:45:08 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:08 --> Input Class Initialized
INFO - 2017-07-24 12:45:08 --> Language Class Initialized
INFO - 2017-07-24 12:45:08 --> Loader Class Initialized
INFO - 2017-07-24 12:45:08 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:08 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:08 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:08 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:08 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:08 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:08 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:08 --> Email Class Initialized
INFO - 2017-07-24 12:45:08 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:08 --> Model Class Initialized
INFO - 2017-07-24 12:45:08 --> Model Class Initialized
INFO - 2017-07-24 12:45:08 --> Model Class Initialized
INFO - 2017-07-24 12:45:08 --> Model Class Initialized
INFO - 2017-07-24 12:45:08 --> Controller Class Initialized
INFO - 2017-07-24 12:45:08 --> Model Class Initialized
INFO - 2017-07-24 12:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:45:08 --> Pagination Class Initialized
INFO - 2017-07-24 12:45:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 48
ERROR - 2017-07-24 12:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\case_answer.php 63
INFO - 2017-07-24 12:45:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/case_answer.php
INFO - 2017-07-24 12:45:08 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:08 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:08 --> Total execution time: 0.2260
DEBUG - 2017-07-24 12:45:08 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:08 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:08 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:11 --> Config Class Initialized
INFO - 2017-07-24 12:45:11 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:11 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:11 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:11 --> URI Class Initialized
INFO - 2017-07-24 12:45:11 --> Router Class Initialized
INFO - 2017-07-24 12:45:11 --> Output Class Initialized
INFO - 2017-07-24 12:45:11 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:11 --> Input Class Initialized
INFO - 2017-07-24 12:45:11 --> Language Class Initialized
INFO - 2017-07-24 12:45:11 --> Loader Class Initialized
INFO - 2017-07-24 12:45:11 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:11 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:11 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:11 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:11 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:11 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:11 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:11 --> Email Class Initialized
INFO - 2017-07-24 12:45:11 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:11 --> Model Class Initialized
INFO - 2017-07-24 12:45:11 --> Model Class Initialized
INFO - 2017-07-24 12:45:11 --> Model Class Initialized
INFO - 2017-07-24 12:45:11 --> Model Class Initialized
INFO - 2017-07-24 12:45:11 --> Controller Class Initialized
INFO - 2017-07-24 12:45:11 --> Model Class Initialized
INFO - 2017-07-24 12:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:45:11 --> Pagination Class Initialized
INFO - 2017-07-24 12:45:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\pathlogy.php 53
INFO - 2017-07-24 12:45:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/pathlogy.php
INFO - 2017-07-24 12:45:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:11 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:11 --> Total execution time: 0.0980
DEBUG - 2017-07-24 12:45:11 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:11 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:11 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:12 --> Config Class Initialized
INFO - 2017-07-24 12:45:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:12 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:12 --> URI Class Initialized
INFO - 2017-07-24 12:45:12 --> Router Class Initialized
INFO - 2017-07-24 12:45:12 --> Output Class Initialized
INFO - 2017-07-24 12:45:12 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:12 --> Input Class Initialized
INFO - 2017-07-24 12:45:12 --> Language Class Initialized
INFO - 2017-07-24 12:45:12 --> Loader Class Initialized
INFO - 2017-07-24 12:45:12 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:12 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:12 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:12 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:12 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:12 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:12 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:12 --> Email Class Initialized
INFO - 2017-07-24 12:45:12 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:12 --> Model Class Initialized
INFO - 2017-07-24 12:45:12 --> Model Class Initialized
INFO - 2017-07-24 12:45:12 --> Model Class Initialized
INFO - 2017-07-24 12:45:12 --> Model Class Initialized
INFO - 2017-07-24 12:45:12 --> Controller Class Initialized
INFO - 2017-07-24 12:45:12 --> Model Class Initialized
INFO - 2017-07-24 12:45:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\regimens.php 57
INFO - 2017-07-24 12:45:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/regimens.php
INFO - 2017-07-24 12:45:12 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:12 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:12 --> Total execution time: 0.1430
DEBUG - 2017-07-24 12:45:12 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:12 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:12 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:16 --> Config Class Initialized
INFO - 2017-07-24 12:45:16 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:16 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:16 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:16 --> URI Class Initialized
INFO - 2017-07-24 12:45:16 --> Router Class Initialized
INFO - 2017-07-24 12:45:16 --> Output Class Initialized
INFO - 2017-07-24 12:45:16 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:16 --> Input Class Initialized
INFO - 2017-07-24 12:45:16 --> Language Class Initialized
INFO - 2017-07-24 12:45:16 --> Loader Class Initialized
INFO - 2017-07-24 12:45:16 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:16 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:16 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:16 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:16 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:16 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:16 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:16 --> Email Class Initialized
INFO - 2017-07-24 12:45:16 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:16 --> Model Class Initialized
INFO - 2017-07-24 12:45:16 --> Model Class Initialized
INFO - 2017-07-24 12:45:16 --> Model Class Initialized
INFO - 2017-07-24 12:45:16 --> Model Class Initialized
INFO - 2017-07-24 12:45:16 --> Controller Class Initialized
DEBUG - 2017-07-24 12:45:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:45:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/admin_profile.php
INFO - 2017-07-24 12:45:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:16 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:16 --> Total execution time: 0.1690
DEBUG - 2017-07-24 12:45:16 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:16 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:16 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:24 --> Config Class Initialized
INFO - 2017-07-24 12:45:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:24 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:24 --> URI Class Initialized
INFO - 2017-07-24 12:45:24 --> Router Class Initialized
INFO - 2017-07-24 12:45:24 --> Output Class Initialized
INFO - 2017-07-24 12:45:24 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:24 --> Input Class Initialized
INFO - 2017-07-24 12:45:24 --> Language Class Initialized
INFO - 2017-07-24 12:45:24 --> Loader Class Initialized
INFO - 2017-07-24 12:45:24 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:24 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:24 --> Email Class Initialized
INFO - 2017-07-24 12:45:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Controller Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:45:24 --> Config Class Initialized
INFO - 2017-07-24 12:45:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:24 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:24 --> URI Class Initialized
INFO - 2017-07-24 12:45:24 --> Router Class Initialized
INFO - 2017-07-24 12:45:24 --> Output Class Initialized
INFO - 2017-07-24 12:45:24 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:24 --> Input Class Initialized
INFO - 2017-07-24 12:45:24 --> Language Class Initialized
INFO - 2017-07-24 12:45:24 --> Loader Class Initialized
INFO - 2017-07-24 12:45:24 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:24 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:24 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:24 --> Email Class Initialized
INFO - 2017-07-24 12:45:24 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Model Class Initialized
INFO - 2017-07-24 12:45:24 --> Controller Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:45:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/admin_profile.php
INFO - 2017-07-24 12:45:24 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:24 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:24 --> Total execution time: 0.0990
DEBUG - 2017-07-24 12:45:24 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:24 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:24 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:27 --> Config Class Initialized
INFO - 2017-07-24 12:45:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:27 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:27 --> URI Class Initialized
INFO - 2017-07-24 12:45:27 --> Router Class Initialized
INFO - 2017-07-24 12:45:27 --> Output Class Initialized
INFO - 2017-07-24 12:45:27 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:27 --> Input Class Initialized
INFO - 2017-07-24 12:45:27 --> Language Class Initialized
INFO - 2017-07-24 12:45:27 --> Loader Class Initialized
INFO - 2017-07-24 12:45:27 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:27 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:27 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:27 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:27 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:27 --> Email Class Initialized
INFO - 2017-07-24 12:45:27 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:27 --> Model Class Initialized
INFO - 2017-07-24 12:45:27 --> Model Class Initialized
INFO - 2017-07-24 12:45:27 --> Model Class Initialized
INFO - 2017-07-24 12:45:27 --> Model Class Initialized
INFO - 2017-07-24 12:45:27 --> Controller Class Initialized
INFO - 2017-07-24 12:45:27 --> Model Class Initialized
INFO - 2017-07-24 12:45:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:45:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/email_templates.php
INFO - 2017-07-24 12:45:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:27 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:27 --> Total execution time: 0.0790
DEBUG - 2017-07-24 12:45:27 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:27 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:27 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:28 --> Config Class Initialized
INFO - 2017-07-24 12:45:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:28 --> URI Class Initialized
INFO - 2017-07-24 12:45:28 --> Router Class Initialized
INFO - 2017-07-24 12:45:28 --> Output Class Initialized
INFO - 2017-07-24 12:45:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:28 --> Input Class Initialized
INFO - 2017-07-24 12:45:28 --> Language Class Initialized
INFO - 2017-07-24 12:45:28 --> Loader Class Initialized
INFO - 2017-07-24 12:45:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:28 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:28 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:28 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:28 --> Email Class Initialized
INFO - 2017-07-24 12:45:28 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:28 --> Model Class Initialized
INFO - 2017-07-24 12:45:28 --> Model Class Initialized
INFO - 2017-07-24 12:45:28 --> Model Class Initialized
INFO - 2017-07-24 12:45:28 --> Model Class Initialized
INFO - 2017-07-24 12:45:28 --> Controller Class Initialized
INFO - 2017-07-24 12:45:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:45:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/page.php
INFO - 2017-07-24 12:45:28 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:45:28 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:28 --> Total execution time: 0.0760
DEBUG - 2017-07-24 12:45:28 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:28 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:28 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:31 --> Config Class Initialized
INFO - 2017-07-24 12:45:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:31 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:31 --> URI Class Initialized
INFO - 2017-07-24 12:45:31 --> Router Class Initialized
INFO - 2017-07-24 12:45:31 --> Output Class Initialized
INFO - 2017-07-24 12:45:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:31 --> Input Class Initialized
INFO - 2017-07-24 12:45:31 --> Language Class Initialized
INFO - 2017-07-24 12:45:31 --> Loader Class Initialized
INFO - 2017-07-24 12:45:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:31 --> Email Class Initialized
INFO - 2017-07-24 12:45:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Controller Class Initialized
INFO - 2017-07-24 12:45:31 --> Config Class Initialized
INFO - 2017-07-24 12:45:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:31 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:31 --> URI Class Initialized
INFO - 2017-07-24 12:45:31 --> Router Class Initialized
INFO - 2017-07-24 12:45:31 --> Output Class Initialized
INFO - 2017-07-24 12:45:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:31 --> Input Class Initialized
INFO - 2017-07-24 12:45:31 --> Language Class Initialized
INFO - 2017-07-24 12:45:31 --> Loader Class Initialized
INFO - 2017-07-24 12:45:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:31 --> Email Class Initialized
INFO - 2017-07-24 12:45:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Model Class Initialized
INFO - 2017-07-24 12:45:31 --> Controller Class Initialized
INFO - 2017-07-24 12:45:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:45:31 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:31 --> Total execution time: 0.0750
DEBUG - 2017-07-24 12:45:31 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:31 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:31 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:35 --> Config Class Initialized
INFO - 2017-07-24 12:45:35 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:35 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:35 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:35 --> URI Class Initialized
DEBUG - 2017-07-24 12:45:35 --> No URI present. Default controller set.
INFO - 2017-07-24 12:45:35 --> Router Class Initialized
INFO - 2017-07-24 12:45:35 --> Output Class Initialized
INFO - 2017-07-24 12:45:35 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:35 --> Input Class Initialized
INFO - 2017-07-24 12:45:35 --> Language Class Initialized
INFO - 2017-07-24 12:45:35 --> Loader Class Initialized
INFO - 2017-07-24 12:45:35 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:35 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:35 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:35 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:35 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:35 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:35 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:35 --> Email Class Initialized
INFO - 2017-07-24 12:45:35 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:35 --> Model Class Initialized
INFO - 2017-07-24 12:45:35 --> Model Class Initialized
INFO - 2017-07-24 12:45:35 --> Model Class Initialized
INFO - 2017-07-24 12:45:35 --> Model Class Initialized
INFO - 2017-07-24 12:45:35 --> Controller Class Initialized
DEBUG - 2017-07-24 12:45:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:35 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 12:45:35 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 12:45:35 --> Final output sent to browser
DEBUG - 2017-07-24 12:45:35 --> Total execution time: 0.1410
DEBUG - 2017-07-24 12:45:35 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:45:35 --> Database Forge Class Initialized
INFO - 2017-07-24 12:45:35 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:42 --> Config Class Initialized
INFO - 2017-07-24 12:45:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:45:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:45:42 --> Utf8 Class Initialized
INFO - 2017-07-24 12:45:42 --> URI Class Initialized
INFO - 2017-07-24 12:45:42 --> Router Class Initialized
INFO - 2017-07-24 12:45:42 --> Output Class Initialized
INFO - 2017-07-24 12:45:42 --> Security Class Initialized
DEBUG - 2017-07-24 12:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:45:42 --> Input Class Initialized
INFO - 2017-07-24 12:45:42 --> Language Class Initialized
INFO - 2017-07-24 12:45:42 --> Loader Class Initialized
INFO - 2017-07-24 12:45:42 --> Helper loaded: url_helper
INFO - 2017-07-24 12:45:42 --> Helper loaded: form_helper
INFO - 2017-07-24 12:45:42 --> Helper loaded: security_helper
INFO - 2017-07-24 12:45:42 --> Helper loaded: path_helper
INFO - 2017-07-24 12:45:42 --> Helper loaded: common_helper
INFO - 2017-07-24 12:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:45:42 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:45:42 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:45:42 --> Email Class Initialized
INFO - 2017-07-24 12:45:42 --> Form Validation Class Initialized
INFO - 2017-07-24 12:45:42 --> Model Class Initialized
INFO - 2017-07-24 12:45:42 --> Model Class Initialized
INFO - 2017-07-24 12:45:42 --> Model Class Initialized
INFO - 2017-07-24 12:45:42 --> Model Class Initialized
INFO - 2017-07-24 12:45:42 --> Controller Class Initialized
INFO - 2017-07-24 12:45:42 --> Model Class Initialized
ERROR - 2017-07-24 12:45:42 --> Query error: Unknown column 'url_slug' in 'where clause' - Invalid query: SELECT *
FROM `page`
WHERE `url_slug` = 'how-it-works'
 LIMIT 1
INFO - 2017-07-24 12:45:42 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:47:29 --> Config Class Initialized
INFO - 2017-07-24 12:47:29 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:47:29 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:47:29 --> Utf8 Class Initialized
INFO - 2017-07-24 12:47:29 --> URI Class Initialized
INFO - 2017-07-24 12:47:29 --> Router Class Initialized
INFO - 2017-07-24 12:47:29 --> Output Class Initialized
INFO - 2017-07-24 12:47:29 --> Security Class Initialized
DEBUG - 2017-07-24 12:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:47:29 --> Input Class Initialized
INFO - 2017-07-24 12:47:29 --> Language Class Initialized
INFO - 2017-07-24 12:47:29 --> Loader Class Initialized
INFO - 2017-07-24 12:47:29 --> Helper loaded: url_helper
INFO - 2017-07-24 12:47:29 --> Helper loaded: form_helper
INFO - 2017-07-24 12:47:29 --> Helper loaded: security_helper
INFO - 2017-07-24 12:47:29 --> Helper loaded: path_helper
INFO - 2017-07-24 12:47:29 --> Helper loaded: common_helper
INFO - 2017-07-24 12:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:47:29 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:47:29 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:47:29 --> Email Class Initialized
INFO - 2017-07-24 12:47:29 --> Form Validation Class Initialized
INFO - 2017-07-24 12:47:29 --> Model Class Initialized
INFO - 2017-07-24 12:47:29 --> Model Class Initialized
INFO - 2017-07-24 12:47:29 --> Model Class Initialized
INFO - 2017-07-24 12:47:29 --> Model Class Initialized
INFO - 2017-07-24 12:47:29 --> Controller Class Initialized
INFO - 2017-07-24 12:47:29 --> Model Class Initialized
INFO - 2017-07-24 12:47:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\page.php
INFO - 2017-07-24 12:47:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:47:29 --> Final output sent to browser
DEBUG - 2017-07-24 12:47:29 --> Total execution time: 0.1780
DEBUG - 2017-07-24 12:47:29 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:47:29 --> Database Forge Class Initialized
INFO - 2017-07-24 12:47:29 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:47:36 --> Config Class Initialized
INFO - 2017-07-24 12:47:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:47:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:47:36 --> Utf8 Class Initialized
INFO - 2017-07-24 12:47:36 --> URI Class Initialized
INFO - 2017-07-24 12:47:36 --> Router Class Initialized
INFO - 2017-07-24 12:47:36 --> Output Class Initialized
INFO - 2017-07-24 12:47:36 --> Security Class Initialized
DEBUG - 2017-07-24 12:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:47:36 --> Input Class Initialized
INFO - 2017-07-24 12:47:36 --> Language Class Initialized
ERROR - 2017-07-24 12:47:36 --> 404 Page Not Found: Page/assets
INFO - 2017-07-24 12:47:38 --> Config Class Initialized
INFO - 2017-07-24 12:47:38 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:47:38 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:47:38 --> Utf8 Class Initialized
INFO - 2017-07-24 12:47:38 --> URI Class Initialized
INFO - 2017-07-24 12:47:38 --> Router Class Initialized
INFO - 2017-07-24 12:47:38 --> Output Class Initialized
INFO - 2017-07-24 12:47:38 --> Security Class Initialized
DEBUG - 2017-07-24 12:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:47:38 --> Input Class Initialized
INFO - 2017-07-24 12:47:38 --> Language Class Initialized
ERROR - 2017-07-24 12:47:38 --> 404 Page Not Found: Page/assets
INFO - 2017-07-24 12:48:30 --> Config Class Initialized
INFO - 2017-07-24 12:48:30 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:48:30 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:48:30 --> Utf8 Class Initialized
INFO - 2017-07-24 12:48:30 --> URI Class Initialized
INFO - 2017-07-24 12:48:30 --> Router Class Initialized
INFO - 2017-07-24 12:48:30 --> Output Class Initialized
INFO - 2017-07-24 12:48:30 --> Security Class Initialized
DEBUG - 2017-07-24 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:48:30 --> Input Class Initialized
INFO - 2017-07-24 12:48:30 --> Language Class Initialized
INFO - 2017-07-24 12:48:30 --> Loader Class Initialized
INFO - 2017-07-24 12:48:30 --> Helper loaded: url_helper
INFO - 2017-07-24 12:48:30 --> Helper loaded: form_helper
INFO - 2017-07-24 12:48:30 --> Helper loaded: security_helper
INFO - 2017-07-24 12:48:30 --> Helper loaded: path_helper
INFO - 2017-07-24 12:48:30 --> Helper loaded: common_helper
INFO - 2017-07-24 12:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:48:30 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:48:30 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:48:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:48:30 --> Email Class Initialized
INFO - 2017-07-24 12:48:30 --> Form Validation Class Initialized
INFO - 2017-07-24 12:48:30 --> Model Class Initialized
INFO - 2017-07-24 12:48:30 --> Model Class Initialized
INFO - 2017-07-24 12:48:30 --> Model Class Initialized
INFO - 2017-07-24 12:48:30 --> Model Class Initialized
INFO - 2017-07-24 12:48:30 --> Controller Class Initialized
INFO - 2017-07-24 12:48:30 --> Model Class Initialized
ERROR - 2017-07-24 12:48:30 --> 404 Page Not Found: 
INFO - 2017-07-24 12:48:30 --> Config Class Initialized
INFO - 2017-07-24 12:48:30 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:48:30 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:48:30 --> Utf8 Class Initialized
INFO - 2017-07-24 12:48:30 --> URI Class Initialized
INFO - 2017-07-24 12:48:30 --> Router Class Initialized
INFO - 2017-07-24 12:48:31 --> Output Class Initialized
INFO - 2017-07-24 12:48:31 --> Security Class Initialized
DEBUG - 2017-07-24 12:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:48:31 --> Input Class Initialized
INFO - 2017-07-24 12:48:31 --> Language Class Initialized
INFO - 2017-07-24 12:48:31 --> Loader Class Initialized
INFO - 2017-07-24 12:48:31 --> Helper loaded: url_helper
INFO - 2017-07-24 12:48:31 --> Helper loaded: form_helper
INFO - 2017-07-24 12:48:31 --> Helper loaded: security_helper
INFO - 2017-07-24 12:48:31 --> Helper loaded: path_helper
INFO - 2017-07-24 12:48:31 --> Helper loaded: common_helper
INFO - 2017-07-24 12:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:48:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:48:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:48:31 --> Email Class Initialized
INFO - 2017-07-24 12:48:31 --> Form Validation Class Initialized
INFO - 2017-07-24 12:48:31 --> Model Class Initialized
INFO - 2017-07-24 12:48:31 --> Model Class Initialized
INFO - 2017-07-24 12:48:31 --> Model Class Initialized
INFO - 2017-07-24 12:48:31 --> Model Class Initialized
INFO - 2017-07-24 12:48:31 --> Controller Class Initialized
INFO - 2017-07-24 12:48:31 --> Helper loaded: captcha_helper
ERROR - 2017-07-24 12:48:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\oncolens\application\views\template\cms_template.php 9
ERROR - 2017-07-24 12:48:31 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\oncolens\application\views\template\cms_template.php 9
ERROR - 2017-07-24 12:48:31 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\oncolens\application\views\template\cms_template.php 10
ERROR - 2017-07-24 12:48:31 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\oncolens\application\views\template\cms_template.php 10
INFO - 2017-07-24 12:48:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\contact_us.php
INFO - 2017-07-24 12:48:31 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:48:31 --> Final output sent to browser
DEBUG - 2017-07-24 12:48:31 --> Total execution time: 0.1880
DEBUG - 2017-07-24 12:48:31 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:48:31 --> Database Forge Class Initialized
INFO - 2017-07-24 12:48:31 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:48:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:14 --> Config Class Initialized
INFO - 2017-07-24 12:49:14 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:49:14 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:49:14 --> Utf8 Class Initialized
INFO - 2017-07-24 12:49:14 --> URI Class Initialized
INFO - 2017-07-24 12:49:14 --> Router Class Initialized
INFO - 2017-07-24 12:49:14 --> Output Class Initialized
INFO - 2017-07-24 12:49:14 --> Security Class Initialized
DEBUG - 2017-07-24 12:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:49:14 --> Input Class Initialized
INFO - 2017-07-24 12:49:14 --> Language Class Initialized
INFO - 2017-07-24 12:49:14 --> Loader Class Initialized
INFO - 2017-07-24 12:49:14 --> Helper loaded: url_helper
INFO - 2017-07-24 12:49:14 --> Helper loaded: form_helper
INFO - 2017-07-24 12:49:14 --> Helper loaded: security_helper
INFO - 2017-07-24 12:49:14 --> Helper loaded: path_helper
INFO - 2017-07-24 12:49:14 --> Helper loaded: common_helper
INFO - 2017-07-24 12:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:49:14 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:49:14 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:14 --> Email Class Initialized
INFO - 2017-07-24 12:49:14 --> Form Validation Class Initialized
INFO - 2017-07-24 12:49:14 --> Model Class Initialized
INFO - 2017-07-24 12:49:14 --> Model Class Initialized
INFO - 2017-07-24 12:49:14 --> Model Class Initialized
INFO - 2017-07-24 12:49:14 --> Model Class Initialized
INFO - 2017-07-24 12:49:14 --> Controller Class Initialized
INFO - 2017-07-24 12:49:14 --> Model Class Initialized
INFO - 2017-07-24 12:49:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\page.php
INFO - 2017-07-24 12:49:14 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:49:14 --> Final output sent to browser
DEBUG - 2017-07-24 12:49:14 --> Total execution time: 0.0650
DEBUG - 2017-07-24 12:49:14 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:49:14 --> Database Forge Class Initialized
INFO - 2017-07-24 12:49:14 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:21 --> Config Class Initialized
INFO - 2017-07-24 12:49:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:49:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:49:21 --> Utf8 Class Initialized
INFO - 2017-07-24 12:49:21 --> URI Class Initialized
INFO - 2017-07-24 12:49:21 --> Router Class Initialized
INFO - 2017-07-24 12:49:21 --> Output Class Initialized
INFO - 2017-07-24 12:49:21 --> Security Class Initialized
DEBUG - 2017-07-24 12:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:49:21 --> Input Class Initialized
INFO - 2017-07-24 12:49:21 --> Language Class Initialized
INFO - 2017-07-24 12:49:21 --> Loader Class Initialized
INFO - 2017-07-24 12:49:21 --> Helper loaded: url_helper
INFO - 2017-07-24 12:49:21 --> Helper loaded: form_helper
INFO - 2017-07-24 12:49:21 --> Helper loaded: security_helper
INFO - 2017-07-24 12:49:21 --> Helper loaded: path_helper
INFO - 2017-07-24 12:49:21 --> Helper loaded: common_helper
INFO - 2017-07-24 12:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:49:21 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:49:21 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:21 --> Email Class Initialized
INFO - 2017-07-24 12:49:21 --> Form Validation Class Initialized
INFO - 2017-07-24 12:49:21 --> Model Class Initialized
INFO - 2017-07-24 12:49:21 --> Model Class Initialized
INFO - 2017-07-24 12:49:21 --> Model Class Initialized
INFO - 2017-07-24 12:49:21 --> Model Class Initialized
INFO - 2017-07-24 12:49:21 --> Controller Class Initialized
INFO - 2017-07-24 12:49:21 --> Model Class Initialized
ERROR - 2017-07-24 12:49:21 --> 404 Page Not Found: 
INFO - 2017-07-24 12:49:42 --> Config Class Initialized
INFO - 2017-07-24 12:49:42 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:49:42 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:49:42 --> Utf8 Class Initialized
INFO - 2017-07-24 12:49:42 --> URI Class Initialized
INFO - 2017-07-24 12:49:42 --> Router Class Initialized
INFO - 2017-07-24 12:49:42 --> Output Class Initialized
INFO - 2017-07-24 12:49:42 --> Security Class Initialized
DEBUG - 2017-07-24 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:49:42 --> Input Class Initialized
INFO - 2017-07-24 12:49:42 --> Language Class Initialized
INFO - 2017-07-24 12:49:42 --> Loader Class Initialized
INFO - 2017-07-24 12:49:42 --> Helper loaded: url_helper
INFO - 2017-07-24 12:49:42 --> Helper loaded: form_helper
INFO - 2017-07-24 12:49:42 --> Helper loaded: security_helper
INFO - 2017-07-24 12:49:42 --> Helper loaded: path_helper
INFO - 2017-07-24 12:49:42 --> Helper loaded: common_helper
INFO - 2017-07-24 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:49:42 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:49:42 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:42 --> Email Class Initialized
INFO - 2017-07-24 12:49:42 --> Form Validation Class Initialized
INFO - 2017-07-24 12:49:42 --> Model Class Initialized
INFO - 2017-07-24 12:49:42 --> Model Class Initialized
INFO - 2017-07-24 12:49:42 --> Model Class Initialized
INFO - 2017-07-24 12:49:42 --> Model Class Initialized
INFO - 2017-07-24 12:49:42 --> Controller Class Initialized
INFO - 2017-07-24 12:49:42 --> Model Class Initialized
INFO - 2017-07-24 12:49:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\page.php
INFO - 2017-07-24 12:49:42 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:49:42 --> Final output sent to browser
DEBUG - 2017-07-24 12:49:42 --> Total execution time: 0.1400
DEBUG - 2017-07-24 12:49:42 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:49:42 --> Database Forge Class Initialized
INFO - 2017-07-24 12:49:42 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:49:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:47 --> Config Class Initialized
INFO - 2017-07-24 12:49:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:49:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:49:47 --> Utf8 Class Initialized
INFO - 2017-07-24 12:49:47 --> URI Class Initialized
INFO - 2017-07-24 12:49:47 --> Router Class Initialized
INFO - 2017-07-24 12:49:47 --> Output Class Initialized
INFO - 2017-07-24 12:49:47 --> Security Class Initialized
DEBUG - 2017-07-24 12:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:49:47 --> Input Class Initialized
INFO - 2017-07-24 12:49:47 --> Language Class Initialized
INFO - 2017-07-24 12:49:47 --> Loader Class Initialized
INFO - 2017-07-24 12:49:47 --> Helper loaded: url_helper
INFO - 2017-07-24 12:49:47 --> Helper loaded: form_helper
INFO - 2017-07-24 12:49:47 --> Helper loaded: security_helper
INFO - 2017-07-24 12:49:47 --> Helper loaded: path_helper
INFO - 2017-07-24 12:49:47 --> Helper loaded: common_helper
INFO - 2017-07-24 12:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:49:47 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:49:47 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:48 --> Email Class Initialized
INFO - 2017-07-24 12:49:48 --> Form Validation Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Controller Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
ERROR - 2017-07-24 12:49:48 --> 404 Page Not Found: 
INFO - 2017-07-24 12:49:48 --> Config Class Initialized
INFO - 2017-07-24 12:49:48 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:49:48 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:49:48 --> Utf8 Class Initialized
INFO - 2017-07-24 12:49:48 --> URI Class Initialized
INFO - 2017-07-24 12:49:48 --> Router Class Initialized
INFO - 2017-07-24 12:49:48 --> Output Class Initialized
INFO - 2017-07-24 12:49:48 --> Security Class Initialized
DEBUG - 2017-07-24 12:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:49:48 --> Input Class Initialized
INFO - 2017-07-24 12:49:48 --> Language Class Initialized
INFO - 2017-07-24 12:49:48 --> Loader Class Initialized
INFO - 2017-07-24 12:49:48 --> Helper loaded: url_helper
INFO - 2017-07-24 12:49:48 --> Helper loaded: form_helper
INFO - 2017-07-24 12:49:48 --> Helper loaded: security_helper
INFO - 2017-07-24 12:49:48 --> Helper loaded: path_helper
INFO - 2017-07-24 12:49:48 --> Helper loaded: common_helper
INFO - 2017-07-24 12:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:49:48 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:49:48 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:49:48 --> Email Class Initialized
INFO - 2017-07-24 12:49:48 --> Form Validation Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
INFO - 2017-07-24 12:49:48 --> Controller Class Initialized
INFO - 2017-07-24 12:49:48 --> Model Class Initialized
ERROR - 2017-07-24 12:49:48 --> 404 Page Not Found: 
INFO - 2017-07-24 12:50:16 --> Config Class Initialized
INFO - 2017-07-24 12:50:16 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:50:16 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:50:16 --> Utf8 Class Initialized
INFO - 2017-07-24 12:50:16 --> URI Class Initialized
INFO - 2017-07-24 12:50:16 --> Router Class Initialized
INFO - 2017-07-24 12:50:16 --> Output Class Initialized
INFO - 2017-07-24 12:50:16 --> Security Class Initialized
DEBUG - 2017-07-24 12:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:50:16 --> Input Class Initialized
INFO - 2017-07-24 12:50:16 --> Language Class Initialized
INFO - 2017-07-24 12:50:16 --> Loader Class Initialized
INFO - 2017-07-24 12:50:16 --> Helper loaded: url_helper
INFO - 2017-07-24 12:50:16 --> Helper loaded: form_helper
INFO - 2017-07-24 12:50:16 --> Helper loaded: security_helper
INFO - 2017-07-24 12:50:16 --> Helper loaded: path_helper
INFO - 2017-07-24 12:50:16 --> Helper loaded: common_helper
INFO - 2017-07-24 12:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:50:16 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:50:16 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:16 --> Email Class Initialized
INFO - 2017-07-24 12:50:16 --> Form Validation Class Initialized
INFO - 2017-07-24 12:50:16 --> Model Class Initialized
INFO - 2017-07-24 12:50:16 --> Model Class Initialized
INFO - 2017-07-24 12:50:16 --> Model Class Initialized
INFO - 2017-07-24 12:50:16 --> Model Class Initialized
INFO - 2017-07-24 12:50:16 --> Controller Class Initialized
INFO - 2017-07-24 12:50:16 --> Model Class Initialized
INFO - 2017-07-24 12:50:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\page.php
INFO - 2017-07-24 12:50:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:50:16 --> Final output sent to browser
DEBUG - 2017-07-24 12:50:16 --> Total execution time: 0.0810
DEBUG - 2017-07-24 12:50:16 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:50:16 --> Database Forge Class Initialized
INFO - 2017-07-24 12:50:16 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:50 --> Config Class Initialized
INFO - 2017-07-24 12:50:50 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:50:50 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:50:50 --> Utf8 Class Initialized
INFO - 2017-07-24 12:50:50 --> URI Class Initialized
INFO - 2017-07-24 12:50:50 --> Router Class Initialized
INFO - 2017-07-24 12:50:50 --> Output Class Initialized
INFO - 2017-07-24 12:50:50 --> Security Class Initialized
DEBUG - 2017-07-24 12:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:50:50 --> Input Class Initialized
INFO - 2017-07-24 12:50:50 --> Language Class Initialized
INFO - 2017-07-24 12:50:50 --> Loader Class Initialized
INFO - 2017-07-24 12:50:50 --> Helper loaded: url_helper
INFO - 2017-07-24 12:50:50 --> Helper loaded: form_helper
INFO - 2017-07-24 12:50:50 --> Helper loaded: security_helper
INFO - 2017-07-24 12:50:50 --> Helper loaded: path_helper
INFO - 2017-07-24 12:50:50 --> Helper loaded: common_helper
INFO - 2017-07-24 12:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:50:50 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:50:50 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:50 --> Email Class Initialized
INFO - 2017-07-24 12:50:50 --> Form Validation Class Initialized
INFO - 2017-07-24 12:50:50 --> Model Class Initialized
INFO - 2017-07-24 12:50:50 --> Model Class Initialized
INFO - 2017-07-24 12:50:50 --> Model Class Initialized
INFO - 2017-07-24 12:50:50 --> Model Class Initialized
INFO - 2017-07-24 12:50:50 --> Controller Class Initialized
INFO - 2017-07-24 12:50:50 --> Model Class Initialized
INFO - 2017-07-24 12:50:50 --> File loaded: E:\xampp\htdocs\oncolens\application\views\page.php
INFO - 2017-07-24 12:50:50 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/cms_template.php
INFO - 2017-07-24 12:50:50 --> Final output sent to browser
DEBUG - 2017-07-24 12:50:50 --> Total execution time: 0.0710
DEBUG - 2017-07-24 12:50:50 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:50:50 --> Database Forge Class Initialized
INFO - 2017-07-24 12:50:50 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:56 --> Config Class Initialized
INFO - 2017-07-24 12:50:56 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:50:56 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:50:56 --> Utf8 Class Initialized
INFO - 2017-07-24 12:50:56 --> URI Class Initialized
DEBUG - 2017-07-24 12:50:56 --> No URI present. Default controller set.
INFO - 2017-07-24 12:50:56 --> Router Class Initialized
INFO - 2017-07-24 12:50:56 --> Output Class Initialized
INFO - 2017-07-24 12:50:56 --> Security Class Initialized
DEBUG - 2017-07-24 12:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:50:56 --> Input Class Initialized
INFO - 2017-07-24 12:50:56 --> Language Class Initialized
INFO - 2017-07-24 12:50:56 --> Loader Class Initialized
INFO - 2017-07-24 12:50:56 --> Helper loaded: url_helper
INFO - 2017-07-24 12:50:56 --> Helper loaded: form_helper
INFO - 2017-07-24 12:50:56 --> Helper loaded: security_helper
INFO - 2017-07-24 12:50:56 --> Helper loaded: path_helper
INFO - 2017-07-24 12:50:56 --> Helper loaded: common_helper
INFO - 2017-07-24 12:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:50:56 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:50:56 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:56 --> Email Class Initialized
INFO - 2017-07-24 12:50:56 --> Form Validation Class Initialized
INFO - 2017-07-24 12:50:56 --> Model Class Initialized
INFO - 2017-07-24 12:50:56 --> Model Class Initialized
INFO - 2017-07-24 12:50:56 --> Model Class Initialized
INFO - 2017-07-24 12:50:56 --> Model Class Initialized
INFO - 2017-07-24 12:50:56 --> Controller Class Initialized
DEBUG - 2017-07-24 12:50:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:50:56 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 12:50:56 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 12:50:56 --> Final output sent to browser
DEBUG - 2017-07-24 12:50:56 --> Total execution time: 0.1570
DEBUG - 2017-07-24 12:50:56 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:50:56 --> Database Forge Class Initialized
INFO - 2017-07-24 12:50:57 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:07 --> Config Class Initialized
INFO - 2017-07-24 12:51:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:07 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:07 --> URI Class Initialized
INFO - 2017-07-24 12:51:07 --> Router Class Initialized
INFO - 2017-07-24 12:51:07 --> Output Class Initialized
INFO - 2017-07-24 12:51:07 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:07 --> Input Class Initialized
INFO - 2017-07-24 12:51:07 --> Language Class Initialized
INFO - 2017-07-24 12:51:07 --> Loader Class Initialized
INFO - 2017-07-24 12:51:07 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:07 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:07 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:07 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:07 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:07 --> Email Class Initialized
INFO - 2017-07-24 12:51:07 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:07 --> Model Class Initialized
INFO - 2017-07-24 12:51:07 --> Model Class Initialized
INFO - 2017-07-24 12:51:07 --> Model Class Initialized
INFO - 2017-07-24 12:51:07 --> Model Class Initialized
INFO - 2017-07-24 12:51:07 --> Controller Class Initialized
INFO - 2017-07-24 12:51:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 12:51:07 --> Final output sent to browser
DEBUG - 2017-07-24 12:51:07 --> Total execution time: 0.0590
DEBUG - 2017-07-24 12:51:07 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:51:07 --> Database Forge Class Initialized
INFO - 2017-07-24 12:51:07 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:12 --> Config Class Initialized
INFO - 2017-07-24 12:51:12 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:12 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:12 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:12 --> URI Class Initialized
INFO - 2017-07-24 12:51:12 --> Router Class Initialized
INFO - 2017-07-24 12:51:12 --> Output Class Initialized
INFO - 2017-07-24 12:51:12 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:12 --> Input Class Initialized
INFO - 2017-07-24 12:51:12 --> Language Class Initialized
INFO - 2017-07-24 12:51:12 --> Loader Class Initialized
INFO - 2017-07-24 12:51:12 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:12 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:12 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:12 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:12 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:12 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:12 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:12 --> Email Class Initialized
INFO - 2017-07-24 12:51:12 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:12 --> Model Class Initialized
INFO - 2017-07-24 12:51:12 --> Model Class Initialized
INFO - 2017-07-24 12:51:12 --> Model Class Initialized
INFO - 2017-07-24 12:51:12 --> Model Class Initialized
INFO - 2017-07-24 12:51:12 --> Controller Class Initialized
INFO - 2017-07-24 12:51:13 --> Config Class Initialized
INFO - 2017-07-24 12:51:13 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:13 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:13 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:13 --> URI Class Initialized
INFO - 2017-07-24 12:51:13 --> Router Class Initialized
INFO - 2017-07-24 12:51:13 --> Output Class Initialized
INFO - 2017-07-24 12:51:13 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:13 --> Input Class Initialized
INFO - 2017-07-24 12:51:13 --> Language Class Initialized
INFO - 2017-07-24 12:51:13 --> Loader Class Initialized
INFO - 2017-07-24 12:51:13 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:13 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:13 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:13 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:13 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:13 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:13 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:13 --> Email Class Initialized
INFO - 2017-07-24 12:51:13 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:13 --> Model Class Initialized
INFO - 2017-07-24 12:51:13 --> Model Class Initialized
INFO - 2017-07-24 12:51:13 --> Model Class Initialized
INFO - 2017-07-24 12:51:13 --> Model Class Initialized
INFO - 2017-07-24 12:51:13 --> Controller Class Initialized
INFO - 2017-07-24 12:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:51:13 --> Pagination Class Initialized
INFO - 2017-07-24 12:51:13 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:51:13 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:51:13 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:51:13 --> Final output sent to browser
DEBUG - 2017-07-24 12:51:13 --> Total execution time: 0.2330
DEBUG - 2017-07-24 12:51:13 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:51:13 --> Database Forge Class Initialized
INFO - 2017-07-24 12:51:13 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:17 --> Config Class Initialized
INFO - 2017-07-24 12:51:17 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:17 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:17 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:17 --> URI Class Initialized
INFO - 2017-07-24 12:51:17 --> Router Class Initialized
INFO - 2017-07-24 12:51:17 --> Output Class Initialized
INFO - 2017-07-24 12:51:17 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:17 --> Input Class Initialized
INFO - 2017-07-24 12:51:17 --> Language Class Initialized
INFO - 2017-07-24 12:51:17 --> Loader Class Initialized
INFO - 2017-07-24 12:51:17 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:17 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:17 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:17 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:17 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:17 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:17 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:17 --> Email Class Initialized
INFO - 2017-07-24 12:51:17 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:17 --> Model Class Initialized
INFO - 2017-07-24 12:51:17 --> Model Class Initialized
INFO - 2017-07-24 12:51:17 --> Model Class Initialized
INFO - 2017-07-24 12:51:17 --> Model Class Initialized
INFO - 2017-07-24 12:51:17 --> Controller Class Initialized
DEBUG - 2017-07-24 12:51:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
ERROR - 2017-07-24 12:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\admin\user_add.php 63
INFO - 2017-07-24 12:51:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:51:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:51:17 --> Final output sent to browser
DEBUG - 2017-07-24 12:51:17 --> Total execution time: 0.0940
DEBUG - 2017-07-24 12:51:17 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:51:17 --> Database Forge Class Initialized
INFO - 2017-07-24 12:51:17 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:46 --> Config Class Initialized
INFO - 2017-07-24 12:51:46 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:46 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:46 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:46 --> URI Class Initialized
INFO - 2017-07-24 12:51:46 --> Router Class Initialized
INFO - 2017-07-24 12:51:46 --> Output Class Initialized
INFO - 2017-07-24 12:51:46 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:46 --> Input Class Initialized
INFO - 2017-07-24 12:51:46 --> Language Class Initialized
INFO - 2017-07-24 12:51:46 --> Loader Class Initialized
INFO - 2017-07-24 12:51:46 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:46 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:46 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:46 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:46 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:46 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:46 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:46 --> Email Class Initialized
INFO - 2017-07-24 12:51:46 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:46 --> Model Class Initialized
INFO - 2017-07-24 12:51:46 --> Model Class Initialized
INFO - 2017-07-24 12:51:46 --> Model Class Initialized
INFO - 2017-07-24 12:51:46 --> Model Class Initialized
INFO - 2017-07-24 12:51:46 --> Controller Class Initialized
DEBUG - 2017-07-24 12:51:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:51:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:51:46 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:51:46 --> Final output sent to browser
DEBUG - 2017-07-24 12:51:46 --> Total execution time: 0.2040
DEBUG - 2017-07-24 12:51:46 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:51:46 --> Database Forge Class Initialized
INFO - 2017-07-24 12:51:46 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:54 --> Config Class Initialized
INFO - 2017-07-24 12:51:54 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:51:54 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:51:54 --> Utf8 Class Initialized
INFO - 2017-07-24 12:51:54 --> URI Class Initialized
INFO - 2017-07-24 12:51:54 --> Router Class Initialized
INFO - 2017-07-24 12:51:54 --> Output Class Initialized
INFO - 2017-07-24 12:51:54 --> Security Class Initialized
DEBUG - 2017-07-24 12:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:51:54 --> Input Class Initialized
INFO - 2017-07-24 12:51:54 --> Language Class Initialized
INFO - 2017-07-24 12:51:54 --> Loader Class Initialized
INFO - 2017-07-24 12:51:54 --> Helper loaded: url_helper
INFO - 2017-07-24 12:51:54 --> Helper loaded: form_helper
INFO - 2017-07-24 12:51:54 --> Helper loaded: security_helper
INFO - 2017-07-24 12:51:54 --> Helper loaded: path_helper
INFO - 2017-07-24 12:51:54 --> Helper loaded: common_helper
INFO - 2017-07-24 12:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:51:54 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:51:54 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:51:54 --> Email Class Initialized
INFO - 2017-07-24 12:51:54 --> Form Validation Class Initialized
INFO - 2017-07-24 12:51:54 --> Model Class Initialized
INFO - 2017-07-24 12:51:54 --> Model Class Initialized
INFO - 2017-07-24 12:51:54 --> Model Class Initialized
INFO - 2017-07-24 12:51:54 --> Model Class Initialized
INFO - 2017-07-24 12:51:54 --> Controller Class Initialized
ERROR - 2017-07-24 12:51:54 --> Query error: Table 'oncolens.hospital_doctor_tumor_board' doesn't exist - Invalid query: SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN(SELECT * from hospital_tumor_board as b where hospital_id = '1') as c on c.tumor_id = a.tumor_id WHERE a.tumor_id NOT IN (SELECT hdtb.tumor_id FROM hospital_doctor AS hd INNER JOIN hospital_doctor_tumor_board AS hdtb ON hd.hospital_doctor_id = hdtb.hospital_doctor_id WHERE hd.hospital_id = '1' AND hd.doctor_id = '' )
INFO - 2017-07-24 12:51:54 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:52:18 --> Config Class Initialized
INFO - 2017-07-24 12:52:18 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:52:18 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:52:18 --> Utf8 Class Initialized
INFO - 2017-07-24 12:52:18 --> URI Class Initialized
INFO - 2017-07-24 12:52:18 --> Router Class Initialized
INFO - 2017-07-24 12:52:18 --> Output Class Initialized
INFO - 2017-07-24 12:52:18 --> Security Class Initialized
DEBUG - 2017-07-24 12:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:52:18 --> Input Class Initialized
INFO - 2017-07-24 12:52:18 --> Language Class Initialized
INFO - 2017-07-24 12:52:18 --> Loader Class Initialized
INFO - 2017-07-24 12:52:18 --> Helper loaded: url_helper
INFO - 2017-07-24 12:52:18 --> Helper loaded: form_helper
INFO - 2017-07-24 12:52:18 --> Helper loaded: security_helper
INFO - 2017-07-24 12:52:18 --> Helper loaded: path_helper
INFO - 2017-07-24 12:52:18 --> Helper loaded: common_helper
INFO - 2017-07-24 12:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:52:18 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:52:18 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:52:18 --> Email Class Initialized
INFO - 2017-07-24 12:52:18 --> Form Validation Class Initialized
INFO - 2017-07-24 12:52:18 --> Model Class Initialized
INFO - 2017-07-24 12:52:18 --> Model Class Initialized
INFO - 2017-07-24 12:52:18 --> Model Class Initialized
INFO - 2017-07-24 12:52:18 --> Model Class Initialized
INFO - 2017-07-24 12:52:18 --> Controller Class Initialized
DEBUG - 2017-07-24 12:52:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:52:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 12:52:18 --> Query error: Table 'oncolens.speciality_hospital_doctor' doesn't exist - Invalid query: INSERT INTO `speciality_hospital_doctor` (`speciality_id`, `hospital_doctor_id`) VALUES ('1', 1)
INFO - 2017-07-24 12:52:18 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:53:10 --> Config Class Initialized
INFO - 2017-07-24 12:53:10 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:10 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:10 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:10 --> URI Class Initialized
INFO - 2017-07-24 12:53:10 --> Router Class Initialized
INFO - 2017-07-24 12:53:10 --> Output Class Initialized
INFO - 2017-07-24 12:53:10 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:10 --> Input Class Initialized
INFO - 2017-07-24 12:53:10 --> Language Class Initialized
INFO - 2017-07-24 12:53:10 --> Loader Class Initialized
INFO - 2017-07-24 12:53:10 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:10 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:10 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:10 --> Email Class Initialized
INFO - 2017-07-24 12:53:10 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Controller Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:53:10 --> Config Class Initialized
INFO - 2017-07-24 12:53:10 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:10 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:10 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:10 --> URI Class Initialized
INFO - 2017-07-24 12:53:10 --> Router Class Initialized
INFO - 2017-07-24 12:53:10 --> Output Class Initialized
INFO - 2017-07-24 12:53:10 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:10 --> Input Class Initialized
INFO - 2017-07-24 12:53:10 --> Language Class Initialized
INFO - 2017-07-24 12:53:10 --> Loader Class Initialized
INFO - 2017-07-24 12:53:10 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:10 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:10 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:10 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:10 --> Email Class Initialized
INFO - 2017-07-24 12:53:10 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Model Class Initialized
INFO - 2017-07-24 12:53:10 --> Controller Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:10 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:53:10 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:53:10 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:53:10 --> Final output sent to browser
DEBUG - 2017-07-24 12:53:10 --> Total execution time: 0.2620
DEBUG - 2017-07-24 12:53:10 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:53:10 --> Database Forge Class Initialized
INFO - 2017-07-24 12:53:10 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:16 --> Config Class Initialized
INFO - 2017-07-24 12:53:16 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:16 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:16 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:16 --> URI Class Initialized
INFO - 2017-07-24 12:53:16 --> Router Class Initialized
INFO - 2017-07-24 12:53:16 --> Output Class Initialized
INFO - 2017-07-24 12:53:16 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:16 --> Input Class Initialized
INFO - 2017-07-24 12:53:16 --> Language Class Initialized
INFO - 2017-07-24 12:53:16 --> Loader Class Initialized
INFO - 2017-07-24 12:53:16 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:16 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:16 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:16 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:16 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:16 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:16 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:16 --> Email Class Initialized
INFO - 2017-07-24 12:53:16 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:16 --> Model Class Initialized
INFO - 2017-07-24 12:53:16 --> Model Class Initialized
INFO - 2017-07-24 12:53:16 --> Model Class Initialized
INFO - 2017-07-24 12:53:16 --> Model Class Initialized
INFO - 2017-07-24 12:53:16 --> Controller Class Initialized
INFO - 2017-07-24 12:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:53:16 --> Pagination Class Initialized
INFO - 2017-07-24 12:53:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:53:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:53:16 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:53:16 --> Final output sent to browser
DEBUG - 2017-07-24 12:53:16 --> Total execution time: 0.0950
DEBUG - 2017-07-24 12:53:16 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:53:16 --> Database Forge Class Initialized
INFO - 2017-07-24 12:53:16 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:39 --> Config Class Initialized
INFO - 2017-07-24 12:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:39 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:39 --> URI Class Initialized
INFO - 2017-07-24 12:53:39 --> Router Class Initialized
INFO - 2017-07-24 12:53:39 --> Output Class Initialized
INFO - 2017-07-24 12:53:39 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:39 --> Input Class Initialized
INFO - 2017-07-24 12:53:39 --> Language Class Initialized
INFO - 2017-07-24 12:53:39 --> Loader Class Initialized
INFO - 2017-07-24 12:53:39 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:39 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:39 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:39 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:39 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:39 --> Email Class Initialized
INFO - 2017-07-24 12:53:39 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:39 --> Model Class Initialized
INFO - 2017-07-24 12:53:39 --> Model Class Initialized
INFO - 2017-07-24 12:53:39 --> Model Class Initialized
INFO - 2017-07-24 12:53:39 --> Model Class Initialized
INFO - 2017-07-24 12:53:39 --> Controller Class Initialized
DEBUG - 2017-07-24 12:53:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:53:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:53:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:53:39 --> Final output sent to browser
DEBUG - 2017-07-24 12:53:39 --> Total execution time: 0.1600
DEBUG - 2017-07-24 12:53:39 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:53:39 --> Database Forge Class Initialized
INFO - 2017-07-24 12:53:39 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:45 --> Config Class Initialized
INFO - 2017-07-24 12:53:45 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:45 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:45 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:45 --> URI Class Initialized
INFO - 2017-07-24 12:53:45 --> Router Class Initialized
INFO - 2017-07-24 12:53:45 --> Output Class Initialized
INFO - 2017-07-24 12:53:45 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:45 --> Input Class Initialized
INFO - 2017-07-24 12:53:45 --> Language Class Initialized
INFO - 2017-07-24 12:53:45 --> Loader Class Initialized
INFO - 2017-07-24 12:53:45 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:45 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:45 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:45 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:45 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:45 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:45 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:45 --> Email Class Initialized
INFO - 2017-07-24 12:53:45 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:45 --> Model Class Initialized
INFO - 2017-07-24 12:53:45 --> Model Class Initialized
INFO - 2017-07-24 12:53:45 --> Model Class Initialized
INFO - 2017-07-24 12:53:45 --> Model Class Initialized
INFO - 2017-07-24 12:53:45 --> Controller Class Initialized
ERROR - 2017-07-24 12:53:45 --> Query error: Table 'oncolens.hospital_doctor_tumor_board' doesn't exist - Invalid query: SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN(SELECT * from hospital_tumor_board as b where hospital_id = '1') as c on c.tumor_id = a.tumor_id WHERE a.tumor_id NOT IN (SELECT hdtb.tumor_id FROM hospital_doctor AS hd INNER JOIN hospital_doctor_tumor_board AS hdtb ON hd.hospital_doctor_id = hdtb.hospital_doctor_id WHERE hd.hospital_id = '1' AND hd.doctor_id = '' )
INFO - 2017-07-24 12:53:45 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:53:58 --> Config Class Initialized
INFO - 2017-07-24 12:53:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:53:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:53:58 --> Utf8 Class Initialized
INFO - 2017-07-24 12:53:58 --> URI Class Initialized
INFO - 2017-07-24 12:53:58 --> Router Class Initialized
INFO - 2017-07-24 12:53:58 --> Output Class Initialized
INFO - 2017-07-24 12:53:58 --> Security Class Initialized
DEBUG - 2017-07-24 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:53:58 --> Input Class Initialized
INFO - 2017-07-24 12:53:58 --> Language Class Initialized
INFO - 2017-07-24 12:53:58 --> Loader Class Initialized
INFO - 2017-07-24 12:53:58 --> Helper loaded: url_helper
INFO - 2017-07-24 12:53:58 --> Helper loaded: form_helper
INFO - 2017-07-24 12:53:58 --> Helper loaded: security_helper
INFO - 2017-07-24 12:53:58 --> Helper loaded: path_helper
INFO - 2017-07-24 12:53:58 --> Helper loaded: common_helper
INFO - 2017-07-24 12:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:53:58 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:53:58 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:58 --> Email Class Initialized
INFO - 2017-07-24 12:53:58 --> Form Validation Class Initialized
INFO - 2017-07-24 12:53:58 --> Model Class Initialized
INFO - 2017-07-24 12:53:58 --> Model Class Initialized
INFO - 2017-07-24 12:53:58 --> Model Class Initialized
INFO - 2017-07-24 12:53:58 --> Model Class Initialized
INFO - 2017-07-24 12:53:58 --> Controller Class Initialized
DEBUG - 2017-07-24 12:53:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:53:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 12:53:58 --> Query error: Table 'oncolens.hospital_doctor_tumor_board' doesn't exist - Invalid query: INSERT INTO `hospital_doctor_tumor_board` (`tumor_id`, `hospital_doctor_id`) VALUES ('', 2)
INFO - 2017-07-24 12:53:58 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:54:40 --> Config Class Initialized
INFO - 2017-07-24 12:54:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:54:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:54:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:54:40 --> URI Class Initialized
INFO - 2017-07-24 12:54:40 --> Router Class Initialized
INFO - 2017-07-24 12:54:40 --> Output Class Initialized
INFO - 2017-07-24 12:54:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:54:40 --> Input Class Initialized
INFO - 2017-07-24 12:54:40 --> Language Class Initialized
INFO - 2017-07-24 12:54:40 --> Loader Class Initialized
INFO - 2017-07-24 12:54:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:54:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:54:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:54:40 --> Email Class Initialized
INFO - 2017-07-24 12:54:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Controller Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:54:40 --> Config Class Initialized
INFO - 2017-07-24 12:54:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:54:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:54:40 --> Utf8 Class Initialized
INFO - 2017-07-24 12:54:40 --> URI Class Initialized
INFO - 2017-07-24 12:54:40 --> Router Class Initialized
INFO - 2017-07-24 12:54:40 --> Output Class Initialized
INFO - 2017-07-24 12:54:40 --> Security Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:54:40 --> Input Class Initialized
INFO - 2017-07-24 12:54:40 --> Language Class Initialized
INFO - 2017-07-24 12:54:40 --> Loader Class Initialized
INFO - 2017-07-24 12:54:40 --> Helper loaded: url_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: form_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: security_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: path_helper
INFO - 2017-07-24 12:54:40 --> Helper loaded: common_helper
INFO - 2017-07-24 12:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:54:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:54:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:54:40 --> Email Class Initialized
INFO - 2017-07-24 12:54:40 --> Form Validation Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Model Class Initialized
INFO - 2017-07-24 12:54:40 --> Controller Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:54:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:54:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:54:40 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:54:40 --> Final output sent to browser
DEBUG - 2017-07-24 12:54:40 --> Total execution time: 0.0770
DEBUG - 2017-07-24 12:54:40 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:54:40 --> Database Forge Class Initialized
INFO - 2017-07-24 12:54:40 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:55:21 --> Config Class Initialized
INFO - 2017-07-24 12:55:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:55:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:55:21 --> Utf8 Class Initialized
INFO - 2017-07-24 12:55:21 --> URI Class Initialized
INFO - 2017-07-24 12:55:21 --> Router Class Initialized
INFO - 2017-07-24 12:55:21 --> Output Class Initialized
INFO - 2017-07-24 12:55:21 --> Security Class Initialized
DEBUG - 2017-07-24 12:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:55:21 --> Input Class Initialized
INFO - 2017-07-24 12:55:21 --> Language Class Initialized
INFO - 2017-07-24 12:55:21 --> Loader Class Initialized
INFO - 2017-07-24 12:55:21 --> Helper loaded: url_helper
INFO - 2017-07-24 12:55:21 --> Helper loaded: form_helper
INFO - 2017-07-24 12:55:21 --> Helper loaded: security_helper
INFO - 2017-07-24 12:55:21 --> Helper loaded: path_helper
INFO - 2017-07-24 12:55:21 --> Helper loaded: common_helper
INFO - 2017-07-24 12:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:55:21 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:55:21 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:55:21 --> Email Class Initialized
INFO - 2017-07-24 12:55:21 --> Form Validation Class Initialized
INFO - 2017-07-24 12:55:21 --> Model Class Initialized
INFO - 2017-07-24 12:55:21 --> Model Class Initialized
INFO - 2017-07-24 12:55:21 --> Model Class Initialized
INFO - 2017-07-24 12:55:21 --> Model Class Initialized
INFO - 2017-07-24 12:55:21 --> Controller Class Initialized
ERROR - 2017-07-24 12:55:21 --> Query error: Unknown column 'hd.hospital_doctor_id' in 'on clause' - Invalid query: SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN(SELECT * from hospital_tumor_board as b where hospital_id = '1') as c on c.tumor_id = a.tumor_id WHERE a.tumor_id NOT IN (SELECT hdtb.tumor_id FROM hospital_doctor AS hd INNER JOIN hospital_doctor_tumor_board AS hdtb ON hd.hospital_doctor_id = hdtb.hospital_doctor_id WHERE hd.hospital_id = '1' AND hd.doctor_id = '' )
INFO - 2017-07-24 12:55:21 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:55:38 --> Config Class Initialized
INFO - 2017-07-24 12:55:38 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:55:38 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:55:38 --> Utf8 Class Initialized
INFO - 2017-07-24 12:55:38 --> URI Class Initialized
INFO - 2017-07-24 12:55:38 --> Router Class Initialized
INFO - 2017-07-24 12:55:38 --> Output Class Initialized
INFO - 2017-07-24 12:55:38 --> Security Class Initialized
DEBUG - 2017-07-24 12:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:55:38 --> Input Class Initialized
INFO - 2017-07-24 12:55:38 --> Language Class Initialized
INFO - 2017-07-24 12:55:38 --> Loader Class Initialized
INFO - 2017-07-24 12:55:38 --> Helper loaded: url_helper
INFO - 2017-07-24 12:55:38 --> Helper loaded: form_helper
INFO - 2017-07-24 12:55:38 --> Helper loaded: security_helper
INFO - 2017-07-24 12:55:38 --> Helper loaded: path_helper
INFO - 2017-07-24 12:55:38 --> Helper loaded: common_helper
INFO - 2017-07-24 12:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:55:38 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:55:38 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:55:38 --> Email Class Initialized
INFO - 2017-07-24 12:55:38 --> Form Validation Class Initialized
INFO - 2017-07-24 12:55:38 --> Model Class Initialized
INFO - 2017-07-24 12:55:38 --> Model Class Initialized
INFO - 2017-07-24 12:55:38 --> Model Class Initialized
INFO - 2017-07-24 12:55:38 --> Model Class Initialized
INFO - 2017-07-24 12:55:38 --> Controller Class Initialized
DEBUG - 2017-07-24 12:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:55:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:55:39 --> Model Class Initialized
ERROR - 2017-07-24 12:55:39 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `email_template`
WHERE `name` = 'registration'
INFO - 2017-07-24 12:55:39 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:56:22 --> Config Class Initialized
INFO - 2017-07-24 12:56:22 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:56:22 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:56:22 --> Utf8 Class Initialized
INFO - 2017-07-24 12:56:22 --> URI Class Initialized
INFO - 2017-07-24 12:56:22 --> Router Class Initialized
INFO - 2017-07-24 12:56:22 --> Output Class Initialized
INFO - 2017-07-24 12:56:22 --> Security Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:56:22 --> Input Class Initialized
INFO - 2017-07-24 12:56:22 --> Language Class Initialized
INFO - 2017-07-24 12:56:22 --> Loader Class Initialized
INFO - 2017-07-24 12:56:22 --> Helper loaded: url_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: form_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: security_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: path_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: common_helper
INFO - 2017-07-24 12:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:56:22 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:56:22 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:22 --> Email Class Initialized
INFO - 2017-07-24 12:56:22 --> Form Validation Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Controller Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:56:22 --> Config Class Initialized
INFO - 2017-07-24 12:56:22 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:56:22 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:56:22 --> Utf8 Class Initialized
INFO - 2017-07-24 12:56:22 --> URI Class Initialized
INFO - 2017-07-24 12:56:22 --> Router Class Initialized
INFO - 2017-07-24 12:56:22 --> Output Class Initialized
INFO - 2017-07-24 12:56:22 --> Security Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:56:22 --> Input Class Initialized
INFO - 2017-07-24 12:56:22 --> Language Class Initialized
INFO - 2017-07-24 12:56:22 --> Loader Class Initialized
INFO - 2017-07-24 12:56:22 --> Helper loaded: url_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: form_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: security_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: path_helper
INFO - 2017-07-24 12:56:22 --> Helper loaded: common_helper
INFO - 2017-07-24 12:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:56:22 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:56:22 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:22 --> Email Class Initialized
INFO - 2017-07-24 12:56:22 --> Form Validation Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Model Class Initialized
INFO - 2017-07-24 12:56:22 --> Controller Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:56:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:56:22 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:56:22 --> Final output sent to browser
DEBUG - 2017-07-24 12:56:22 --> Total execution time: 0.0810
DEBUG - 2017-07-24 12:56:22 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:56:22 --> Database Forge Class Initialized
INFO - 2017-07-24 12:56:22 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:56:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:26 --> Config Class Initialized
INFO - 2017-07-24 12:56:26 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:56:26 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:56:26 --> Utf8 Class Initialized
INFO - 2017-07-24 12:56:26 --> URI Class Initialized
INFO - 2017-07-24 12:56:26 --> Router Class Initialized
INFO - 2017-07-24 12:56:26 --> Output Class Initialized
INFO - 2017-07-24 12:56:26 --> Security Class Initialized
DEBUG - 2017-07-24 12:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:56:26 --> Input Class Initialized
INFO - 2017-07-24 12:56:26 --> Language Class Initialized
INFO - 2017-07-24 12:56:26 --> Loader Class Initialized
INFO - 2017-07-24 12:56:26 --> Helper loaded: url_helper
INFO - 2017-07-24 12:56:26 --> Helper loaded: form_helper
INFO - 2017-07-24 12:56:26 --> Helper loaded: security_helper
INFO - 2017-07-24 12:56:26 --> Helper loaded: path_helper
INFO - 2017-07-24 12:56:26 --> Helper loaded: common_helper
INFO - 2017-07-24 12:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:56:26 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:56:26 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:26 --> Email Class Initialized
INFO - 2017-07-24 12:56:26 --> Form Validation Class Initialized
INFO - 2017-07-24 12:56:26 --> Model Class Initialized
INFO - 2017-07-24 12:56:26 --> Model Class Initialized
INFO - 2017-07-24 12:56:26 --> Model Class Initialized
INFO - 2017-07-24 12:56:26 --> Model Class Initialized
INFO - 2017-07-24 12:56:26 --> Controller Class Initialized
INFO - 2017-07-24 12:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:56:26 --> Pagination Class Initialized
INFO - 2017-07-24 12:56:26 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:56:26 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:56:26 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:56:26 --> Final output sent to browser
DEBUG - 2017-07-24 12:56:26 --> Total execution time: 0.0840
DEBUG - 2017-07-24 12:56:26 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:56:26 --> Database Forge Class Initialized
INFO - 2017-07-24 12:56:26 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:56:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:58 --> Config Class Initialized
INFO - 2017-07-24 12:56:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:56:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:56:58 --> Utf8 Class Initialized
INFO - 2017-07-24 12:56:58 --> URI Class Initialized
INFO - 2017-07-24 12:56:58 --> Router Class Initialized
INFO - 2017-07-24 12:56:58 --> Output Class Initialized
INFO - 2017-07-24 12:56:58 --> Security Class Initialized
DEBUG - 2017-07-24 12:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:56:58 --> Input Class Initialized
INFO - 2017-07-24 12:56:58 --> Language Class Initialized
INFO - 2017-07-24 12:56:58 --> Loader Class Initialized
INFO - 2017-07-24 12:56:58 --> Helper loaded: url_helper
INFO - 2017-07-24 12:56:58 --> Helper loaded: form_helper
INFO - 2017-07-24 12:56:58 --> Helper loaded: security_helper
INFO - 2017-07-24 12:56:58 --> Helper loaded: path_helper
INFO - 2017-07-24 12:56:58 --> Helper loaded: common_helper
INFO - 2017-07-24 12:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:56:58 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:56:58 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:58 --> Email Class Initialized
INFO - 2017-07-24 12:56:58 --> Form Validation Class Initialized
INFO - 2017-07-24 12:56:58 --> Model Class Initialized
INFO - 2017-07-24 12:56:58 --> Model Class Initialized
INFO - 2017-07-24 12:56:58 --> Model Class Initialized
INFO - 2017-07-24 12:56:58 --> Model Class Initialized
INFO - 2017-07-24 12:56:58 --> Controller Class Initialized
DEBUG - 2017-07-24 12:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:56:58 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:56:58 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 12:56:58 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:56:58 --> Final output sent to browser
DEBUG - 2017-07-24 12:56:58 --> Total execution time: 0.0880
DEBUG - 2017-07-24 12:56:58 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:56:58 --> Database Forge Class Initialized
INFO - 2017-07-24 12:56:58 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:57:03 --> Config Class Initialized
INFO - 2017-07-24 12:57:03 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:57:03 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:57:03 --> Utf8 Class Initialized
INFO - 2017-07-24 12:57:03 --> URI Class Initialized
INFO - 2017-07-24 12:57:03 --> Router Class Initialized
INFO - 2017-07-24 12:57:03 --> Output Class Initialized
INFO - 2017-07-24 12:57:03 --> Security Class Initialized
DEBUG - 2017-07-24 12:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:57:03 --> Input Class Initialized
INFO - 2017-07-24 12:57:03 --> Language Class Initialized
INFO - 2017-07-24 12:57:03 --> Loader Class Initialized
INFO - 2017-07-24 12:57:03 --> Helper loaded: url_helper
INFO - 2017-07-24 12:57:03 --> Helper loaded: form_helper
INFO - 2017-07-24 12:57:03 --> Helper loaded: security_helper
INFO - 2017-07-24 12:57:03 --> Helper loaded: path_helper
INFO - 2017-07-24 12:57:03 --> Helper loaded: common_helper
INFO - 2017-07-24 12:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:57:03 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:57:04 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:57:04 --> Email Class Initialized
INFO - 2017-07-24 12:57:04 --> Form Validation Class Initialized
INFO - 2017-07-24 12:57:04 --> Model Class Initialized
INFO - 2017-07-24 12:57:04 --> Model Class Initialized
INFO - 2017-07-24 12:57:04 --> Model Class Initialized
INFO - 2017-07-24 12:57:04 --> Model Class Initialized
INFO - 2017-07-24 12:57:04 --> Controller Class Initialized
ERROR - 2017-07-24 12:57:04 --> Query error: Unknown column 'hd.hospital_doctor_id' in 'on clause' - Invalid query: SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN(SELECT * from hospital_tumor_board as b where hospital_id = '1') as c on c.tumor_id = a.tumor_id WHERE a.tumor_id NOT IN (SELECT hdtb.tumor_id FROM hospital_doctor AS hd INNER JOIN hospital_doctor_tumor_board AS hdtb ON hd.hospital_doctor_id = hdtb.hospital_doctor_id WHERE hd.hospital_id = '1' AND hd.doctor_id = '' )
INFO - 2017-07-24 12:57:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 12:57:17 --> Config Class Initialized
INFO - 2017-07-24 12:57:17 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:57:17 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:57:17 --> Utf8 Class Initialized
INFO - 2017-07-24 12:57:17 --> URI Class Initialized
INFO - 2017-07-24 12:57:17 --> Router Class Initialized
INFO - 2017-07-24 12:57:17 --> Output Class Initialized
INFO - 2017-07-24 12:57:17 --> Security Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:57:17 --> Input Class Initialized
INFO - 2017-07-24 12:57:17 --> Language Class Initialized
INFO - 2017-07-24 12:57:17 --> Loader Class Initialized
INFO - 2017-07-24 12:57:17 --> Helper loaded: url_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: form_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: security_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: path_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: common_helper
INFO - 2017-07-24 12:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:57:17 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:57:17 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:57:17 --> Email Class Initialized
INFO - 2017-07-24 12:57:17 --> Form Validation Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Controller Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:57:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Config Class Initialized
INFO - 2017-07-24 12:57:17 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:57:17 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:57:17 --> Utf8 Class Initialized
INFO - 2017-07-24 12:57:17 --> URI Class Initialized
INFO - 2017-07-24 12:57:17 --> Router Class Initialized
INFO - 2017-07-24 12:57:17 --> Output Class Initialized
INFO - 2017-07-24 12:57:17 --> Security Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:57:17 --> Input Class Initialized
INFO - 2017-07-24 12:57:17 --> Language Class Initialized
INFO - 2017-07-24 12:57:17 --> Loader Class Initialized
INFO - 2017-07-24 12:57:17 --> Helper loaded: url_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: form_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: security_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: path_helper
INFO - 2017-07-24 12:57:17 --> Helper loaded: common_helper
INFO - 2017-07-24 12:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:57:17 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:57:17 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:57:17 --> Email Class Initialized
INFO - 2017-07-24 12:57:17 --> Form Validation Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Model Class Initialized
INFO - 2017-07-24 12:57:17 --> Controller Class Initialized
INFO - 2017-07-24 12:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:57:17 --> Pagination Class Initialized
INFO - 2017-07-24 12:57:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 12:57:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 12:57:17 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 12:57:17 --> Final output sent to browser
DEBUG - 2017-07-24 12:57:17 --> Total execution time: 0.0720
DEBUG - 2017-07-24 12:57:17 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 12:57:17 --> Database Forge Class Initialized
INFO - 2017-07-24 12:57:17 --> User Agent Class Initialized
DEBUG - 2017-07-24 12:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:59:07 --> Config Class Initialized
INFO - 2017-07-24 12:59:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:59:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:59:07 --> Utf8 Class Initialized
INFO - 2017-07-24 12:59:07 --> URI Class Initialized
INFO - 2017-07-24 12:59:07 --> Router Class Initialized
INFO - 2017-07-24 12:59:07 --> Output Class Initialized
INFO - 2017-07-24 12:59:07 --> Security Class Initialized
DEBUG - 2017-07-24 12:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:59:07 --> Input Class Initialized
INFO - 2017-07-24 12:59:07 --> Language Class Initialized
INFO - 2017-07-24 12:59:07 --> Loader Class Initialized
INFO - 2017-07-24 12:59:07 --> Helper loaded: url_helper
INFO - 2017-07-24 12:59:07 --> Helper loaded: form_helper
INFO - 2017-07-24 12:59:07 --> Helper loaded: security_helper
INFO - 2017-07-24 12:59:07 --> Helper loaded: path_helper
INFO - 2017-07-24 12:59:07 --> Helper loaded: common_helper
INFO - 2017-07-24 12:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 12:59:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 12:59:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 12:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 12:59:07 --> Email Class Initialized
INFO - 2017-07-24 12:59:07 --> Form Validation Class Initialized
INFO - 2017-07-24 12:59:07 --> Model Class Initialized
INFO - 2017-07-24 12:59:07 --> Model Class Initialized
INFO - 2017-07-24 12:59:07 --> Model Class Initialized
INFO - 2017-07-24 12:59:07 --> Model Class Initialized
INFO - 2017-07-24 12:59:07 --> Controller Class Initialized
INFO - 2017-07-24 12:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 12:59:07 --> Pagination Class Initialized
INFO - 2017-07-24 13:00:49 --> Config Class Initialized
INFO - 2017-07-24 13:00:49 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:00:49 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:00:49 --> Utf8 Class Initialized
INFO - 2017-07-24 13:00:49 --> URI Class Initialized
INFO - 2017-07-24 13:00:49 --> Router Class Initialized
INFO - 2017-07-24 13:00:49 --> Output Class Initialized
INFO - 2017-07-24 13:00:49 --> Security Class Initialized
DEBUG - 2017-07-24 13:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:00:49 --> Input Class Initialized
INFO - 2017-07-24 13:00:49 --> Language Class Initialized
INFO - 2017-07-24 13:00:49 --> Loader Class Initialized
INFO - 2017-07-24 13:00:49 --> Helper loaded: url_helper
INFO - 2017-07-24 13:00:49 --> Helper loaded: form_helper
INFO - 2017-07-24 13:00:49 --> Helper loaded: security_helper
INFO - 2017-07-24 13:00:49 --> Helper loaded: path_helper
INFO - 2017-07-24 13:00:49 --> Helper loaded: common_helper
INFO - 2017-07-24 13:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:00:49 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:00:49 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:00:49 --> Email Class Initialized
INFO - 2017-07-24 13:00:49 --> Form Validation Class Initialized
INFO - 2017-07-24 13:00:49 --> Model Class Initialized
INFO - 2017-07-24 13:00:49 --> Model Class Initialized
INFO - 2017-07-24 13:00:49 --> Model Class Initialized
INFO - 2017-07-24 13:00:49 --> Model Class Initialized
INFO - 2017-07-24 13:00:49 --> Controller Class Initialized
INFO - 2017-07-24 13:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 13:00:49 --> Pagination Class Initialized
INFO - 2017-07-24 13:00:54 --> Config Class Initialized
INFO - 2017-07-24 13:00:54 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:00:54 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:00:54 --> Utf8 Class Initialized
INFO - 2017-07-24 13:00:54 --> URI Class Initialized
INFO - 2017-07-24 13:00:54 --> Router Class Initialized
INFO - 2017-07-24 13:00:54 --> Output Class Initialized
INFO - 2017-07-24 13:00:54 --> Security Class Initialized
DEBUG - 2017-07-24 13:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:00:54 --> Input Class Initialized
INFO - 2017-07-24 13:00:54 --> Language Class Initialized
INFO - 2017-07-24 13:00:54 --> Loader Class Initialized
INFO - 2017-07-24 13:00:54 --> Helper loaded: url_helper
INFO - 2017-07-24 13:00:54 --> Helper loaded: form_helper
INFO - 2017-07-24 13:00:54 --> Helper loaded: security_helper
INFO - 2017-07-24 13:00:54 --> Helper loaded: path_helper
INFO - 2017-07-24 13:00:54 --> Helper loaded: common_helper
INFO - 2017-07-24 13:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:00:54 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:00:54 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:00:54 --> Email Class Initialized
INFO - 2017-07-24 13:00:54 --> Form Validation Class Initialized
INFO - 2017-07-24 13:00:54 --> Model Class Initialized
INFO - 2017-07-24 13:00:54 --> Model Class Initialized
INFO - 2017-07-24 13:00:54 --> Model Class Initialized
INFO - 2017-07-24 13:00:54 --> Model Class Initialized
INFO - 2017-07-24 13:00:54 --> Controller Class Initialized
INFO - 2017-07-24 13:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 13:00:54 --> Pagination Class Initialized
INFO - 2017-07-24 13:00:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 13:00:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 13:00:54 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 13:00:54 --> Final output sent to browser
DEBUG - 2017-07-24 13:00:54 --> Total execution time: 0.0810
DEBUG - 2017-07-24 13:00:54 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:00:54 --> Database Forge Class Initialized
INFO - 2017-07-24 13:00:54 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:01:07 --> Config Class Initialized
INFO - 2017-07-24 13:01:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:01:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:01:07 --> Utf8 Class Initialized
INFO - 2017-07-24 13:01:07 --> URI Class Initialized
INFO - 2017-07-24 13:01:07 --> Router Class Initialized
INFO - 2017-07-24 13:01:07 --> Output Class Initialized
INFO - 2017-07-24 13:01:07 --> Security Class Initialized
DEBUG - 2017-07-24 13:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:01:07 --> Input Class Initialized
INFO - 2017-07-24 13:01:07 --> Language Class Initialized
INFO - 2017-07-24 13:01:07 --> Loader Class Initialized
INFO - 2017-07-24 13:01:07 --> Helper loaded: url_helper
INFO - 2017-07-24 13:01:07 --> Helper loaded: form_helper
INFO - 2017-07-24 13:01:07 --> Helper loaded: security_helper
INFO - 2017-07-24 13:01:07 --> Helper loaded: path_helper
INFO - 2017-07-24 13:01:07 --> Helper loaded: common_helper
INFO - 2017-07-24 13:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:01:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:01:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:01:07 --> Email Class Initialized
INFO - 2017-07-24 13:01:07 --> Form Validation Class Initialized
INFO - 2017-07-24 13:01:07 --> Model Class Initialized
INFO - 2017-07-24 13:01:07 --> Model Class Initialized
INFO - 2017-07-24 13:01:07 --> Model Class Initialized
INFO - 2017-07-24 13:01:07 --> Model Class Initialized
INFO - 2017-07-24 13:01:07 --> Controller Class Initialized
DEBUG - 2017-07-24 13:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:01:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 13:01:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/user_add.php
INFO - 2017-07-24 13:01:07 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 13:01:07 --> Final output sent to browser
DEBUG - 2017-07-24 13:01:07 --> Total execution time: 0.1980
DEBUG - 2017-07-24 13:01:07 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:01:07 --> Database Forge Class Initialized
INFO - 2017-07-24 13:01:07 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:01:54 --> Config Class Initialized
INFO - 2017-07-24 13:01:54 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:01:54 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:01:54 --> Utf8 Class Initialized
INFO - 2017-07-24 13:01:54 --> URI Class Initialized
INFO - 2017-07-24 13:01:54 --> Router Class Initialized
INFO - 2017-07-24 13:01:54 --> Output Class Initialized
INFO - 2017-07-24 13:01:54 --> Security Class Initialized
DEBUG - 2017-07-24 13:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:01:54 --> Input Class Initialized
INFO - 2017-07-24 13:01:54 --> Language Class Initialized
INFO - 2017-07-24 13:01:54 --> Loader Class Initialized
INFO - 2017-07-24 13:01:54 --> Helper loaded: url_helper
INFO - 2017-07-24 13:01:54 --> Helper loaded: form_helper
INFO - 2017-07-24 13:01:54 --> Helper loaded: security_helper
INFO - 2017-07-24 13:01:54 --> Helper loaded: path_helper
INFO - 2017-07-24 13:01:54 --> Helper loaded: common_helper
INFO - 2017-07-24 13:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:01:54 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:01:54 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:01:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:01:54 --> Email Class Initialized
INFO - 2017-07-24 13:01:54 --> Form Validation Class Initialized
INFO - 2017-07-24 13:01:54 --> Model Class Initialized
INFO - 2017-07-24 13:01:54 --> Model Class Initialized
INFO - 2017-07-24 13:01:54 --> Model Class Initialized
INFO - 2017-07-24 13:01:54 --> Model Class Initialized
INFO - 2017-07-24 13:01:54 --> Controller Class Initialized
INFO - 2017-07-24 13:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-24 13:01:54 --> Pagination Class Initialized
INFO - 2017-07-24 13:01:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/header.php
INFO - 2017-07-24 13:01:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/users.php
INFO - 2017-07-24 13:01:55 --> File loaded: E:\xampp\htdocs\oncolens\application\views\admin/template.php
INFO - 2017-07-24 13:01:55 --> Final output sent to browser
DEBUG - 2017-07-24 13:01:55 --> Total execution time: 0.1560
DEBUG - 2017-07-24 13:01:55 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:01:55 --> Database Forge Class Initialized
INFO - 2017-07-24 13:01:55 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:01 --> Config Class Initialized
INFO - 2017-07-24 13:02:01 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:02:01 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:02:01 --> Utf8 Class Initialized
INFO - 2017-07-24 13:02:01 --> URI Class Initialized
INFO - 2017-07-24 13:02:01 --> Router Class Initialized
INFO - 2017-07-24 13:02:01 --> Output Class Initialized
INFO - 2017-07-24 13:02:01 --> Security Class Initialized
DEBUG - 2017-07-24 13:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:02:01 --> Input Class Initialized
INFO - 2017-07-24 13:02:01 --> Language Class Initialized
INFO - 2017-07-24 13:02:01 --> Loader Class Initialized
INFO - 2017-07-24 13:02:01 --> Helper loaded: url_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: form_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: security_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: path_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: common_helper
INFO - 2017-07-24 13:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:02:01 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:02:01 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:01 --> Email Class Initialized
INFO - 2017-07-24 13:02:01 --> Form Validation Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Controller Class Initialized
INFO - 2017-07-24 13:02:01 --> Config Class Initialized
INFO - 2017-07-24 13:02:01 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:02:01 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:02:01 --> Utf8 Class Initialized
INFO - 2017-07-24 13:02:01 --> URI Class Initialized
INFO - 2017-07-24 13:02:01 --> Router Class Initialized
INFO - 2017-07-24 13:02:01 --> Output Class Initialized
INFO - 2017-07-24 13:02:01 --> Security Class Initialized
DEBUG - 2017-07-24 13:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:02:01 --> Input Class Initialized
INFO - 2017-07-24 13:02:01 --> Language Class Initialized
INFO - 2017-07-24 13:02:01 --> Loader Class Initialized
INFO - 2017-07-24 13:02:01 --> Helper loaded: url_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: form_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: security_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: path_helper
INFO - 2017-07-24 13:02:01 --> Helper loaded: common_helper
INFO - 2017-07-24 13:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:02:01 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:02:01 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:01 --> Email Class Initialized
INFO - 2017-07-24 13:02:01 --> Form Validation Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Model Class Initialized
INFO - 2017-07-24 13:02:01 --> Controller Class Initialized
INFO - 2017-07-24 13:02:01 --> File loaded: E:\xampp\htdocs\oncolens\application\views\login.php
INFO - 2017-07-24 13:02:01 --> Final output sent to browser
DEBUG - 2017-07-24 13:02:01 --> Total execution time: 0.0750
DEBUG - 2017-07-24 13:02:01 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:02:01 --> Database Forge Class Initialized
INFO - 2017-07-24 13:02:01 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:13 --> Config Class Initialized
INFO - 2017-07-24 13:02:13 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:02:13 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:02:13 --> Utf8 Class Initialized
INFO - 2017-07-24 13:02:13 --> URI Class Initialized
DEBUG - 2017-07-24 13:02:13 --> No URI present. Default controller set.
INFO - 2017-07-24 13:02:13 --> Router Class Initialized
INFO - 2017-07-24 13:02:13 --> Output Class Initialized
INFO - 2017-07-24 13:02:13 --> Security Class Initialized
DEBUG - 2017-07-24 13:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:02:13 --> Input Class Initialized
INFO - 2017-07-24 13:02:13 --> Language Class Initialized
INFO - 2017-07-24 13:02:13 --> Loader Class Initialized
INFO - 2017-07-24 13:02:13 --> Helper loaded: url_helper
INFO - 2017-07-24 13:02:13 --> Helper loaded: form_helper
INFO - 2017-07-24 13:02:13 --> Helper loaded: security_helper
INFO - 2017-07-24 13:02:13 --> Helper loaded: path_helper
INFO - 2017-07-24 13:02:13 --> Helper loaded: common_helper
INFO - 2017-07-24 13:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:02:13 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:02:13 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:13 --> Email Class Initialized
INFO - 2017-07-24 13:02:13 --> Form Validation Class Initialized
INFO - 2017-07-24 13:02:13 --> Model Class Initialized
INFO - 2017-07-24 13:02:13 --> Model Class Initialized
INFO - 2017-07-24 13:02:13 --> Model Class Initialized
INFO - 2017-07-24 13:02:13 --> Model Class Initialized
INFO - 2017-07-24 13:02:13 --> Controller Class Initialized
DEBUG - 2017-07-24 13:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 13:02:13 --> Query error: Unknown column 'last_password_change_date' in 'field list' - Invalid query: SELECT `id`, `fname`, `lname`, `email`, `speciality_id`, `hospital_id`, `last_password_change_date`
FROM `users`
WHERE upper(email) = 'SONUJANGID2011@GMAIL.COM'
AND `is_active` = '1'
 LIMIT 1
INFO - 2017-07-24 13:02:13 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:02:51 --> Config Class Initialized
INFO - 2017-07-24 13:02:51 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:02:51 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:02:51 --> Utf8 Class Initialized
INFO - 2017-07-24 13:02:51 --> URI Class Initialized
DEBUG - 2017-07-24 13:02:51 --> No URI present. Default controller set.
INFO - 2017-07-24 13:02:51 --> Router Class Initialized
INFO - 2017-07-24 13:02:52 --> Output Class Initialized
INFO - 2017-07-24 13:02:52 --> Security Class Initialized
DEBUG - 2017-07-24 13:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:02:52 --> Input Class Initialized
INFO - 2017-07-24 13:02:52 --> Language Class Initialized
INFO - 2017-07-24 13:02:52 --> Loader Class Initialized
INFO - 2017-07-24 13:02:52 --> Helper loaded: url_helper
INFO - 2017-07-24 13:02:52 --> Helper loaded: form_helper
INFO - 2017-07-24 13:02:52 --> Helper loaded: security_helper
INFO - 2017-07-24 13:02:52 --> Helper loaded: path_helper
INFO - 2017-07-24 13:02:52 --> Helper loaded: common_helper
INFO - 2017-07-24 13:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:02:52 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:02:52 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:02:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:52 --> Email Class Initialized
INFO - 2017-07-24 13:02:52 --> Form Validation Class Initialized
INFO - 2017-07-24 13:02:52 --> Model Class Initialized
INFO - 2017-07-24 13:02:52 --> Model Class Initialized
INFO - 2017-07-24 13:02:52 --> Model Class Initialized
INFO - 2017-07-24 13:02:52 --> Model Class Initialized
INFO - 2017-07-24 13:02:52 --> Controller Class Initialized
DEBUG - 2017-07-24 13:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:02:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 13:02:52 --> Query error: Unknown column 'last_password_change_date' in 'field list' - Invalid query: SELECT `id`, `fname`, `lname`, `email`, `speciality_id`, `hospital_id`, `last_password_change_date`
FROM `users`
WHERE upper(email) = 'SONUJANGID2011@GMAIL.COM'
AND `is_active` = '1'
 LIMIT 1
INFO - 2017-07-24 13:02:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:03:06 --> Config Class Initialized
INFO - 2017-07-24 13:03:06 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:03:06 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:03:06 --> Utf8 Class Initialized
INFO - 2017-07-24 13:03:06 --> URI Class Initialized
DEBUG - 2017-07-24 13:03:06 --> No URI present. Default controller set.
INFO - 2017-07-24 13:03:06 --> Router Class Initialized
INFO - 2017-07-24 13:03:06 --> Output Class Initialized
INFO - 2017-07-24 13:03:06 --> Security Class Initialized
DEBUG - 2017-07-24 13:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:03:06 --> Input Class Initialized
INFO - 2017-07-24 13:03:06 --> Language Class Initialized
INFO - 2017-07-24 13:03:06 --> Loader Class Initialized
INFO - 2017-07-24 13:03:06 --> Helper loaded: url_helper
INFO - 2017-07-24 13:03:06 --> Helper loaded: form_helper
INFO - 2017-07-24 13:03:06 --> Helper loaded: security_helper
INFO - 2017-07-24 13:03:06 --> Helper loaded: path_helper
INFO - 2017-07-24 13:03:06 --> Helper loaded: common_helper
INFO - 2017-07-24 13:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:03:06 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:03:06 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:06 --> Email Class Initialized
INFO - 2017-07-24 13:03:06 --> Form Validation Class Initialized
INFO - 2017-07-24 13:03:06 --> Model Class Initialized
INFO - 2017-07-24 13:03:06 --> Model Class Initialized
INFO - 2017-07-24 13:03:06 --> Model Class Initialized
INFO - 2017-07-24 13:03:06 --> Model Class Initialized
INFO - 2017-07-24 13:03:06 --> Controller Class Initialized
DEBUG - 2017-07-24 13:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 13:03:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 13:03:06 --> Final output sent to browser
DEBUG - 2017-07-24 13:03:06 --> Total execution time: 0.1190
DEBUG - 2017-07-24 13:03:06 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:03:06 --> Database Forge Class Initialized
INFO - 2017-07-24 13:03:07 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:18 --> Config Class Initialized
INFO - 2017-07-24 13:03:18 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:03:18 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:03:18 --> Utf8 Class Initialized
INFO - 2017-07-24 13:03:18 --> URI Class Initialized
DEBUG - 2017-07-24 13:03:18 --> No URI present. Default controller set.
INFO - 2017-07-24 13:03:18 --> Router Class Initialized
INFO - 2017-07-24 13:03:18 --> Output Class Initialized
INFO - 2017-07-24 13:03:18 --> Security Class Initialized
DEBUG - 2017-07-24 13:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:03:18 --> Input Class Initialized
INFO - 2017-07-24 13:03:18 --> Language Class Initialized
INFO - 2017-07-24 13:03:18 --> Loader Class Initialized
INFO - 2017-07-24 13:03:18 --> Helper loaded: url_helper
INFO - 2017-07-24 13:03:18 --> Helper loaded: form_helper
INFO - 2017-07-24 13:03:18 --> Helper loaded: security_helper
INFO - 2017-07-24 13:03:18 --> Helper loaded: path_helper
INFO - 2017-07-24 13:03:18 --> Helper loaded: common_helper
INFO - 2017-07-24 13:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:03:18 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:03:18 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:03:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:18 --> Email Class Initialized
INFO - 2017-07-24 13:03:18 --> Form Validation Class Initialized
INFO - 2017-07-24 13:03:18 --> Model Class Initialized
INFO - 2017-07-24 13:03:18 --> Model Class Initialized
INFO - 2017-07-24 13:03:18 --> Model Class Initialized
INFO - 2017-07-24 13:03:18 --> Model Class Initialized
INFO - 2017-07-24 13:03:18 --> Controller Class Initialized
DEBUG - 2017-07-24 13:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 13:03:18 --> Query error: Unknown column 'last_password_change_date' in 'field list' - Invalid query: SELECT `id`, `fname`, `lname`, `email`, `speciality_id`, `hospital_id`, `last_password_change_date`
FROM `users`
WHERE upper(email) = 'SONUJANGID2011@GMAIL.COM'
AND `is_active` = '1'
 LIMIT 1
INFO - 2017-07-24 13:03:18 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:03:44 --> Config Class Initialized
INFO - 2017-07-24 13:03:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:03:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:03:44 --> Utf8 Class Initialized
INFO - 2017-07-24 13:03:44 --> URI Class Initialized
DEBUG - 2017-07-24 13:03:44 --> No URI present. Default controller set.
INFO - 2017-07-24 13:03:44 --> Router Class Initialized
INFO - 2017-07-24 13:03:44 --> Output Class Initialized
INFO - 2017-07-24 13:03:44 --> Security Class Initialized
DEBUG - 2017-07-24 13:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:03:44 --> Input Class Initialized
INFO - 2017-07-24 13:03:44 --> Language Class Initialized
INFO - 2017-07-24 13:03:44 --> Loader Class Initialized
INFO - 2017-07-24 13:03:44 --> Helper loaded: url_helper
INFO - 2017-07-24 13:03:44 --> Helper loaded: form_helper
INFO - 2017-07-24 13:03:44 --> Helper loaded: security_helper
INFO - 2017-07-24 13:03:44 --> Helper loaded: path_helper
INFO - 2017-07-24 13:03:44 --> Helper loaded: common_helper
INFO - 2017-07-24 13:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:03:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:03:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:03:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:44 --> Email Class Initialized
INFO - 2017-07-24 13:03:44 --> Form Validation Class Initialized
INFO - 2017-07-24 13:03:44 --> Model Class Initialized
INFO - 2017-07-24 13:03:44 --> Model Class Initialized
INFO - 2017-07-24 13:03:44 --> Model Class Initialized
INFO - 2017-07-24 13:03:44 --> Model Class Initialized
INFO - 2017-07-24 13:03:44 --> Controller Class Initialized
DEBUG - 2017-07-24 13:03:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:03:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-24 13:03:44 --> Query error: Table 'oncolens.login_stats' doesn't exist - Invalid query: insert into login_stats set user_id=1,user_login_time='2017-07-24 01:03:44',user_ip_address=''
INFO - 2017-07-24 13:03:44 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:05:02 --> Config Class Initialized
INFO - 2017-07-24 13:05:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:05:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:05:02 --> Utf8 Class Initialized
INFO - 2017-07-24 13:05:02 --> URI Class Initialized
DEBUG - 2017-07-24 13:05:02 --> No URI present. Default controller set.
INFO - 2017-07-24 13:05:02 --> Router Class Initialized
INFO - 2017-07-24 13:05:03 --> Output Class Initialized
INFO - 2017-07-24 13:05:03 --> Security Class Initialized
DEBUG - 2017-07-24 13:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:05:03 --> Input Class Initialized
INFO - 2017-07-24 13:05:03 --> Language Class Initialized
INFO - 2017-07-24 13:05:03 --> Loader Class Initialized
INFO - 2017-07-24 13:05:03 --> Helper loaded: url_helper
INFO - 2017-07-24 13:05:03 --> Helper loaded: form_helper
INFO - 2017-07-24 13:05:03 --> Helper loaded: security_helper
INFO - 2017-07-24 13:05:03 --> Helper loaded: path_helper
INFO - 2017-07-24 13:05:03 --> Helper loaded: common_helper
INFO - 2017-07-24 13:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:05:03 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:05:03 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:05:03 --> Email Class Initialized
INFO - 2017-07-24 13:05:03 --> Form Validation Class Initialized
INFO - 2017-07-24 13:05:03 --> Model Class Initialized
INFO - 2017-07-24 13:05:03 --> Model Class Initialized
INFO - 2017-07-24 13:05:03 --> Model Class Initialized
INFO - 2017-07-24 13:05:03 --> Model Class Initialized
INFO - 2017-07-24 13:05:03 --> Controller Class Initialized
INFO - 2017-07-24 13:05:04 --> Config Class Initialized
INFO - 2017-07-24 13:05:04 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:05:04 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:05:04 --> Utf8 Class Initialized
INFO - 2017-07-24 13:05:04 --> URI Class Initialized
INFO - 2017-07-24 13:05:04 --> Router Class Initialized
INFO - 2017-07-24 13:05:04 --> Output Class Initialized
INFO - 2017-07-24 13:05:04 --> Security Class Initialized
DEBUG - 2017-07-24 13:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:05:04 --> Input Class Initialized
INFO - 2017-07-24 13:05:04 --> Language Class Initialized
INFO - 2017-07-24 13:05:04 --> Loader Class Initialized
INFO - 2017-07-24 13:05:04 --> Helper loaded: url_helper
INFO - 2017-07-24 13:05:04 --> Helper loaded: form_helper
INFO - 2017-07-24 13:05:04 --> Helper loaded: security_helper
INFO - 2017-07-24 13:05:04 --> Helper loaded: path_helper
INFO - 2017-07-24 13:05:04 --> Helper loaded: common_helper
INFO - 2017-07-24 13:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:05:04 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:05:04 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:05:04 --> Email Class Initialized
INFO - 2017-07-24 13:05:04 --> Form Validation Class Initialized
INFO - 2017-07-24 13:05:04 --> Model Class Initialized
INFO - 2017-07-24 13:05:04 --> Model Class Initialized
INFO - 2017-07-24 13:05:04 --> Model Class Initialized
INFO - 2017-07-24 13:05:04 --> Model Class Initialized
INFO - 2017-07-24 13:05:04 --> Controller Class Initialized
INFO - 2017-07-24 13:05:04 --> Model Class Initialized
ERROR - 2017-07-24 13:05:04 --> Query error: Unknown column 'b.is_active' in 'where clause' - Invalid query: SELECT `d`.`tumor_id`, `d`.`tumor_board_name`
FROM `hospital_doctor` `a`
LEFT JOIN `hospital_doctor_tumor_board` `b` ON `a`.`hospital_doctor_id` = `b`.`hospital_doctor_id`
LEFT JOIN `hospital_network` `c` ON `c`.`id` = `a`.`hospital_id`
LEFT JOIN `tumor_board` `d` ON `d`.`tumor_id` = `b`.`tumor_id`
WHERE `a`.`doctor_id` = '1'
AND `b`.`is_active` = '1'
INFO - 2017-07-24 13:05:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:05:31 --> Config Class Initialized
INFO - 2017-07-24 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:05:31 --> Utf8 Class Initialized
INFO - 2017-07-24 13:05:31 --> URI Class Initialized
INFO - 2017-07-24 13:05:31 --> Router Class Initialized
INFO - 2017-07-24 13:05:31 --> Output Class Initialized
INFO - 2017-07-24 13:05:31 --> Security Class Initialized
DEBUG - 2017-07-24 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:05:31 --> Input Class Initialized
INFO - 2017-07-24 13:05:31 --> Language Class Initialized
INFO - 2017-07-24 13:05:31 --> Loader Class Initialized
INFO - 2017-07-24 13:05:31 --> Helper loaded: url_helper
INFO - 2017-07-24 13:05:31 --> Helper loaded: form_helper
INFO - 2017-07-24 13:05:31 --> Helper loaded: security_helper
INFO - 2017-07-24 13:05:31 --> Helper loaded: path_helper
INFO - 2017-07-24 13:05:31 --> Helper loaded: common_helper
INFO - 2017-07-24 13:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:05:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:05:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:05:31 --> Email Class Initialized
INFO - 2017-07-24 13:05:31 --> Form Validation Class Initialized
INFO - 2017-07-24 13:05:31 --> Model Class Initialized
INFO - 2017-07-24 13:05:31 --> Model Class Initialized
INFO - 2017-07-24 13:05:31 --> Model Class Initialized
INFO - 2017-07-24 13:05:31 --> Model Class Initialized
INFO - 2017-07-24 13:05:31 --> Controller Class Initialized
INFO - 2017-07-24 13:05:31 --> Model Class Initialized
ERROR - 2017-07-24 13:05:31 --> Query error: Unknown column 'a.hospital_doctor_id' in 'on clause' - Invalid query: SELECT `d`.`tumor_id`, `d`.`tumor_board_name`
FROM `hospital_doctor` `a`
LEFT JOIN `hospital_doctor_tumor_board` `b` ON `a`.`hospital_doctor_id` = `b`.`hospital_doctor_id`
LEFT JOIN `hospital_network` `c` ON `c`.`id` = `a`.`hospital_id`
LEFT JOIN `tumor_board` `d` ON `d`.`tumor_id` = `b`.`tumor_id`
WHERE `a`.`doctor_id` = '1'
AND `b`.`is_active` = '1'
INFO - 2017-07-24 13:05:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:06:05 --> Config Class Initialized
INFO - 2017-07-24 13:06:05 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:06:05 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:06:05 --> Utf8 Class Initialized
INFO - 2017-07-24 13:06:05 --> URI Class Initialized
INFO - 2017-07-24 13:06:05 --> Router Class Initialized
INFO - 2017-07-24 13:06:05 --> Output Class Initialized
INFO - 2017-07-24 13:06:05 --> Security Class Initialized
DEBUG - 2017-07-24 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:06:05 --> Input Class Initialized
INFO - 2017-07-24 13:06:05 --> Language Class Initialized
INFO - 2017-07-24 13:06:05 --> Loader Class Initialized
INFO - 2017-07-24 13:06:05 --> Helper loaded: url_helper
INFO - 2017-07-24 13:06:05 --> Helper loaded: form_helper
INFO - 2017-07-24 13:06:05 --> Helper loaded: security_helper
INFO - 2017-07-24 13:06:05 --> Helper loaded: path_helper
INFO - 2017-07-24 13:06:05 --> Helper loaded: common_helper
INFO - 2017-07-24 13:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:06:05 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:06:05 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:06:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:06:05 --> Email Class Initialized
INFO - 2017-07-24 13:06:05 --> Form Validation Class Initialized
INFO - 2017-07-24 13:06:05 --> Model Class Initialized
INFO - 2017-07-24 13:06:05 --> Model Class Initialized
INFO - 2017-07-24 13:06:05 --> Model Class Initialized
INFO - 2017-07-24 13:06:05 --> Model Class Initialized
INFO - 2017-07-24 13:06:05 --> Controller Class Initialized
INFO - 2017-07-24 13:06:05 --> Model Class Initialized
ERROR - 2017-07-24 13:06:05 --> Query error: Table 'oncolens.case_meeting_details' doesn't exist - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:06:05 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:07:51 --> Config Class Initialized
INFO - 2017-07-24 13:07:51 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:07:51 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:07:51 --> Utf8 Class Initialized
INFO - 2017-07-24 13:07:51 --> URI Class Initialized
INFO - 2017-07-24 13:07:51 --> Router Class Initialized
INFO - 2017-07-24 13:07:51 --> Output Class Initialized
INFO - 2017-07-24 13:07:51 --> Security Class Initialized
DEBUG - 2017-07-24 13:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:07:51 --> Input Class Initialized
INFO - 2017-07-24 13:07:51 --> Language Class Initialized
INFO - 2017-07-24 13:07:51 --> Loader Class Initialized
INFO - 2017-07-24 13:07:51 --> Helper loaded: url_helper
INFO - 2017-07-24 13:07:51 --> Helper loaded: form_helper
INFO - 2017-07-24 13:07:51 --> Helper loaded: security_helper
INFO - 2017-07-24 13:07:51 --> Helper loaded: path_helper
INFO - 2017-07-24 13:07:51 --> Helper loaded: common_helper
INFO - 2017-07-24 13:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:07:51 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:07:51 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:07:52 --> Email Class Initialized
INFO - 2017-07-24 13:07:52 --> Form Validation Class Initialized
INFO - 2017-07-24 13:07:52 --> Model Class Initialized
INFO - 2017-07-24 13:07:52 --> Model Class Initialized
INFO - 2017-07-24 13:07:52 --> Model Class Initialized
INFO - 2017-07-24 13:07:52 --> Model Class Initialized
INFO - 2017-07-24 13:07:52 --> Controller Class Initialized
INFO - 2017-07-24 13:07:52 --> Model Class Initialized
ERROR - 2017-07-24 13:07:52 --> Query error: Table 'oncolens.case_meeting_assignments' doesn't exist - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:07:52 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:08:44 --> Config Class Initialized
INFO - 2017-07-24 13:08:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:08:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:08:44 --> Utf8 Class Initialized
INFO - 2017-07-24 13:08:44 --> URI Class Initialized
INFO - 2017-07-24 13:08:44 --> Router Class Initialized
INFO - 2017-07-24 13:08:44 --> Output Class Initialized
INFO - 2017-07-24 13:08:44 --> Security Class Initialized
DEBUG - 2017-07-24 13:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:08:44 --> Input Class Initialized
INFO - 2017-07-24 13:08:44 --> Language Class Initialized
INFO - 2017-07-24 13:08:44 --> Loader Class Initialized
INFO - 2017-07-24 13:08:44 --> Helper loaded: url_helper
INFO - 2017-07-24 13:08:44 --> Helper loaded: form_helper
INFO - 2017-07-24 13:08:44 --> Helper loaded: security_helper
INFO - 2017-07-24 13:08:44 --> Helper loaded: path_helper
INFO - 2017-07-24 13:08:44 --> Helper loaded: common_helper
INFO - 2017-07-24 13:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:08:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:08:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:08:45 --> Email Class Initialized
INFO - 2017-07-24 13:08:45 --> Form Validation Class Initialized
INFO - 2017-07-24 13:08:45 --> Model Class Initialized
INFO - 2017-07-24 13:08:45 --> Model Class Initialized
INFO - 2017-07-24 13:08:45 --> Model Class Initialized
INFO - 2017-07-24 13:08:45 --> Model Class Initialized
INFO - 2017-07-24 13:08:45 --> Controller Class Initialized
INFO - 2017-07-24 13:08:46 --> Model Class Initialized
ERROR - 2017-07-24 13:08:46 --> Query error: Table 'oncolens.case_save_images_summary' doesn't exist - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:08:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:09:45 --> Config Class Initialized
INFO - 2017-07-24 13:09:45 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:09:45 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:09:45 --> Utf8 Class Initialized
INFO - 2017-07-24 13:09:45 --> URI Class Initialized
INFO - 2017-07-24 13:09:45 --> Router Class Initialized
INFO - 2017-07-24 13:09:45 --> Output Class Initialized
INFO - 2017-07-24 13:09:45 --> Security Class Initialized
DEBUG - 2017-07-24 13:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:09:45 --> Input Class Initialized
INFO - 2017-07-24 13:09:45 --> Language Class Initialized
INFO - 2017-07-24 13:09:45 --> Loader Class Initialized
INFO - 2017-07-24 13:09:45 --> Helper loaded: url_helper
INFO - 2017-07-24 13:09:45 --> Helper loaded: form_helper
INFO - 2017-07-24 13:09:45 --> Helper loaded: security_helper
INFO - 2017-07-24 13:09:45 --> Helper loaded: path_helper
INFO - 2017-07-24 13:09:45 --> Helper loaded: common_helper
INFO - 2017-07-24 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:09:45 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:09:45 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:09:46 --> Email Class Initialized
INFO - 2017-07-24 13:09:46 --> Form Validation Class Initialized
INFO - 2017-07-24 13:09:46 --> Model Class Initialized
INFO - 2017-07-24 13:09:46 --> Model Class Initialized
INFO - 2017-07-24 13:09:46 --> Model Class Initialized
INFO - 2017-07-24 13:09:46 --> Model Class Initialized
INFO - 2017-07-24 13:09:46 --> Controller Class Initialized
INFO - 2017-07-24 13:09:46 --> Model Class Initialized
ERROR - 2017-07-24 13:09:46 --> Query error: Table 'oncolens.case_meeting' doesn't exist - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:09:46 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:11:30 --> Config Class Initialized
INFO - 2017-07-24 13:11:30 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:11:30 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:11:30 --> Utf8 Class Initialized
INFO - 2017-07-24 13:11:30 --> URI Class Initialized
INFO - 2017-07-24 13:11:30 --> Router Class Initialized
INFO - 2017-07-24 13:11:30 --> Output Class Initialized
INFO - 2017-07-24 13:11:30 --> Security Class Initialized
DEBUG - 2017-07-24 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:11:30 --> Input Class Initialized
INFO - 2017-07-24 13:11:30 --> Language Class Initialized
INFO - 2017-07-24 13:11:30 --> Loader Class Initialized
INFO - 2017-07-24 13:11:30 --> Helper loaded: url_helper
INFO - 2017-07-24 13:11:30 --> Helper loaded: form_helper
INFO - 2017-07-24 13:11:30 --> Helper loaded: security_helper
INFO - 2017-07-24 13:11:30 --> Helper loaded: path_helper
INFO - 2017-07-24 13:11:30 --> Helper loaded: common_helper
INFO - 2017-07-24 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:11:30 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:11:30 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:11:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:11:31 --> Email Class Initialized
INFO - 2017-07-24 13:11:31 --> Form Validation Class Initialized
INFO - 2017-07-24 13:11:31 --> Model Class Initialized
INFO - 2017-07-24 13:11:31 --> Model Class Initialized
INFO - 2017-07-24 13:11:31 --> Model Class Initialized
INFO - 2017-07-24 13:11:31 --> Model Class Initialized
INFO - 2017-07-24 13:11:31 --> Controller Class Initialized
INFO - 2017-07-24 13:11:31 --> Model Class Initialized
ERROR - 2017-07-24 13:11:31 --> Query error: Unknown column 'cmd.meeting_date' in 'field list' - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:11:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:12:37 --> Config Class Initialized
INFO - 2017-07-24 13:12:37 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:12:37 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:12:37 --> Utf8 Class Initialized
INFO - 2017-07-24 13:12:37 --> URI Class Initialized
INFO - 2017-07-24 13:12:37 --> Router Class Initialized
INFO - 2017-07-24 13:12:37 --> Output Class Initialized
INFO - 2017-07-24 13:12:37 --> Security Class Initialized
DEBUG - 2017-07-24 13:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:12:37 --> Input Class Initialized
INFO - 2017-07-24 13:12:37 --> Language Class Initialized
INFO - 2017-07-24 13:12:37 --> Loader Class Initialized
INFO - 2017-07-24 13:12:37 --> Helper loaded: url_helper
INFO - 2017-07-24 13:12:37 --> Helper loaded: form_helper
INFO - 2017-07-24 13:12:37 --> Helper loaded: security_helper
INFO - 2017-07-24 13:12:37 --> Helper loaded: path_helper
INFO - 2017-07-24 13:12:37 --> Helper loaded: common_helper
INFO - 2017-07-24 13:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:12:37 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:12:37 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:12:37 --> Email Class Initialized
INFO - 2017-07-24 13:12:37 --> Form Validation Class Initialized
INFO - 2017-07-24 13:12:37 --> Model Class Initialized
INFO - 2017-07-24 13:12:37 --> Model Class Initialized
INFO - 2017-07-24 13:12:37 --> Model Class Initialized
INFO - 2017-07-24 13:12:37 --> Model Class Initialized
INFO - 2017-07-24 13:12:37 --> Controller Class Initialized
INFO - 2017-07-24 13:12:37 --> Model Class Initialized
ERROR - 2017-07-24 13:12:37 --> Query error: Unknown column 'ca.case_id' in 'on clause' - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:12:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:13:15 --> Config Class Initialized
INFO - 2017-07-24 13:13:15 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:13:15 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:13:15 --> Utf8 Class Initialized
INFO - 2017-07-24 13:13:15 --> URI Class Initialized
INFO - 2017-07-24 13:13:15 --> Router Class Initialized
INFO - 2017-07-24 13:13:15 --> Output Class Initialized
INFO - 2017-07-24 13:13:15 --> Security Class Initialized
DEBUG - 2017-07-24 13:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:13:15 --> Input Class Initialized
INFO - 2017-07-24 13:13:15 --> Language Class Initialized
INFO - 2017-07-24 13:13:15 --> Loader Class Initialized
INFO - 2017-07-24 13:13:15 --> Helper loaded: url_helper
INFO - 2017-07-24 13:13:15 --> Helper loaded: form_helper
INFO - 2017-07-24 13:13:15 --> Helper loaded: security_helper
INFO - 2017-07-24 13:13:15 --> Helper loaded: path_helper
INFO - 2017-07-24 13:13:15 --> Helper loaded: common_helper
INFO - 2017-07-24 13:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:13:15 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:13:15 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:13:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:13:15 --> Email Class Initialized
INFO - 2017-07-24 13:13:15 --> Form Validation Class Initialized
INFO - 2017-07-24 13:13:15 --> Model Class Initialized
INFO - 2017-07-24 13:13:15 --> Model Class Initialized
INFO - 2017-07-24 13:13:15 --> Model Class Initialized
INFO - 2017-07-24 13:13:15 --> Model Class Initialized
INFO - 2017-07-24 13:13:15 --> Controller Class Initialized
INFO - 2017-07-24 13:13:15 --> Model Class Initialized
ERROR - 2017-07-24 13:13:15 --> Query error: Unknown column 'cmd.is_deleted' in 'where clause' - Invalid query: SELECT `cmd`.`id`, `tb`.`tumor_board_name`, `hn`.`hospital_network`, `cmd`.`meeting_date`, `cmd`.`meeting_time`, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=1  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=1))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned
FROM `case_meeting_details` `cmd`
LEFT JOIN `case_meeting` `cm` ON `cmd`.`parent_id` = `cm`.`id`
LEFT JOIN `tumor_board` `tb` ON `cm`.`tumor_board_id` = `tb`.`tumor_id`
LEFT JOIN `hospital_tumor_board` `htb` ON `cm`.`tumor_board_id` = `htb`.`tumor_id`
LEFT JOIN `hospital_network` `hn` ON `htb`.`hospital_id` = `hn`.`id`
WHERE cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
AND `cm`.`tumor_board_id` IN(0)
AND `cmd`.`is_deleted` = '0'
ORDER BY `cmd`.`meeting_date` ASC, `cmd`.`id` ASC
 LIMIT 10
INFO - 2017-07-24 13:13:15 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:13:36 --> Config Class Initialized
INFO - 2017-07-24 13:13:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:13:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:13:36 --> Utf8 Class Initialized
INFO - 2017-07-24 13:13:36 --> URI Class Initialized
INFO - 2017-07-24 13:13:36 --> Router Class Initialized
INFO - 2017-07-24 13:13:36 --> Output Class Initialized
INFO - 2017-07-24 13:13:36 --> Security Class Initialized
DEBUG - 2017-07-24 13:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:13:36 --> Input Class Initialized
INFO - 2017-07-24 13:13:36 --> Language Class Initialized
INFO - 2017-07-24 13:13:36 --> Loader Class Initialized
INFO - 2017-07-24 13:13:36 --> Helper loaded: url_helper
INFO - 2017-07-24 13:13:36 --> Helper loaded: form_helper
INFO - 2017-07-24 13:13:36 --> Helper loaded: security_helper
INFO - 2017-07-24 13:13:36 --> Helper loaded: path_helper
INFO - 2017-07-24 13:13:36 --> Helper loaded: common_helper
INFO - 2017-07-24 13:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:13:36 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:13:36 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:13:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:13:36 --> Email Class Initialized
INFO - 2017-07-24 13:13:36 --> Form Validation Class Initialized
INFO - 2017-07-24 13:13:36 --> Model Class Initialized
INFO - 2017-07-24 13:13:36 --> Model Class Initialized
INFO - 2017-07-24 13:13:36 --> Model Class Initialized
INFO - 2017-07-24 13:13:36 --> Model Class Initialized
INFO - 2017-07-24 13:13:36 --> Controller Class Initialized
INFO - 2017-07-24 13:13:36 --> Model Class Initialized
INFO - 2017-07-24 13:13:36 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:13:36 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
ERROR - 2017-07-24 13:13:36 --> Query error: Table 'oncolens.login_ip_tracking_record' doesn't exist - Invalid query: SELECT *
FROM `login_ip_tracking_record`
WHERE `city_name` = ''
AND `country_code` = ''
AND `user_id` = '1'
 LIMIT 1
INFO - 2017-07-24 13:13:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:15:05 --> Config Class Initialized
INFO - 2017-07-24 13:15:05 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:15:05 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:15:05 --> Utf8 Class Initialized
INFO - 2017-07-24 13:15:05 --> URI Class Initialized
INFO - 2017-07-24 13:15:05 --> Router Class Initialized
INFO - 2017-07-24 13:15:05 --> Output Class Initialized
INFO - 2017-07-24 13:15:05 --> Security Class Initialized
DEBUG - 2017-07-24 13:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:15:05 --> Input Class Initialized
INFO - 2017-07-24 13:15:05 --> Language Class Initialized
INFO - 2017-07-24 13:15:05 --> Loader Class Initialized
INFO - 2017-07-24 13:15:05 --> Helper loaded: url_helper
INFO - 2017-07-24 13:15:05 --> Helper loaded: form_helper
INFO - 2017-07-24 13:15:05 --> Helper loaded: security_helper
INFO - 2017-07-24 13:15:05 --> Helper loaded: path_helper
INFO - 2017-07-24 13:15:05 --> Helper loaded: common_helper
INFO - 2017-07-24 13:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:15:05 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:15:05 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:15:06 --> Email Class Initialized
INFO - 2017-07-24 13:15:06 --> Form Validation Class Initialized
INFO - 2017-07-24 13:15:06 --> Model Class Initialized
INFO - 2017-07-24 13:15:06 --> Model Class Initialized
INFO - 2017-07-24 13:15:06 --> Model Class Initialized
INFO - 2017-07-24 13:15:06 --> Model Class Initialized
INFO - 2017-07-24 13:15:06 --> Controller Class Initialized
INFO - 2017-07-24 13:15:06 --> Model Class Initialized
INFO - 2017-07-24 13:15:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:15:06 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
ERROR - 2017-07-24 13:15:06 --> Query error: Unknown column 'ip_address' in 'field list' - Invalid query: INSERT INTO `login_ip_tracking_record` (`ip_address`, `login_date_time`, `city_name`, `country_code`, `user_id`) VALUES ('::1', '2017-07-24 13:15:06', '', '', '1')
INFO - 2017-07-24 13:15:06 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:15:57 --> Config Class Initialized
INFO - 2017-07-24 13:15:57 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:15:57 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:15:57 --> Utf8 Class Initialized
INFO - 2017-07-24 13:15:57 --> URI Class Initialized
INFO - 2017-07-24 13:15:57 --> Router Class Initialized
INFO - 2017-07-24 13:15:57 --> Output Class Initialized
INFO - 2017-07-24 13:15:57 --> Security Class Initialized
DEBUG - 2017-07-24 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:15:57 --> Input Class Initialized
INFO - 2017-07-24 13:15:57 --> Language Class Initialized
INFO - 2017-07-24 13:15:57 --> Loader Class Initialized
INFO - 2017-07-24 13:15:57 --> Helper loaded: url_helper
INFO - 2017-07-24 13:15:57 --> Helper loaded: form_helper
INFO - 2017-07-24 13:15:57 --> Helper loaded: security_helper
INFO - 2017-07-24 13:15:57 --> Helper loaded: path_helper
INFO - 2017-07-24 13:15:57 --> Helper loaded: common_helper
INFO - 2017-07-24 13:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:15:57 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:15:57 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:15:57 --> Email Class Initialized
INFO - 2017-07-24 13:15:57 --> Form Validation Class Initialized
INFO - 2017-07-24 13:15:57 --> Model Class Initialized
INFO - 2017-07-24 13:15:57 --> Model Class Initialized
INFO - 2017-07-24 13:15:57 --> Model Class Initialized
INFO - 2017-07-24 13:15:57 --> Model Class Initialized
INFO - 2017-07-24 13:15:57 --> Controller Class Initialized
INFO - 2017-07-24 13:15:57 --> Model Class Initialized
INFO - 2017-07-24 13:15:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:15:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:15:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\inperson_tumorboard.php
INFO - 2017-07-24 13:15:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:15:57 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:15:57 --> Final output sent to browser
DEBUG - 2017-07-24 13:15:57 --> Total execution time: 0.2140
DEBUG - 2017-07-24 13:15:57 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:15:57 --> Database Forge Class Initialized
INFO - 2017-07-24 13:15:57 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:16:05 --> Config Class Initialized
INFO - 2017-07-24 13:16:05 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:16:05 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:16:05 --> Utf8 Class Initialized
INFO - 2017-07-24 13:16:05 --> URI Class Initialized
INFO - 2017-07-24 13:16:05 --> Router Class Initialized
INFO - 2017-07-24 13:16:05 --> Output Class Initialized
INFO - 2017-07-24 13:16:05 --> Security Class Initialized
DEBUG - 2017-07-24 13:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:16:05 --> Input Class Initialized
INFO - 2017-07-24 13:16:05 --> Language Class Initialized
INFO - 2017-07-24 13:16:05 --> Loader Class Initialized
INFO - 2017-07-24 13:16:05 --> Helper loaded: url_helper
INFO - 2017-07-24 13:16:05 --> Helper loaded: form_helper
INFO - 2017-07-24 13:16:05 --> Helper loaded: security_helper
INFO - 2017-07-24 13:16:05 --> Helper loaded: path_helper
INFO - 2017-07-24 13:16:05 --> Helper loaded: common_helper
INFO - 2017-07-24 13:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:16:05 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:16:05 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:16:05 --> Email Class Initialized
INFO - 2017-07-24 13:16:05 --> Form Validation Class Initialized
INFO - 2017-07-24 13:16:05 --> Model Class Initialized
INFO - 2017-07-24 13:16:05 --> Model Class Initialized
INFO - 2017-07-24 13:16:05 --> Model Class Initialized
INFO - 2017-07-24 13:16:05 --> Model Class Initialized
INFO - 2017-07-24 13:16:05 --> Controller Class Initialized
INFO - 2017-07-24 13:16:05 --> Model Class Initialized
ERROR - 2017-07-24 13:16:05 --> Query error: Table 'oncolens.case_assignment_priority' doesn't exist - Invalid query: SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND  case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id) where (a.doctor_id ='1')  and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')

         group by e.id order by e.case_updated_date DESC
INFO - 2017-07-24 13:16:05 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:16:57 --> Config Class Initialized
INFO - 2017-07-24 13:16:57 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:16:57 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:16:57 --> Utf8 Class Initialized
INFO - 2017-07-24 13:16:57 --> URI Class Initialized
INFO - 2017-07-24 13:16:57 --> Router Class Initialized
INFO - 2017-07-24 13:16:57 --> Output Class Initialized
INFO - 2017-07-24 13:16:57 --> Security Class Initialized
DEBUG - 2017-07-24 13:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:16:57 --> Input Class Initialized
INFO - 2017-07-24 13:16:57 --> Language Class Initialized
INFO - 2017-07-24 13:16:57 --> Loader Class Initialized
INFO - 2017-07-24 13:16:57 --> Helper loaded: url_helper
INFO - 2017-07-24 13:16:57 --> Helper loaded: form_helper
INFO - 2017-07-24 13:16:57 --> Helper loaded: security_helper
INFO - 2017-07-24 13:16:57 --> Helper loaded: path_helper
INFO - 2017-07-24 13:16:57 --> Helper loaded: common_helper
INFO - 2017-07-24 13:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:16:57 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:16:57 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:16:57 --> Email Class Initialized
INFO - 2017-07-24 13:16:57 --> Form Validation Class Initialized
INFO - 2017-07-24 13:16:57 --> Model Class Initialized
INFO - 2017-07-24 13:16:57 --> Model Class Initialized
INFO - 2017-07-24 13:16:57 --> Model Class Initialized
INFO - 2017-07-24 13:16:57 --> Model Class Initialized
INFO - 2017-07-24 13:16:57 --> Controller Class Initialized
INFO - 2017-07-24 13:16:57 --> Model Class Initialized
ERROR - 2017-07-24 13:16:57 --> Query error: Table 'oncolens.case_assignments' doesn't exist - Invalid query: SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND  case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id) where (a.doctor_id ='1')  and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')

         group by e.id order by e.case_updated_date DESC
INFO - 2017-07-24 13:16:57 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:18:57 --> Config Class Initialized
INFO - 2017-07-24 13:18:57 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:18:57 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:18:57 --> Utf8 Class Initialized
INFO - 2017-07-24 13:18:57 --> URI Class Initialized
INFO - 2017-07-24 13:18:57 --> Router Class Initialized
INFO - 2017-07-24 13:18:57 --> Output Class Initialized
INFO - 2017-07-24 13:18:57 --> Security Class Initialized
DEBUG - 2017-07-24 13:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:18:57 --> Input Class Initialized
INFO - 2017-07-24 13:18:57 --> Language Class Initialized
INFO - 2017-07-24 13:18:57 --> Loader Class Initialized
INFO - 2017-07-24 13:18:57 --> Helper loaded: url_helper
INFO - 2017-07-24 13:18:57 --> Helper loaded: form_helper
INFO - 2017-07-24 13:18:57 --> Helper loaded: security_helper
INFO - 2017-07-24 13:18:57 --> Helper loaded: path_helper
INFO - 2017-07-24 13:18:57 --> Helper loaded: common_helper
INFO - 2017-07-24 13:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:18:57 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:18:57 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:18:57 --> Email Class Initialized
INFO - 2017-07-24 13:18:57 --> Form Validation Class Initialized
INFO - 2017-07-24 13:18:57 --> Model Class Initialized
INFO - 2017-07-24 13:18:57 --> Model Class Initialized
INFO - 2017-07-24 13:18:57 --> Model Class Initialized
INFO - 2017-07-24 13:18:57 --> Model Class Initialized
INFO - 2017-07-24 13:18:57 --> Controller Class Initialized
INFO - 2017-07-24 13:18:57 --> Model Class Initialized
ERROR - 2017-07-24 13:18:57 --> Query error: Table 'oncolens.case_doc_email_status' doesn't exist - Invalid query: SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND  case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id) where (a.doctor_id ='1')  and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')

         group by e.id order by e.case_updated_date DESC
INFO - 2017-07-24 13:18:57 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:24:58 --> Config Class Initialized
INFO - 2017-07-24 13:24:58 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:24:58 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:24:58 --> Utf8 Class Initialized
INFO - 2017-07-24 13:24:58 --> URI Class Initialized
INFO - 2017-07-24 13:24:58 --> Router Class Initialized
INFO - 2017-07-24 13:24:58 --> Output Class Initialized
INFO - 2017-07-24 13:24:58 --> Security Class Initialized
DEBUG - 2017-07-24 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:24:58 --> Input Class Initialized
INFO - 2017-07-24 13:24:58 --> Language Class Initialized
INFO - 2017-07-24 13:24:58 --> Loader Class Initialized
INFO - 2017-07-24 13:24:58 --> Helper loaded: url_helper
INFO - 2017-07-24 13:24:58 --> Helper loaded: form_helper
INFO - 2017-07-24 13:24:58 --> Helper loaded: security_helper
INFO - 2017-07-24 13:24:58 --> Helper loaded: path_helper
INFO - 2017-07-24 13:24:58 --> Helper loaded: common_helper
INFO - 2017-07-24 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:24:58 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:24:58 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:24:58 --> Email Class Initialized
INFO - 2017-07-24 13:24:58 --> Form Validation Class Initialized
INFO - 2017-07-24 13:24:58 --> Model Class Initialized
INFO - 2017-07-24 13:24:58 --> Model Class Initialized
INFO - 2017-07-24 13:24:58 --> Model Class Initialized
INFO - 2017-07-24 13:24:58 --> Model Class Initialized
INFO - 2017-07-24 13:24:58 --> Controller Class Initialized
INFO - 2017-07-24 13:24:58 --> Model Class Initialized
ERROR - 2017-07-24 13:24:58 --> Query error: Table 'oncolens.case_doctor_comments' doesn't exist - Invalid query: SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND  case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id) where (a.doctor_id ='1')  and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')

         group by e.id order by e.case_updated_date DESC
INFO - 2017-07-24 13:24:58 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:25:39 --> Config Class Initialized
INFO - 2017-07-24 13:25:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:25:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:25:39 --> Utf8 Class Initialized
INFO - 2017-07-24 13:25:39 --> URI Class Initialized
INFO - 2017-07-24 13:25:39 --> Router Class Initialized
INFO - 2017-07-24 13:25:39 --> Output Class Initialized
INFO - 2017-07-24 13:25:39 --> Security Class Initialized
DEBUG - 2017-07-24 13:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:25:39 --> Input Class Initialized
INFO - 2017-07-24 13:25:39 --> Language Class Initialized
INFO - 2017-07-24 13:25:39 --> Loader Class Initialized
INFO - 2017-07-24 13:25:39 --> Helper loaded: url_helper
INFO - 2017-07-24 13:25:39 --> Helper loaded: form_helper
INFO - 2017-07-24 13:25:39 --> Helper loaded: security_helper
INFO - 2017-07-24 13:25:39 --> Helper loaded: path_helper
INFO - 2017-07-24 13:25:39 --> Helper loaded: common_helper
INFO - 2017-07-24 13:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:25:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:25:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:25:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:25:39 --> Email Class Initialized
INFO - 2017-07-24 13:25:39 --> Form Validation Class Initialized
INFO - 2017-07-24 13:25:39 --> Model Class Initialized
INFO - 2017-07-24 13:25:39 --> Model Class Initialized
INFO - 2017-07-24 13:25:39 --> Model Class Initialized
INFO - 2017-07-24 13:25:39 --> Model Class Initialized
INFO - 2017-07-24 13:25:39 --> Controller Class Initialized
INFO - 2017-07-24 13:25:39 --> Model Class Initialized
ERROR - 2017-07-24 13:25:39 --> Query error: Unknown column 'e.name' in 'field list' - Invalid query: SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND  case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id) where (a.doctor_id ='1')  and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')

         group by e.id order by e.case_updated_date DESC
INFO - 2017-07-24 13:25:39 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:27:37 --> Config Class Initialized
INFO - 2017-07-24 13:27:37 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:27:37 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:27:37 --> Utf8 Class Initialized
INFO - 2017-07-24 13:27:37 --> URI Class Initialized
INFO - 2017-07-24 13:27:37 --> Router Class Initialized
INFO - 2017-07-24 13:27:37 --> Output Class Initialized
INFO - 2017-07-24 13:27:37 --> Security Class Initialized
DEBUG - 2017-07-24 13:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:27:37 --> Input Class Initialized
INFO - 2017-07-24 13:27:37 --> Language Class Initialized
INFO - 2017-07-24 13:27:37 --> Loader Class Initialized
INFO - 2017-07-24 13:27:37 --> Helper loaded: url_helper
INFO - 2017-07-24 13:27:37 --> Helper loaded: form_helper
INFO - 2017-07-24 13:27:37 --> Helper loaded: security_helper
INFO - 2017-07-24 13:27:37 --> Helper loaded: path_helper
INFO - 2017-07-24 13:27:37 --> Helper loaded: common_helper
INFO - 2017-07-24 13:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:27:37 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:27:37 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:27:37 --> Email Class Initialized
INFO - 2017-07-24 13:27:37 --> Form Validation Class Initialized
INFO - 2017-07-24 13:27:37 --> Model Class Initialized
INFO - 2017-07-24 13:27:37 --> Model Class Initialized
INFO - 2017-07-24 13:27:37 --> Model Class Initialized
INFO - 2017-07-24 13:27:37 --> Model Class Initialized
INFO - 2017-07-24 13:27:37 --> Controller Class Initialized
INFO - 2017-07-24 13:27:37 --> Model Class Initialized
ERROR - 2017-07-24 13:27:37 --> Query error: Unknown column 'e.case_mr_number' in 'field list' - Invalid query: SELECT
                    e.case_entered_by,
                    AES_DECRYPT(e.case_description, 'Oncolens') AS case_description,
                    AES_DECRYPT(e.name, 'Oncolens') AS name,
                    AES_DECRYPT(e.dob, 'Oncolens') AS dob,
                    e.case_submit_date,
						e.case_mr_number,
                    DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                    e.pathology_others_text,
                    e.id as case_id,
                    b.is_tumor,
                    b.is_specific_provider,
                    b.is_speciality,
                    b.is_other,
                    (SELECT
                      CONCAT(fname, ' ', lname)
                    FROM
                      users
                    WHERE id = e.case_entered_by) AS submitted_by,
                    (SELECT
                      COUNT(id)
                    FROM
                      case_assignment_priority
                    WHERE priority_id = '2'
                      AND   case_id = e.id) AS count_priority,
                e.case_entered_by AS doctor_id,
                d.speciality_id,
                e.case_status
                FROM
                    case_history AS e
                    INNER JOIN case_assignments AS b
                      ON (e.id = b.case_id)
                    LEFT JOIN case_doc_email_status AS a
                      ON (b.case_id = a.case_id)
                    LEFT JOIN users AS d
                      ON (a.doctor_id = d.id)
                   where (a.doctor_id ='1')  and e.case_status = '1' and is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '1')   group by e.id  order by e.case_updated_date DESC limit 10
INFO - 2017-07-24 13:27:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:28:02 --> Config Class Initialized
INFO - 2017-07-24 13:28:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:28:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:28:02 --> Utf8 Class Initialized
INFO - 2017-07-24 13:28:02 --> URI Class Initialized
INFO - 2017-07-24 13:28:02 --> Router Class Initialized
INFO - 2017-07-24 13:28:02 --> Output Class Initialized
INFO - 2017-07-24 13:28:02 --> Security Class Initialized
DEBUG - 2017-07-24 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:28:02 --> Input Class Initialized
INFO - 2017-07-24 13:28:02 --> Language Class Initialized
INFO - 2017-07-24 13:28:02 --> Loader Class Initialized
INFO - 2017-07-24 13:28:02 --> Helper loaded: url_helper
INFO - 2017-07-24 13:28:02 --> Helper loaded: form_helper
INFO - 2017-07-24 13:28:02 --> Helper loaded: security_helper
INFO - 2017-07-24 13:28:02 --> Helper loaded: path_helper
INFO - 2017-07-24 13:28:02 --> Helper loaded: common_helper
INFO - 2017-07-24 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:28:02 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:28:02 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:28:02 --> Email Class Initialized
INFO - 2017-07-24 13:28:02 --> Form Validation Class Initialized
INFO - 2017-07-24 13:28:02 --> Model Class Initialized
INFO - 2017-07-24 13:28:02 --> Model Class Initialized
INFO - 2017-07-24 13:28:02 --> Model Class Initialized
INFO - 2017-07-24 13:28:02 --> Model Class Initialized
INFO - 2017-07-24 13:28:02 --> Controller Class Initialized
INFO - 2017-07-24 13:28:02 --> Model Class Initialized
INFO - 2017-07-24 13:28:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:28:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:28:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\answer_opencase.php
INFO - 2017-07-24 13:28:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:28:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:28:02 --> Final output sent to browser
DEBUG - 2017-07-24 13:28:02 --> Total execution time: 0.3930
DEBUG - 2017-07-24 13:28:02 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:28:02 --> Database Forge Class Initialized
INFO - 2017-07-24 13:28:02 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:28:08 --> Config Class Initialized
INFO - 2017-07-24 13:28:08 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:28:08 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:28:08 --> Utf8 Class Initialized
INFO - 2017-07-24 13:28:08 --> URI Class Initialized
INFO - 2017-07-24 13:28:08 --> Router Class Initialized
INFO - 2017-07-24 13:28:08 --> Output Class Initialized
INFO - 2017-07-24 13:28:08 --> Security Class Initialized
DEBUG - 2017-07-24 13:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:28:08 --> Input Class Initialized
INFO - 2017-07-24 13:28:08 --> Language Class Initialized
INFO - 2017-07-24 13:28:08 --> Loader Class Initialized
INFO - 2017-07-24 13:28:08 --> Helper loaded: url_helper
INFO - 2017-07-24 13:28:08 --> Helper loaded: form_helper
INFO - 2017-07-24 13:28:08 --> Helper loaded: security_helper
INFO - 2017-07-24 13:28:08 --> Helper loaded: path_helper
INFO - 2017-07-24 13:28:08 --> Helper loaded: common_helper
INFO - 2017-07-24 13:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:28:08 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:28:08 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:28:08 --> Email Class Initialized
INFO - 2017-07-24 13:28:08 --> Form Validation Class Initialized
INFO - 2017-07-24 13:28:08 --> Model Class Initialized
INFO - 2017-07-24 13:28:08 --> Model Class Initialized
INFO - 2017-07-24 13:28:08 --> Model Class Initialized
INFO - 2017-07-24 13:28:08 --> Model Class Initialized
INFO - 2017-07-24 13:28:08 --> Controller Class Initialized
INFO - 2017-07-24 13:28:08 --> Model Class Initialized
ERROR - 2017-07-24 13:28:08 --> Query error: Table 'oncolens.race' doesn't exist - Invalid query: SELECT *
FROM `race`
INFO - 2017-07-24 13:28:08 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:30:11 --> Config Class Initialized
INFO - 2017-07-24 13:30:11 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:30:11 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:30:11 --> Utf8 Class Initialized
INFO - 2017-07-24 13:30:11 --> URI Class Initialized
INFO - 2017-07-24 13:30:11 --> Router Class Initialized
INFO - 2017-07-24 13:30:11 --> Output Class Initialized
INFO - 2017-07-24 13:30:11 --> Security Class Initialized
DEBUG - 2017-07-24 13:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:30:11 --> Input Class Initialized
INFO - 2017-07-24 13:30:11 --> Language Class Initialized
INFO - 2017-07-24 13:30:11 --> Loader Class Initialized
INFO - 2017-07-24 13:30:11 --> Helper loaded: url_helper
INFO - 2017-07-24 13:30:11 --> Helper loaded: form_helper
INFO - 2017-07-24 13:30:11 --> Helper loaded: security_helper
INFO - 2017-07-24 13:30:11 --> Helper loaded: path_helper
INFO - 2017-07-24 13:30:11 --> Helper loaded: common_helper
INFO - 2017-07-24 13:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:30:11 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:30:11 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:30:11 --> Email Class Initialized
INFO - 2017-07-24 13:30:11 --> Form Validation Class Initialized
INFO - 2017-07-24 13:30:11 --> Model Class Initialized
INFO - 2017-07-24 13:30:11 --> Model Class Initialized
INFO - 2017-07-24 13:30:11 --> Model Class Initialized
INFO - 2017-07-24 13:30:11 --> Model Class Initialized
INFO - 2017-07-24 13:30:11 --> Controller Class Initialized
INFO - 2017-07-24 13:30:11 --> Model Class Initialized
INFO - 2017-07-24 13:30:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:30:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
ERROR - 2017-07-24 13:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\userpostcase.php 49
ERROR - 2017-07-24 13:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\userpostcase.php 134
INFO - 2017-07-24 13:30:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\userpostcase.php
INFO - 2017-07-24 13:30:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:30:11 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:30:11 --> Final output sent to browser
DEBUG - 2017-07-24 13:30:11 --> Total execution time: 0.3780
DEBUG - 2017-07-24 13:30:11 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:30:11 --> Database Forge Class Initialized
INFO - 2017-07-24 13:30:11 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:30:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:30:30 --> Config Class Initialized
INFO - 2017-07-24 13:30:30 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:30:30 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:30:30 --> Utf8 Class Initialized
INFO - 2017-07-24 13:30:30 --> URI Class Initialized
INFO - 2017-07-24 13:30:30 --> Router Class Initialized
INFO - 2017-07-24 13:30:30 --> Output Class Initialized
INFO - 2017-07-24 13:30:30 --> Security Class Initialized
DEBUG - 2017-07-24 13:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:30:30 --> Input Class Initialized
INFO - 2017-07-24 13:30:30 --> Language Class Initialized
INFO - 2017-07-24 13:30:30 --> Loader Class Initialized
INFO - 2017-07-24 13:30:31 --> Helper loaded: url_helper
INFO - 2017-07-24 13:30:31 --> Helper loaded: form_helper
INFO - 2017-07-24 13:30:31 --> Helper loaded: security_helper
INFO - 2017-07-24 13:30:31 --> Helper loaded: path_helper
INFO - 2017-07-24 13:30:31 --> Helper loaded: common_helper
INFO - 2017-07-24 13:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:30:31 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:30:31 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:30:31 --> Email Class Initialized
INFO - 2017-07-24 13:30:31 --> Form Validation Class Initialized
INFO - 2017-07-24 13:30:31 --> Model Class Initialized
INFO - 2017-07-24 13:30:31 --> Model Class Initialized
INFO - 2017-07-24 13:30:31 --> Model Class Initialized
INFO - 2017-07-24 13:30:31 --> Model Class Initialized
INFO - 2017-07-24 13:30:31 --> Controller Class Initialized
INFO - 2017-07-24 13:30:31 --> Model Class Initialized
ERROR - 2017-07-24 13:30:31 --> Query error: Unknown column 'e.mark_as_discussed_live' in 'field list' - Invalid query: SELECT
                            AES_DECRYPT(e.name, 'Oncolens') AS name,
                            DATE_FORMAT(AES_DECRYPT(e.dob, 'Oncolens'),'%m/%d/%Y') AS dob,
                            e.case_submit_date,
                            DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                            e.pathology_others_text,
                            AES_DECRYPT(e.case_description, 'Oncolens') AS case_description,
                            e.case_entered_by,
							   e.case_mr_number,
                            e.id AS case_id,
                            b.is_tumor,
                            b.is_specific_provider,
                            b.is_speciality,
                            b.is_other,
                            e.case_entered_by AS doctor_id,
                            d.speciality_id,
                            e.case_status,
                            e.mark_as_discussed_live,
                            (SELECT
                              COUNT(id)
                            FROM
                              case_doctor_comments
                            WHERE case_id = e.id) AS online,
                            (SELECT
                              GROUP_CONCAT(
                                DATE_FORMAT(meeting_date, '%m/%d/%Y'),
                                ' ',
                                DATE_FORMAT(meeting_time, '%h:%i %p')
                              )
                            FROM
                              case_meeting_assignments AS cma
                              INNER JOIN case_meeting_details AS cmd
                                ON cma.sub_meeting_id = cmd.id
                            WHERE cma.case_id = e.id) AS assigned
                          FROM
                            case_history AS e
                            INNER JOIN case_assignments AS b
                              ON (e.id = b.case_id)
                            LEFT JOIN case_doc_email_status AS a
                              ON (b.case_id = a.case_id)
                             LEFT JOIN users AS d
                              ON (a.doctor_id = d.id)
                          where e.case_status='1' and   e.case_entered_by='1'   and e.is_deleted = '0'
                        GROUP BY e.id
                    order by e.case_updated_date DESC limit 0 , 10
INFO - 2017-07-24 13:30:31 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:31:21 --> Config Class Initialized
INFO - 2017-07-24 13:31:21 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:31:21 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:31:21 --> Utf8 Class Initialized
INFO - 2017-07-24 13:31:21 --> URI Class Initialized
INFO - 2017-07-24 13:31:21 --> Router Class Initialized
INFO - 2017-07-24 13:31:21 --> Output Class Initialized
INFO - 2017-07-24 13:31:21 --> Security Class Initialized
DEBUG - 2017-07-24 13:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:31:21 --> Input Class Initialized
INFO - 2017-07-24 13:31:21 --> Language Class Initialized
INFO - 2017-07-24 13:31:21 --> Loader Class Initialized
INFO - 2017-07-24 13:31:21 --> Helper loaded: url_helper
INFO - 2017-07-24 13:31:21 --> Helper loaded: form_helper
INFO - 2017-07-24 13:31:21 --> Helper loaded: security_helper
INFO - 2017-07-24 13:31:21 --> Helper loaded: path_helper
INFO - 2017-07-24 13:31:21 --> Helper loaded: common_helper
INFO - 2017-07-24 13:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:31:21 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:31:21 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:31:21 --> Email Class Initialized
INFO - 2017-07-24 13:31:21 --> Form Validation Class Initialized
INFO - 2017-07-24 13:31:21 --> Model Class Initialized
INFO - 2017-07-24 13:31:21 --> Model Class Initialized
INFO - 2017-07-24 13:31:21 --> Model Class Initialized
INFO - 2017-07-24 13:31:21 --> Model Class Initialized
INFO - 2017-07-24 13:31:21 --> Controller Class Initialized
INFO - 2017-07-24 13:31:21 --> Model Class Initialized
INFO - 2017-07-24 13:31:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:31:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:31:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\your_case.php
INFO - 2017-07-24 13:31:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:31:21 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:31:21 --> Final output sent to browser
DEBUG - 2017-07-24 13:31:21 --> Total execution time: 0.1970
DEBUG - 2017-07-24 13:31:21 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:31:21 --> Database Forge Class Initialized
INFO - 2017-07-24 13:31:21 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:31:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:31:29 --> Config Class Initialized
INFO - 2017-07-24 13:31:29 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:31:29 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:31:29 --> Utf8 Class Initialized
INFO - 2017-07-24 13:31:29 --> URI Class Initialized
INFO - 2017-07-24 13:31:29 --> Router Class Initialized
INFO - 2017-07-24 13:31:29 --> Output Class Initialized
INFO - 2017-07-24 13:31:29 --> Security Class Initialized
DEBUG - 2017-07-24 13:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:31:29 --> Input Class Initialized
INFO - 2017-07-24 13:31:29 --> Language Class Initialized
INFO - 2017-07-24 13:31:29 --> Loader Class Initialized
INFO - 2017-07-24 13:31:29 --> Helper loaded: url_helper
INFO - 2017-07-24 13:31:29 --> Helper loaded: form_helper
INFO - 2017-07-24 13:31:29 --> Helper loaded: security_helper
INFO - 2017-07-24 13:31:29 --> Helper loaded: path_helper
INFO - 2017-07-24 13:31:29 --> Helper loaded: common_helper
INFO - 2017-07-24 13:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:31:29 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:31:29 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:31:29 --> Email Class Initialized
INFO - 2017-07-24 13:31:29 --> Form Validation Class Initialized
INFO - 2017-07-24 13:31:29 --> Model Class Initialized
INFO - 2017-07-24 13:31:29 --> Model Class Initialized
INFO - 2017-07-24 13:31:29 --> Model Class Initialized
INFO - 2017-07-24 13:31:29 --> Model Class Initialized
INFO - 2017-07-24 13:31:29 --> Controller Class Initialized
INFO - 2017-07-24 13:31:29 --> Model Class Initialized
ERROR - 2017-07-24 13:31:29 --> Severity: Notice --> Undefined variable: next_id E:\xampp\htdocs\oncolens\application\models\Mcase.php 4462
INFO - 2017-07-24 13:31:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:31:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
ERROR - 2017-07-24 13:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xampp\htdocs\oncolens\application\views\search_case.php 80
INFO - 2017-07-24 13:31:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\search_case.php
INFO - 2017-07-24 13:31:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:31:29 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:31:29 --> Final output sent to browser
DEBUG - 2017-07-24 13:31:29 --> Total execution time: 0.2990
DEBUG - 2017-07-24 13:31:29 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:31:29 --> Database Forge Class Initialized
INFO - 2017-07-24 13:31:29 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:31:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:31:39 --> Config Class Initialized
INFO - 2017-07-24 13:31:39 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:31:39 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:31:39 --> Utf8 Class Initialized
INFO - 2017-07-24 13:31:39 --> URI Class Initialized
INFO - 2017-07-24 13:31:39 --> Router Class Initialized
INFO - 2017-07-24 13:31:39 --> Output Class Initialized
INFO - 2017-07-24 13:31:39 --> Security Class Initialized
DEBUG - 2017-07-24 13:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:31:39 --> Input Class Initialized
INFO - 2017-07-24 13:31:39 --> Language Class Initialized
INFO - 2017-07-24 13:31:39 --> Loader Class Initialized
INFO - 2017-07-24 13:31:39 --> Helper loaded: url_helper
INFO - 2017-07-24 13:31:39 --> Helper loaded: form_helper
INFO - 2017-07-24 13:31:39 --> Helper loaded: security_helper
INFO - 2017-07-24 13:31:39 --> Helper loaded: path_helper
INFO - 2017-07-24 13:31:39 --> Helper loaded: common_helper
INFO - 2017-07-24 13:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:31:39 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:31:39 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:31:39 --> Email Class Initialized
INFO - 2017-07-24 13:31:39 --> Form Validation Class Initialized
INFO - 2017-07-24 13:31:39 --> Model Class Initialized
INFO - 2017-07-24 13:31:39 --> Model Class Initialized
INFO - 2017-07-24 13:31:39 --> Model Class Initialized
INFO - 2017-07-24 13:31:39 --> Model Class Initialized
INFO - 2017-07-24 13:31:39 --> Controller Class Initialized
INFO - 2017-07-24 13:31:39 --> Model Class Initialized
ERROR - 2017-07-24 13:31:39 --> Severity: Notice --> Undefined variable: filter E:\xampp\htdocs\oncolens\application\controllers\Inperson.php 141
INFO - 2017-07-24 13:31:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:31:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
ERROR - 2017-07-24 13:31:39 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\oncolens\application\views\faq-login.php 4
ERROR - 2017-07-24 13:31:39 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\oncolens\application\views\faq-login.php 4
ERROR - 2017-07-24 13:31:39 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\oncolens\application\views\faq-login.php 18
ERROR - 2017-07-24 13:31:39 --> Severity: Notice --> Trying to get property of non-object E:\xampp\htdocs\oncolens\application\views\faq-login.php 18
INFO - 2017-07-24 13:31:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\faq-login.php
INFO - 2017-07-24 13:31:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:31:39 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:31:39 --> Final output sent to browser
DEBUG - 2017-07-24 13:31:39 --> Total execution time: 0.1600
DEBUG - 2017-07-24 13:31:39 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:31:39 --> Database Forge Class Initialized
INFO - 2017-07-24 13:31:39 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:31:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:02 --> Config Class Initialized
INFO - 2017-07-24 13:34:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:34:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:34:02 --> Utf8 Class Initialized
INFO - 2017-07-24 13:34:02 --> URI Class Initialized
INFO - 2017-07-24 13:34:02 --> Router Class Initialized
INFO - 2017-07-24 13:34:02 --> Output Class Initialized
INFO - 2017-07-24 13:34:02 --> Security Class Initialized
DEBUG - 2017-07-24 13:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:34:02 --> Input Class Initialized
INFO - 2017-07-24 13:34:02 --> Language Class Initialized
INFO - 2017-07-24 13:34:02 --> Loader Class Initialized
INFO - 2017-07-24 13:34:02 --> Helper loaded: url_helper
INFO - 2017-07-24 13:34:02 --> Helper loaded: form_helper
INFO - 2017-07-24 13:34:02 --> Helper loaded: security_helper
INFO - 2017-07-24 13:34:02 --> Helper loaded: path_helper
INFO - 2017-07-24 13:34:02 --> Helper loaded: common_helper
INFO - 2017-07-24 13:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:34:02 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:34:02 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:02 --> Email Class Initialized
INFO - 2017-07-24 13:34:02 --> Form Validation Class Initialized
INFO - 2017-07-24 13:34:02 --> Model Class Initialized
INFO - 2017-07-24 13:34:02 --> Model Class Initialized
INFO - 2017-07-24 13:34:02 --> Model Class Initialized
INFO - 2017-07-24 13:34:02 --> Model Class Initialized
INFO - 2017-07-24 13:34:02 --> Controller Class Initialized
INFO - 2017-07-24 13:34:02 --> Model Class Initialized
ERROR - 2017-07-24 13:34:02 --> Severity: Notice --> Undefined variable: filter E:\xampp\htdocs\oncolens\application\controllers\Inperson.php 141
INFO - 2017-07-24 13:34:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:34:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:34:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\faq-login.php
INFO - 2017-07-24 13:34:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:34:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:34:02 --> Final output sent to browser
DEBUG - 2017-07-24 13:34:02 --> Total execution time: 0.0770
DEBUG - 2017-07-24 13:34:02 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:34:02 --> Database Forge Class Initialized
INFO - 2017-07-24 13:34:02 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:34:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:25 --> Config Class Initialized
INFO - 2017-07-24 13:34:25 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:34:25 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:34:25 --> Utf8 Class Initialized
INFO - 2017-07-24 13:34:25 --> URI Class Initialized
INFO - 2017-07-24 13:34:25 --> Router Class Initialized
INFO - 2017-07-24 13:34:25 --> Output Class Initialized
INFO - 2017-07-24 13:34:25 --> Security Class Initialized
DEBUG - 2017-07-24 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:34:25 --> Input Class Initialized
INFO - 2017-07-24 13:34:25 --> Language Class Initialized
INFO - 2017-07-24 13:34:25 --> Loader Class Initialized
INFO - 2017-07-24 13:34:25 --> Helper loaded: url_helper
INFO - 2017-07-24 13:34:25 --> Helper loaded: form_helper
INFO - 2017-07-24 13:34:25 --> Helper loaded: security_helper
INFO - 2017-07-24 13:34:25 --> Helper loaded: path_helper
INFO - 2017-07-24 13:34:25 --> Helper loaded: common_helper
INFO - 2017-07-24 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:34:25 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:34:25 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:25 --> Email Class Initialized
INFO - 2017-07-24 13:34:25 --> Form Validation Class Initialized
INFO - 2017-07-24 13:34:25 --> Model Class Initialized
INFO - 2017-07-24 13:34:25 --> Model Class Initialized
INFO - 2017-07-24 13:34:25 --> Model Class Initialized
INFO - 2017-07-24 13:34:25 --> Model Class Initialized
INFO - 2017-07-24 13:34:25 --> Controller Class Initialized
INFO - 2017-07-24 13:34:25 --> Model Class Initialized
INFO - 2017-07-24 13:34:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:34:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:34:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\faq-login.php
INFO - 2017-07-24 13:34:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:34:25 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:34:25 --> Final output sent to browser
DEBUG - 2017-07-24 13:34:25 --> Total execution time: 0.0790
DEBUG - 2017-07-24 13:34:25 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:34:25 --> Database Forge Class Initialized
INFO - 2017-07-24 13:34:25 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:32 --> Config Class Initialized
INFO - 2017-07-24 13:34:32 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:34:32 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:34:32 --> Utf8 Class Initialized
INFO - 2017-07-24 13:34:32 --> URI Class Initialized
INFO - 2017-07-24 13:34:32 --> Router Class Initialized
INFO - 2017-07-24 13:34:32 --> Output Class Initialized
INFO - 2017-07-24 13:34:32 --> Security Class Initialized
DEBUG - 2017-07-24 13:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:34:32 --> Input Class Initialized
INFO - 2017-07-24 13:34:32 --> Language Class Initialized
INFO - 2017-07-24 13:34:32 --> Loader Class Initialized
INFO - 2017-07-24 13:34:32 --> Helper loaded: url_helper
INFO - 2017-07-24 13:34:32 --> Helper loaded: form_helper
INFO - 2017-07-24 13:34:32 --> Helper loaded: security_helper
INFO - 2017-07-24 13:34:32 --> Helper loaded: path_helper
INFO - 2017-07-24 13:34:32 --> Helper loaded: common_helper
INFO - 2017-07-24 13:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:34:32 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:34:32 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:34:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:32 --> Email Class Initialized
INFO - 2017-07-24 13:34:32 --> Form Validation Class Initialized
INFO - 2017-07-24 13:34:32 --> Model Class Initialized
INFO - 2017-07-24 13:34:32 --> Model Class Initialized
INFO - 2017-07-24 13:34:32 --> Model Class Initialized
INFO - 2017-07-24 13:34:32 --> Model Class Initialized
INFO - 2017-07-24 13:34:32 --> Controller Class Initialized
ERROR - 2017-07-24 13:34:32 --> Query error: Unknown column 'notification' in 'field list' - Invalid query: SELECT `notification`
FROM `users`
WHERE `id` = 1
ERROR - 2017-07-24 13:34:32 --> Severity: Error --> Call to a member function num_rows() on a non-object E:\xampp\htdocs\oncolens\application\models\Mcustom.php 8
INFO - 2017-07-24 13:34:36 --> Config Class Initialized
INFO - 2017-07-24 13:34:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:34:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:34:36 --> Utf8 Class Initialized
INFO - 2017-07-24 13:34:36 --> URI Class Initialized
INFO - 2017-07-24 13:34:36 --> Router Class Initialized
INFO - 2017-07-24 13:34:36 --> Output Class Initialized
INFO - 2017-07-24 13:34:36 --> Security Class Initialized
DEBUG - 2017-07-24 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:34:36 --> Input Class Initialized
INFO - 2017-07-24 13:34:36 --> Language Class Initialized
INFO - 2017-07-24 13:34:36 --> Loader Class Initialized
INFO - 2017-07-24 13:34:36 --> Helper loaded: url_helper
INFO - 2017-07-24 13:34:36 --> Helper loaded: form_helper
INFO - 2017-07-24 13:34:36 --> Helper loaded: security_helper
INFO - 2017-07-24 13:34:36 --> Helper loaded: path_helper
INFO - 2017-07-24 13:34:36 --> Helper loaded: common_helper
INFO - 2017-07-24 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:34:36 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:34:36 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:34:36 --> Email Class Initialized
INFO - 2017-07-24 13:34:36 --> Form Validation Class Initialized
INFO - 2017-07-24 13:34:36 --> Model Class Initialized
INFO - 2017-07-24 13:34:36 --> Model Class Initialized
INFO - 2017-07-24 13:34:36 --> Model Class Initialized
INFO - 2017-07-24 13:34:36 --> Model Class Initialized
INFO - 2017-07-24 13:34:36 --> Controller Class Initialized
ERROR - 2017-07-24 13:34:36 --> Query error: Unknown column 'notification' in 'field list' - Invalid query: SELECT `notification`
FROM `users`
WHERE `id` = 1
INFO - 2017-07-24 13:34:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:35:27 --> Config Class Initialized
INFO - 2017-07-24 13:35:27 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:35:27 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:35:27 --> Utf8 Class Initialized
INFO - 2017-07-24 13:35:27 --> URI Class Initialized
INFO - 2017-07-24 13:35:27 --> Router Class Initialized
INFO - 2017-07-24 13:35:27 --> Output Class Initialized
INFO - 2017-07-24 13:35:27 --> Security Class Initialized
DEBUG - 2017-07-24 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:35:27 --> Input Class Initialized
INFO - 2017-07-24 13:35:27 --> Language Class Initialized
INFO - 2017-07-24 13:35:27 --> Loader Class Initialized
INFO - 2017-07-24 13:35:27 --> Helper loaded: url_helper
INFO - 2017-07-24 13:35:27 --> Helper loaded: form_helper
INFO - 2017-07-24 13:35:27 --> Helper loaded: security_helper
INFO - 2017-07-24 13:35:27 --> Helper loaded: path_helper
INFO - 2017-07-24 13:35:27 --> Helper loaded: common_helper
INFO - 2017-07-24 13:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:35:27 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:35:27 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:27 --> Email Class Initialized
INFO - 2017-07-24 13:35:27 --> Form Validation Class Initialized
INFO - 2017-07-24 13:35:27 --> Model Class Initialized
INFO - 2017-07-24 13:35:27 --> Model Class Initialized
INFO - 2017-07-24 13:35:27 --> Model Class Initialized
INFO - 2017-07-24 13:35:27 --> Model Class Initialized
INFO - 2017-07-24 13:35:27 --> Controller Class Initialized
INFO - 2017-07-24 13:35:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:35:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:35:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\profile.php
INFO - 2017-07-24 13:35:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:35:27 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:35:27 --> Final output sent to browser
DEBUG - 2017-07-24 13:35:27 --> Total execution time: 0.1160
DEBUG - 2017-07-24 13:35:27 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:35:27 --> Database Forge Class Initialized
INFO - 2017-07-24 13:35:27 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:38 --> Config Class Initialized
INFO - 2017-07-24 13:35:38 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:35:38 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:35:38 --> Utf8 Class Initialized
INFO - 2017-07-24 13:35:38 --> URI Class Initialized
INFO - 2017-07-24 13:35:38 --> Router Class Initialized
INFO - 2017-07-24 13:35:38 --> Output Class Initialized
INFO - 2017-07-24 13:35:38 --> Security Class Initialized
DEBUG - 2017-07-24 13:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:35:38 --> Input Class Initialized
INFO - 2017-07-24 13:35:38 --> Language Class Initialized
INFO - 2017-07-24 13:35:38 --> Loader Class Initialized
INFO - 2017-07-24 13:35:38 --> Helper loaded: url_helper
INFO - 2017-07-24 13:35:38 --> Helper loaded: form_helper
INFO - 2017-07-24 13:35:38 --> Helper loaded: security_helper
INFO - 2017-07-24 13:35:38 --> Helper loaded: path_helper
INFO - 2017-07-24 13:35:38 --> Helper loaded: common_helper
INFO - 2017-07-24 13:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:35:38 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:35:38 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:38 --> Email Class Initialized
INFO - 2017-07-24 13:35:38 --> Form Validation Class Initialized
INFO - 2017-07-24 13:35:38 --> Model Class Initialized
INFO - 2017-07-24 13:35:38 --> Model Class Initialized
INFO - 2017-07-24 13:35:38 --> Model Class Initialized
INFO - 2017-07-24 13:35:38 --> Model Class Initialized
INFO - 2017-07-24 13:35:38 --> Controller Class Initialized
INFO - 2017-07-24 13:35:38 --> Final output sent to browser
DEBUG - 2017-07-24 13:35:38 --> Total execution time: 0.4250
DEBUG - 2017-07-24 13:35:38 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:35:38 --> Database Forge Class Initialized
INFO - 2017-07-24 13:35:38 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:35:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:41 --> Config Class Initialized
INFO - 2017-07-24 13:35:41 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:35:41 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:35:41 --> Utf8 Class Initialized
INFO - 2017-07-24 13:35:41 --> URI Class Initialized
INFO - 2017-07-24 13:35:41 --> Router Class Initialized
INFO - 2017-07-24 13:35:41 --> Output Class Initialized
INFO - 2017-07-24 13:35:41 --> Security Class Initialized
DEBUG - 2017-07-24 13:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:35:41 --> Input Class Initialized
INFO - 2017-07-24 13:35:41 --> Language Class Initialized
INFO - 2017-07-24 13:35:41 --> Loader Class Initialized
INFO - 2017-07-24 13:35:41 --> Helper loaded: url_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: form_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: security_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: path_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: common_helper
INFO - 2017-07-24 13:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:35:41 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:35:41 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:41 --> Email Class Initialized
INFO - 2017-07-24 13:35:41 --> Form Validation Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Controller Class Initialized
INFO - 2017-07-24 13:35:41 --> Config Class Initialized
INFO - 2017-07-24 13:35:41 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:35:41 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:35:41 --> Utf8 Class Initialized
INFO - 2017-07-24 13:35:41 --> URI Class Initialized
INFO - 2017-07-24 13:35:41 --> Router Class Initialized
INFO - 2017-07-24 13:35:41 --> Output Class Initialized
INFO - 2017-07-24 13:35:41 --> Security Class Initialized
DEBUG - 2017-07-24 13:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:35:41 --> Input Class Initialized
INFO - 2017-07-24 13:35:41 --> Language Class Initialized
INFO - 2017-07-24 13:35:41 --> Loader Class Initialized
INFO - 2017-07-24 13:35:41 --> Helper loaded: url_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: form_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: security_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: path_helper
INFO - 2017-07-24 13:35:41 --> Helper loaded: common_helper
INFO - 2017-07-24 13:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:35:41 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:35:41 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:41 --> Email Class Initialized
INFO - 2017-07-24 13:35:41 --> Form Validation Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Model Class Initialized
INFO - 2017-07-24 13:35:41 --> Controller Class Initialized
INFO - 2017-07-24 13:35:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:35:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:35:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\profile.php
INFO - 2017-07-24 13:35:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:35:41 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:35:41 --> Final output sent to browser
DEBUG - 2017-07-24 13:35:41 --> Total execution time: 0.1460
DEBUG - 2017-07-24 13:35:41 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:35:41 --> Database Forge Class Initialized
INFO - 2017-07-24 13:35:41 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:47 --> Config Class Initialized
INFO - 2017-07-24 13:35:47 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:35:47 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:35:47 --> Utf8 Class Initialized
INFO - 2017-07-24 13:35:47 --> URI Class Initialized
INFO - 2017-07-24 13:35:47 --> Router Class Initialized
INFO - 2017-07-24 13:35:47 --> Output Class Initialized
INFO - 2017-07-24 13:35:47 --> Security Class Initialized
DEBUG - 2017-07-24 13:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:35:47 --> Input Class Initialized
INFO - 2017-07-24 13:35:47 --> Language Class Initialized
INFO - 2017-07-24 13:35:47 --> Loader Class Initialized
INFO - 2017-07-24 13:35:47 --> Helper loaded: url_helper
INFO - 2017-07-24 13:35:47 --> Helper loaded: form_helper
INFO - 2017-07-24 13:35:47 --> Helper loaded: security_helper
INFO - 2017-07-24 13:35:47 --> Helper loaded: path_helper
INFO - 2017-07-24 13:35:47 --> Helper loaded: common_helper
INFO - 2017-07-24 13:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:35:47 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:35:47 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:35:47 --> Email Class Initialized
INFO - 2017-07-24 13:35:47 --> Form Validation Class Initialized
INFO - 2017-07-24 13:35:47 --> Model Class Initialized
INFO - 2017-07-24 13:35:47 --> Model Class Initialized
INFO - 2017-07-24 13:35:47 --> Model Class Initialized
INFO - 2017-07-24 13:35:47 --> Model Class Initialized
INFO - 2017-07-24 13:35:47 --> Controller Class Initialized
INFO - 2017-07-24 13:35:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:35:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:35:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\profile.php
INFO - 2017-07-24 13:35:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:35:47 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:35:47 --> Final output sent to browser
DEBUG - 2017-07-24 13:35:47 --> Total execution time: 0.2180
DEBUG - 2017-07-24 13:35:47 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:35:47 --> Database Forge Class Initialized
INFO - 2017-07-24 13:35:47 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:35:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:36:02 --> Config Class Initialized
INFO - 2017-07-24 13:36:02 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:36:02 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:36:02 --> Utf8 Class Initialized
INFO - 2017-07-24 13:36:02 --> URI Class Initialized
INFO - 2017-07-24 13:36:02 --> Router Class Initialized
INFO - 2017-07-24 13:36:02 --> Output Class Initialized
INFO - 2017-07-24 13:36:02 --> Security Class Initialized
DEBUG - 2017-07-24 13:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:36:02 --> Input Class Initialized
INFO - 2017-07-24 13:36:02 --> Language Class Initialized
INFO - 2017-07-24 13:36:02 --> Loader Class Initialized
INFO - 2017-07-24 13:36:02 --> Helper loaded: url_helper
INFO - 2017-07-24 13:36:02 --> Helper loaded: form_helper
INFO - 2017-07-24 13:36:02 --> Helper loaded: security_helper
INFO - 2017-07-24 13:36:02 --> Helper loaded: path_helper
INFO - 2017-07-24 13:36:02 --> Helper loaded: common_helper
INFO - 2017-07-24 13:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:36:02 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:36:02 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:36:02 --> Email Class Initialized
INFO - 2017-07-24 13:36:02 --> Form Validation Class Initialized
INFO - 2017-07-24 13:36:02 --> Model Class Initialized
INFO - 2017-07-24 13:36:02 --> Model Class Initialized
INFO - 2017-07-24 13:36:02 --> Model Class Initialized
INFO - 2017-07-24 13:36:02 --> Model Class Initialized
INFO - 2017-07-24 13:36:02 --> Controller Class Initialized
INFO - 2017-07-24 13:36:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/header.php
INFO - 2017-07-24 13:36:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/left_menu.php
INFO - 2017-07-24 13:36:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\change_password.php
INFO - 2017-07-24 13:36:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/footer.php
INFO - 2017-07-24 13:36:02 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/template.php
INFO - 2017-07-24 13:36:02 --> Final output sent to browser
DEBUG - 2017-07-24 13:36:02 --> Total execution time: 0.1370
DEBUG - 2017-07-24 13:36:02 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:36:02 --> Database Forge Class Initialized
INFO - 2017-07-24 13:36:02 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:36:07 --> Config Class Initialized
INFO - 2017-07-24 13:36:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:36:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:36:07 --> Utf8 Class Initialized
INFO - 2017-07-24 13:36:07 --> URI Class Initialized
INFO - 2017-07-24 13:36:07 --> Router Class Initialized
INFO - 2017-07-24 13:36:07 --> Output Class Initialized
INFO - 2017-07-24 13:36:07 --> Security Class Initialized
DEBUG - 2017-07-24 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:36:07 --> Input Class Initialized
INFO - 2017-07-24 13:36:07 --> Language Class Initialized
INFO - 2017-07-24 13:36:07 --> Loader Class Initialized
INFO - 2017-07-24 13:36:07 --> Helper loaded: url_helper
INFO - 2017-07-24 13:36:07 --> Helper loaded: form_helper
INFO - 2017-07-24 13:36:07 --> Helper loaded: security_helper
INFO - 2017-07-24 13:36:07 --> Helper loaded: path_helper
INFO - 2017-07-24 13:36:07 --> Helper loaded: common_helper
INFO - 2017-07-24 13:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:36:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:36:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:36:08 --> Email Class Initialized
INFO - 2017-07-24 13:36:08 --> Form Validation Class Initialized
INFO - 2017-07-24 13:36:08 --> Model Class Initialized
INFO - 2017-07-24 13:36:08 --> Model Class Initialized
INFO - 2017-07-24 13:36:08 --> Model Class Initialized
INFO - 2017-07-24 13:36:08 --> Model Class Initialized
INFO - 2017-07-24 13:36:08 --> Controller Class Initialized
ERROR - 2017-07-24 13:36:08 --> Query error: Unknown column 'stat_id' in 'order clause' - Invalid query: update  login_stats set user_logout_time='2017-07-24 01:36:08' where  user_id=1 and user_ip_address='' order by stat_id desc limit 1
INFO - 2017-07-24 13:36:08 --> Language file loaded: language/english/db_lang.php
INFO - 2017-07-24 13:37:19 --> Config Class Initialized
INFO - 2017-07-24 13:37:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:37:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:37:19 --> Utf8 Class Initialized
INFO - 2017-07-24 13:37:19 --> URI Class Initialized
INFO - 2017-07-24 13:37:19 --> Router Class Initialized
INFO - 2017-07-24 13:37:19 --> Output Class Initialized
INFO - 2017-07-24 13:37:19 --> Security Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:37:19 --> Input Class Initialized
INFO - 2017-07-24 13:37:19 --> Language Class Initialized
INFO - 2017-07-24 13:37:19 --> Loader Class Initialized
INFO - 2017-07-24 13:37:19 --> Helper loaded: url_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: form_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: security_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: path_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: common_helper
INFO - 2017-07-24 13:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:37:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:37:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:37:19 --> Email Class Initialized
INFO - 2017-07-24 13:37:19 --> Form Validation Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Controller Class Initialized
INFO - 2017-07-24 13:37:19 --> Config Class Initialized
INFO - 2017-07-24 13:37:19 --> Hooks Class Initialized
DEBUG - 2017-07-24 13:37:19 --> UTF-8 Support Enabled
INFO - 2017-07-24 13:37:19 --> Utf8 Class Initialized
INFO - 2017-07-24 13:37:19 --> URI Class Initialized
DEBUG - 2017-07-24 13:37:19 --> No URI present. Default controller set.
INFO - 2017-07-24 13:37:19 --> Router Class Initialized
INFO - 2017-07-24 13:37:19 --> Output Class Initialized
INFO - 2017-07-24 13:37:19 --> Security Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 13:37:19 --> Input Class Initialized
INFO - 2017-07-24 13:37:19 --> Language Class Initialized
INFO - 2017-07-24 13:37:19 --> Loader Class Initialized
INFO - 2017-07-24 13:37:19 --> Helper loaded: url_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: form_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: security_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: path_helper
INFO - 2017-07-24 13:37:19 --> Helper loaded: common_helper
INFO - 2017-07-24 13:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 13:37:19 --> Helper loaded: check_session_helper
INFO - 2017-07-24 13:37:19 --> Database Driver Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:37:19 --> Email Class Initialized
INFO - 2017-07-24 13:37:19 --> Form Validation Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Model Class Initialized
INFO - 2017-07-24 13:37:19 --> Controller Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 13:37:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\user_login.php
INFO - 2017-07-24 13:37:19 --> File loaded: E:\xampp\htdocs\oncolens\application\views\template/login_template.php
INFO - 2017-07-24 13:37:19 --> Final output sent to browser
DEBUG - 2017-07-24 13:37:19 --> Total execution time: 0.0850
DEBUG - 2017-07-24 13:37:19 --> Config file loaded: E:\xampp\htdocs\oncolens\application\config/usertracking_config.php
INFO - 2017-07-24 13:37:19 --> Database Forge Class Initialized
INFO - 2017-07-24 13:37:19 --> User Agent Class Initialized
DEBUG - 2017-07-24 13:37:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Config Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Hooks Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:04:35 --> UTF-8 Support Enabled
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Utf8 Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> URI Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:04:35 --> No URI present. Default controller set.
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Router Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Output Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Security Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Input Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Language Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Loader Class Initialized
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Helper loaded: url_helper
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Helper loaded: form_helper
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Helper loaded: security_helper
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Helper loaded: path_helper
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:04:35 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:04:35 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php:176) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Common.php 569
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(01a8d8e3ed4108c8402005b50b5ec57e6cb840c9) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(01a8d8e3ed4108c8402005b50b5ec57e6cb840c9) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> fopen(01a8d8e3ed4108c8402005b50b5ec57e6cb840c9): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:04:35 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:04:35 --> Session: File '01a8d8e3ed4108c8402005b50b5ec57e6cb840c9' doesn't exist and cannot be created.
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Config Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Hooks Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:21 --> UTF-8 Support Enabled
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Utf8 Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> URI Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:21 --> No URI present. Default controller set.
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Router Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Output Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Security Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Input Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Language Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Loader Class Initialized
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Helper loaded: url_helper
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Helper loaded: form_helper
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Helper loaded: security_helper
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Helper loaded: path_helper
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:21 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:21 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:21 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:21 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Config Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Hooks Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:23 --> UTF-8 Support Enabled
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Utf8 Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> URI Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:23 --> No URI present. Default controller set.
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Router Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Output Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Security Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Input Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Language Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Loader Class Initialized
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Helper loaded: url_helper
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Helper loaded: form_helper
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Helper loaded: security_helper
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Helper loaded: path_helper
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:23 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:23 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:24 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:24 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:24 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Config Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Hooks Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:37 --> UTF-8 Support Enabled
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Utf8 Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> URI Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:37 --> No URI present. Default controller set.
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Router Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Output Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Security Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
DEBUG - 2017-07-24 12:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Input Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Language Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Loader Class Initialized
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Helper loaded: url_helper
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Helper loaded: form_helper
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Helper loaded: security_helper
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Helper loaded: path_helper
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
INFO - 2017-07-24 12:05:37 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:37 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php:176) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Common.php 569
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 176
ERROR - 2017-07-24 12:05:37 --> Severity: Warning --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/core/Log.php 204
ERROR - 2017-07-24 12:05:37 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
INFO - 2017-07-24 12:11:08 --> Config Class Initialized
INFO - 2017-07-24 12:11:08 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:11:08 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:11:08 --> Utf8 Class Initialized
INFO - 2017-07-24 12:11:08 --> URI Class Initialized
DEBUG - 2017-07-24 12:11:08 --> No URI present. Default controller set.
INFO - 2017-07-24 12:11:08 --> Router Class Initialized
INFO - 2017-07-24 12:11:08 --> Output Class Initialized
INFO - 2017-07-24 12:11:08 --> Security Class Initialized
DEBUG - 2017-07-24 12:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:11:08 --> Input Class Initialized
INFO - 2017-07-24 12:11:08 --> Language Class Initialized
INFO - 2017-07-24 12:11:08 --> Loader Class Initialized
INFO - 2017-07-24 12:11:08 --> Helper loaded: url_helper
INFO - 2017-07-24 12:11:08 --> Helper loaded: form_helper
INFO - 2017-07-24 12:11:08 --> Helper loaded: security_helper
INFO - 2017-07-24 12:11:08 --> Helper loaded: path_helper
INFO - 2017-07-24 12:11:08 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:11:08 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:11:08 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:11:08 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:11:08 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:08 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:08 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
INFO - 2017-07-24 12:11:28 --> Config Class Initialized
INFO - 2017-07-24 12:11:28 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:11:28 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:11:28 --> Utf8 Class Initialized
INFO - 2017-07-24 12:11:28 --> URI Class Initialized
DEBUG - 2017-07-24 12:11:28 --> No URI present. Default controller set.
INFO - 2017-07-24 12:11:28 --> Router Class Initialized
INFO - 2017-07-24 12:11:28 --> Output Class Initialized
INFO - 2017-07-24 12:11:28 --> Security Class Initialized
DEBUG - 2017-07-24 12:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:11:28 --> Input Class Initialized
INFO - 2017-07-24 12:11:28 --> Language Class Initialized
INFO - 2017-07-24 12:11:28 --> Loader Class Initialized
INFO - 2017-07-24 12:11:28 --> Helper loaded: url_helper
INFO - 2017-07-24 12:11:28 --> Helper loaded: form_helper
INFO - 2017-07-24 12:11:28 --> Helper loaded: security_helper
INFO - 2017-07-24 12:11:28 --> Helper loaded: path_helper
INFO - 2017-07-24 12:11:28 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:11:28 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:11:28 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:11:28 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:11:28 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:28 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:28 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
INFO - 2017-07-24 12:11:43 --> Config Class Initialized
INFO - 2017-07-24 12:11:43 --> Hooks Class Initialized
DEBUG - 2017-07-24 12:11:43 --> UTF-8 Support Enabled
INFO - 2017-07-24 12:11:43 --> Utf8 Class Initialized
INFO - 2017-07-24 12:11:43 --> URI Class Initialized
DEBUG - 2017-07-24 12:11:43 --> No URI present. Default controller set.
INFO - 2017-07-24 12:11:43 --> Router Class Initialized
INFO - 2017-07-24 12:11:43 --> Output Class Initialized
INFO - 2017-07-24 12:11:43 --> Security Class Initialized
DEBUG - 2017-07-24 12:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 12:11:43 --> Input Class Initialized
INFO - 2017-07-24 12:11:43 --> Language Class Initialized
INFO - 2017-07-24 12:11:43 --> Loader Class Initialized
INFO - 2017-07-24 12:11:43 --> Helper loaded: url_helper
INFO - 2017-07-24 12:11:43 --> Helper loaded: form_helper
INFO - 2017-07-24 12:11:43 --> Helper loaded: security_helper
INFO - 2017-07-24 12:11:43 --> Helper loaded: path_helper
INFO - 2017-07-24 12:11:43 --> Helper loaded: common_helper
ERROR - 2017-07-24 12:11:43 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 12:11:43 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 12:11:43 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 12:11:43 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:43 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 12:11:43 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
INFO - 2017-07-24 15:49:11 --> Config Class Initialized
INFO - 2017-07-24 15:49:11 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:49:11 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:49:11 --> Utf8 Class Initialized
INFO - 2017-07-24 15:49:11 --> URI Class Initialized
DEBUG - 2017-07-24 15:49:11 --> No URI present. Default controller set.
INFO - 2017-07-24 15:49:11 --> Router Class Initialized
INFO - 2017-07-24 15:49:11 --> Output Class Initialized
INFO - 2017-07-24 15:49:11 --> Security Class Initialized
DEBUG - 2017-07-24 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:49:11 --> Input Class Initialized
INFO - 2017-07-24 15:49:11 --> Language Class Initialized
INFO - 2017-07-24 15:49:11 --> Loader Class Initialized
INFO - 2017-07-24 15:49:11 --> Helper loaded: url_helper
INFO - 2017-07-24 15:49:11 --> Helper loaded: form_helper
INFO - 2017-07-24 15:49:11 --> Helper loaded: security_helper
INFO - 2017-07-24 15:49:11 --> Helper loaded: path_helper
INFO - 2017-07-24 15:49:11 --> Helper loaded: common_helper
ERROR - 2017-07-24 15:49:13 --> Severity: Warning --> mkdir(): Invalid path /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 117
ERROR - 2017-07-24 15:49:13 --> Severity: error --> Exception: Session: Configured save path '' is not a directory, doesn't exist or cannot be created. /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 119
ERROR - 2017-07-24 15:49:13 --> Severity: Warning --> file_exists(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 154
ERROR - 2017-07-24 15:49:13 --> Severity: Warning --> fopen(): open_basedir restriction in effect. File(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd) is not within the allowed path(s): (/var/www/vhosts/codunite.com/:/tmp/) /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 15:49:13 --> Severity: Warning --> fopen(2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd): failed to open stream: Operation not permitted /var/www/vhosts/codunite.com/oncolens.accretelabs.com/system/libraries/Session/drivers/Session_files_driver.php 156
ERROR - 2017-07-24 15:49:13 --> Session: File '2ce7b668c0bc4b3ff22cb5085ae4e448953b20bd' doesn't exist and cannot be created.
INFO - 2017-07-24 15:52:24 --> Config Class Initialized
INFO - 2017-07-24 15:52:24 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:52:24 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:52:24 --> Utf8 Class Initialized
INFO - 2017-07-24 15:52:24 --> URI Class Initialized
DEBUG - 2017-07-24 15:52:24 --> No URI present. Default controller set.
INFO - 2017-07-24 15:52:24 --> Router Class Initialized
INFO - 2017-07-24 15:52:24 --> Output Class Initialized
INFO - 2017-07-24 15:52:24 --> Security Class Initialized
DEBUG - 2017-07-24 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:52:24 --> Input Class Initialized
INFO - 2017-07-24 15:52:24 --> Language Class Initialized
INFO - 2017-07-24 15:52:24 --> Loader Class Initialized
INFO - 2017-07-24 15:52:24 --> Helper loaded: url_helper
INFO - 2017-07-24 15:52:24 --> Helper loaded: form_helper
INFO - 2017-07-24 15:52:24 --> Helper loaded: security_helper
INFO - 2017-07-24 15:52:24 --> Helper loaded: path_helper
INFO - 2017-07-24 15:52:24 --> Helper loaded: common_helper
INFO - 2017-07-24 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:52:24 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:52:25 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:52:25 --> Email Class Initialized
INFO - 2017-07-24 15:52:25 --> Form Validation Class Initialized
INFO - 2017-07-24 15:52:25 --> Model Class Initialized
INFO - 2017-07-24 15:52:25 --> Model Class Initialized
INFO - 2017-07-24 15:52:25 --> Model Class Initialized
INFO - 2017-07-24 15:52:25 --> Model Class Initialized
INFO - 2017-07-24 15:52:25 --> Controller Class Initialized
DEBUG - 2017-07-24 15:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:52:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 15:52:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 15:52:25 --> Final output sent to browser
DEBUG - 2017-07-24 15:52:25 --> Total execution time: 0.6844
DEBUG - 2017-07-24 15:52:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:52:26 --> Database Forge Class Initialized
INFO - 2017-07-24 15:52:26 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:52:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:07 --> Config Class Initialized
INFO - 2017-07-24 15:53:07 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:07 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:07 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:07 --> URI Class Initialized
DEBUG - 2017-07-24 15:53:07 --> No URI present. Default controller set.
INFO - 2017-07-24 15:53:07 --> Router Class Initialized
INFO - 2017-07-24 15:53:07 --> Output Class Initialized
INFO - 2017-07-24 15:53:07 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:07 --> Input Class Initialized
INFO - 2017-07-24 15:53:07 --> Language Class Initialized
INFO - 2017-07-24 15:53:07 --> Loader Class Initialized
INFO - 2017-07-24 15:53:07 --> Helper loaded: url_helper
INFO - 2017-07-24 15:53:07 --> Helper loaded: form_helper
INFO - 2017-07-24 15:53:07 --> Helper loaded: security_helper
INFO - 2017-07-24 15:53:07 --> Helper loaded: path_helper
INFO - 2017-07-24 15:53:07 --> Helper loaded: common_helper
INFO - 2017-07-24 15:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:53:07 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:53:07 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:07 --> Email Class Initialized
INFO - 2017-07-24 15:53:07 --> Form Validation Class Initialized
INFO - 2017-07-24 15:53:07 --> Model Class Initialized
INFO - 2017-07-24 15:53:07 --> Model Class Initialized
INFO - 2017-07-24 15:53:07 --> Model Class Initialized
INFO - 2017-07-24 15:53:07 --> Model Class Initialized
INFO - 2017-07-24 15:53:07 --> Controller Class Initialized
DEBUG - 2017-07-24 15:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 15:53:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 15:53:07 --> Final output sent to browser
DEBUG - 2017-07-24 15:53:07 --> Total execution time: 0.0280
DEBUG - 2017-07-24 15:53:07 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:53:07 --> Database Forge Class Initialized
INFO - 2017-07-24 15:53:07 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:53:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:36 --> Config Class Initialized
INFO - 2017-07-24 15:53:36 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:36 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:36 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:36 --> URI Class Initialized
INFO - 2017-07-24 15:53:36 --> Router Class Initialized
INFO - 2017-07-24 15:53:36 --> Output Class Initialized
INFO - 2017-07-24 15:53:36 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:36 --> Input Class Initialized
INFO - 2017-07-24 15:53:36 --> Language Class Initialized
INFO - 2017-07-24 15:53:36 --> Loader Class Initialized
INFO - 2017-07-24 15:53:36 --> Helper loaded: url_helper
INFO - 2017-07-24 15:53:36 --> Helper loaded: form_helper
INFO - 2017-07-24 15:53:36 --> Helper loaded: security_helper
INFO - 2017-07-24 15:53:36 --> Helper loaded: path_helper
INFO - 2017-07-24 15:53:36 --> Helper loaded: common_helper
INFO - 2017-07-24 15:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:53:36 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:53:36 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:36 --> Email Class Initialized
INFO - 2017-07-24 15:53:36 --> Form Validation Class Initialized
INFO - 2017-07-24 15:53:36 --> Model Class Initialized
INFO - 2017-07-24 15:53:36 --> Model Class Initialized
INFO - 2017-07-24 15:53:36 --> Model Class Initialized
INFO - 2017-07-24 15:53:36 --> Model Class Initialized
INFO - 2017-07-24 15:53:36 --> Controller Class Initialized
INFO - 2017-07-24 15:53:36 --> Model Class Initialized
INFO - 2017-07-24 15:53:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-24 15:53:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-24 15:53:36 --> Final output sent to browser
DEBUG - 2017-07-24 15:53:36 --> Total execution time: 0.3251
DEBUG - 2017-07-24 15:53:36 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:53:36 --> Database Forge Class Initialized
INFO - 2017-07-24 15:53:36 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:40 --> Config Class Initialized
INFO - 2017-07-24 15:53:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:40 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:40 --> URI Class Initialized
INFO - 2017-07-24 15:53:40 --> Router Class Initialized
INFO - 2017-07-24 15:53:40 --> Output Class Initialized
INFO - 2017-07-24 15:53:40 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:40 --> Input Class Initialized
INFO - 2017-07-24 15:53:40 --> Language Class Initialized
ERROR - 2017-07-24 15:53:40 --> 404 Page Not Found: Page/assets
INFO - 2017-07-24 15:53:40 --> Config Class Initialized
INFO - 2017-07-24 15:53:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:40 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:40 --> URI Class Initialized
INFO - 2017-07-24 15:53:40 --> Router Class Initialized
INFO - 2017-07-24 15:53:40 --> Output Class Initialized
INFO - 2017-07-24 15:53:40 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:40 --> Input Class Initialized
INFO - 2017-07-24 15:53:40 --> Language Class Initialized
ERROR - 2017-07-24 15:53:40 --> 404 Page Not Found: Page/assets
INFO - 2017-07-24 15:53:40 --> Config Class Initialized
INFO - 2017-07-24 15:53:40 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:40 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:40 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:40 --> URI Class Initialized
INFO - 2017-07-24 15:53:40 --> Router Class Initialized
INFO - 2017-07-24 15:53:40 --> Output Class Initialized
INFO - 2017-07-24 15:53:40 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:40 --> Input Class Initialized
INFO - 2017-07-24 15:53:40 --> Language Class Initialized
INFO - 2017-07-24 15:53:40 --> Loader Class Initialized
INFO - 2017-07-24 15:53:40 --> Helper loaded: url_helper
INFO - 2017-07-24 15:53:40 --> Helper loaded: form_helper
INFO - 2017-07-24 15:53:40 --> Helper loaded: security_helper
INFO - 2017-07-24 15:53:40 --> Helper loaded: path_helper
INFO - 2017-07-24 15:53:40 --> Helper loaded: common_helper
INFO - 2017-07-24 15:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:53:40 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:53:40 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:40 --> Email Class Initialized
INFO - 2017-07-24 15:53:40 --> Form Validation Class Initialized
INFO - 2017-07-24 15:53:40 --> Model Class Initialized
INFO - 2017-07-24 15:53:40 --> Model Class Initialized
INFO - 2017-07-24 15:53:40 --> Model Class Initialized
INFO - 2017-07-24 15:53:40 --> Model Class Initialized
INFO - 2017-07-24 15:53:40 --> Controller Class Initialized
INFO - 2017-07-24 15:53:40 --> Helper loaded: captcha_helper
INFO - 2017-07-24 15:53:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-07-24 15:53:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-24 15:53:40 --> Final output sent to browser
DEBUG - 2017-07-24 15:53:40 --> Total execution time: 0.0945
DEBUG - 2017-07-24 15:53:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:53:40 --> Database Forge Class Initialized
INFO - 2017-07-24 15:53:40 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:53:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:44 --> Config Class Initialized
INFO - 2017-07-24 15:53:44 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:53:44 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:53:44 --> Utf8 Class Initialized
INFO - 2017-07-24 15:53:44 --> URI Class Initialized
INFO - 2017-07-24 15:53:44 --> Router Class Initialized
INFO - 2017-07-24 15:53:44 --> Output Class Initialized
INFO - 2017-07-24 15:53:44 --> Security Class Initialized
DEBUG - 2017-07-24 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:53:44 --> Input Class Initialized
INFO - 2017-07-24 15:53:44 --> Language Class Initialized
INFO - 2017-07-24 15:53:44 --> Loader Class Initialized
INFO - 2017-07-24 15:53:44 --> Helper loaded: url_helper
INFO - 2017-07-24 15:53:44 --> Helper loaded: form_helper
INFO - 2017-07-24 15:53:44 --> Helper loaded: security_helper
INFO - 2017-07-24 15:53:44 --> Helper loaded: path_helper
INFO - 2017-07-24 15:53:44 --> Helper loaded: common_helper
INFO - 2017-07-24 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:53:44 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:53:44 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:53:44 --> Email Class Initialized
INFO - 2017-07-24 15:53:44 --> Form Validation Class Initialized
INFO - 2017-07-24 15:53:44 --> Model Class Initialized
INFO - 2017-07-24 15:53:44 --> Model Class Initialized
INFO - 2017-07-24 15:53:44 --> Model Class Initialized
INFO - 2017-07-24 15:53:44 --> Model Class Initialized
INFO - 2017-07-24 15:53:44 --> Controller Class Initialized
INFO - 2017-07-24 15:53:44 --> Model Class Initialized
INFO - 2017-07-24 15:53:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-24 15:53:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-24 15:53:44 --> Final output sent to browser
DEBUG - 2017-07-24 15:53:44 --> Total execution time: 0.0274
DEBUG - 2017-07-24 15:53:44 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:53:44 --> Database Forge Class Initialized
INFO - 2017-07-24 15:53:44 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:53:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:54:17 --> Config Class Initialized
INFO - 2017-07-24 15:54:17 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:54:17 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:54:17 --> Utf8 Class Initialized
INFO - 2017-07-24 15:54:17 --> URI Class Initialized
DEBUG - 2017-07-24 15:54:17 --> No URI present. Default controller set.
INFO - 2017-07-24 15:54:17 --> Router Class Initialized
INFO - 2017-07-24 15:54:17 --> Output Class Initialized
INFO - 2017-07-24 15:54:17 --> Security Class Initialized
DEBUG - 2017-07-24 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:54:17 --> Input Class Initialized
INFO - 2017-07-24 15:54:17 --> Language Class Initialized
INFO - 2017-07-24 15:54:17 --> Loader Class Initialized
INFO - 2017-07-24 15:54:17 --> Helper loaded: url_helper
INFO - 2017-07-24 15:54:17 --> Helper loaded: form_helper
INFO - 2017-07-24 15:54:17 --> Helper loaded: security_helper
INFO - 2017-07-24 15:54:17 --> Helper loaded: path_helper
INFO - 2017-07-24 15:54:17 --> Helper loaded: common_helper
INFO - 2017-07-24 15:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:54:17 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:54:17 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:54:17 --> Email Class Initialized
INFO - 2017-07-24 15:54:17 --> Form Validation Class Initialized
INFO - 2017-07-24 15:54:17 --> Model Class Initialized
INFO - 2017-07-24 15:54:17 --> Model Class Initialized
INFO - 2017-07-24 15:54:17 --> Model Class Initialized
INFO - 2017-07-24 15:54:17 --> Model Class Initialized
INFO - 2017-07-24 15:54:17 --> Controller Class Initialized
DEBUG - 2017-07-24 15:54:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:54:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 15:54:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 15:54:17 --> Final output sent to browser
DEBUG - 2017-07-24 15:54:17 --> Total execution time: 0.0315
DEBUG - 2017-07-24 15:54:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:54:17 --> Database Forge Class Initialized
INFO - 2017-07-24 15:54:17 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:58:48 --> Config Class Initialized
INFO - 2017-07-24 15:58:48 --> Hooks Class Initialized
DEBUG - 2017-07-24 15:58:48 --> UTF-8 Support Enabled
INFO - 2017-07-24 15:58:48 --> Utf8 Class Initialized
INFO - 2017-07-24 15:58:48 --> URI Class Initialized
DEBUG - 2017-07-24 15:58:48 --> No URI present. Default controller set.
INFO - 2017-07-24 15:58:48 --> Router Class Initialized
INFO - 2017-07-24 15:58:48 --> Output Class Initialized
INFO - 2017-07-24 15:58:48 --> Security Class Initialized
DEBUG - 2017-07-24 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 15:58:48 --> Input Class Initialized
INFO - 2017-07-24 15:58:48 --> Language Class Initialized
INFO - 2017-07-24 15:58:48 --> Loader Class Initialized
INFO - 2017-07-24 15:58:48 --> Helper loaded: url_helper
INFO - 2017-07-24 15:58:48 --> Helper loaded: form_helper
INFO - 2017-07-24 15:58:48 --> Helper loaded: security_helper
INFO - 2017-07-24 15:58:48 --> Helper loaded: path_helper
INFO - 2017-07-24 15:58:48 --> Helper loaded: common_helper
INFO - 2017-07-24 15:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 15:58:48 --> Helper loaded: check_session_helper
INFO - 2017-07-24 15:58:48 --> Database Driver Class Initialized
DEBUG - 2017-07-24 15:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:58:48 --> Email Class Initialized
INFO - 2017-07-24 15:58:48 --> Form Validation Class Initialized
INFO - 2017-07-24 15:58:48 --> Model Class Initialized
INFO - 2017-07-24 15:58:48 --> Model Class Initialized
INFO - 2017-07-24 15:58:48 --> Model Class Initialized
INFO - 2017-07-24 15:58:48 --> Model Class Initialized
INFO - 2017-07-24 15:58:48 --> Controller Class Initialized
DEBUG - 2017-07-24 15:58:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 15:58:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 15:58:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 15:58:48 --> Final output sent to browser
DEBUG - 2017-07-24 15:58:48 --> Total execution time: 0.0298
DEBUG - 2017-07-24 15:58:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 15:58:48 --> Database Forge Class Initialized
INFO - 2017-07-24 15:58:48 --> User Agent Class Initialized
DEBUG - 2017-07-24 15:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:08:18 --> Config Class Initialized
INFO - 2017-07-24 16:08:18 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:08:18 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:08:18 --> Utf8 Class Initialized
INFO - 2017-07-24 16:08:18 --> URI Class Initialized
DEBUG - 2017-07-24 16:08:18 --> No URI present. Default controller set.
INFO - 2017-07-24 16:08:18 --> Router Class Initialized
INFO - 2017-07-24 16:08:18 --> Output Class Initialized
INFO - 2017-07-24 16:08:18 --> Security Class Initialized
DEBUG - 2017-07-24 16:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:08:18 --> Input Class Initialized
INFO - 2017-07-24 16:08:18 --> Language Class Initialized
INFO - 2017-07-24 16:08:18 --> Loader Class Initialized
INFO - 2017-07-24 16:08:18 --> Helper loaded: url_helper
INFO - 2017-07-24 16:08:18 --> Helper loaded: form_helper
INFO - 2017-07-24 16:08:18 --> Helper loaded: security_helper
INFO - 2017-07-24 16:08:18 --> Helper loaded: path_helper
INFO - 2017-07-24 16:08:18 --> Helper loaded: common_helper
INFO - 2017-07-24 16:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 16:08:18 --> Helper loaded: check_session_helper
INFO - 2017-07-24 16:08:18 --> Database Driver Class Initialized
DEBUG - 2017-07-24 16:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:08:18 --> Email Class Initialized
INFO - 2017-07-24 16:08:18 --> Form Validation Class Initialized
INFO - 2017-07-24 16:08:18 --> Model Class Initialized
INFO - 2017-07-24 16:08:18 --> Model Class Initialized
INFO - 2017-07-24 16:08:18 --> Model Class Initialized
INFO - 2017-07-24 16:08:18 --> Model Class Initialized
INFO - 2017-07-24 16:08:18 --> Controller Class Initialized
DEBUG - 2017-07-24 16:08:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:08:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 16:08:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 16:08:18 --> Final output sent to browser
DEBUG - 2017-07-24 16:08:18 --> Total execution time: 0.0282
DEBUG - 2017-07-24 16:08:18 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 16:08:18 --> Database Forge Class Initialized
INFO - 2017-07-24 16:08:18 --> User Agent Class Initialized
DEBUG - 2017-07-24 16:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:19:09 --> Config Class Initialized
INFO - 2017-07-24 16:19:09 --> Hooks Class Initialized
DEBUG - 2017-07-24 16:19:09 --> UTF-8 Support Enabled
INFO - 2017-07-24 16:19:09 --> Utf8 Class Initialized
INFO - 2017-07-24 16:19:09 --> URI Class Initialized
DEBUG - 2017-07-24 16:19:09 --> No URI present. Default controller set.
INFO - 2017-07-24 16:19:09 --> Router Class Initialized
INFO - 2017-07-24 16:19:09 --> Output Class Initialized
INFO - 2017-07-24 16:19:09 --> Security Class Initialized
DEBUG - 2017-07-24 16:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 16:19:09 --> Input Class Initialized
INFO - 2017-07-24 16:19:09 --> Language Class Initialized
INFO - 2017-07-24 16:19:09 --> Loader Class Initialized
INFO - 2017-07-24 16:19:09 --> Helper loaded: url_helper
INFO - 2017-07-24 16:19:10 --> Helper loaded: form_helper
INFO - 2017-07-24 16:19:10 --> Helper loaded: security_helper
INFO - 2017-07-24 16:19:10 --> Helper loaded: path_helper
INFO - 2017-07-24 16:19:10 --> Helper loaded: common_helper
INFO - 2017-07-24 16:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 16:19:10 --> Helper loaded: check_session_helper
INFO - 2017-07-24 16:19:10 --> Database Driver Class Initialized
DEBUG - 2017-07-24 16:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:19:10 --> Email Class Initialized
INFO - 2017-07-24 16:19:10 --> Form Validation Class Initialized
INFO - 2017-07-24 16:19:10 --> Model Class Initialized
INFO - 2017-07-24 16:19:10 --> Model Class Initialized
INFO - 2017-07-24 16:19:10 --> Model Class Initialized
INFO - 2017-07-24 16:19:10 --> Model Class Initialized
INFO - 2017-07-24 16:19:10 --> Controller Class Initialized
DEBUG - 2017-07-24 16:19:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 16:19:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 16:19:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 16:19:10 --> Final output sent to browser
DEBUG - 2017-07-24 16:19:10 --> Total execution time: 0.0313
DEBUG - 2017-07-24 16:19:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 16:19:10 --> Database Forge Class Initialized
INFO - 2017-07-24 16:19:10 --> User Agent Class Initialized
DEBUG - 2017-07-24 16:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 17:14:23 --> Config Class Initialized
INFO - 2017-07-24 17:14:23 --> Hooks Class Initialized
DEBUG - 2017-07-24 17:14:23 --> UTF-8 Support Enabled
INFO - 2017-07-24 17:14:23 --> Utf8 Class Initialized
INFO - 2017-07-24 17:14:23 --> URI Class Initialized
DEBUG - 2017-07-24 17:14:23 --> No URI present. Default controller set.
INFO - 2017-07-24 17:14:23 --> Router Class Initialized
INFO - 2017-07-24 17:14:23 --> Output Class Initialized
INFO - 2017-07-24 17:14:23 --> Security Class Initialized
DEBUG - 2017-07-24 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-24 17:14:23 --> Input Class Initialized
INFO - 2017-07-24 17:14:23 --> Language Class Initialized
INFO - 2017-07-24 17:14:23 --> Loader Class Initialized
INFO - 2017-07-24 17:14:23 --> Helper loaded: url_helper
INFO - 2017-07-24 17:14:23 --> Helper loaded: form_helper
INFO - 2017-07-24 17:14:23 --> Helper loaded: security_helper
INFO - 2017-07-24 17:14:23 --> Helper loaded: path_helper
INFO - 2017-07-24 17:14:23 --> Helper loaded: common_helper
INFO - 2017-07-24 17:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-24 17:14:23 --> Helper loaded: check_session_helper
INFO - 2017-07-24 17:14:23 --> Database Driver Class Initialized
DEBUG - 2017-07-24 17:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-24 17:14:23 --> Email Class Initialized
INFO - 2017-07-24 17:14:23 --> Form Validation Class Initialized
INFO - 2017-07-24 17:14:23 --> Model Class Initialized
INFO - 2017-07-24 17:14:23 --> Model Class Initialized
INFO - 2017-07-24 17:14:23 --> Model Class Initialized
INFO - 2017-07-24 17:14:23 --> Model Class Initialized
INFO - 2017-07-24 17:14:23 --> Controller Class Initialized
DEBUG - 2017-07-24 17:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-24 17:14:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-24 17:14:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-24 17:14:23 --> Final output sent to browser
DEBUG - 2017-07-24 17:14:23 --> Total execution time: 0.0310
DEBUG - 2017-07-24 17:14:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-24 17:14:23 --> Database Forge Class Initialized
INFO - 2017-07-24 17:14:23 --> User Agent Class Initialized
DEBUG - 2017-07-24 17:14:23 --> Session class already loaded. Second attempt ignored.
