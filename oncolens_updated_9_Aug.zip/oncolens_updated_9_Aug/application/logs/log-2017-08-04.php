<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-04 04:57:47 --> Config Class Initialized
INFO - 2017-08-04 04:57:47 --> Hooks Class Initialized
DEBUG - 2017-08-04 04:57:47 --> UTF-8 Support Enabled
INFO - 2017-08-04 04:57:47 --> Utf8 Class Initialized
INFO - 2017-08-04 04:57:47 --> URI Class Initialized
DEBUG - 2017-08-04 04:57:47 --> No URI present. Default controller set.
INFO - 2017-08-04 04:57:47 --> Router Class Initialized
INFO - 2017-08-04 04:57:47 --> Output Class Initialized
INFO - 2017-08-04 04:57:47 --> Security Class Initialized
DEBUG - 2017-08-04 04:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 04:57:47 --> Input Class Initialized
INFO - 2017-08-04 04:57:47 --> Language Class Initialized
INFO - 2017-08-04 04:57:47 --> Loader Class Initialized
INFO - 2017-08-04 04:57:47 --> Helper loaded: url_helper
INFO - 2017-08-04 04:57:47 --> Helper loaded: form_helper
INFO - 2017-08-04 04:57:47 --> Helper loaded: security_helper
INFO - 2017-08-04 04:57:47 --> Helper loaded: path_helper
INFO - 2017-08-04 04:57:47 --> Helper loaded: common_helper
INFO - 2017-08-04 04:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 04:57:48 --> Helper loaded: check_session_helper
INFO - 2017-08-04 04:57:48 --> Database Driver Class Initialized
DEBUG - 2017-08-04 04:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 04:57:48 --> Email Class Initialized
INFO - 2017-08-04 04:57:48 --> Form Validation Class Initialized
INFO - 2017-08-04 04:57:48 --> Model Class Initialized
INFO - 2017-08-04 04:57:48 --> Model Class Initialized
INFO - 2017-08-04 04:57:48 --> Model Class Initialized
INFO - 2017-08-04 04:57:48 --> Model Class Initialized
INFO - 2017-08-04 04:57:48 --> Controller Class Initialized
DEBUG - 2017-08-04 04:57:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 04:57:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 04:57:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 04:57:48 --> Final output sent to browser
DEBUG - 2017-08-04 04:57:48 --> Total execution time: 1.3048
DEBUG - 2017-08-04 04:57:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 04:57:48 --> Database Forge Class Initialized
INFO - 2017-08-04 04:57:48 --> User Agent Class Initialized
DEBUG - 2017-08-04 04:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 05:02:10 --> Config Class Initialized
INFO - 2017-08-04 05:02:10 --> Hooks Class Initialized
DEBUG - 2017-08-04 05:02:10 --> UTF-8 Support Enabled
INFO - 2017-08-04 05:02:10 --> Utf8 Class Initialized
INFO - 2017-08-04 05:02:10 --> URI Class Initialized
INFO - 2017-08-04 05:02:10 --> Router Class Initialized
INFO - 2017-08-04 05:02:10 --> Output Class Initialized
INFO - 2017-08-04 05:02:10 --> Security Class Initialized
DEBUG - 2017-08-04 05:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 05:02:10 --> Input Class Initialized
INFO - 2017-08-04 05:02:10 --> Language Class Initialized
INFO - 2017-08-04 05:02:11 --> Loader Class Initialized
INFO - 2017-08-04 05:02:11 --> Helper loaded: url_helper
INFO - 2017-08-04 05:02:11 --> Helper loaded: form_helper
INFO - 2017-08-04 05:02:11 --> Helper loaded: security_helper
INFO - 2017-08-04 05:02:11 --> Helper loaded: path_helper
INFO - 2017-08-04 05:02:11 --> Helper loaded: common_helper
INFO - 2017-08-04 05:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 05:02:11 --> Helper loaded: check_session_helper
INFO - 2017-08-04 05:02:11 --> Database Driver Class Initialized
DEBUG - 2017-08-04 05:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 05:02:11 --> Email Class Initialized
INFO - 2017-08-04 05:02:11 --> Form Validation Class Initialized
INFO - 2017-08-04 05:02:11 --> Model Class Initialized
INFO - 2017-08-04 05:02:11 --> Model Class Initialized
INFO - 2017-08-04 05:02:11 --> Model Class Initialized
INFO - 2017-08-04 05:02:11 --> Model Class Initialized
INFO - 2017-08-04 05:02:11 --> Controller Class Initialized
INFO - 2017-08-04 05:02:11 --> Model Class Initialized
INFO - 2017-08-04 05:02:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 05:02:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 05:02:11 --> Final output sent to browser
DEBUG - 2017-08-04 05:02:11 --> Total execution time: 0.6871
DEBUG - 2017-08-04 05:02:11 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 05:02:11 --> Database Forge Class Initialized
INFO - 2017-08-04 05:02:11 --> User Agent Class Initialized
DEBUG - 2017-08-04 05:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 05:02:13 --> Config Class Initialized
INFO - 2017-08-04 05:02:13 --> Hooks Class Initialized
DEBUG - 2017-08-04 05:02:13 --> UTF-8 Support Enabled
INFO - 2017-08-04 05:02:13 --> Utf8 Class Initialized
INFO - 2017-08-04 05:02:13 --> URI Class Initialized
INFO - 2017-08-04 05:02:13 --> Router Class Initialized
INFO - 2017-08-04 05:02:13 --> Output Class Initialized
INFO - 2017-08-04 05:02:13 --> Security Class Initialized
DEBUG - 2017-08-04 05:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 05:02:13 --> Input Class Initialized
INFO - 2017-08-04 05:02:13 --> Language Class Initialized
ERROR - 2017-08-04 05:02:13 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 05:12:59 --> Config Class Initialized
INFO - 2017-08-04 05:12:59 --> Hooks Class Initialized
DEBUG - 2017-08-04 05:12:59 --> UTF-8 Support Enabled
INFO - 2017-08-04 05:12:59 --> Utf8 Class Initialized
INFO - 2017-08-04 05:12:59 --> URI Class Initialized
INFO - 2017-08-04 05:12:59 --> Router Class Initialized
INFO - 2017-08-04 05:12:59 --> Output Class Initialized
INFO - 2017-08-04 05:12:59 --> Security Class Initialized
DEBUG - 2017-08-04 05:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 05:12:59 --> Input Class Initialized
INFO - 2017-08-04 05:12:59 --> Language Class Initialized
INFO - 2017-08-04 05:12:59 --> Loader Class Initialized
INFO - 2017-08-04 05:12:59 --> Helper loaded: url_helper
INFO - 2017-08-04 05:12:59 --> Helper loaded: form_helper
INFO - 2017-08-04 05:12:59 --> Helper loaded: security_helper
INFO - 2017-08-04 05:12:59 --> Helper loaded: path_helper
INFO - 2017-08-04 05:12:59 --> Helper loaded: common_helper
INFO - 2017-08-04 05:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 05:12:59 --> Helper loaded: check_session_helper
INFO - 2017-08-04 05:12:59 --> Database Driver Class Initialized
DEBUG - 2017-08-04 05:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 05:12:59 --> Email Class Initialized
INFO - 2017-08-04 05:12:59 --> Form Validation Class Initialized
INFO - 2017-08-04 05:12:59 --> Model Class Initialized
INFO - 2017-08-04 05:12:59 --> Model Class Initialized
INFO - 2017-08-04 05:12:59 --> Model Class Initialized
INFO - 2017-08-04 05:12:59 --> Model Class Initialized
INFO - 2017-08-04 05:12:59 --> Controller Class Initialized
INFO - 2017-08-04 05:12:59 --> Model Class Initialized
INFO - 2017-08-04 05:12:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 05:12:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 05:12:59 --> Final output sent to browser
DEBUG - 2017-08-04 05:12:59 --> Total execution time: 0.0276
DEBUG - 2017-08-04 05:12:59 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 05:12:59 --> Database Forge Class Initialized
INFO - 2017-08-04 05:12:59 --> User Agent Class Initialized
DEBUG - 2017-08-04 05:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 05:13:01 --> Config Class Initialized
INFO - 2017-08-04 05:13:01 --> Hooks Class Initialized
DEBUG - 2017-08-04 05:13:01 --> UTF-8 Support Enabled
INFO - 2017-08-04 05:13:01 --> Utf8 Class Initialized
INFO - 2017-08-04 05:13:01 --> URI Class Initialized
INFO - 2017-08-04 05:13:01 --> Router Class Initialized
INFO - 2017-08-04 05:13:01 --> Output Class Initialized
INFO - 2017-08-04 05:13:01 --> Security Class Initialized
DEBUG - 2017-08-04 05:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 05:13:01 --> Input Class Initialized
INFO - 2017-08-04 05:13:01 --> Language Class Initialized
ERROR - 2017-08-04 05:13:01 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 06:00:26 --> Config Class Initialized
INFO - 2017-08-04 06:00:26 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:00:26 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:00:26 --> Utf8 Class Initialized
INFO - 2017-08-04 06:00:26 --> URI Class Initialized
INFO - 2017-08-04 06:00:26 --> Router Class Initialized
INFO - 2017-08-04 06:00:26 --> Output Class Initialized
INFO - 2017-08-04 06:00:26 --> Security Class Initialized
DEBUG - 2017-08-04 06:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:00:26 --> Input Class Initialized
INFO - 2017-08-04 06:00:26 --> Language Class Initialized
INFO - 2017-08-04 06:00:26 --> Loader Class Initialized
INFO - 2017-08-04 06:00:26 --> Helper loaded: url_helper
INFO - 2017-08-04 06:00:26 --> Helper loaded: form_helper
INFO - 2017-08-04 06:00:26 --> Helper loaded: security_helper
INFO - 2017-08-04 06:00:26 --> Helper loaded: path_helper
INFO - 2017-08-04 06:00:26 --> Helper loaded: common_helper
INFO - 2017-08-04 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:00:26 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:00:26 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:26 --> Email Class Initialized
INFO - 2017-08-04 06:00:26 --> Form Validation Class Initialized
INFO - 2017-08-04 06:00:26 --> Model Class Initialized
INFO - 2017-08-04 06:00:26 --> Model Class Initialized
INFO - 2017-08-04 06:00:26 --> Model Class Initialized
INFO - 2017-08-04 06:00:26 --> Model Class Initialized
INFO - 2017-08-04 06:00:26 --> Controller Class Initialized
INFO - 2017-08-04 06:00:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 06:00:26 --> Final output sent to browser
DEBUG - 2017-08-04 06:00:26 --> Total execution time: 0.0409
DEBUG - 2017-08-04 06:00:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:00:26 --> Database Forge Class Initialized
INFO - 2017-08-04 06:00:26 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:00:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:28 --> Config Class Initialized
INFO - 2017-08-04 06:00:28 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:00:28 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:00:28 --> Utf8 Class Initialized
INFO - 2017-08-04 06:00:28 --> URI Class Initialized
INFO - 2017-08-04 06:00:28 --> Router Class Initialized
INFO - 2017-08-04 06:00:28 --> Output Class Initialized
INFO - 2017-08-04 06:00:28 --> Security Class Initialized
DEBUG - 2017-08-04 06:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:00:28 --> Input Class Initialized
INFO - 2017-08-04 06:00:28 --> Language Class Initialized
ERROR - 2017-08-04 06:00:28 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 06:00:29 --> Config Class Initialized
INFO - 2017-08-04 06:00:29 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:00:29 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:00:29 --> Utf8 Class Initialized
INFO - 2017-08-04 06:00:29 --> URI Class Initialized
INFO - 2017-08-04 06:00:29 --> Router Class Initialized
INFO - 2017-08-04 06:00:29 --> Output Class Initialized
INFO - 2017-08-04 06:00:29 --> Security Class Initialized
DEBUG - 2017-08-04 06:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:00:29 --> Input Class Initialized
INFO - 2017-08-04 06:00:29 --> Language Class Initialized
INFO - 2017-08-04 06:00:29 --> Loader Class Initialized
INFO - 2017-08-04 06:00:29 --> Helper loaded: url_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: form_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: security_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: path_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: common_helper
INFO - 2017-08-04 06:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:00:29 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:00:29 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:29 --> Email Class Initialized
INFO - 2017-08-04 06:00:29 --> Form Validation Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Controller Class Initialized
INFO - 2017-08-04 06:00:29 --> Config Class Initialized
INFO - 2017-08-04 06:00:29 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:00:29 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:00:29 --> Utf8 Class Initialized
INFO - 2017-08-04 06:00:29 --> URI Class Initialized
INFO - 2017-08-04 06:00:29 --> Router Class Initialized
INFO - 2017-08-04 06:00:29 --> Output Class Initialized
INFO - 2017-08-04 06:00:29 --> Security Class Initialized
DEBUG - 2017-08-04 06:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:00:29 --> Input Class Initialized
INFO - 2017-08-04 06:00:29 --> Language Class Initialized
INFO - 2017-08-04 06:00:29 --> Loader Class Initialized
INFO - 2017-08-04 06:00:29 --> Helper loaded: url_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: form_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: security_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: path_helper
INFO - 2017-08-04 06:00:29 --> Helper loaded: common_helper
INFO - 2017-08-04 06:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:00:29 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:00:29 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:00:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:29 --> Email Class Initialized
INFO - 2017-08-04 06:00:29 --> Form Validation Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Model Class Initialized
INFO - 2017-08-04 06:00:29 --> Controller Class Initialized
INFO - 2017-08-04 06:00:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 06:00:31 --> Pagination Class Initialized
INFO - 2017-08-04 06:00:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:00:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 06:00:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:00:31 --> Final output sent to browser
DEBUG - 2017-08-04 06:00:31 --> Total execution time: 2.1171
DEBUG - 2017-08-04 06:00:31 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:00:31 --> Database Forge Class Initialized
INFO - 2017-08-04 06:00:31 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:42 --> Config Class Initialized
INFO - 2017-08-04 06:00:42 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:00:42 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:00:42 --> Utf8 Class Initialized
INFO - 2017-08-04 06:00:42 --> URI Class Initialized
INFO - 2017-08-04 06:00:42 --> Router Class Initialized
INFO - 2017-08-04 06:00:42 --> Output Class Initialized
INFO - 2017-08-04 06:00:42 --> Security Class Initialized
DEBUG - 2017-08-04 06:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:00:42 --> Input Class Initialized
INFO - 2017-08-04 06:00:42 --> Language Class Initialized
INFO - 2017-08-04 06:00:42 --> Loader Class Initialized
INFO - 2017-08-04 06:00:42 --> Helper loaded: url_helper
INFO - 2017-08-04 06:00:42 --> Helper loaded: form_helper
INFO - 2017-08-04 06:00:42 --> Helper loaded: security_helper
INFO - 2017-08-04 06:00:42 --> Helper loaded: path_helper
INFO - 2017-08-04 06:00:42 --> Helper loaded: common_helper
INFO - 2017-08-04 06:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:00:42 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:00:42 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:00:42 --> Email Class Initialized
INFO - 2017-08-04 06:00:42 --> Form Validation Class Initialized
INFO - 2017-08-04 06:00:42 --> Model Class Initialized
INFO - 2017-08-04 06:00:42 --> Model Class Initialized
INFO - 2017-08-04 06:00:42 --> Model Class Initialized
INFO - 2017-08-04 06:00:42 --> Model Class Initialized
INFO - 2017-08-04 06:00:42 --> Controller Class Initialized
INFO - 2017-08-04 06:00:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:00:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 06:00:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:00:42 --> Final output sent to browser
DEBUG - 2017-08-04 06:00:42 --> Total execution time: 0.0310
DEBUG - 2017-08-04 06:00:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:00:42 --> Database Forge Class Initialized
INFO - 2017-08-04 06:00:42 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:22 --> Config Class Initialized
INFO - 2017-08-04 06:05:22 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:05:22 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:05:22 --> Utf8 Class Initialized
INFO - 2017-08-04 06:05:22 --> URI Class Initialized
INFO - 2017-08-04 06:05:22 --> Router Class Initialized
INFO - 2017-08-04 06:05:22 --> Output Class Initialized
INFO - 2017-08-04 06:05:22 --> Security Class Initialized
DEBUG - 2017-08-04 06:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:05:22 --> Input Class Initialized
INFO - 2017-08-04 06:05:22 --> Language Class Initialized
INFO - 2017-08-04 06:05:22 --> Loader Class Initialized
INFO - 2017-08-04 06:05:22 --> Helper loaded: url_helper
INFO - 2017-08-04 06:05:22 --> Helper loaded: form_helper
INFO - 2017-08-04 06:05:22 --> Helper loaded: security_helper
INFO - 2017-08-04 06:05:22 --> Helper loaded: path_helper
INFO - 2017-08-04 06:05:22 --> Helper loaded: common_helper
INFO - 2017-08-04 06:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:05:22 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:05:22 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:22 --> Email Class Initialized
INFO - 2017-08-04 06:05:22 --> Form Validation Class Initialized
INFO - 2017-08-04 06:05:22 --> Model Class Initialized
INFO - 2017-08-04 06:05:22 --> Model Class Initialized
INFO - 2017-08-04 06:05:22 --> Model Class Initialized
INFO - 2017-08-04 06:05:22 --> Model Class Initialized
INFO - 2017-08-04 06:05:22 --> Controller Class Initialized
DEBUG - 2017-08-04 06:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:05:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:05:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:05:22 --> Final output sent to browser
DEBUG - 2017-08-04 06:05:22 --> Total execution time: 0.7344
DEBUG - 2017-08-04 06:05:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:05:22 --> Database Forge Class Initialized
INFO - 2017-08-04 06:05:22 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:38 --> Config Class Initialized
INFO - 2017-08-04 06:05:38 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:05:38 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:05:38 --> Utf8 Class Initialized
INFO - 2017-08-04 06:05:38 --> URI Class Initialized
INFO - 2017-08-04 06:05:38 --> Router Class Initialized
INFO - 2017-08-04 06:05:38 --> Output Class Initialized
INFO - 2017-08-04 06:05:38 --> Security Class Initialized
DEBUG - 2017-08-04 06:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:05:38 --> Input Class Initialized
INFO - 2017-08-04 06:05:38 --> Language Class Initialized
INFO - 2017-08-04 06:05:38 --> Loader Class Initialized
INFO - 2017-08-04 06:05:38 --> Helper loaded: url_helper
INFO - 2017-08-04 06:05:38 --> Helper loaded: form_helper
INFO - 2017-08-04 06:05:38 --> Helper loaded: security_helper
INFO - 2017-08-04 06:05:38 --> Helper loaded: path_helper
INFO - 2017-08-04 06:05:38 --> Helper loaded: common_helper
INFO - 2017-08-04 06:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:05:38 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:05:38 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:38 --> Email Class Initialized
INFO - 2017-08-04 06:05:38 --> Form Validation Class Initialized
INFO - 2017-08-04 06:05:38 --> Model Class Initialized
INFO - 2017-08-04 06:05:38 --> Model Class Initialized
INFO - 2017-08-04 06:05:38 --> Model Class Initialized
INFO - 2017-08-04 06:05:38 --> Model Class Initialized
INFO - 2017-08-04 06:05:38 --> Controller Class Initialized
DEBUG - 2017-08-04 06:05:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:05:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:05:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:05:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:05:38 --> Final output sent to browser
DEBUG - 2017-08-04 06:05:38 --> Total execution time: 0.0281
DEBUG - 2017-08-04 06:05:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:05:38 --> Database Forge Class Initialized
INFO - 2017-08-04 06:05:38 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:47 --> Config Class Initialized
INFO - 2017-08-04 06:07:47 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:07:47 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:07:47 --> Utf8 Class Initialized
INFO - 2017-08-04 06:07:47 --> URI Class Initialized
INFO - 2017-08-04 06:07:47 --> Router Class Initialized
INFO - 2017-08-04 06:07:47 --> Output Class Initialized
INFO - 2017-08-04 06:07:47 --> Security Class Initialized
DEBUG - 2017-08-04 06:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:07:47 --> Input Class Initialized
INFO - 2017-08-04 06:07:47 --> Language Class Initialized
INFO - 2017-08-04 06:07:47 --> Loader Class Initialized
INFO - 2017-08-04 06:07:47 --> Helper loaded: url_helper
INFO - 2017-08-04 06:07:47 --> Helper loaded: form_helper
INFO - 2017-08-04 06:07:47 --> Helper loaded: security_helper
INFO - 2017-08-04 06:07:47 --> Helper loaded: path_helper
INFO - 2017-08-04 06:07:47 --> Helper loaded: common_helper
INFO - 2017-08-04 06:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:07:47 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:07:47 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:47 --> Email Class Initialized
INFO - 2017-08-04 06:07:47 --> Form Validation Class Initialized
INFO - 2017-08-04 06:07:47 --> Model Class Initialized
INFO - 2017-08-04 06:07:47 --> Model Class Initialized
INFO - 2017-08-04 06:07:47 --> Model Class Initialized
INFO - 2017-08-04 06:07:47 --> Model Class Initialized
INFO - 2017-08-04 06:07:47 --> Controller Class Initialized
INFO - 2017-08-04 06:07:47 --> Model Class Initialized
INFO - 2017-08-04 06:07:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:07:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:07:47 --> Final output sent to browser
DEBUG - 2017-08-04 06:07:47 --> Total execution time: 0.0289
DEBUG - 2017-08-04 06:07:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:07:47 --> Database Forge Class Initialized
INFO - 2017-08-04 06:07:47 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:54 --> Config Class Initialized
INFO - 2017-08-04 06:07:54 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:07:54 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:07:54 --> Utf8 Class Initialized
INFO - 2017-08-04 06:07:54 --> URI Class Initialized
INFO - 2017-08-04 06:07:54 --> Router Class Initialized
INFO - 2017-08-04 06:07:54 --> Output Class Initialized
INFO - 2017-08-04 06:07:54 --> Security Class Initialized
DEBUG - 2017-08-04 06:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:07:54 --> Input Class Initialized
INFO - 2017-08-04 06:07:54 --> Language Class Initialized
INFO - 2017-08-04 06:07:54 --> Loader Class Initialized
INFO - 2017-08-04 06:07:54 --> Helper loaded: url_helper
INFO - 2017-08-04 06:07:54 --> Helper loaded: form_helper
INFO - 2017-08-04 06:07:54 --> Helper loaded: security_helper
INFO - 2017-08-04 06:07:54 --> Helper loaded: path_helper
INFO - 2017-08-04 06:07:54 --> Helper loaded: common_helper
INFO - 2017-08-04 06:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:07:54 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:07:54 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:54 --> Email Class Initialized
INFO - 2017-08-04 06:07:54 --> Form Validation Class Initialized
INFO - 2017-08-04 06:07:54 --> Model Class Initialized
INFO - 2017-08-04 06:07:54 --> Model Class Initialized
INFO - 2017-08-04 06:07:54 --> Model Class Initialized
INFO - 2017-08-04 06:07:54 --> Model Class Initialized
INFO - 2017-08-04 06:07:54 --> Controller Class Initialized
INFO - 2017-08-04 06:07:54 --> Model Class Initialized
INFO - 2017-08-04 06:07:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:07:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:07:54 --> Final output sent to browser
DEBUG - 2017-08-04 06:07:54 --> Total execution time: 0.0260
DEBUG - 2017-08-04 06:07:54 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:07:54 --> Database Forge Class Initialized
INFO - 2017-08-04 06:07:54 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:07:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:57 --> Config Class Initialized
INFO - 2017-08-04 06:07:57 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:07:57 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:07:57 --> Utf8 Class Initialized
INFO - 2017-08-04 06:07:57 --> URI Class Initialized
INFO - 2017-08-04 06:07:57 --> Router Class Initialized
INFO - 2017-08-04 06:07:57 --> Output Class Initialized
INFO - 2017-08-04 06:07:57 --> Security Class Initialized
DEBUG - 2017-08-04 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:07:57 --> Input Class Initialized
INFO - 2017-08-04 06:07:57 --> Language Class Initialized
INFO - 2017-08-04 06:07:57 --> Loader Class Initialized
INFO - 2017-08-04 06:07:57 --> Helper loaded: url_helper
INFO - 2017-08-04 06:07:57 --> Helper loaded: form_helper
INFO - 2017-08-04 06:07:57 --> Helper loaded: security_helper
INFO - 2017-08-04 06:07:57 --> Helper loaded: path_helper
INFO - 2017-08-04 06:07:57 --> Helper loaded: common_helper
INFO - 2017-08-04 06:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:07:57 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:07:57 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:07:57 --> Email Class Initialized
INFO - 2017-08-04 06:07:57 --> Form Validation Class Initialized
INFO - 2017-08-04 06:07:57 --> Model Class Initialized
INFO - 2017-08-04 06:07:57 --> Model Class Initialized
INFO - 2017-08-04 06:07:57 --> Model Class Initialized
INFO - 2017-08-04 06:07:57 --> Model Class Initialized
INFO - 2017-08-04 06:07:57 --> Controller Class Initialized
INFO - 2017-08-04 06:07:57 --> Model Class Initialized
INFO - 2017-08-04 06:07:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:07:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:07:57 --> Final output sent to browser
DEBUG - 2017-08-04 06:07:57 --> Total execution time: 0.0255
DEBUG - 2017-08-04 06:07:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:07:57 --> Database Forge Class Initialized
INFO - 2017-08-04 06:07:57 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:08:00 --> Config Class Initialized
INFO - 2017-08-04 06:08:00 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:08:00 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:08:00 --> Utf8 Class Initialized
INFO - 2017-08-04 06:08:00 --> URI Class Initialized
INFO - 2017-08-04 06:08:00 --> Router Class Initialized
INFO - 2017-08-04 06:08:00 --> Output Class Initialized
INFO - 2017-08-04 06:08:00 --> Security Class Initialized
DEBUG - 2017-08-04 06:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:08:00 --> Input Class Initialized
INFO - 2017-08-04 06:08:00 --> Language Class Initialized
ERROR - 2017-08-04 06:08:00 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 06:08:05 --> Config Class Initialized
INFO - 2017-08-04 06:08:05 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:08:05 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:08:05 --> Utf8 Class Initialized
INFO - 2017-08-04 06:08:05 --> URI Class Initialized
INFO - 2017-08-04 06:08:05 --> Router Class Initialized
INFO - 2017-08-04 06:08:05 --> Output Class Initialized
INFO - 2017-08-04 06:08:05 --> Security Class Initialized
DEBUG - 2017-08-04 06:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:08:05 --> Input Class Initialized
INFO - 2017-08-04 06:08:05 --> Language Class Initialized
INFO - 2017-08-04 06:08:05 --> Loader Class Initialized
INFO - 2017-08-04 06:08:05 --> Helper loaded: url_helper
INFO - 2017-08-04 06:08:05 --> Helper loaded: form_helper
INFO - 2017-08-04 06:08:05 --> Helper loaded: security_helper
INFO - 2017-08-04 06:08:05 --> Helper loaded: path_helper
INFO - 2017-08-04 06:08:05 --> Helper loaded: common_helper
INFO - 2017-08-04 06:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:08:05 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:08:05 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:08:05 --> Email Class Initialized
INFO - 2017-08-04 06:08:05 --> Form Validation Class Initialized
INFO - 2017-08-04 06:08:05 --> Model Class Initialized
INFO - 2017-08-04 06:08:05 --> Model Class Initialized
INFO - 2017-08-04 06:08:05 --> Model Class Initialized
INFO - 2017-08-04 06:08:05 --> Model Class Initialized
INFO - 2017-08-04 06:08:05 --> Controller Class Initialized
DEBUG - 2017-08-04 06:08:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:08:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:08:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:08:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:08:05 --> Final output sent to browser
DEBUG - 2017-08-04 06:08:05 --> Total execution time: 0.0353
DEBUG - 2017-08-04 06:08:05 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:08:05 --> Database Forge Class Initialized
INFO - 2017-08-04 06:08:05 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:08:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:08:07 --> Config Class Initialized
INFO - 2017-08-04 06:08:07 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:08:07 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:08:07 --> Utf8 Class Initialized
INFO - 2017-08-04 06:08:07 --> URI Class Initialized
INFO - 2017-08-04 06:08:07 --> Router Class Initialized
INFO - 2017-08-04 06:08:07 --> Output Class Initialized
INFO - 2017-08-04 06:08:07 --> Security Class Initialized
DEBUG - 2017-08-04 06:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:08:07 --> Input Class Initialized
INFO - 2017-08-04 06:08:07 --> Language Class Initialized
ERROR - 2017-08-04 06:08:07 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 06:08:11 --> Config Class Initialized
INFO - 2017-08-04 06:08:11 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:08:11 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:08:11 --> Utf8 Class Initialized
INFO - 2017-08-04 06:08:11 --> URI Class Initialized
INFO - 2017-08-04 06:08:11 --> Router Class Initialized
INFO - 2017-08-04 06:08:11 --> Output Class Initialized
INFO - 2017-08-04 06:08:11 --> Security Class Initialized
DEBUG - 2017-08-04 06:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:08:11 --> Input Class Initialized
INFO - 2017-08-04 06:08:11 --> Language Class Initialized
INFO - 2017-08-04 06:08:11 --> Loader Class Initialized
INFO - 2017-08-04 06:08:11 --> Helper loaded: url_helper
INFO - 2017-08-04 06:08:11 --> Helper loaded: form_helper
INFO - 2017-08-04 06:08:11 --> Helper loaded: security_helper
INFO - 2017-08-04 06:08:11 --> Helper loaded: path_helper
INFO - 2017-08-04 06:08:11 --> Helper loaded: common_helper
INFO - 2017-08-04 06:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:08:11 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:08:11 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:08:11 --> Email Class Initialized
INFO - 2017-08-04 06:08:11 --> Form Validation Class Initialized
INFO - 2017-08-04 06:08:11 --> Model Class Initialized
INFO - 2017-08-04 06:08:11 --> Model Class Initialized
INFO - 2017-08-04 06:08:11 --> Model Class Initialized
INFO - 2017-08-04 06:08:11 --> Model Class Initialized
INFO - 2017-08-04 06:08:11 --> Controller Class Initialized
INFO - 2017-08-04 06:08:11 --> Model Class Initialized
INFO - 2017-08-04 06:08:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:08:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:08:11 --> Final output sent to browser
DEBUG - 2017-08-04 06:08:11 --> Total execution time: 0.0263
DEBUG - 2017-08-04 06:08:11 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:08:11 --> Database Forge Class Initialized
INFO - 2017-08-04 06:08:11 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:10:39 --> Config Class Initialized
INFO - 2017-08-04 06:10:39 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:10:39 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:10:39 --> Utf8 Class Initialized
INFO - 2017-08-04 06:10:39 --> URI Class Initialized
INFO - 2017-08-04 06:10:39 --> Router Class Initialized
INFO - 2017-08-04 06:10:39 --> Output Class Initialized
INFO - 2017-08-04 06:10:39 --> Security Class Initialized
DEBUG - 2017-08-04 06:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:10:39 --> Input Class Initialized
INFO - 2017-08-04 06:10:39 --> Language Class Initialized
INFO - 2017-08-04 06:10:39 --> Loader Class Initialized
INFO - 2017-08-04 06:10:39 --> Helper loaded: url_helper
INFO - 2017-08-04 06:10:39 --> Helper loaded: form_helper
INFO - 2017-08-04 06:10:39 --> Helper loaded: security_helper
INFO - 2017-08-04 06:10:39 --> Helper loaded: path_helper
INFO - 2017-08-04 06:10:39 --> Helper loaded: common_helper
INFO - 2017-08-04 06:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:10:39 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:10:39 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:10:39 --> Email Class Initialized
INFO - 2017-08-04 06:10:39 --> Form Validation Class Initialized
INFO - 2017-08-04 06:10:39 --> Model Class Initialized
INFO - 2017-08-04 06:10:39 --> Model Class Initialized
INFO - 2017-08-04 06:10:39 --> Model Class Initialized
INFO - 2017-08-04 06:10:39 --> Model Class Initialized
INFO - 2017-08-04 06:10:39 --> Controller Class Initialized
DEBUG - 2017-08-04 06:10:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:10:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:10:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:10:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:10:39 --> Final output sent to browser
DEBUG - 2017-08-04 06:10:39 --> Total execution time: 0.0368
DEBUG - 2017-08-04 06:10:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:10:39 --> Database Forge Class Initialized
INFO - 2017-08-04 06:10:39 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:15:31 --> Config Class Initialized
INFO - 2017-08-04 06:15:31 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:15:31 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:15:31 --> Utf8 Class Initialized
INFO - 2017-08-04 06:15:31 --> URI Class Initialized
INFO - 2017-08-04 06:15:31 --> Router Class Initialized
INFO - 2017-08-04 06:15:31 --> Output Class Initialized
INFO - 2017-08-04 06:15:31 --> Security Class Initialized
DEBUG - 2017-08-04 06:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:15:31 --> Input Class Initialized
INFO - 2017-08-04 06:15:31 --> Language Class Initialized
INFO - 2017-08-04 06:15:31 --> Loader Class Initialized
INFO - 2017-08-04 06:15:31 --> Helper loaded: url_helper
INFO - 2017-08-04 06:15:31 --> Helper loaded: form_helper
INFO - 2017-08-04 06:15:31 --> Helper loaded: security_helper
INFO - 2017-08-04 06:15:31 --> Helper loaded: path_helper
INFO - 2017-08-04 06:15:31 --> Helper loaded: common_helper
INFO - 2017-08-04 06:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:15:31 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:15:31 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:15:31 --> Email Class Initialized
INFO - 2017-08-04 06:15:31 --> Form Validation Class Initialized
INFO - 2017-08-04 06:15:31 --> Model Class Initialized
INFO - 2017-08-04 06:15:31 --> Model Class Initialized
INFO - 2017-08-04 06:15:31 --> Model Class Initialized
INFO - 2017-08-04 06:15:31 --> Model Class Initialized
INFO - 2017-08-04 06:15:31 --> Controller Class Initialized
INFO - 2017-08-04 06:15:31 --> Model Class Initialized
INFO - 2017-08-04 06:15:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:15:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:15:31 --> Final output sent to browser
DEBUG - 2017-08-04 06:15:31 --> Total execution time: 0.0310
DEBUG - 2017-08-04 06:15:31 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:15:31 --> Database Forge Class Initialized
INFO - 2017-08-04 06:15:31 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:15:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:04 --> Config Class Initialized
INFO - 2017-08-04 06:18:04 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:18:04 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:18:04 --> Utf8 Class Initialized
INFO - 2017-08-04 06:18:04 --> URI Class Initialized
INFO - 2017-08-04 06:18:04 --> Router Class Initialized
INFO - 2017-08-04 06:18:04 --> Output Class Initialized
INFO - 2017-08-04 06:18:04 --> Security Class Initialized
DEBUG - 2017-08-04 06:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:18:04 --> Input Class Initialized
INFO - 2017-08-04 06:18:04 --> Language Class Initialized
INFO - 2017-08-04 06:18:04 --> Loader Class Initialized
INFO - 2017-08-04 06:18:04 --> Helper loaded: url_helper
INFO - 2017-08-04 06:18:04 --> Helper loaded: form_helper
INFO - 2017-08-04 06:18:04 --> Helper loaded: security_helper
INFO - 2017-08-04 06:18:04 --> Helper loaded: path_helper
INFO - 2017-08-04 06:18:04 --> Helper loaded: common_helper
INFO - 2017-08-04 06:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:18:04 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:18:04 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:04 --> Email Class Initialized
INFO - 2017-08-04 06:18:04 --> Form Validation Class Initialized
INFO - 2017-08-04 06:18:04 --> Model Class Initialized
INFO - 2017-08-04 06:18:04 --> Model Class Initialized
INFO - 2017-08-04 06:18:04 --> Model Class Initialized
INFO - 2017-08-04 06:18:04 --> Model Class Initialized
INFO - 2017-08-04 06:18:04 --> Controller Class Initialized
INFO - 2017-08-04 06:18:04 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 06:18:04 --> Final output sent to browser
DEBUG - 2017-08-04 06:18:04 --> Total execution time: 0.0273
DEBUG - 2017-08-04 06:18:04 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:18:04 --> Database Forge Class Initialized
INFO - 2017-08-04 06:18:04 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:07 --> Config Class Initialized
INFO - 2017-08-04 06:18:08 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:18:08 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:18:08 --> Utf8 Class Initialized
INFO - 2017-08-04 06:18:08 --> URI Class Initialized
INFO - 2017-08-04 06:18:08 --> Router Class Initialized
INFO - 2017-08-04 06:18:08 --> Output Class Initialized
INFO - 2017-08-04 06:18:08 --> Security Class Initialized
DEBUG - 2017-08-04 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:18:08 --> Input Class Initialized
INFO - 2017-08-04 06:18:08 --> Language Class Initialized
INFO - 2017-08-04 06:18:08 --> Loader Class Initialized
INFO - 2017-08-04 06:18:08 --> Helper loaded: url_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: form_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: security_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: path_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: common_helper
INFO - 2017-08-04 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:18:08 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:18:08 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:08 --> Email Class Initialized
INFO - 2017-08-04 06:18:08 --> Form Validation Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Controller Class Initialized
INFO - 2017-08-04 06:18:08 --> Config Class Initialized
INFO - 2017-08-04 06:18:08 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:18:08 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:18:08 --> Utf8 Class Initialized
INFO - 2017-08-04 06:18:08 --> URI Class Initialized
INFO - 2017-08-04 06:18:08 --> Router Class Initialized
INFO - 2017-08-04 06:18:08 --> Output Class Initialized
INFO - 2017-08-04 06:18:08 --> Security Class Initialized
DEBUG - 2017-08-04 06:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:18:08 --> Input Class Initialized
INFO - 2017-08-04 06:18:08 --> Language Class Initialized
INFO - 2017-08-04 06:18:08 --> Loader Class Initialized
INFO - 2017-08-04 06:18:08 --> Helper loaded: url_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: form_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: security_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: path_helper
INFO - 2017-08-04 06:18:08 --> Helper loaded: common_helper
INFO - 2017-08-04 06:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:18:08 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:18:08 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:08 --> Email Class Initialized
INFO - 2017-08-04 06:18:08 --> Form Validation Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Model Class Initialized
INFO - 2017-08-04 06:18:08 --> Controller Class Initialized
INFO - 2017-08-04 06:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 06:18:08 --> Pagination Class Initialized
INFO - 2017-08-04 06:18:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:18:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 06:18:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:18:08 --> Final output sent to browser
DEBUG - 2017-08-04 06:18:08 --> Total execution time: 0.0283
DEBUG - 2017-08-04 06:18:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:18:08 --> Database Forge Class Initialized
INFO - 2017-08-04 06:18:08 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:18:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:12 --> Config Class Initialized
INFO - 2017-08-04 06:18:12 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:18:12 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:18:12 --> Utf8 Class Initialized
INFO - 2017-08-04 06:18:12 --> URI Class Initialized
INFO - 2017-08-04 06:18:12 --> Router Class Initialized
INFO - 2017-08-04 06:18:12 --> Output Class Initialized
INFO - 2017-08-04 06:18:12 --> Security Class Initialized
DEBUG - 2017-08-04 06:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:18:12 --> Input Class Initialized
INFO - 2017-08-04 06:18:12 --> Language Class Initialized
INFO - 2017-08-04 06:18:12 --> Loader Class Initialized
INFO - 2017-08-04 06:18:12 --> Helper loaded: url_helper
INFO - 2017-08-04 06:18:12 --> Helper loaded: form_helper
INFO - 2017-08-04 06:18:12 --> Helper loaded: security_helper
INFO - 2017-08-04 06:18:12 --> Helper loaded: path_helper
INFO - 2017-08-04 06:18:12 --> Helper loaded: common_helper
INFO - 2017-08-04 06:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:18:12 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:18:12 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:12 --> Email Class Initialized
INFO - 2017-08-04 06:18:12 --> Form Validation Class Initialized
INFO - 2017-08-04 06:18:12 --> Model Class Initialized
INFO - 2017-08-04 06:18:12 --> Model Class Initialized
INFO - 2017-08-04 06:18:12 --> Model Class Initialized
INFO - 2017-08-04 06:18:12 --> Model Class Initialized
INFO - 2017-08-04 06:18:12 --> Controller Class Initialized
INFO - 2017-08-04 06:18:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:18:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 06:18:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:18:12 --> Final output sent to browser
DEBUG - 2017-08-04 06:18:12 --> Total execution time: 0.0295
DEBUG - 2017-08-04 06:18:12 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:18:12 --> Database Forge Class Initialized
INFO - 2017-08-04 06:18:12 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:16 --> Config Class Initialized
INFO - 2017-08-04 06:18:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:18:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:18:16 --> Utf8 Class Initialized
INFO - 2017-08-04 06:18:16 --> URI Class Initialized
INFO - 2017-08-04 06:18:16 --> Router Class Initialized
INFO - 2017-08-04 06:18:16 --> Output Class Initialized
INFO - 2017-08-04 06:18:16 --> Security Class Initialized
DEBUG - 2017-08-04 06:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:18:16 --> Input Class Initialized
INFO - 2017-08-04 06:18:16 --> Language Class Initialized
INFO - 2017-08-04 06:18:16 --> Loader Class Initialized
INFO - 2017-08-04 06:18:16 --> Helper loaded: url_helper
INFO - 2017-08-04 06:18:16 --> Helper loaded: form_helper
INFO - 2017-08-04 06:18:16 --> Helper loaded: security_helper
INFO - 2017-08-04 06:18:16 --> Helper loaded: path_helper
INFO - 2017-08-04 06:18:16 --> Helper loaded: common_helper
INFO - 2017-08-04 06:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:18:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:18:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:16 --> Email Class Initialized
INFO - 2017-08-04 06:18:16 --> Form Validation Class Initialized
INFO - 2017-08-04 06:18:16 --> Model Class Initialized
INFO - 2017-08-04 06:18:16 --> Model Class Initialized
INFO - 2017-08-04 06:18:16 --> Model Class Initialized
INFO - 2017-08-04 06:18:16 --> Model Class Initialized
INFO - 2017-08-04 06:18:16 --> Controller Class Initialized
DEBUG - 2017-08-04 06:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:18:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:18:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:18:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:18:16 --> Final output sent to browser
DEBUG - 2017-08-04 06:18:16 --> Total execution time: 0.0284
DEBUG - 2017-08-04 06:18:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:18:16 --> Database Forge Class Initialized
INFO - 2017-08-04 06:18:16 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:16 --> Config Class Initialized
INFO - 2017-08-04 06:29:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:29:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:29:16 --> Utf8 Class Initialized
INFO - 2017-08-04 06:29:16 --> URI Class Initialized
DEBUG - 2017-08-04 06:29:16 --> No URI present. Default controller set.
INFO - 2017-08-04 06:29:16 --> Router Class Initialized
INFO - 2017-08-04 06:29:16 --> Output Class Initialized
INFO - 2017-08-04 06:29:16 --> Security Class Initialized
DEBUG - 2017-08-04 06:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:29:16 --> Input Class Initialized
INFO - 2017-08-04 06:29:16 --> Language Class Initialized
INFO - 2017-08-04 06:29:16 --> Loader Class Initialized
INFO - 2017-08-04 06:29:16 --> Helper loaded: url_helper
INFO - 2017-08-04 06:29:16 --> Helper loaded: form_helper
INFO - 2017-08-04 06:29:16 --> Helper loaded: security_helper
INFO - 2017-08-04 06:29:16 --> Helper loaded: path_helper
INFO - 2017-08-04 06:29:16 --> Helper loaded: common_helper
INFO - 2017-08-04 06:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:29:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:29:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:16 --> Email Class Initialized
INFO - 2017-08-04 06:29:16 --> Form Validation Class Initialized
INFO - 2017-08-04 06:29:16 --> Model Class Initialized
INFO - 2017-08-04 06:29:16 --> Model Class Initialized
INFO - 2017-08-04 06:29:16 --> Model Class Initialized
INFO - 2017-08-04 06:29:16 --> Model Class Initialized
INFO - 2017-08-04 06:29:16 --> Controller Class Initialized
DEBUG - 2017-08-04 06:29:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:29:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:29:16 --> Final output sent to browser
DEBUG - 2017-08-04 06:29:16 --> Total execution time: 0.0282
DEBUG - 2017-08-04 06:29:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:29:16 --> Database Forge Class Initialized
INFO - 2017-08-04 06:29:16 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:30 --> Config Class Initialized
INFO - 2017-08-04 06:29:30 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:29:30 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:29:30 --> Utf8 Class Initialized
INFO - 2017-08-04 06:29:30 --> URI Class Initialized
INFO - 2017-08-04 06:29:30 --> Router Class Initialized
INFO - 2017-08-04 06:29:30 --> Output Class Initialized
INFO - 2017-08-04 06:29:30 --> Security Class Initialized
DEBUG - 2017-08-04 06:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:29:30 --> Input Class Initialized
INFO - 2017-08-04 06:29:30 --> Language Class Initialized
INFO - 2017-08-04 06:29:30 --> Loader Class Initialized
INFO - 2017-08-04 06:29:30 --> Helper loaded: url_helper
INFO - 2017-08-04 06:29:30 --> Helper loaded: form_helper
INFO - 2017-08-04 06:29:30 --> Helper loaded: security_helper
INFO - 2017-08-04 06:29:30 --> Helper loaded: path_helper
INFO - 2017-08-04 06:29:30 --> Helper loaded: common_helper
INFO - 2017-08-04 06:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:29:30 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:29:30 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:30 --> Email Class Initialized
INFO - 2017-08-04 06:29:30 --> Form Validation Class Initialized
INFO - 2017-08-04 06:29:30 --> Model Class Initialized
INFO - 2017-08-04 06:29:30 --> Model Class Initialized
INFO - 2017-08-04 06:29:30 --> Model Class Initialized
INFO - 2017-08-04 06:29:30 --> Model Class Initialized
INFO - 2017-08-04 06:29:30 --> Controller Class Initialized
INFO - 2017-08-04 06:29:30 --> Model Class Initialized
INFO - 2017-08-04 06:29:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:29:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:29:30 --> Final output sent to browser
DEBUG - 2017-08-04 06:29:30 --> Total execution time: 0.0273
DEBUG - 2017-08-04 06:29:30 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:29:30 --> Database Forge Class Initialized
INFO - 2017-08-04 06:29:30 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:29:35 --> Config Class Initialized
INFO - 2017-08-04 06:29:35 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:29:35 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:29:35 --> Utf8 Class Initialized
INFO - 2017-08-04 06:29:35 --> URI Class Initialized
INFO - 2017-08-04 06:29:35 --> Router Class Initialized
INFO - 2017-08-04 06:29:35 --> Output Class Initialized
INFO - 2017-08-04 06:29:35 --> Security Class Initialized
DEBUG - 2017-08-04 06:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:29:35 --> Input Class Initialized
INFO - 2017-08-04 06:29:35 --> Language Class Initialized
ERROR - 2017-08-04 06:29:35 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 06:30:35 --> Config Class Initialized
INFO - 2017-08-04 06:30:35 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:30:35 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:30:35 --> Utf8 Class Initialized
INFO - 2017-08-04 06:30:35 --> URI Class Initialized
INFO - 2017-08-04 06:30:35 --> Router Class Initialized
INFO - 2017-08-04 06:30:35 --> Output Class Initialized
INFO - 2017-08-04 06:30:35 --> Security Class Initialized
DEBUG - 2017-08-04 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:30:35 --> Input Class Initialized
INFO - 2017-08-04 06:30:35 --> Language Class Initialized
INFO - 2017-08-04 06:30:35 --> Loader Class Initialized
INFO - 2017-08-04 06:30:35 --> Helper loaded: url_helper
INFO - 2017-08-04 06:30:35 --> Helper loaded: form_helper
INFO - 2017-08-04 06:30:35 --> Helper loaded: security_helper
INFO - 2017-08-04 06:30:35 --> Helper loaded: path_helper
INFO - 2017-08-04 06:30:35 --> Helper loaded: common_helper
INFO - 2017-08-04 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:30:35 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:30:35 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:30:35 --> Email Class Initialized
INFO - 2017-08-04 06:30:35 --> Form Validation Class Initialized
INFO - 2017-08-04 06:30:35 --> Model Class Initialized
INFO - 2017-08-04 06:30:35 --> Model Class Initialized
INFO - 2017-08-04 06:30:35 --> Model Class Initialized
INFO - 2017-08-04 06:30:35 --> Model Class Initialized
INFO - 2017-08-04 06:30:35 --> Controller Class Initialized
INFO - 2017-08-04 06:30:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 06:30:35 --> Final output sent to browser
DEBUG - 2017-08-04 06:30:35 --> Total execution time: 0.0275
DEBUG - 2017-08-04 06:30:35 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:30:35 --> Database Forge Class Initialized
INFO - 2017-08-04 06:30:35 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:30:35 --> Config Class Initialized
INFO - 2017-08-04 06:30:35 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:30:35 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:30:35 --> Utf8 Class Initialized
INFO - 2017-08-04 06:30:35 --> URI Class Initialized
INFO - 2017-08-04 06:30:35 --> Router Class Initialized
INFO - 2017-08-04 06:30:35 --> Output Class Initialized
INFO - 2017-08-04 06:30:35 --> Security Class Initialized
DEBUG - 2017-08-04 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:30:35 --> Input Class Initialized
INFO - 2017-08-04 06:30:35 --> Language Class Initialized
ERROR - 2017-08-04 06:30:35 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 06:30:40 --> Config Class Initialized
INFO - 2017-08-04 06:30:40 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:30:40 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:30:40 --> Utf8 Class Initialized
INFO - 2017-08-04 06:30:40 --> URI Class Initialized
INFO - 2017-08-04 06:30:40 --> Router Class Initialized
INFO - 2017-08-04 06:30:40 --> Output Class Initialized
INFO - 2017-08-04 06:30:40 --> Security Class Initialized
DEBUG - 2017-08-04 06:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:30:40 --> Input Class Initialized
INFO - 2017-08-04 06:30:40 --> Language Class Initialized
INFO - 2017-08-04 06:30:40 --> Loader Class Initialized
INFO - 2017-08-04 06:30:40 --> Helper loaded: url_helper
INFO - 2017-08-04 06:30:40 --> Helper loaded: form_helper
INFO - 2017-08-04 06:30:40 --> Helper loaded: security_helper
INFO - 2017-08-04 06:30:40 --> Helper loaded: path_helper
INFO - 2017-08-04 06:30:40 --> Helper loaded: common_helper
INFO - 2017-08-04 06:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:30:40 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:30:40 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:30:40 --> Email Class Initialized
INFO - 2017-08-04 06:30:40 --> Form Validation Class Initialized
INFO - 2017-08-04 06:30:40 --> Model Class Initialized
INFO - 2017-08-04 06:30:40 --> Model Class Initialized
INFO - 2017-08-04 06:30:40 --> Model Class Initialized
INFO - 2017-08-04 06:30:40 --> Model Class Initialized
INFO - 2017-08-04 06:30:40 --> Controller Class Initialized
INFO - 2017-08-04 06:30:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 06:30:40 --> Final output sent to browser
DEBUG - 2017-08-04 06:30:40 --> Total execution time: 0.0269
DEBUG - 2017-08-04 06:30:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:30:40 --> Database Forge Class Initialized
INFO - 2017-08-04 06:30:40 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:30:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:31:00 --> Config Class Initialized
INFO - 2017-08-04 06:31:00 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:31:00 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:31:00 --> Utf8 Class Initialized
INFO - 2017-08-04 06:31:00 --> URI Class Initialized
INFO - 2017-08-04 06:31:00 --> Router Class Initialized
INFO - 2017-08-04 06:31:00 --> Output Class Initialized
INFO - 2017-08-04 06:31:00 --> Security Class Initialized
DEBUG - 2017-08-04 06:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:31:00 --> Input Class Initialized
INFO - 2017-08-04 06:31:00 --> Language Class Initialized
INFO - 2017-08-04 06:31:00 --> Loader Class Initialized
INFO - 2017-08-04 06:31:00 --> Helper loaded: url_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: form_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: security_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: path_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: common_helper
INFO - 2017-08-04 06:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:31:00 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:31:00 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:31:00 --> Email Class Initialized
INFO - 2017-08-04 06:31:00 --> Form Validation Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Controller Class Initialized
INFO - 2017-08-04 06:31:00 --> Config Class Initialized
INFO - 2017-08-04 06:31:00 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:31:00 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:31:00 --> Utf8 Class Initialized
INFO - 2017-08-04 06:31:00 --> URI Class Initialized
INFO - 2017-08-04 06:31:00 --> Router Class Initialized
INFO - 2017-08-04 06:31:00 --> Output Class Initialized
INFO - 2017-08-04 06:31:00 --> Security Class Initialized
DEBUG - 2017-08-04 06:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:31:00 --> Input Class Initialized
INFO - 2017-08-04 06:31:00 --> Language Class Initialized
INFO - 2017-08-04 06:31:00 --> Loader Class Initialized
INFO - 2017-08-04 06:31:00 --> Helper loaded: url_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: form_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: security_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: path_helper
INFO - 2017-08-04 06:31:00 --> Helper loaded: common_helper
INFO - 2017-08-04 06:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:31:00 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:31:00 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:31:00 --> Email Class Initialized
INFO - 2017-08-04 06:31:00 --> Form Validation Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Model Class Initialized
INFO - 2017-08-04 06:31:00 --> Controller Class Initialized
INFO - 2017-08-04 06:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 06:31:00 --> Pagination Class Initialized
INFO - 2017-08-04 06:31:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:31:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 06:31:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:31:00 --> Final output sent to browser
DEBUG - 2017-08-04 06:31:00 --> Total execution time: 0.0304
DEBUG - 2017-08-04 06:31:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:31:00 --> Database Forge Class Initialized
INFO - 2017-08-04 06:31:00 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:31:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:32:48 --> Config Class Initialized
INFO - 2017-08-04 06:32:48 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:32:48 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:32:48 --> Utf8 Class Initialized
INFO - 2017-08-04 06:32:48 --> URI Class Initialized
DEBUG - 2017-08-04 06:32:48 --> No URI present. Default controller set.
INFO - 2017-08-04 06:32:48 --> Router Class Initialized
INFO - 2017-08-04 06:32:48 --> Output Class Initialized
INFO - 2017-08-04 06:32:48 --> Security Class Initialized
DEBUG - 2017-08-04 06:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:32:48 --> Input Class Initialized
INFO - 2017-08-04 06:32:48 --> Language Class Initialized
INFO - 2017-08-04 06:32:48 --> Loader Class Initialized
INFO - 2017-08-04 06:32:48 --> Helper loaded: url_helper
INFO - 2017-08-04 06:32:48 --> Helper loaded: form_helper
INFO - 2017-08-04 06:32:48 --> Helper loaded: security_helper
INFO - 2017-08-04 06:32:48 --> Helper loaded: path_helper
INFO - 2017-08-04 06:32:48 --> Helper loaded: common_helper
INFO - 2017-08-04 06:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:32:48 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:32:48 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:32:48 --> Email Class Initialized
INFO - 2017-08-04 06:32:48 --> Form Validation Class Initialized
INFO - 2017-08-04 06:32:48 --> Model Class Initialized
INFO - 2017-08-04 06:32:48 --> Model Class Initialized
INFO - 2017-08-04 06:32:48 --> Model Class Initialized
INFO - 2017-08-04 06:32:48 --> Model Class Initialized
INFO - 2017-08-04 06:32:48 --> Controller Class Initialized
DEBUG - 2017-08-04 06:32:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:32:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:32:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:32:48 --> Final output sent to browser
DEBUG - 2017-08-04 06:32:48 --> Total execution time: 0.0295
DEBUG - 2017-08-04 06:32:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:32:48 --> Database Forge Class Initialized
INFO - 2017-08-04 06:32:48 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:35:16 --> Config Class Initialized
INFO - 2017-08-04 06:35:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:35:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:35:16 --> Utf8 Class Initialized
INFO - 2017-08-04 06:35:16 --> URI Class Initialized
INFO - 2017-08-04 06:35:16 --> Router Class Initialized
INFO - 2017-08-04 06:35:16 --> Output Class Initialized
INFO - 2017-08-04 06:35:16 --> Security Class Initialized
DEBUG - 2017-08-04 06:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:35:16 --> Input Class Initialized
INFO - 2017-08-04 06:35:16 --> Language Class Initialized
INFO - 2017-08-04 06:35:16 --> Loader Class Initialized
INFO - 2017-08-04 06:35:16 --> Helper loaded: url_helper
INFO - 2017-08-04 06:35:16 --> Helper loaded: form_helper
INFO - 2017-08-04 06:35:16 --> Helper loaded: security_helper
INFO - 2017-08-04 06:35:16 --> Helper loaded: path_helper
INFO - 2017-08-04 06:35:16 --> Helper loaded: common_helper
INFO - 2017-08-04 06:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:35:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:35:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:35:16 --> Email Class Initialized
INFO - 2017-08-04 06:35:16 --> Form Validation Class Initialized
INFO - 2017-08-04 06:35:16 --> Model Class Initialized
INFO - 2017-08-04 06:35:16 --> Model Class Initialized
INFO - 2017-08-04 06:35:16 --> Model Class Initialized
INFO - 2017-08-04 06:35:16 --> Model Class Initialized
INFO - 2017-08-04 06:35:16 --> Controller Class Initialized
INFO - 2017-08-04 06:35:16 --> Model Class Initialized
INFO - 2017-08-04 06:35:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:35:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:35:16 --> Final output sent to browser
DEBUG - 2017-08-04 06:35:16 --> Total execution time: 0.0283
DEBUG - 2017-08-04 06:35:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:35:16 --> Database Forge Class Initialized
INFO - 2017-08-04 06:35:16 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:35:45 --> Config Class Initialized
INFO - 2017-08-04 06:35:45 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:35:45 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:35:45 --> Utf8 Class Initialized
INFO - 2017-08-04 06:35:45 --> URI Class Initialized
DEBUG - 2017-08-04 06:35:45 --> No URI present. Default controller set.
INFO - 2017-08-04 06:35:45 --> Router Class Initialized
INFO - 2017-08-04 06:35:45 --> Output Class Initialized
INFO - 2017-08-04 06:35:45 --> Security Class Initialized
DEBUG - 2017-08-04 06:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:35:45 --> Input Class Initialized
INFO - 2017-08-04 06:35:45 --> Language Class Initialized
INFO - 2017-08-04 06:35:45 --> Loader Class Initialized
INFO - 2017-08-04 06:35:45 --> Helper loaded: url_helper
INFO - 2017-08-04 06:35:45 --> Helper loaded: form_helper
INFO - 2017-08-04 06:35:45 --> Helper loaded: security_helper
INFO - 2017-08-04 06:35:45 --> Helper loaded: path_helper
INFO - 2017-08-04 06:35:45 --> Helper loaded: common_helper
INFO - 2017-08-04 06:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:35:45 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:35:45 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:35:45 --> Email Class Initialized
INFO - 2017-08-04 06:35:45 --> Form Validation Class Initialized
INFO - 2017-08-04 06:35:45 --> Model Class Initialized
INFO - 2017-08-04 06:35:45 --> Model Class Initialized
INFO - 2017-08-04 06:35:45 --> Model Class Initialized
INFO - 2017-08-04 06:35:45 --> Model Class Initialized
INFO - 2017-08-04 06:35:45 --> Controller Class Initialized
DEBUG - 2017-08-04 06:35:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:35:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:35:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:35:45 --> Final output sent to browser
DEBUG - 2017-08-04 06:35:45 --> Total execution time: 0.0298
DEBUG - 2017-08-04 06:35:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:35:45 --> Database Forge Class Initialized
INFO - 2017-08-04 06:35:45 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:35:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:29 --> Config Class Initialized
INFO - 2017-08-04 06:37:29 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:37:29 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:37:29 --> Utf8 Class Initialized
INFO - 2017-08-04 06:37:29 --> URI Class Initialized
DEBUG - 2017-08-04 06:37:29 --> No URI present. Default controller set.
INFO - 2017-08-04 06:37:29 --> Router Class Initialized
INFO - 2017-08-04 06:37:29 --> Output Class Initialized
INFO - 2017-08-04 06:37:29 --> Security Class Initialized
DEBUG - 2017-08-04 06:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:37:29 --> Input Class Initialized
INFO - 2017-08-04 06:37:29 --> Language Class Initialized
INFO - 2017-08-04 06:37:29 --> Loader Class Initialized
INFO - 2017-08-04 06:37:29 --> Helper loaded: url_helper
INFO - 2017-08-04 06:37:29 --> Helper loaded: form_helper
INFO - 2017-08-04 06:37:29 --> Helper loaded: security_helper
INFO - 2017-08-04 06:37:29 --> Helper loaded: path_helper
INFO - 2017-08-04 06:37:29 --> Helper loaded: common_helper
INFO - 2017-08-04 06:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:37:29 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:37:29 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:29 --> Email Class Initialized
INFO - 2017-08-04 06:37:29 --> Form Validation Class Initialized
INFO - 2017-08-04 06:37:29 --> Model Class Initialized
INFO - 2017-08-04 06:37:29 --> Model Class Initialized
INFO - 2017-08-04 06:37:29 --> Model Class Initialized
INFO - 2017-08-04 06:37:29 --> Model Class Initialized
INFO - 2017-08-04 06:37:29 --> Controller Class Initialized
DEBUG - 2017-08-04 06:37:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:37:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:37:29 --> Final output sent to browser
DEBUG - 2017-08-04 06:37:29 --> Total execution time: 0.0295
DEBUG - 2017-08-04 06:37:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:37:29 --> Database Forge Class Initialized
INFO - 2017-08-04 06:37:29 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:35 --> Config Class Initialized
INFO - 2017-08-04 06:37:35 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:37:35 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:37:35 --> Utf8 Class Initialized
INFO - 2017-08-04 06:37:35 --> URI Class Initialized
DEBUG - 2017-08-04 06:37:35 --> No URI present. Default controller set.
INFO - 2017-08-04 06:37:35 --> Router Class Initialized
INFO - 2017-08-04 06:37:35 --> Output Class Initialized
INFO - 2017-08-04 06:37:35 --> Security Class Initialized
DEBUG - 2017-08-04 06:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:37:35 --> Input Class Initialized
INFO - 2017-08-04 06:37:35 --> Language Class Initialized
INFO - 2017-08-04 06:37:35 --> Loader Class Initialized
INFO - 2017-08-04 06:37:35 --> Helper loaded: url_helper
INFO - 2017-08-04 06:37:35 --> Helper loaded: form_helper
INFO - 2017-08-04 06:37:35 --> Helper loaded: security_helper
INFO - 2017-08-04 06:37:35 --> Helper loaded: path_helper
INFO - 2017-08-04 06:37:35 --> Helper loaded: common_helper
INFO - 2017-08-04 06:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:37:35 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:37:35 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:35 --> Email Class Initialized
INFO - 2017-08-04 06:37:35 --> Form Validation Class Initialized
INFO - 2017-08-04 06:37:35 --> Model Class Initialized
INFO - 2017-08-04 06:37:35 --> Model Class Initialized
INFO - 2017-08-04 06:37:35 --> Model Class Initialized
INFO - 2017-08-04 06:37:35 --> Model Class Initialized
INFO - 2017-08-04 06:37:35 --> Controller Class Initialized
DEBUG - 2017-08-04 06:37:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:37:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:37:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:37:35 --> Final output sent to browser
DEBUG - 2017-08-04 06:37:35 --> Total execution time: 0.0279
DEBUG - 2017-08-04 06:37:35 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:37:35 --> Database Forge Class Initialized
INFO - 2017-08-04 06:37:35 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:35 --> Config Class Initialized
INFO - 2017-08-04 06:38:35 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:38:35 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:38:35 --> Utf8 Class Initialized
INFO - 2017-08-04 06:38:35 --> URI Class Initialized
INFO - 2017-08-04 06:38:35 --> Router Class Initialized
INFO - 2017-08-04 06:38:35 --> Output Class Initialized
INFO - 2017-08-04 06:38:35 --> Security Class Initialized
DEBUG - 2017-08-04 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:38:35 --> Input Class Initialized
INFO - 2017-08-04 06:38:35 --> Language Class Initialized
INFO - 2017-08-04 06:38:35 --> Loader Class Initialized
INFO - 2017-08-04 06:38:35 --> Helper loaded: url_helper
INFO - 2017-08-04 06:38:35 --> Helper loaded: form_helper
INFO - 2017-08-04 06:38:35 --> Helper loaded: security_helper
INFO - 2017-08-04 06:38:35 --> Helper loaded: path_helper
INFO - 2017-08-04 06:38:35 --> Helper loaded: common_helper
INFO - 2017-08-04 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:38:35 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:38:35 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:35 --> Email Class Initialized
INFO - 2017-08-04 06:38:35 --> Form Validation Class Initialized
INFO - 2017-08-04 06:38:35 --> Model Class Initialized
INFO - 2017-08-04 06:38:35 --> Model Class Initialized
INFO - 2017-08-04 06:38:35 --> Model Class Initialized
INFO - 2017-08-04 06:38:35 --> Model Class Initialized
INFO - 2017-08-04 06:38:35 --> Controller Class Initialized
INFO - 2017-08-04 06:38:35 --> Model Class Initialized
INFO - 2017-08-04 06:38:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:38:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:38:35 --> Final output sent to browser
DEBUG - 2017-08-04 06:38:35 --> Total execution time: 0.0304
DEBUG - 2017-08-04 06:38:35 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:38:35 --> Database Forge Class Initialized
INFO - 2017-08-04 06:38:35 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:42 --> Config Class Initialized
INFO - 2017-08-04 06:38:42 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:38:42 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:38:42 --> Utf8 Class Initialized
INFO - 2017-08-04 06:38:42 --> URI Class Initialized
INFO - 2017-08-04 06:38:42 --> Router Class Initialized
INFO - 2017-08-04 06:38:42 --> Output Class Initialized
INFO - 2017-08-04 06:38:42 --> Security Class Initialized
DEBUG - 2017-08-04 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:38:42 --> Input Class Initialized
INFO - 2017-08-04 06:38:42 --> Language Class Initialized
INFO - 2017-08-04 06:38:42 --> Loader Class Initialized
INFO - 2017-08-04 06:38:42 --> Helper loaded: url_helper
INFO - 2017-08-04 06:38:42 --> Helper loaded: form_helper
INFO - 2017-08-04 06:38:42 --> Helper loaded: security_helper
INFO - 2017-08-04 06:38:42 --> Helper loaded: path_helper
INFO - 2017-08-04 06:38:42 --> Helper loaded: common_helper
INFO - 2017-08-04 06:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:38:42 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:38:42 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:42 --> Email Class Initialized
INFO - 2017-08-04 06:38:42 --> Form Validation Class Initialized
INFO - 2017-08-04 06:38:42 --> Model Class Initialized
INFO - 2017-08-04 06:38:42 --> Model Class Initialized
INFO - 2017-08-04 06:38:42 --> Model Class Initialized
INFO - 2017-08-04 06:38:42 --> Model Class Initialized
INFO - 2017-08-04 06:38:42 --> Controller Class Initialized
INFO - 2017-08-04 06:38:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:38:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 06:38:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:38:42 --> Final output sent to browser
DEBUG - 2017-08-04 06:38:42 --> Total execution time: 0.0335
DEBUG - 2017-08-04 06:38:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:38:42 --> Database Forge Class Initialized
INFO - 2017-08-04 06:38:42 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:45 --> Config Class Initialized
INFO - 2017-08-04 06:38:45 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:38:45 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:38:45 --> Utf8 Class Initialized
INFO - 2017-08-04 06:38:45 --> URI Class Initialized
INFO - 2017-08-04 06:38:45 --> Router Class Initialized
INFO - 2017-08-04 06:38:45 --> Output Class Initialized
INFO - 2017-08-04 06:38:45 --> Security Class Initialized
DEBUG - 2017-08-04 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:38:45 --> Input Class Initialized
INFO - 2017-08-04 06:38:45 --> Language Class Initialized
INFO - 2017-08-04 06:38:45 --> Loader Class Initialized
INFO - 2017-08-04 06:38:45 --> Helper loaded: url_helper
INFO - 2017-08-04 06:38:45 --> Helper loaded: form_helper
INFO - 2017-08-04 06:38:45 --> Helper loaded: security_helper
INFO - 2017-08-04 06:38:45 --> Helper loaded: path_helper
INFO - 2017-08-04 06:38:45 --> Helper loaded: common_helper
INFO - 2017-08-04 06:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:38:45 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:38:45 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:45 --> Email Class Initialized
INFO - 2017-08-04 06:38:45 --> Form Validation Class Initialized
INFO - 2017-08-04 06:38:45 --> Model Class Initialized
INFO - 2017-08-04 06:38:45 --> Model Class Initialized
INFO - 2017-08-04 06:38:45 --> Model Class Initialized
INFO - 2017-08-04 06:38:45 --> Model Class Initialized
INFO - 2017-08-04 06:38:45 --> Controller Class Initialized
DEBUG - 2017-08-04 06:38:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:38:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:38:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:38:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:38:45 --> Final output sent to browser
DEBUG - 2017-08-04 06:38:45 --> Total execution time: 0.0294
DEBUG - 2017-08-04 06:38:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:38:45 --> Database Forge Class Initialized
INFO - 2017-08-04 06:38:45 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:12 --> Config Class Initialized
INFO - 2017-08-04 06:39:12 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:39:12 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:39:12 --> Utf8 Class Initialized
INFO - 2017-08-04 06:39:12 --> URI Class Initialized
INFO - 2017-08-04 06:39:12 --> Router Class Initialized
INFO - 2017-08-04 06:39:12 --> Output Class Initialized
INFO - 2017-08-04 06:39:12 --> Security Class Initialized
DEBUG - 2017-08-04 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:39:12 --> Input Class Initialized
INFO - 2017-08-04 06:39:12 --> Language Class Initialized
INFO - 2017-08-04 06:39:12 --> Loader Class Initialized
INFO - 2017-08-04 06:39:12 --> Helper loaded: url_helper
INFO - 2017-08-04 06:39:12 --> Helper loaded: form_helper
INFO - 2017-08-04 06:39:12 --> Helper loaded: security_helper
INFO - 2017-08-04 06:39:12 --> Helper loaded: path_helper
INFO - 2017-08-04 06:39:12 --> Helper loaded: common_helper
INFO - 2017-08-04 06:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:39:12 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:39:12 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:12 --> Email Class Initialized
INFO - 2017-08-04 06:39:12 --> Form Validation Class Initialized
INFO - 2017-08-04 06:39:12 --> Model Class Initialized
INFO - 2017-08-04 06:39:12 --> Model Class Initialized
INFO - 2017-08-04 06:39:12 --> Model Class Initialized
INFO - 2017-08-04 06:39:12 --> Model Class Initialized
INFO - 2017-08-04 06:39:12 --> Controller Class Initialized
DEBUG - 2017-08-04 06:39:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:39:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:39:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:39:12 --> Final output sent to browser
DEBUG - 2017-08-04 06:39:12 --> Total execution time: 0.0329
DEBUG - 2017-08-04 06:39:12 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:39:12 --> Database Forge Class Initialized
INFO - 2017-08-04 06:39:12 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:39:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:16 --> Config Class Initialized
INFO - 2017-08-04 06:39:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:39:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:39:16 --> Utf8 Class Initialized
INFO - 2017-08-04 06:39:16 --> URI Class Initialized
INFO - 2017-08-04 06:39:16 --> Router Class Initialized
INFO - 2017-08-04 06:39:16 --> Output Class Initialized
INFO - 2017-08-04 06:39:16 --> Security Class Initialized
DEBUG - 2017-08-04 06:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:39:16 --> Input Class Initialized
INFO - 2017-08-04 06:39:16 --> Language Class Initialized
INFO - 2017-08-04 06:39:16 --> Loader Class Initialized
INFO - 2017-08-04 06:39:16 --> Helper loaded: url_helper
INFO - 2017-08-04 06:39:16 --> Helper loaded: form_helper
INFO - 2017-08-04 06:39:16 --> Helper loaded: security_helper
INFO - 2017-08-04 06:39:16 --> Helper loaded: path_helper
INFO - 2017-08-04 06:39:16 --> Helper loaded: common_helper
INFO - 2017-08-04 06:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:39:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:39:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:16 --> Email Class Initialized
INFO - 2017-08-04 06:39:16 --> Form Validation Class Initialized
INFO - 2017-08-04 06:39:16 --> Model Class Initialized
INFO - 2017-08-04 06:39:16 --> Model Class Initialized
INFO - 2017-08-04 06:39:16 --> Model Class Initialized
INFO - 2017-08-04 06:39:16 --> Model Class Initialized
INFO - 2017-08-04 06:39:16 --> Controller Class Initialized
INFO - 2017-08-04 06:39:16 --> Model Class Initialized
INFO - 2017-08-04 06:39:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:39:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:39:16 --> Final output sent to browser
DEBUG - 2017-08-04 06:39:16 --> Total execution time: 0.0296
DEBUG - 2017-08-04 06:39:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:39:16 --> Database Forge Class Initialized
INFO - 2017-08-04 06:39:16 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:39:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:22 --> Config Class Initialized
INFO - 2017-08-04 06:39:22 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:39:22 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:39:22 --> Utf8 Class Initialized
INFO - 2017-08-04 06:39:22 --> URI Class Initialized
INFO - 2017-08-04 06:39:22 --> Router Class Initialized
INFO - 2017-08-04 06:39:22 --> Output Class Initialized
INFO - 2017-08-04 06:39:22 --> Security Class Initialized
DEBUG - 2017-08-04 06:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:39:22 --> Input Class Initialized
INFO - 2017-08-04 06:39:22 --> Language Class Initialized
INFO - 2017-08-04 06:39:22 --> Loader Class Initialized
INFO - 2017-08-04 06:39:22 --> Helper loaded: url_helper
INFO - 2017-08-04 06:39:22 --> Helper loaded: form_helper
INFO - 2017-08-04 06:39:22 --> Helper loaded: security_helper
INFO - 2017-08-04 06:39:22 --> Helper loaded: path_helper
INFO - 2017-08-04 06:39:22 --> Helper loaded: common_helper
INFO - 2017-08-04 06:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:39:22 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:39:22 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:22 --> Email Class Initialized
INFO - 2017-08-04 06:39:22 --> Form Validation Class Initialized
INFO - 2017-08-04 06:39:22 --> Model Class Initialized
INFO - 2017-08-04 06:39:22 --> Model Class Initialized
INFO - 2017-08-04 06:39:22 --> Model Class Initialized
INFO - 2017-08-04 06:39:22 --> Model Class Initialized
INFO - 2017-08-04 06:39:22 --> Controller Class Initialized
INFO - 2017-08-04 06:39:22 --> Model Class Initialized
INFO - 2017-08-04 06:39:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:39:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:39:22 --> Final output sent to browser
DEBUG - 2017-08-04 06:39:22 --> Total execution time: 0.0277
DEBUG - 2017-08-04 06:39:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:39:22 --> Database Forge Class Initialized
INFO - 2017-08-04 06:39:22 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:39:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:57 --> Config Class Initialized
INFO - 2017-08-04 06:39:57 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:39:57 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:39:57 --> Utf8 Class Initialized
INFO - 2017-08-04 06:39:57 --> URI Class Initialized
INFO - 2017-08-04 06:39:57 --> Router Class Initialized
INFO - 2017-08-04 06:39:57 --> Output Class Initialized
INFO - 2017-08-04 06:39:57 --> Security Class Initialized
DEBUG - 2017-08-04 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:39:57 --> Input Class Initialized
INFO - 2017-08-04 06:39:57 --> Language Class Initialized
INFO - 2017-08-04 06:39:57 --> Loader Class Initialized
INFO - 2017-08-04 06:39:57 --> Helper loaded: url_helper
INFO - 2017-08-04 06:39:57 --> Helper loaded: form_helper
INFO - 2017-08-04 06:39:57 --> Helper loaded: security_helper
INFO - 2017-08-04 06:39:57 --> Helper loaded: path_helper
INFO - 2017-08-04 06:39:57 --> Helper loaded: common_helper
INFO - 2017-08-04 06:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:39:57 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:39:57 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:57 --> Email Class Initialized
INFO - 2017-08-04 06:39:57 --> Form Validation Class Initialized
INFO - 2017-08-04 06:39:57 --> Model Class Initialized
INFO - 2017-08-04 06:39:57 --> Model Class Initialized
INFO - 2017-08-04 06:39:57 --> Model Class Initialized
INFO - 2017-08-04 06:39:57 --> Model Class Initialized
INFO - 2017-08-04 06:39:57 --> Controller Class Initialized
DEBUG - 2017-08-04 06:39:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:39:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:39:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:39:57 --> Final output sent to browser
DEBUG - 2017-08-04 06:39:57 --> Total execution time: 0.0348
DEBUG - 2017-08-04 06:39:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:39:57 --> Database Forge Class Initialized
INFO - 2017-08-04 06:39:57 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:58 --> Config Class Initialized
INFO - 2017-08-04 06:39:58 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:39:58 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:39:58 --> Utf8 Class Initialized
INFO - 2017-08-04 06:39:58 --> URI Class Initialized
INFO - 2017-08-04 06:39:58 --> Router Class Initialized
INFO - 2017-08-04 06:39:58 --> Output Class Initialized
INFO - 2017-08-04 06:39:58 --> Security Class Initialized
DEBUG - 2017-08-04 06:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:39:58 --> Input Class Initialized
INFO - 2017-08-04 06:39:58 --> Language Class Initialized
INFO - 2017-08-04 06:39:58 --> Loader Class Initialized
INFO - 2017-08-04 06:39:58 --> Helper loaded: url_helper
INFO - 2017-08-04 06:39:58 --> Helper loaded: form_helper
INFO - 2017-08-04 06:39:58 --> Helper loaded: security_helper
INFO - 2017-08-04 06:39:58 --> Helper loaded: path_helper
INFO - 2017-08-04 06:39:58 --> Helper loaded: common_helper
INFO - 2017-08-04 06:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:39:58 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:39:58 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:39:58 --> Email Class Initialized
INFO - 2017-08-04 06:39:58 --> Form Validation Class Initialized
INFO - 2017-08-04 06:39:58 --> Model Class Initialized
INFO - 2017-08-04 06:39:58 --> Model Class Initialized
INFO - 2017-08-04 06:39:58 --> Model Class Initialized
INFO - 2017-08-04 06:39:58 --> Model Class Initialized
INFO - 2017-08-04 06:39:58 --> Controller Class Initialized
INFO - 2017-08-04 06:39:58 --> Model Class Initialized
INFO - 2017-08-04 06:39:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:39:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:39:58 --> Final output sent to browser
DEBUG - 2017-08-04 06:39:58 --> Total execution time: 0.0275
DEBUG - 2017-08-04 06:39:58 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:39:58 --> Database Forge Class Initialized
INFO - 2017-08-04 06:39:58 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:39:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:40:20 --> Config Class Initialized
INFO - 2017-08-04 06:40:20 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:40:20 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:40:20 --> Utf8 Class Initialized
INFO - 2017-08-04 06:40:20 --> URI Class Initialized
INFO - 2017-08-04 06:40:20 --> Router Class Initialized
INFO - 2017-08-04 06:40:20 --> Output Class Initialized
INFO - 2017-08-04 06:40:20 --> Security Class Initialized
DEBUG - 2017-08-04 06:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:40:20 --> Input Class Initialized
INFO - 2017-08-04 06:40:20 --> Language Class Initialized
INFO - 2017-08-04 06:40:20 --> Loader Class Initialized
INFO - 2017-08-04 06:40:20 --> Helper loaded: url_helper
INFO - 2017-08-04 06:40:20 --> Helper loaded: form_helper
INFO - 2017-08-04 06:40:20 --> Helper loaded: security_helper
INFO - 2017-08-04 06:40:20 --> Helper loaded: path_helper
INFO - 2017-08-04 06:40:20 --> Helper loaded: common_helper
INFO - 2017-08-04 06:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:40:20 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:40:20 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:40:20 --> Email Class Initialized
INFO - 2017-08-04 06:40:20 --> Form Validation Class Initialized
INFO - 2017-08-04 06:40:20 --> Model Class Initialized
INFO - 2017-08-04 06:40:20 --> Model Class Initialized
INFO - 2017-08-04 06:40:20 --> Model Class Initialized
INFO - 2017-08-04 06:40:20 --> Model Class Initialized
INFO - 2017-08-04 06:40:20 --> Controller Class Initialized
DEBUG - 2017-08-04 06:40:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:40:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:40:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:40:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:40:20 --> Final output sent to browser
DEBUG - 2017-08-04 06:40:20 --> Total execution time: 0.0298
DEBUG - 2017-08-04 06:40:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:40:20 --> Database Forge Class Initialized
INFO - 2017-08-04 06:40:20 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:40:23 --> Config Class Initialized
INFO - 2017-08-04 06:40:23 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:40:23 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:40:23 --> Utf8 Class Initialized
INFO - 2017-08-04 06:40:23 --> URI Class Initialized
INFO - 2017-08-04 06:40:23 --> Router Class Initialized
INFO - 2017-08-04 06:40:23 --> Output Class Initialized
INFO - 2017-08-04 06:40:23 --> Security Class Initialized
DEBUG - 2017-08-04 06:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:40:23 --> Input Class Initialized
INFO - 2017-08-04 06:40:23 --> Language Class Initialized
INFO - 2017-08-04 06:40:23 --> Loader Class Initialized
INFO - 2017-08-04 06:40:23 --> Helper loaded: url_helper
INFO - 2017-08-04 06:40:23 --> Helper loaded: form_helper
INFO - 2017-08-04 06:40:23 --> Helper loaded: security_helper
INFO - 2017-08-04 06:40:23 --> Helper loaded: path_helper
INFO - 2017-08-04 06:40:23 --> Helper loaded: common_helper
INFO - 2017-08-04 06:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:40:23 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:40:23 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:40:23 --> Email Class Initialized
INFO - 2017-08-04 06:40:23 --> Form Validation Class Initialized
INFO - 2017-08-04 06:40:23 --> Model Class Initialized
INFO - 2017-08-04 06:40:23 --> Model Class Initialized
INFO - 2017-08-04 06:40:23 --> Model Class Initialized
INFO - 2017-08-04 06:40:23 --> Model Class Initialized
INFO - 2017-08-04 06:40:23 --> Controller Class Initialized
INFO - 2017-08-04 06:40:23 --> Model Class Initialized
INFO - 2017-08-04 06:40:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:40:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:40:23 --> Final output sent to browser
DEBUG - 2017-08-04 06:40:23 --> Total execution time: 0.0260
DEBUG - 2017-08-04 06:40:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:40:23 --> Database Forge Class Initialized
INFO - 2017-08-04 06:40:23 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:06 --> Config Class Initialized
INFO - 2017-08-04 06:41:06 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:06 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:06 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:06 --> URI Class Initialized
INFO - 2017-08-04 06:41:06 --> Router Class Initialized
INFO - 2017-08-04 06:41:06 --> Output Class Initialized
INFO - 2017-08-04 06:41:06 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:06 --> Input Class Initialized
INFO - 2017-08-04 06:41:06 --> Language Class Initialized
INFO - 2017-08-04 06:41:06 --> Loader Class Initialized
INFO - 2017-08-04 06:41:06 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:06 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:06 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:06 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:06 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:06 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:06 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:06 --> Email Class Initialized
INFO - 2017-08-04 06:41:06 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:06 --> Model Class Initialized
INFO - 2017-08-04 06:41:06 --> Model Class Initialized
INFO - 2017-08-04 06:41:06 --> Model Class Initialized
INFO - 2017-08-04 06:41:06 --> Model Class Initialized
INFO - 2017-08-04 06:41:06 --> Controller Class Initialized
DEBUG - 2017-08-04 06:41:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:41:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:41:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:41:06 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:06 --> Total execution time: 0.0323
DEBUG - 2017-08-04 06:41:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:06 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:06 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:08 --> Config Class Initialized
INFO - 2017-08-04 06:41:08 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:08 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:08 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:08 --> URI Class Initialized
INFO - 2017-08-04 06:41:08 --> Router Class Initialized
INFO - 2017-08-04 06:41:08 --> Output Class Initialized
INFO - 2017-08-04 06:41:08 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:08 --> Input Class Initialized
INFO - 2017-08-04 06:41:08 --> Language Class Initialized
INFO - 2017-08-04 06:41:08 --> Loader Class Initialized
INFO - 2017-08-04 06:41:08 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:08 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:08 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:08 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:08 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:08 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:08 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:08 --> Email Class Initialized
INFO - 2017-08-04 06:41:08 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:08 --> Model Class Initialized
INFO - 2017-08-04 06:41:08 --> Model Class Initialized
INFO - 2017-08-04 06:41:08 --> Model Class Initialized
INFO - 2017-08-04 06:41:08 --> Model Class Initialized
INFO - 2017-08-04 06:41:08 --> Controller Class Initialized
INFO - 2017-08-04 06:41:08 --> Model Class Initialized
INFO - 2017-08-04 06:41:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:41:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:41:08 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:08 --> Total execution time: 0.0323
DEBUG - 2017-08-04 06:41:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:08 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:08 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:34 --> Config Class Initialized
INFO - 2017-08-04 06:41:34 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:34 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:34 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:34 --> URI Class Initialized
INFO - 2017-08-04 06:41:34 --> Router Class Initialized
INFO - 2017-08-04 06:41:34 --> Output Class Initialized
INFO - 2017-08-04 06:41:34 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:34 --> Input Class Initialized
INFO - 2017-08-04 06:41:34 --> Language Class Initialized
INFO - 2017-08-04 06:41:34 --> Loader Class Initialized
INFO - 2017-08-04 06:41:34 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:34 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:34 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:34 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:34 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:34 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:34 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:34 --> Email Class Initialized
INFO - 2017-08-04 06:41:34 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:34 --> Model Class Initialized
INFO - 2017-08-04 06:41:34 --> Model Class Initialized
INFO - 2017-08-04 06:41:34 --> Model Class Initialized
INFO - 2017-08-04 06:41:34 --> Model Class Initialized
INFO - 2017-08-04 06:41:34 --> Controller Class Initialized
DEBUG - 2017-08-04 06:41:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:41:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:41:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:41:34 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:34 --> Total execution time: 0.0348
DEBUG - 2017-08-04 06:41:34 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:34 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:34 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:36 --> Config Class Initialized
INFO - 2017-08-04 06:41:36 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:36 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:36 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:36 --> URI Class Initialized
INFO - 2017-08-04 06:41:36 --> Router Class Initialized
INFO - 2017-08-04 06:41:36 --> Output Class Initialized
INFO - 2017-08-04 06:41:36 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:36 --> Input Class Initialized
INFO - 2017-08-04 06:41:36 --> Language Class Initialized
INFO - 2017-08-04 06:41:36 --> Loader Class Initialized
INFO - 2017-08-04 06:41:36 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:36 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:36 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:36 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:36 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:36 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:36 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:36 --> Email Class Initialized
INFO - 2017-08-04 06:41:36 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:36 --> Model Class Initialized
INFO - 2017-08-04 06:41:36 --> Model Class Initialized
INFO - 2017-08-04 06:41:36 --> Model Class Initialized
INFO - 2017-08-04 06:41:36 --> Model Class Initialized
INFO - 2017-08-04 06:41:36 --> Controller Class Initialized
INFO - 2017-08-04 06:41:36 --> Model Class Initialized
INFO - 2017-08-04 06:41:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:41:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:41:36 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:36 --> Total execution time: 0.0353
DEBUG - 2017-08-04 06:41:36 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:36 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:36 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:45 --> Config Class Initialized
INFO - 2017-08-04 06:41:45 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:45 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:45 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:45 --> URI Class Initialized
INFO - 2017-08-04 06:41:45 --> Router Class Initialized
INFO - 2017-08-04 06:41:45 --> Output Class Initialized
INFO - 2017-08-04 06:41:45 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:45 --> Input Class Initialized
INFO - 2017-08-04 06:41:45 --> Language Class Initialized
INFO - 2017-08-04 06:41:45 --> Loader Class Initialized
INFO - 2017-08-04 06:41:45 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:45 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:45 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:45 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:45 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:45 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:45 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:45 --> Email Class Initialized
INFO - 2017-08-04 06:41:45 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:45 --> Model Class Initialized
INFO - 2017-08-04 06:41:45 --> Model Class Initialized
INFO - 2017-08-04 06:41:45 --> Model Class Initialized
INFO - 2017-08-04 06:41:45 --> Model Class Initialized
INFO - 2017-08-04 06:41:45 --> Controller Class Initialized
INFO - 2017-08-04 06:41:45 --> Model Class Initialized
INFO - 2017-08-04 06:41:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:41:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:41:45 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:45 --> Total execution time: 0.0268
DEBUG - 2017-08-04 06:41:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:45 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:45 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:52 --> Config Class Initialized
INFO - 2017-08-04 06:41:52 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:41:52 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:41:52 --> Utf8 Class Initialized
INFO - 2017-08-04 06:41:52 --> URI Class Initialized
INFO - 2017-08-04 06:41:52 --> Router Class Initialized
INFO - 2017-08-04 06:41:52 --> Output Class Initialized
INFO - 2017-08-04 06:41:52 --> Security Class Initialized
DEBUG - 2017-08-04 06:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:41:52 --> Input Class Initialized
INFO - 2017-08-04 06:41:52 --> Language Class Initialized
INFO - 2017-08-04 06:41:52 --> Loader Class Initialized
INFO - 2017-08-04 06:41:52 --> Helper loaded: url_helper
INFO - 2017-08-04 06:41:52 --> Helper loaded: form_helper
INFO - 2017-08-04 06:41:52 --> Helper loaded: security_helper
INFO - 2017-08-04 06:41:52 --> Helper loaded: path_helper
INFO - 2017-08-04 06:41:52 --> Helper loaded: common_helper
INFO - 2017-08-04 06:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:41:52 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:41:52 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:41:52 --> Email Class Initialized
INFO - 2017-08-04 06:41:52 --> Form Validation Class Initialized
INFO - 2017-08-04 06:41:52 --> Model Class Initialized
INFO - 2017-08-04 06:41:52 --> Model Class Initialized
INFO - 2017-08-04 06:41:52 --> Model Class Initialized
INFO - 2017-08-04 06:41:52 --> Model Class Initialized
INFO - 2017-08-04 06:41:52 --> Controller Class Initialized
INFO - 2017-08-04 06:41:52 --> Model Class Initialized
INFO - 2017-08-04 06:41:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:41:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:41:52 --> Final output sent to browser
DEBUG - 2017-08-04 06:41:52 --> Total execution time: 0.0282
DEBUG - 2017-08-04 06:41:52 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:41:52 --> Database Forge Class Initialized
INFO - 2017-08-04 06:41:52 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:32 --> Config Class Initialized
INFO - 2017-08-04 06:42:32 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:42:32 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:42:32 --> Utf8 Class Initialized
INFO - 2017-08-04 06:42:32 --> URI Class Initialized
INFO - 2017-08-04 06:42:32 --> Router Class Initialized
INFO - 2017-08-04 06:42:32 --> Output Class Initialized
INFO - 2017-08-04 06:42:32 --> Security Class Initialized
DEBUG - 2017-08-04 06:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:42:32 --> Input Class Initialized
INFO - 2017-08-04 06:42:32 --> Language Class Initialized
INFO - 2017-08-04 06:42:32 --> Loader Class Initialized
INFO - 2017-08-04 06:42:32 --> Helper loaded: url_helper
INFO - 2017-08-04 06:42:32 --> Helper loaded: form_helper
INFO - 2017-08-04 06:42:32 --> Helper loaded: security_helper
INFO - 2017-08-04 06:42:32 --> Helper loaded: path_helper
INFO - 2017-08-04 06:42:32 --> Helper loaded: common_helper
INFO - 2017-08-04 06:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:42:32 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:42:32 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:32 --> Email Class Initialized
INFO - 2017-08-04 06:42:32 --> Form Validation Class Initialized
INFO - 2017-08-04 06:42:32 --> Model Class Initialized
INFO - 2017-08-04 06:42:32 --> Model Class Initialized
INFO - 2017-08-04 06:42:32 --> Model Class Initialized
INFO - 2017-08-04 06:42:32 --> Model Class Initialized
INFO - 2017-08-04 06:42:32 --> Controller Class Initialized
INFO - 2017-08-04 06:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 06:42:32 --> Pagination Class Initialized
INFO - 2017-08-04 06:42:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:42:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 06:42:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:42:32 --> Final output sent to browser
DEBUG - 2017-08-04 06:42:32 --> Total execution time: 0.0333
DEBUG - 2017-08-04 06:42:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:42:32 --> Database Forge Class Initialized
INFO - 2017-08-04 06:42:32 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:34 --> Config Class Initialized
INFO - 2017-08-04 06:42:34 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:42:34 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:42:34 --> Utf8 Class Initialized
INFO - 2017-08-04 06:42:34 --> URI Class Initialized
INFO - 2017-08-04 06:42:34 --> Router Class Initialized
INFO - 2017-08-04 06:42:34 --> Output Class Initialized
INFO - 2017-08-04 06:42:34 --> Security Class Initialized
DEBUG - 2017-08-04 06:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:42:34 --> Input Class Initialized
INFO - 2017-08-04 06:42:34 --> Language Class Initialized
INFO - 2017-08-04 06:42:34 --> Loader Class Initialized
INFO - 2017-08-04 06:42:34 --> Helper loaded: url_helper
INFO - 2017-08-04 06:42:34 --> Helper loaded: form_helper
INFO - 2017-08-04 06:42:34 --> Helper loaded: security_helper
INFO - 2017-08-04 06:42:34 --> Helper loaded: path_helper
INFO - 2017-08-04 06:42:34 --> Helper loaded: common_helper
INFO - 2017-08-04 06:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:42:34 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:42:34 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:34 --> Email Class Initialized
INFO - 2017-08-04 06:42:34 --> Form Validation Class Initialized
INFO - 2017-08-04 06:42:34 --> Model Class Initialized
INFO - 2017-08-04 06:42:34 --> Model Class Initialized
INFO - 2017-08-04 06:42:34 --> Model Class Initialized
INFO - 2017-08-04 06:42:34 --> Model Class Initialized
INFO - 2017-08-04 06:42:34 --> Controller Class Initialized
INFO - 2017-08-04 06:42:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:42:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 06:42:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:42:34 --> Final output sent to browser
DEBUG - 2017-08-04 06:42:34 --> Total execution time: 0.0303
DEBUG - 2017-08-04 06:42:34 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:42:34 --> Database Forge Class Initialized
INFO - 2017-08-04 06:42:34 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:42:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:39 --> Config Class Initialized
INFO - 2017-08-04 06:42:39 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:42:39 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:42:39 --> Utf8 Class Initialized
INFO - 2017-08-04 06:42:39 --> URI Class Initialized
INFO - 2017-08-04 06:42:39 --> Router Class Initialized
INFO - 2017-08-04 06:42:39 --> Output Class Initialized
INFO - 2017-08-04 06:42:39 --> Security Class Initialized
DEBUG - 2017-08-04 06:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:42:39 --> Input Class Initialized
INFO - 2017-08-04 06:42:39 --> Language Class Initialized
INFO - 2017-08-04 06:42:39 --> Loader Class Initialized
INFO - 2017-08-04 06:42:39 --> Helper loaded: url_helper
INFO - 2017-08-04 06:42:39 --> Helper loaded: form_helper
INFO - 2017-08-04 06:42:39 --> Helper loaded: security_helper
INFO - 2017-08-04 06:42:39 --> Helper loaded: path_helper
INFO - 2017-08-04 06:42:39 --> Helper loaded: common_helper
INFO - 2017-08-04 06:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:42:39 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:42:39 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:39 --> Email Class Initialized
INFO - 2017-08-04 06:42:39 --> Form Validation Class Initialized
INFO - 2017-08-04 06:42:39 --> Model Class Initialized
INFO - 2017-08-04 06:42:39 --> Model Class Initialized
INFO - 2017-08-04 06:42:39 --> Model Class Initialized
INFO - 2017-08-04 06:42:39 --> Model Class Initialized
INFO - 2017-08-04 06:42:39 --> Controller Class Initialized
DEBUG - 2017-08-04 06:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:42:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:42:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:42:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:42:39 --> Final output sent to browser
DEBUG - 2017-08-04 06:42:39 --> Total execution time: 0.0272
DEBUG - 2017-08-04 06:42:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:42:39 --> Database Forge Class Initialized
INFO - 2017-08-04 06:42:39 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:43:23 --> Config Class Initialized
INFO - 2017-08-04 06:43:23 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:43:23 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:43:23 --> Utf8 Class Initialized
INFO - 2017-08-04 06:43:23 --> URI Class Initialized
INFO - 2017-08-04 06:43:23 --> Router Class Initialized
INFO - 2017-08-04 06:43:23 --> Output Class Initialized
INFO - 2017-08-04 06:43:23 --> Security Class Initialized
DEBUG - 2017-08-04 06:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:43:23 --> Input Class Initialized
INFO - 2017-08-04 06:43:23 --> Language Class Initialized
INFO - 2017-08-04 06:43:23 --> Loader Class Initialized
INFO - 2017-08-04 06:43:23 --> Helper loaded: url_helper
INFO - 2017-08-04 06:43:23 --> Helper loaded: form_helper
INFO - 2017-08-04 06:43:23 --> Helper loaded: security_helper
INFO - 2017-08-04 06:43:23 --> Helper loaded: path_helper
INFO - 2017-08-04 06:43:23 --> Helper loaded: common_helper
INFO - 2017-08-04 06:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:43:23 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:43:23 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:43:23 --> Email Class Initialized
INFO - 2017-08-04 06:43:23 --> Form Validation Class Initialized
INFO - 2017-08-04 06:43:23 --> Model Class Initialized
INFO - 2017-08-04 06:43:23 --> Model Class Initialized
INFO - 2017-08-04 06:43:23 --> Model Class Initialized
INFO - 2017-08-04 06:43:23 --> Model Class Initialized
INFO - 2017-08-04 06:43:23 --> Controller Class Initialized
DEBUG - 2017-08-04 06:43:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:43:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 06:43:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 06:43:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 06:43:23 --> Final output sent to browser
DEBUG - 2017-08-04 06:43:23 --> Total execution time: 0.0328
DEBUG - 2017-08-04 06:43:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:43:23 --> Database Forge Class Initialized
INFO - 2017-08-04 06:43:23 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:43:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:43:38 --> Config Class Initialized
INFO - 2017-08-04 06:43:38 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:43:38 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:43:38 --> Utf8 Class Initialized
INFO - 2017-08-04 06:43:38 --> URI Class Initialized
INFO - 2017-08-04 06:43:38 --> Router Class Initialized
INFO - 2017-08-04 06:43:38 --> Output Class Initialized
INFO - 2017-08-04 06:43:38 --> Security Class Initialized
DEBUG - 2017-08-04 06:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:43:38 --> Input Class Initialized
INFO - 2017-08-04 06:43:38 --> Language Class Initialized
INFO - 2017-08-04 06:43:38 --> Loader Class Initialized
INFO - 2017-08-04 06:43:38 --> Helper loaded: url_helper
INFO - 2017-08-04 06:43:38 --> Helper loaded: form_helper
INFO - 2017-08-04 06:43:38 --> Helper loaded: security_helper
INFO - 2017-08-04 06:43:38 --> Helper loaded: path_helper
INFO - 2017-08-04 06:43:38 --> Helper loaded: common_helper
INFO - 2017-08-04 06:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:43:38 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:43:38 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:43:38 --> Email Class Initialized
INFO - 2017-08-04 06:43:38 --> Form Validation Class Initialized
INFO - 2017-08-04 06:43:38 --> Model Class Initialized
INFO - 2017-08-04 06:43:38 --> Model Class Initialized
INFO - 2017-08-04 06:43:38 --> Model Class Initialized
INFO - 2017-08-04 06:43:38 --> Model Class Initialized
INFO - 2017-08-04 06:43:38 --> Controller Class Initialized
INFO - 2017-08-04 06:43:38 --> Model Class Initialized
INFO - 2017-08-04 06:43:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 06:43:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 06:43:38 --> Final output sent to browser
DEBUG - 2017-08-04 06:43:38 --> Total execution time: 0.0279
DEBUG - 2017-08-04 06:43:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:43:38 --> Database Forge Class Initialized
INFO - 2017-08-04 06:43:38 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:49:09 --> Config Class Initialized
INFO - 2017-08-04 06:49:09 --> Hooks Class Initialized
DEBUG - 2017-08-04 06:49:09 --> UTF-8 Support Enabled
INFO - 2017-08-04 06:49:09 --> Utf8 Class Initialized
INFO - 2017-08-04 06:49:09 --> URI Class Initialized
DEBUG - 2017-08-04 06:49:09 --> No URI present. Default controller set.
INFO - 2017-08-04 06:49:09 --> Router Class Initialized
INFO - 2017-08-04 06:49:09 --> Output Class Initialized
INFO - 2017-08-04 06:49:09 --> Security Class Initialized
DEBUG - 2017-08-04 06:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 06:49:09 --> Input Class Initialized
INFO - 2017-08-04 06:49:09 --> Language Class Initialized
INFO - 2017-08-04 06:49:09 --> Loader Class Initialized
INFO - 2017-08-04 06:49:09 --> Helper loaded: url_helper
INFO - 2017-08-04 06:49:09 --> Helper loaded: form_helper
INFO - 2017-08-04 06:49:09 --> Helper loaded: security_helper
INFO - 2017-08-04 06:49:09 --> Helper loaded: path_helper
INFO - 2017-08-04 06:49:09 --> Helper loaded: common_helper
INFO - 2017-08-04 06:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 06:49:09 --> Helper loaded: check_session_helper
INFO - 2017-08-04 06:49:09 --> Database Driver Class Initialized
DEBUG - 2017-08-04 06:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:49:09 --> Email Class Initialized
INFO - 2017-08-04 06:49:09 --> Form Validation Class Initialized
INFO - 2017-08-04 06:49:09 --> Model Class Initialized
INFO - 2017-08-04 06:49:09 --> Model Class Initialized
INFO - 2017-08-04 06:49:09 --> Model Class Initialized
INFO - 2017-08-04 06:49:09 --> Model Class Initialized
INFO - 2017-08-04 06:49:09 --> Controller Class Initialized
DEBUG - 2017-08-04 06:49:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 06:49:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 06:49:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 06:49:09 --> Final output sent to browser
DEBUG - 2017-08-04 06:49:09 --> Total execution time: 0.0282
DEBUG - 2017-08-04 06:49:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 06:49:09 --> Database Forge Class Initialized
INFO - 2017-08-04 06:49:09 --> User Agent Class Initialized
DEBUG - 2017-08-04 06:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:14:27 --> Config Class Initialized
INFO - 2017-08-04 07:14:27 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:14:27 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:14:27 --> Utf8 Class Initialized
INFO - 2017-08-04 07:14:27 --> URI Class Initialized
DEBUG - 2017-08-04 07:14:27 --> No URI present. Default controller set.
INFO - 2017-08-04 07:14:27 --> Router Class Initialized
INFO - 2017-08-04 07:14:27 --> Output Class Initialized
INFO - 2017-08-04 07:14:27 --> Security Class Initialized
DEBUG - 2017-08-04 07:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:14:27 --> Input Class Initialized
INFO - 2017-08-04 07:14:27 --> Language Class Initialized
INFO - 2017-08-04 07:14:27 --> Loader Class Initialized
INFO - 2017-08-04 07:14:27 --> Helper loaded: url_helper
INFO - 2017-08-04 07:14:27 --> Helper loaded: form_helper
INFO - 2017-08-04 07:14:27 --> Helper loaded: security_helper
INFO - 2017-08-04 07:14:27 --> Helper loaded: path_helper
INFO - 2017-08-04 07:14:27 --> Helper loaded: common_helper
INFO - 2017-08-04 07:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:14:27 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:14:27 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:14:27 --> Email Class Initialized
INFO - 2017-08-04 07:14:27 --> Form Validation Class Initialized
INFO - 2017-08-04 07:14:27 --> Model Class Initialized
INFO - 2017-08-04 07:14:27 --> Model Class Initialized
INFO - 2017-08-04 07:14:27 --> Model Class Initialized
INFO - 2017-08-04 07:14:27 --> Model Class Initialized
INFO - 2017-08-04 07:14:27 --> Controller Class Initialized
DEBUG - 2017-08-04 07:14:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:14:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 07:14:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 07:14:27 --> Final output sent to browser
DEBUG - 2017-08-04 07:14:27 --> Total execution time: 0.0310
DEBUG - 2017-08-04 07:14:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:14:27 --> Database Forge Class Initialized
INFO - 2017-08-04 07:14:27 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:48:39 --> Config Class Initialized
INFO - 2017-08-04 07:48:39 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:48:39 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:48:39 --> Utf8 Class Initialized
INFO - 2017-08-04 07:48:39 --> URI Class Initialized
DEBUG - 2017-08-04 07:48:39 --> No URI present. Default controller set.
INFO - 2017-08-04 07:48:39 --> Router Class Initialized
INFO - 2017-08-04 07:48:39 --> Output Class Initialized
INFO - 2017-08-04 07:48:39 --> Security Class Initialized
DEBUG - 2017-08-04 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:48:39 --> Input Class Initialized
INFO - 2017-08-04 07:48:39 --> Language Class Initialized
INFO - 2017-08-04 07:48:39 --> Loader Class Initialized
INFO - 2017-08-04 07:48:39 --> Helper loaded: url_helper
INFO - 2017-08-04 07:48:39 --> Helper loaded: form_helper
INFO - 2017-08-04 07:48:39 --> Helper loaded: security_helper
INFO - 2017-08-04 07:48:39 --> Helper loaded: path_helper
INFO - 2017-08-04 07:48:39 --> Helper loaded: common_helper
INFO - 2017-08-04 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:48:39 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:48:39 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:48:39 --> Email Class Initialized
INFO - 2017-08-04 07:48:39 --> Form Validation Class Initialized
INFO - 2017-08-04 07:48:39 --> Model Class Initialized
INFO - 2017-08-04 07:48:39 --> Model Class Initialized
INFO - 2017-08-04 07:48:39 --> Model Class Initialized
INFO - 2017-08-04 07:48:39 --> Model Class Initialized
INFO - 2017-08-04 07:48:39 --> Controller Class Initialized
DEBUG - 2017-08-04 07:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:48:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 07:48:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 07:48:39 --> Final output sent to browser
DEBUG - 2017-08-04 07:48:39 --> Total execution time: 0.0281
DEBUG - 2017-08-04 07:48:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:48:39 --> Database Forge Class Initialized
INFO - 2017-08-04 07:48:39 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:48:43 --> Config Class Initialized
INFO - 2017-08-04 07:48:43 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:48:43 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:48:43 --> Utf8 Class Initialized
INFO - 2017-08-04 07:48:43 --> URI Class Initialized
INFO - 2017-08-04 07:48:43 --> Router Class Initialized
INFO - 2017-08-04 07:48:43 --> Output Class Initialized
INFO - 2017-08-04 07:48:43 --> Security Class Initialized
DEBUG - 2017-08-04 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:48:43 --> Input Class Initialized
INFO - 2017-08-04 07:48:43 --> Language Class Initialized
INFO - 2017-08-04 07:48:43 --> Loader Class Initialized
INFO - 2017-08-04 07:48:43 --> Helper loaded: url_helper
INFO - 2017-08-04 07:48:43 --> Helper loaded: form_helper
INFO - 2017-08-04 07:48:43 --> Helper loaded: security_helper
INFO - 2017-08-04 07:48:43 --> Helper loaded: path_helper
INFO - 2017-08-04 07:48:43 --> Helper loaded: common_helper
INFO - 2017-08-04 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:48:43 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:48:43 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:48:43 --> Email Class Initialized
INFO - 2017-08-04 07:48:43 --> Form Validation Class Initialized
INFO - 2017-08-04 07:48:43 --> Model Class Initialized
INFO - 2017-08-04 07:48:43 --> Model Class Initialized
INFO - 2017-08-04 07:48:43 --> Model Class Initialized
INFO - 2017-08-04 07:48:43 --> Model Class Initialized
INFO - 2017-08-04 07:48:43 --> Controller Class Initialized
INFO - 2017-08-04 07:48:43 --> Model Class Initialized
INFO - 2017-08-04 07:48:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 07:48:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 07:48:43 --> Final output sent to browser
DEBUG - 2017-08-04 07:48:43 --> Total execution time: 0.0264
DEBUG - 2017-08-04 07:48:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:48:43 --> Database Forge Class Initialized
INFO - 2017-08-04 07:48:43 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:04 --> Config Class Initialized
INFO - 2017-08-04 07:49:04 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:49:04 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:49:04 --> Utf8 Class Initialized
INFO - 2017-08-04 07:49:04 --> URI Class Initialized
INFO - 2017-08-04 07:49:04 --> Router Class Initialized
INFO - 2017-08-04 07:49:04 --> Output Class Initialized
INFO - 2017-08-04 07:49:04 --> Security Class Initialized
DEBUG - 2017-08-04 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:49:04 --> Input Class Initialized
INFO - 2017-08-04 07:49:04 --> Language Class Initialized
INFO - 2017-08-04 07:49:04 --> Loader Class Initialized
INFO - 2017-08-04 07:49:04 --> Helper loaded: url_helper
INFO - 2017-08-04 07:49:04 --> Helper loaded: form_helper
INFO - 2017-08-04 07:49:04 --> Helper loaded: security_helper
INFO - 2017-08-04 07:49:04 --> Helper loaded: path_helper
INFO - 2017-08-04 07:49:04 --> Helper loaded: common_helper
INFO - 2017-08-04 07:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:49:04 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:49:04 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:04 --> Email Class Initialized
INFO - 2017-08-04 07:49:04 --> Form Validation Class Initialized
INFO - 2017-08-04 07:49:04 --> Model Class Initialized
INFO - 2017-08-04 07:49:04 --> Model Class Initialized
INFO - 2017-08-04 07:49:04 --> Model Class Initialized
INFO - 2017-08-04 07:49:04 --> Model Class Initialized
INFO - 2017-08-04 07:49:04 --> Controller Class Initialized
INFO - 2017-08-04 07:49:04 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 07:49:04 --> Final output sent to browser
DEBUG - 2017-08-04 07:49:04 --> Total execution time: 0.0243
DEBUG - 2017-08-04 07:49:04 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:49:04 --> Database Forge Class Initialized
INFO - 2017-08-04 07:49:04 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:11 --> Config Class Initialized
INFO - 2017-08-04 07:49:11 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:49:11 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:49:11 --> Utf8 Class Initialized
INFO - 2017-08-04 07:49:11 --> URI Class Initialized
INFO - 2017-08-04 07:49:11 --> Router Class Initialized
INFO - 2017-08-04 07:49:11 --> Output Class Initialized
INFO - 2017-08-04 07:49:11 --> Security Class Initialized
DEBUG - 2017-08-04 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:49:11 --> Input Class Initialized
INFO - 2017-08-04 07:49:11 --> Language Class Initialized
INFO - 2017-08-04 07:49:11 --> Loader Class Initialized
INFO - 2017-08-04 07:49:11 --> Helper loaded: url_helper
INFO - 2017-08-04 07:49:11 --> Helper loaded: form_helper
INFO - 2017-08-04 07:49:11 --> Helper loaded: security_helper
INFO - 2017-08-04 07:49:11 --> Helper loaded: path_helper
INFO - 2017-08-04 07:49:11 --> Helper loaded: common_helper
INFO - 2017-08-04 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:49:11 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:49:11 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:11 --> Email Class Initialized
INFO - 2017-08-04 07:49:11 --> Form Validation Class Initialized
INFO - 2017-08-04 07:49:11 --> Model Class Initialized
INFO - 2017-08-04 07:49:11 --> Model Class Initialized
INFO - 2017-08-04 07:49:11 --> Model Class Initialized
INFO - 2017-08-04 07:49:11 --> Model Class Initialized
INFO - 2017-08-04 07:49:11 --> Controller Class Initialized
INFO - 2017-08-04 07:49:12 --> Config Class Initialized
INFO - 2017-08-04 07:49:12 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:49:12 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:49:12 --> Utf8 Class Initialized
INFO - 2017-08-04 07:49:12 --> URI Class Initialized
INFO - 2017-08-04 07:49:12 --> Router Class Initialized
INFO - 2017-08-04 07:49:12 --> Output Class Initialized
INFO - 2017-08-04 07:49:12 --> Security Class Initialized
DEBUG - 2017-08-04 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:49:12 --> Input Class Initialized
INFO - 2017-08-04 07:49:12 --> Language Class Initialized
INFO - 2017-08-04 07:49:12 --> Loader Class Initialized
INFO - 2017-08-04 07:49:12 --> Helper loaded: url_helper
INFO - 2017-08-04 07:49:12 --> Helper loaded: form_helper
INFO - 2017-08-04 07:49:12 --> Helper loaded: security_helper
INFO - 2017-08-04 07:49:12 --> Helper loaded: path_helper
INFO - 2017-08-04 07:49:12 --> Helper loaded: common_helper
INFO - 2017-08-04 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:49:12 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:49:12 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:12 --> Email Class Initialized
INFO - 2017-08-04 07:49:12 --> Form Validation Class Initialized
INFO - 2017-08-04 07:49:12 --> Model Class Initialized
INFO - 2017-08-04 07:49:12 --> Model Class Initialized
INFO - 2017-08-04 07:49:12 --> Model Class Initialized
INFO - 2017-08-04 07:49:12 --> Model Class Initialized
INFO - 2017-08-04 07:49:12 --> Controller Class Initialized
INFO - 2017-08-04 07:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 07:49:12 --> Pagination Class Initialized
INFO - 2017-08-04 07:49:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 07:49:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 07:49:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 07:49:12 --> Final output sent to browser
DEBUG - 2017-08-04 07:49:12 --> Total execution time: 0.0335
DEBUG - 2017-08-04 07:49:12 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:49:12 --> Database Forge Class Initialized
INFO - 2017-08-04 07:49:12 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:20 --> Config Class Initialized
INFO - 2017-08-04 07:49:20 --> Hooks Class Initialized
DEBUG - 2017-08-04 07:49:20 --> UTF-8 Support Enabled
INFO - 2017-08-04 07:49:20 --> Utf8 Class Initialized
INFO - 2017-08-04 07:49:20 --> URI Class Initialized
INFO - 2017-08-04 07:49:20 --> Router Class Initialized
INFO - 2017-08-04 07:49:20 --> Output Class Initialized
INFO - 2017-08-04 07:49:20 --> Security Class Initialized
DEBUG - 2017-08-04 07:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 07:49:20 --> Input Class Initialized
INFO - 2017-08-04 07:49:20 --> Language Class Initialized
INFO - 2017-08-04 07:49:20 --> Loader Class Initialized
INFO - 2017-08-04 07:49:20 --> Helper loaded: url_helper
INFO - 2017-08-04 07:49:20 --> Helper loaded: form_helper
INFO - 2017-08-04 07:49:20 --> Helper loaded: security_helper
INFO - 2017-08-04 07:49:20 --> Helper loaded: path_helper
INFO - 2017-08-04 07:49:20 --> Helper loaded: common_helper
INFO - 2017-08-04 07:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 07:49:20 --> Helper loaded: check_session_helper
INFO - 2017-08-04 07:49:20 --> Database Driver Class Initialized
DEBUG - 2017-08-04 07:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 07:49:20 --> Email Class Initialized
INFO - 2017-08-04 07:49:20 --> Form Validation Class Initialized
INFO - 2017-08-04 07:49:20 --> Model Class Initialized
INFO - 2017-08-04 07:49:20 --> Model Class Initialized
INFO - 2017-08-04 07:49:20 --> Model Class Initialized
INFO - 2017-08-04 07:49:20 --> Model Class Initialized
INFO - 2017-08-04 07:49:20 --> Controller Class Initialized
INFO - 2017-08-04 07:49:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 07:49:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 07:49:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 07:49:20 --> Final output sent to browser
DEBUG - 2017-08-04 07:49:20 --> Total execution time: 0.0287
DEBUG - 2017-08-04 07:49:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 07:49:20 --> Database Forge Class Initialized
INFO - 2017-08-04 07:49:20 --> User Agent Class Initialized
DEBUG - 2017-08-04 07:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:05:45 --> Config Class Initialized
INFO - 2017-08-04 08:05:45 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:05:45 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:05:45 --> Utf8 Class Initialized
INFO - 2017-08-04 08:05:45 --> URI Class Initialized
INFO - 2017-08-04 08:05:45 --> Router Class Initialized
INFO - 2017-08-04 08:05:45 --> Output Class Initialized
INFO - 2017-08-04 08:05:45 --> Security Class Initialized
DEBUG - 2017-08-04 08:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:05:45 --> Input Class Initialized
INFO - 2017-08-04 08:05:45 --> Language Class Initialized
INFO - 2017-08-04 08:05:45 --> Loader Class Initialized
INFO - 2017-08-04 08:05:45 --> Helper loaded: url_helper
INFO - 2017-08-04 08:05:45 --> Helper loaded: form_helper
INFO - 2017-08-04 08:05:45 --> Helper loaded: security_helper
INFO - 2017-08-04 08:05:45 --> Helper loaded: path_helper
INFO - 2017-08-04 08:05:45 --> Helper loaded: common_helper
INFO - 2017-08-04 08:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:05:45 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:05:45 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:05:45 --> Email Class Initialized
INFO - 2017-08-04 08:05:45 --> Form Validation Class Initialized
INFO - 2017-08-04 08:05:45 --> Model Class Initialized
INFO - 2017-08-04 08:05:45 --> Model Class Initialized
INFO - 2017-08-04 08:05:45 --> Model Class Initialized
INFO - 2017-08-04 08:05:45 --> Model Class Initialized
INFO - 2017-08-04 08:05:45 --> Controller Class Initialized
INFO - 2017-08-04 08:05:45 --> Model Class Initialized
INFO - 2017-08-04 08:05:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:05:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:05:45 --> Final output sent to browser
DEBUG - 2017-08-04 08:05:45 --> Total execution time: 0.0324
DEBUG - 2017-08-04 08:05:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:05:45 --> Database Forge Class Initialized
INFO - 2017-08-04 08:05:45 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:05:54 --> Config Class Initialized
INFO - 2017-08-04 08:05:54 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:05:54 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:05:54 --> Utf8 Class Initialized
INFO - 2017-08-04 08:05:54 --> URI Class Initialized
INFO - 2017-08-04 08:05:54 --> Router Class Initialized
INFO - 2017-08-04 08:05:54 --> Output Class Initialized
INFO - 2017-08-04 08:05:54 --> Security Class Initialized
DEBUG - 2017-08-04 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:05:54 --> Input Class Initialized
INFO - 2017-08-04 08:05:54 --> Language Class Initialized
ERROR - 2017-08-04 08:05:54 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 08:24:47 --> Config Class Initialized
INFO - 2017-08-04 08:24:47 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:24:47 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:24:47 --> Utf8 Class Initialized
INFO - 2017-08-04 08:24:47 --> URI Class Initialized
INFO - 2017-08-04 08:24:47 --> Router Class Initialized
INFO - 2017-08-04 08:24:47 --> Output Class Initialized
INFO - 2017-08-04 08:24:47 --> Security Class Initialized
DEBUG - 2017-08-04 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:24:47 --> Input Class Initialized
INFO - 2017-08-04 08:24:47 --> Language Class Initialized
INFO - 2017-08-04 08:24:47 --> Loader Class Initialized
INFO - 2017-08-04 08:24:47 --> Helper loaded: url_helper
INFO - 2017-08-04 08:24:47 --> Helper loaded: form_helper
INFO - 2017-08-04 08:24:47 --> Helper loaded: security_helper
INFO - 2017-08-04 08:24:47 --> Helper loaded: path_helper
INFO - 2017-08-04 08:24:47 --> Helper loaded: common_helper
INFO - 2017-08-04 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:24:47 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:24:47 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:24:47 --> Email Class Initialized
INFO - 2017-08-04 08:24:47 --> Form Validation Class Initialized
INFO - 2017-08-04 08:24:47 --> Model Class Initialized
INFO - 2017-08-04 08:24:47 --> Model Class Initialized
INFO - 2017-08-04 08:24:47 --> Model Class Initialized
INFO - 2017-08-04 08:24:47 --> Model Class Initialized
INFO - 2017-08-04 08:24:47 --> Controller Class Initialized
INFO - 2017-08-04 08:24:47 --> Model Class Initialized
INFO - 2017-08-04 08:24:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:24:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:24:47 --> Final output sent to browser
DEBUG - 2017-08-04 08:24:47 --> Total execution time: 0.0308
DEBUG - 2017-08-04 08:24:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:24:47 --> Database Forge Class Initialized
INFO - 2017-08-04 08:24:47 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:24:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:24:57 --> Config Class Initialized
INFO - 2017-08-04 08:24:57 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:24:57 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:24:57 --> Utf8 Class Initialized
INFO - 2017-08-04 08:24:57 --> URI Class Initialized
INFO - 2017-08-04 08:24:57 --> Router Class Initialized
INFO - 2017-08-04 08:24:57 --> Output Class Initialized
INFO - 2017-08-04 08:24:57 --> Security Class Initialized
DEBUG - 2017-08-04 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:24:57 --> Input Class Initialized
INFO - 2017-08-04 08:24:57 --> Language Class Initialized
INFO - 2017-08-04 08:24:57 --> Loader Class Initialized
INFO - 2017-08-04 08:24:57 --> Helper loaded: url_helper
INFO - 2017-08-04 08:24:57 --> Helper loaded: form_helper
INFO - 2017-08-04 08:24:57 --> Helper loaded: security_helper
INFO - 2017-08-04 08:24:57 --> Helper loaded: path_helper
INFO - 2017-08-04 08:24:57 --> Helper loaded: common_helper
INFO - 2017-08-04 08:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:24:57 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:24:57 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:24:57 --> Email Class Initialized
INFO - 2017-08-04 08:24:57 --> Form Validation Class Initialized
INFO - 2017-08-04 08:24:57 --> Model Class Initialized
INFO - 2017-08-04 08:24:57 --> Model Class Initialized
INFO - 2017-08-04 08:24:57 --> Model Class Initialized
INFO - 2017-08-04 08:24:57 --> Model Class Initialized
INFO - 2017-08-04 08:24:57 --> Controller Class Initialized
INFO - 2017-08-04 08:24:57 --> Model Class Initialized
INFO - 2017-08-04 08:24:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:24:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:24:57 --> Final output sent to browser
DEBUG - 2017-08-04 08:24:57 --> Total execution time: 0.0258
DEBUG - 2017-08-04 08:24:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:24:57 --> Database Forge Class Initialized
INFO - 2017-08-04 08:24:57 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:01 --> Config Class Initialized
INFO - 2017-08-04 08:26:01 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:01 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:01 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:01 --> URI Class Initialized
DEBUG - 2017-08-04 08:26:01 --> No URI present. Default controller set.
INFO - 2017-08-04 08:26:01 --> Router Class Initialized
INFO - 2017-08-04 08:26:01 --> Output Class Initialized
INFO - 2017-08-04 08:26:01 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:01 --> Input Class Initialized
INFO - 2017-08-04 08:26:01 --> Language Class Initialized
INFO - 2017-08-04 08:26:01 --> Loader Class Initialized
INFO - 2017-08-04 08:26:01 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:01 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:01 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:01 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:01 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:01 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:01 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:01 --> Email Class Initialized
INFO - 2017-08-04 08:26:01 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:01 --> Model Class Initialized
INFO - 2017-08-04 08:26:01 --> Model Class Initialized
INFO - 2017-08-04 08:26:01 --> Model Class Initialized
INFO - 2017-08-04 08:26:01 --> Model Class Initialized
INFO - 2017-08-04 08:26:01 --> Controller Class Initialized
DEBUG - 2017-08-04 08:26:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 08:26:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 08:26:01 --> Final output sent to browser
DEBUG - 2017-08-04 08:26:01 --> Total execution time: 0.0301
DEBUG - 2017-08-04 08:26:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:26:01 --> Database Forge Class Initialized
INFO - 2017-08-04 08:26:01 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:06 --> Config Class Initialized
INFO - 2017-08-04 08:26:06 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:06 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:06 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:06 --> URI Class Initialized
DEBUG - 2017-08-04 08:26:06 --> No URI present. Default controller set.
INFO - 2017-08-04 08:26:06 --> Router Class Initialized
INFO - 2017-08-04 08:26:06 --> Output Class Initialized
INFO - 2017-08-04 08:26:06 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:06 --> Input Class Initialized
INFO - 2017-08-04 08:26:06 --> Language Class Initialized
INFO - 2017-08-04 08:26:06 --> Loader Class Initialized
INFO - 2017-08-04 08:26:06 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:06 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:06 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:06 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:06 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:06 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:06 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:06 --> Email Class Initialized
INFO - 2017-08-04 08:26:06 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:06 --> Model Class Initialized
INFO - 2017-08-04 08:26:06 --> Model Class Initialized
INFO - 2017-08-04 08:26:06 --> Model Class Initialized
INFO - 2017-08-04 08:26:06 --> Model Class Initialized
INFO - 2017-08-04 08:26:06 --> Controller Class Initialized
DEBUG - 2017-08-04 08:26:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-04 08:26:07 --> Config Class Initialized
INFO - 2017-08-04 08:26:07 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:07 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:07 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:07 --> URI Class Initialized
INFO - 2017-08-04 08:26:07 --> Router Class Initialized
INFO - 2017-08-04 08:26:07 --> Output Class Initialized
INFO - 2017-08-04 08:26:07 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:07 --> Input Class Initialized
INFO - 2017-08-04 08:26:07 --> Language Class Initialized
INFO - 2017-08-04 08:26:07 --> Loader Class Initialized
INFO - 2017-08-04 08:26:07 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:07 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:07 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:07 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:07 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:07 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:07 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:07 --> Email Class Initialized
INFO - 2017-08-04 08:26:07 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:07 --> Model Class Initialized
INFO - 2017-08-04 08:26:07 --> Model Class Initialized
INFO - 2017-08-04 08:26:07 --> Model Class Initialized
INFO - 2017-08-04 08:26:07 --> Model Class Initialized
INFO - 2017-08-04 08:26:07 --> Controller Class Initialized
INFO - 2017-08-04 08:26:07 --> Model Class Initialized
INFO - 2017-08-04 08:26:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/header.php
INFO - 2017-08-04 08:26:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/left_menu.php
INFO - 2017-08-04 08:26:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/inperson_tumorboard.php
INFO - 2017-08-04 08:26:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/footer.php
INFO - 2017-08-04 08:26:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/template.php
INFO - 2017-08-04 08:26:07 --> Final output sent to browser
DEBUG - 2017-08-04 08:26:07 --> Total execution time: 0.6251
DEBUG - 2017-08-04 08:26:07 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:26:07 --> Database Forge Class Initialized
INFO - 2017-08-04 08:26:07 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:26:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:17 --> Config Class Initialized
INFO - 2017-08-04 08:26:17 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:17 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:17 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:17 --> URI Class Initialized
INFO - 2017-08-04 08:26:17 --> Router Class Initialized
INFO - 2017-08-04 08:26:17 --> Output Class Initialized
INFO - 2017-08-04 08:26:17 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:17 --> Input Class Initialized
INFO - 2017-08-04 08:26:17 --> Language Class Initialized
INFO - 2017-08-04 08:26:17 --> Loader Class Initialized
INFO - 2017-08-04 08:26:17 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:17 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:17 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:17 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:17 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:17 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:17 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:17 --> Email Class Initialized
INFO - 2017-08-04 08:26:17 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:17 --> Model Class Initialized
INFO - 2017-08-04 08:26:17 --> Model Class Initialized
INFO - 2017-08-04 08:26:17 --> Model Class Initialized
INFO - 2017-08-04 08:26:17 --> Model Class Initialized
INFO - 2017-08-04 08:26:17 --> Controller Class Initialized
INFO - 2017-08-04 08:26:17 --> Model Class Initialized
INFO - 2017-08-04 08:26:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/header.php
INFO - 2017-08-04 08:26:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/left_menu.php
INFO - 2017-08-04 08:26:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/answer_opencase.php
INFO - 2017-08-04 08:26:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/footer.php
INFO - 2017-08-04 08:26:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/template.php
INFO - 2017-08-04 08:26:17 --> Final output sent to browser
DEBUG - 2017-08-04 08:26:17 --> Total execution time: 0.0859
DEBUG - 2017-08-04 08:26:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:26:17 --> Database Forge Class Initialized
INFO - 2017-08-04 08:26:17 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:31 --> Config Class Initialized
INFO - 2017-08-04 08:26:31 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:31 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:31 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:31 --> URI Class Initialized
INFO - 2017-08-04 08:26:31 --> Router Class Initialized
INFO - 2017-08-04 08:26:31 --> Output Class Initialized
INFO - 2017-08-04 08:26:31 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:31 --> Input Class Initialized
INFO - 2017-08-04 08:26:31 --> Language Class Initialized
INFO - 2017-08-04 08:26:31 --> Loader Class Initialized
INFO - 2017-08-04 08:26:31 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:31 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:31 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:31 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:31 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:31 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:31 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:31 --> Email Class Initialized
INFO - 2017-08-04 08:26:31 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:31 --> Model Class Initialized
INFO - 2017-08-04 08:26:31 --> Model Class Initialized
INFO - 2017-08-04 08:26:31 --> Model Class Initialized
INFO - 2017-08-04 08:26:31 --> Model Class Initialized
INFO - 2017-08-04 08:26:31 --> Controller Class Initialized
INFO - 2017-08-04 08:26:33 --> Helper loaded: captcha_helper
INFO - 2017-08-04 08:26:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-08-04 08:26:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:26:33 --> Final output sent to browser
DEBUG - 2017-08-04 08:26:33 --> Total execution time: 1.7939
DEBUG - 2017-08-04 08:26:33 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:26:33 --> Database Forge Class Initialized
INFO - 2017-08-04 08:26:33 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:52 --> Config Class Initialized
INFO - 2017-08-04 08:26:52 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:52 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:52 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:52 --> URI Class Initialized
DEBUG - 2017-08-04 08:26:52 --> No URI present. Default controller set.
INFO - 2017-08-04 08:26:52 --> Router Class Initialized
INFO - 2017-08-04 08:26:52 --> Output Class Initialized
INFO - 2017-08-04 08:26:52 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:52 --> Input Class Initialized
INFO - 2017-08-04 08:26:52 --> Language Class Initialized
INFO - 2017-08-04 08:26:52 --> Loader Class Initialized
INFO - 2017-08-04 08:26:52 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:52 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:52 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:52 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:52 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:52 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:52 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:52 --> Email Class Initialized
INFO - 2017-08-04 08:26:52 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:52 --> Model Class Initialized
INFO - 2017-08-04 08:26:52 --> Model Class Initialized
INFO - 2017-08-04 08:26:52 --> Model Class Initialized
INFO - 2017-08-04 08:26:52 --> Model Class Initialized
INFO - 2017-08-04 08:26:52 --> Controller Class Initialized
INFO - 2017-08-04 08:26:52 --> Config Class Initialized
INFO - 2017-08-04 08:26:52 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:52 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:52 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:52 --> URI Class Initialized
INFO - 2017-08-04 08:26:52 --> Router Class Initialized
INFO - 2017-08-04 08:26:52 --> Output Class Initialized
INFO - 2017-08-04 08:26:52 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:52 --> Input Class Initialized
INFO - 2017-08-04 08:26:52 --> Language Class Initialized
ERROR - 2017-08-04 08:26:52 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 08:26:53 --> Config Class Initialized
INFO - 2017-08-04 08:26:53 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:26:53 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:26:53 --> Utf8 Class Initialized
INFO - 2017-08-04 08:26:53 --> URI Class Initialized
INFO - 2017-08-04 08:26:53 --> Router Class Initialized
INFO - 2017-08-04 08:26:53 --> Output Class Initialized
INFO - 2017-08-04 08:26:53 --> Security Class Initialized
DEBUG - 2017-08-04 08:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:26:53 --> Input Class Initialized
INFO - 2017-08-04 08:26:53 --> Language Class Initialized
INFO - 2017-08-04 08:26:53 --> Loader Class Initialized
INFO - 2017-08-04 08:26:53 --> Helper loaded: url_helper
INFO - 2017-08-04 08:26:53 --> Helper loaded: form_helper
INFO - 2017-08-04 08:26:53 --> Helper loaded: security_helper
INFO - 2017-08-04 08:26:53 --> Helper loaded: path_helper
INFO - 2017-08-04 08:26:53 --> Helper loaded: common_helper
INFO - 2017-08-04 08:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:26:53 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:26:53 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:26:53 --> Email Class Initialized
INFO - 2017-08-04 08:26:53 --> Form Validation Class Initialized
INFO - 2017-08-04 08:26:53 --> Model Class Initialized
INFO - 2017-08-04 08:26:53 --> Model Class Initialized
INFO - 2017-08-04 08:26:53 --> Model Class Initialized
INFO - 2017-08-04 08:26:53 --> Model Class Initialized
INFO - 2017-08-04 08:26:53 --> Controller Class Initialized
INFO - 2017-08-04 08:26:53 --> Model Class Initialized
INFO - 2017-08-04 08:26:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/header.php
INFO - 2017-08-04 08:26:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/left_menu.php
INFO - 2017-08-04 08:26:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/inperson_tumorboard.php
INFO - 2017-08-04 08:26:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/footer.php
INFO - 2017-08-04 08:26:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/template.php
INFO - 2017-08-04 08:26:53 --> Final output sent to browser
DEBUG - 2017-08-04 08:26:53 --> Total execution time: 0.0328
DEBUG - 2017-08-04 08:26:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:26:53 --> Database Forge Class Initialized
INFO - 2017-08-04 08:26:53 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:00 --> Config Class Initialized
INFO - 2017-08-04 08:27:00 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:00 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:00 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:00 --> URI Class Initialized
INFO - 2017-08-04 08:27:00 --> Router Class Initialized
INFO - 2017-08-04 08:27:00 --> Output Class Initialized
INFO - 2017-08-04 08:27:00 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:00 --> Input Class Initialized
INFO - 2017-08-04 08:27:00 --> Language Class Initialized
INFO - 2017-08-04 08:27:00 --> Loader Class Initialized
INFO - 2017-08-04 08:27:00 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:00 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:00 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:00 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:00 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:00 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:00 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:00 --> Email Class Initialized
INFO - 2017-08-04 08:27:00 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:00 --> Model Class Initialized
INFO - 2017-08-04 08:27:00 --> Model Class Initialized
INFO - 2017-08-04 08:27:01 --> Model Class Initialized
INFO - 2017-08-04 08:27:01 --> Model Class Initialized
INFO - 2017-08-04 08:27:01 --> Controller Class Initialized
INFO - 2017-08-04 08:27:01 --> Model Class Initialized
INFO - 2017-08-04 08:27:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/header.php
INFO - 2017-08-04 08:27:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/left_menu.php
INFO - 2017-08-04 08:27:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/faq-login.php
INFO - 2017-08-04 08:27:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/footer.php
INFO - 2017-08-04 08:27:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/template.php
INFO - 2017-08-04 08:27:01 --> Final output sent to browser
DEBUG - 2017-08-04 08:27:01 --> Total execution time: 0.0335
DEBUG - 2017-08-04 08:27:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:27:01 --> Database Forge Class Initialized
INFO - 2017-08-04 08:27:01 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:16 --> Config Class Initialized
INFO - 2017-08-04 08:27:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:16 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:16 --> URI Class Initialized
INFO - 2017-08-04 08:27:16 --> Router Class Initialized
INFO - 2017-08-04 08:27:16 --> Output Class Initialized
INFO - 2017-08-04 08:27:16 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:16 --> Input Class Initialized
INFO - 2017-08-04 08:27:16 --> Language Class Initialized
INFO - 2017-08-04 08:27:16 --> Loader Class Initialized
INFO - 2017-08-04 08:27:16 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:16 --> Email Class Initialized
INFO - 2017-08-04 08:27:16 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Controller Class Initialized
INFO - 2017-08-04 08:27:16 --> Config Class Initialized
INFO - 2017-08-04 08:27:16 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:16 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:16 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:16 --> URI Class Initialized
DEBUG - 2017-08-04 08:27:16 --> No URI present. Default controller set.
INFO - 2017-08-04 08:27:16 --> Router Class Initialized
INFO - 2017-08-04 08:27:16 --> Output Class Initialized
INFO - 2017-08-04 08:27:16 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:16 --> Input Class Initialized
INFO - 2017-08-04 08:27:16 --> Language Class Initialized
INFO - 2017-08-04 08:27:16 --> Loader Class Initialized
INFO - 2017-08-04 08:27:16 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:16 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:16 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:16 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:16 --> Email Class Initialized
INFO - 2017-08-04 08:27:16 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Model Class Initialized
INFO - 2017-08-04 08:27:16 --> Controller Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 08:27:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 08:27:16 --> Final output sent to browser
DEBUG - 2017-08-04 08:27:16 --> Total execution time: 0.0265
DEBUG - 2017-08-04 08:27:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:27:16 --> Database Forge Class Initialized
INFO - 2017-08-04 08:27:16 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:36 --> Config Class Initialized
INFO - 2017-08-04 08:27:36 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:36 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:36 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:36 --> URI Class Initialized
DEBUG - 2017-08-04 08:27:36 --> No URI present. Default controller set.
INFO - 2017-08-04 08:27:36 --> Router Class Initialized
INFO - 2017-08-04 08:27:36 --> Output Class Initialized
INFO - 2017-08-04 08:27:36 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:36 --> Input Class Initialized
INFO - 2017-08-04 08:27:36 --> Language Class Initialized
INFO - 2017-08-04 08:27:36 --> Loader Class Initialized
INFO - 2017-08-04 08:27:36 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:36 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:36 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:36 --> Email Class Initialized
INFO - 2017-08-04 08:27:36 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Controller Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-04 08:27:36 --> Config Class Initialized
INFO - 2017-08-04 08:27:36 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:36 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:36 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:36 --> URI Class Initialized
DEBUG - 2017-08-04 08:27:36 --> No URI present. Default controller set.
INFO - 2017-08-04 08:27:36 --> Router Class Initialized
INFO - 2017-08-04 08:27:36 --> Output Class Initialized
INFO - 2017-08-04 08:27:36 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:36 --> Input Class Initialized
INFO - 2017-08-04 08:27:36 --> Language Class Initialized
INFO - 2017-08-04 08:27:36 --> Loader Class Initialized
INFO - 2017-08-04 08:27:36 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:36 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:36 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:36 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:36 --> Email Class Initialized
INFO - 2017-08-04 08:27:36 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Model Class Initialized
INFO - 2017-08-04 08:27:36 --> Controller Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 08:27:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 08:27:36 --> Final output sent to browser
DEBUG - 2017-08-04 08:27:36 --> Total execution time: 0.0261
DEBUG - 2017-08-04 08:27:36 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:27:36 --> Database Forge Class Initialized
INFO - 2017-08-04 08:27:36 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:49 --> Config Class Initialized
INFO - 2017-08-04 08:27:49 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:49 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:49 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:49 --> URI Class Initialized
INFO - 2017-08-04 08:27:49 --> Router Class Initialized
INFO - 2017-08-04 08:27:49 --> Output Class Initialized
INFO - 2017-08-04 08:27:49 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:49 --> Input Class Initialized
INFO - 2017-08-04 08:27:49 --> Language Class Initialized
INFO - 2017-08-04 08:27:49 --> Loader Class Initialized
INFO - 2017-08-04 08:27:49 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:49 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:49 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:49 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:49 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:49 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:49 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:49 --> Email Class Initialized
INFO - 2017-08-04 08:27:49 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:49 --> Model Class Initialized
INFO - 2017-08-04 08:27:49 --> Model Class Initialized
INFO - 2017-08-04 08:27:49 --> Model Class Initialized
INFO - 2017-08-04 08:27:49 --> Model Class Initialized
INFO - 2017-08-04 08:27:49 --> Controller Class Initialized
INFO - 2017-08-04 08:27:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 08:27:49 --> Final output sent to browser
DEBUG - 2017-08-04 08:27:49 --> Total execution time: 0.0288
DEBUG - 2017-08-04 08:27:49 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:27:49 --> Database Forge Class Initialized
INFO - 2017-08-04 08:27:49 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:52 --> Config Class Initialized
INFO - 2017-08-04 08:27:52 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:27:52 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:27:52 --> Utf8 Class Initialized
INFO - 2017-08-04 08:27:52 --> URI Class Initialized
INFO - 2017-08-04 08:27:52 --> Router Class Initialized
INFO - 2017-08-04 08:27:52 --> Output Class Initialized
INFO - 2017-08-04 08:27:52 --> Security Class Initialized
DEBUG - 2017-08-04 08:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:27:52 --> Input Class Initialized
INFO - 2017-08-04 08:27:52 --> Language Class Initialized
INFO - 2017-08-04 08:27:52 --> Loader Class Initialized
INFO - 2017-08-04 08:27:52 --> Helper loaded: url_helper
INFO - 2017-08-04 08:27:52 --> Helper loaded: form_helper
INFO - 2017-08-04 08:27:52 --> Helper loaded: security_helper
INFO - 2017-08-04 08:27:52 --> Helper loaded: path_helper
INFO - 2017-08-04 08:27:52 --> Helper loaded: common_helper
INFO - 2017-08-04 08:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:27:52 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:27:52 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:27:52 --> Email Class Initialized
INFO - 2017-08-04 08:27:52 --> Form Validation Class Initialized
INFO - 2017-08-04 08:27:52 --> Model Class Initialized
INFO - 2017-08-04 08:27:52 --> Model Class Initialized
INFO - 2017-08-04 08:27:52 --> Model Class Initialized
INFO - 2017-08-04 08:27:52 --> Model Class Initialized
INFO - 2017-08-04 08:27:52 --> Controller Class Initialized
INFO - 2017-08-04 08:27:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 08:27:52 --> Final output sent to browser
DEBUG - 2017-08-04 08:27:52 --> Total execution time: 0.0262
DEBUG - 2017-08-04 08:27:52 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:27:52 --> Database Forge Class Initialized
INFO - 2017-08-04 08:27:52 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:03 --> Config Class Initialized
INFO - 2017-08-04 08:28:03 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:28:03 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:28:03 --> Utf8 Class Initialized
INFO - 2017-08-04 08:28:03 --> URI Class Initialized
INFO - 2017-08-04 08:28:03 --> Router Class Initialized
INFO - 2017-08-04 08:28:03 --> Output Class Initialized
INFO - 2017-08-04 08:28:03 --> Security Class Initialized
DEBUG - 2017-08-04 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:28:03 --> Input Class Initialized
INFO - 2017-08-04 08:28:03 --> Language Class Initialized
INFO - 2017-08-04 08:28:03 --> Loader Class Initialized
INFO - 2017-08-04 08:28:03 --> Helper loaded: url_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: form_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: security_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: path_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: common_helper
INFO - 2017-08-04 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:28:03 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:28:03 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:03 --> Email Class Initialized
INFO - 2017-08-04 08:28:03 --> Form Validation Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Controller Class Initialized
INFO - 2017-08-04 08:28:03 --> Config Class Initialized
INFO - 2017-08-04 08:28:03 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:28:03 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:28:03 --> Utf8 Class Initialized
INFO - 2017-08-04 08:28:03 --> URI Class Initialized
INFO - 2017-08-04 08:28:03 --> Router Class Initialized
INFO - 2017-08-04 08:28:03 --> Output Class Initialized
INFO - 2017-08-04 08:28:03 --> Security Class Initialized
DEBUG - 2017-08-04 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:28:03 --> Input Class Initialized
INFO - 2017-08-04 08:28:03 --> Language Class Initialized
INFO - 2017-08-04 08:28:03 --> Loader Class Initialized
INFO - 2017-08-04 08:28:03 --> Helper loaded: url_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: form_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: security_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: path_helper
INFO - 2017-08-04 08:28:03 --> Helper loaded: common_helper
INFO - 2017-08-04 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:28:03 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:28:03 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:03 --> Email Class Initialized
INFO - 2017-08-04 08:28:03 --> Form Validation Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Model Class Initialized
INFO - 2017-08-04 08:28:03 --> Controller Class Initialized
INFO - 2017-08-04 08:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 08:28:03 --> Pagination Class Initialized
INFO - 2017-08-04 08:28:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 08:28:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-04 08:28:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 08:28:03 --> Final output sent to browser
DEBUG - 2017-08-04 08:28:03 --> Total execution time: 0.0333
DEBUG - 2017-08-04 08:28:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:28:03 --> Database Forge Class Initialized
INFO - 2017-08-04 08:28:03 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:08 --> Config Class Initialized
INFO - 2017-08-04 08:28:08 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:28:08 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:28:08 --> Utf8 Class Initialized
INFO - 2017-08-04 08:28:08 --> URI Class Initialized
INFO - 2017-08-04 08:28:08 --> Router Class Initialized
INFO - 2017-08-04 08:28:08 --> Output Class Initialized
INFO - 2017-08-04 08:28:08 --> Security Class Initialized
DEBUG - 2017-08-04 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:28:08 --> Input Class Initialized
INFO - 2017-08-04 08:28:08 --> Language Class Initialized
INFO - 2017-08-04 08:28:08 --> Loader Class Initialized
INFO - 2017-08-04 08:28:08 --> Helper loaded: url_helper
INFO - 2017-08-04 08:28:08 --> Helper loaded: form_helper
INFO - 2017-08-04 08:28:08 --> Helper loaded: security_helper
INFO - 2017-08-04 08:28:08 --> Helper loaded: path_helper
INFO - 2017-08-04 08:28:08 --> Helper loaded: common_helper
INFO - 2017-08-04 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:28:08 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:28:08 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:08 --> Email Class Initialized
INFO - 2017-08-04 08:28:08 --> Form Validation Class Initialized
INFO - 2017-08-04 08:28:08 --> Model Class Initialized
INFO - 2017-08-04 08:28:08 --> Model Class Initialized
INFO - 2017-08-04 08:28:08 --> Model Class Initialized
INFO - 2017-08-04 08:28:08 --> Model Class Initialized
INFO - 2017-08-04 08:28:08 --> Controller Class Initialized
INFO - 2017-08-04 08:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-04 08:28:08 --> Pagination Class Initialized
INFO - 2017-08-04 08:28:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 08:28:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/logging_details.php
INFO - 2017-08-04 08:28:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 08:28:08 --> Final output sent to browser
DEBUG - 2017-08-04 08:28:08 --> Total execution time: 0.0401
DEBUG - 2017-08-04 08:28:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:28:08 --> Database Forge Class Initialized
INFO - 2017-08-04 08:28:08 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:18 --> Config Class Initialized
INFO - 2017-08-04 08:28:18 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:28:18 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:28:18 --> Utf8 Class Initialized
INFO - 2017-08-04 08:28:18 --> URI Class Initialized
INFO - 2017-08-04 08:28:18 --> Router Class Initialized
INFO - 2017-08-04 08:28:18 --> Output Class Initialized
INFO - 2017-08-04 08:28:18 --> Security Class Initialized
DEBUG - 2017-08-04 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:28:18 --> Input Class Initialized
INFO - 2017-08-04 08:28:18 --> Language Class Initialized
INFO - 2017-08-04 08:28:18 --> Loader Class Initialized
INFO - 2017-08-04 08:28:18 --> Helper loaded: url_helper
INFO - 2017-08-04 08:28:18 --> Helper loaded: form_helper
INFO - 2017-08-04 08:28:18 --> Helper loaded: security_helper
INFO - 2017-08-04 08:28:18 --> Helper loaded: path_helper
INFO - 2017-08-04 08:28:18 --> Helper loaded: common_helper
INFO - 2017-08-04 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:28:18 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:28:18 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:18 --> Email Class Initialized
INFO - 2017-08-04 08:28:18 --> Form Validation Class Initialized
INFO - 2017-08-04 08:28:18 --> Model Class Initialized
INFO - 2017-08-04 08:28:18 --> Model Class Initialized
INFO - 2017-08-04 08:28:18 --> Model Class Initialized
INFO - 2017-08-04 08:28:18 --> Model Class Initialized
INFO - 2017-08-04 08:28:18 --> Controller Class Initialized
DEBUG - 2017-08-04 08:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:28:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 08:28:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-04 08:28:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 08:28:18 --> Final output sent to browser
DEBUG - 2017-08-04 08:28:18 --> Total execution time: 0.0353
DEBUG - 2017-08-04 08:28:18 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:28:18 --> Database Forge Class Initialized
INFO - 2017-08-04 08:28:18 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:38 --> Config Class Initialized
INFO - 2017-08-04 08:44:38 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:44:38 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:44:38 --> Utf8 Class Initialized
INFO - 2017-08-04 08:44:38 --> URI Class Initialized
INFO - 2017-08-04 08:44:38 --> Router Class Initialized
INFO - 2017-08-04 08:44:38 --> Output Class Initialized
INFO - 2017-08-04 08:44:38 --> Security Class Initialized
DEBUG - 2017-08-04 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:44:38 --> Input Class Initialized
INFO - 2017-08-04 08:44:38 --> Language Class Initialized
INFO - 2017-08-04 08:44:38 --> Loader Class Initialized
INFO - 2017-08-04 08:44:38 --> Helper loaded: url_helper
INFO - 2017-08-04 08:44:38 --> Helper loaded: form_helper
INFO - 2017-08-04 08:44:38 --> Helper loaded: security_helper
INFO - 2017-08-04 08:44:38 --> Helper loaded: path_helper
INFO - 2017-08-04 08:44:38 --> Helper loaded: common_helper
INFO - 2017-08-04 08:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:44:38 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:44:38 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:39 --> Email Class Initialized
INFO - 2017-08-04 08:44:39 --> Form Validation Class Initialized
INFO - 2017-08-04 08:44:39 --> Model Class Initialized
INFO - 2017-08-04 08:44:39 --> Model Class Initialized
INFO - 2017-08-04 08:44:39 --> Model Class Initialized
INFO - 2017-08-04 08:44:39 --> Model Class Initialized
INFO - 2017-08-04 08:44:39 --> Controller Class Initialized
INFO - 2017-08-04 08:44:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 08:44:39 --> Final output sent to browser
DEBUG - 2017-08-04 08:44:39 --> Total execution time: 0.0263
DEBUG - 2017-08-04 08:44:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:44:39 --> Database Forge Class Initialized
INFO - 2017-08-04 08:44:39 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:44:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:39 --> Config Class Initialized
INFO - 2017-08-04 08:44:39 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:44:39 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:44:39 --> Utf8 Class Initialized
INFO - 2017-08-04 08:44:39 --> URI Class Initialized
INFO - 2017-08-04 08:44:39 --> Router Class Initialized
INFO - 2017-08-04 08:44:39 --> Output Class Initialized
INFO - 2017-08-04 08:44:39 --> Security Class Initialized
DEBUG - 2017-08-04 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:44:39 --> Input Class Initialized
INFO - 2017-08-04 08:44:39 --> Language Class Initialized
ERROR - 2017-08-04 08:44:39 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 08:44:46 --> Config Class Initialized
INFO - 2017-08-04 08:44:46 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:44:46 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:44:46 --> Utf8 Class Initialized
INFO - 2017-08-04 08:44:46 --> URI Class Initialized
INFO - 2017-08-04 08:44:46 --> Router Class Initialized
INFO - 2017-08-04 08:44:46 --> Output Class Initialized
INFO - 2017-08-04 08:44:46 --> Security Class Initialized
DEBUG - 2017-08-04 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:44:46 --> Input Class Initialized
INFO - 2017-08-04 08:44:46 --> Language Class Initialized
INFO - 2017-08-04 08:44:46 --> Loader Class Initialized
INFO - 2017-08-04 08:44:46 --> Helper loaded: url_helper
INFO - 2017-08-04 08:44:46 --> Helper loaded: form_helper
INFO - 2017-08-04 08:44:46 --> Helper loaded: security_helper
INFO - 2017-08-04 08:44:46 --> Helper loaded: path_helper
INFO - 2017-08-04 08:44:46 --> Helper loaded: common_helper
INFO - 2017-08-04 08:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:44:46 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:44:46 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:46 --> Email Class Initialized
INFO - 2017-08-04 08:44:46 --> Form Validation Class Initialized
INFO - 2017-08-04 08:44:46 --> Model Class Initialized
INFO - 2017-08-04 08:44:46 --> Model Class Initialized
INFO - 2017-08-04 08:44:46 --> Model Class Initialized
INFO - 2017-08-04 08:44:46 --> Model Class Initialized
INFO - 2017-08-04 08:44:46 --> Controller Class Initialized
INFO - 2017-08-04 08:44:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-04 08:44:46 --> Final output sent to browser
DEBUG - 2017-08-04 08:44:46 --> Total execution time: 0.0251
DEBUG - 2017-08-04 08:44:46 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:44:46 --> Database Forge Class Initialized
INFO - 2017-08-04 08:44:46 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:44:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:46 --> Config Class Initialized
INFO - 2017-08-04 08:44:46 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:44:46 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:44:46 --> Utf8 Class Initialized
INFO - 2017-08-04 08:44:46 --> URI Class Initialized
INFO - 2017-08-04 08:44:46 --> Router Class Initialized
INFO - 2017-08-04 08:44:46 --> Output Class Initialized
INFO - 2017-08-04 08:44:46 --> Security Class Initialized
DEBUG - 2017-08-04 08:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:44:46 --> Input Class Initialized
INFO - 2017-08-04 08:44:46 --> Language Class Initialized
ERROR - 2017-08-04 08:44:46 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 08:44:50 --> Config Class Initialized
INFO - 2017-08-04 08:44:50 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:44:50 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:44:50 --> Utf8 Class Initialized
INFO - 2017-08-04 08:44:50 --> URI Class Initialized
DEBUG - 2017-08-04 08:44:50 --> No URI present. Default controller set.
INFO - 2017-08-04 08:44:50 --> Router Class Initialized
INFO - 2017-08-04 08:44:50 --> Output Class Initialized
INFO - 2017-08-04 08:44:50 --> Security Class Initialized
DEBUG - 2017-08-04 08:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:44:50 --> Input Class Initialized
INFO - 2017-08-04 08:44:50 --> Language Class Initialized
INFO - 2017-08-04 08:44:50 --> Loader Class Initialized
INFO - 2017-08-04 08:44:50 --> Helper loaded: url_helper
INFO - 2017-08-04 08:44:50 --> Helper loaded: form_helper
INFO - 2017-08-04 08:44:50 --> Helper loaded: security_helper
INFO - 2017-08-04 08:44:50 --> Helper loaded: path_helper
INFO - 2017-08-04 08:44:50 --> Helper loaded: common_helper
INFO - 2017-08-04 08:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:44:50 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:44:50 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:50 --> Email Class Initialized
INFO - 2017-08-04 08:44:50 --> Form Validation Class Initialized
INFO - 2017-08-04 08:44:50 --> Model Class Initialized
INFO - 2017-08-04 08:44:50 --> Model Class Initialized
INFO - 2017-08-04 08:44:50 --> Model Class Initialized
INFO - 2017-08-04 08:44:50 --> Model Class Initialized
INFO - 2017-08-04 08:44:50 --> Controller Class Initialized
DEBUG - 2017-08-04 08:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:44:50 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 08:44:50 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 08:44:50 --> Final output sent to browser
DEBUG - 2017-08-04 08:44:50 --> Total execution time: 0.0276
DEBUG - 2017-08-04 08:44:50 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:44:50 --> Database Forge Class Initialized
INFO - 2017-08-04 08:44:50 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:03 --> Config Class Initialized
INFO - 2017-08-04 08:45:03 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:45:03 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:45:03 --> Utf8 Class Initialized
INFO - 2017-08-04 08:45:03 --> URI Class Initialized
INFO - 2017-08-04 08:45:03 --> Router Class Initialized
INFO - 2017-08-04 08:45:03 --> Output Class Initialized
INFO - 2017-08-04 08:45:03 --> Security Class Initialized
DEBUG - 2017-08-04 08:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:45:03 --> Input Class Initialized
INFO - 2017-08-04 08:45:03 --> Language Class Initialized
INFO - 2017-08-04 08:45:03 --> Loader Class Initialized
INFO - 2017-08-04 08:45:03 --> Helper loaded: url_helper
INFO - 2017-08-04 08:45:03 --> Helper loaded: form_helper
INFO - 2017-08-04 08:45:03 --> Helper loaded: security_helper
INFO - 2017-08-04 08:45:03 --> Helper loaded: path_helper
INFO - 2017-08-04 08:45:03 --> Helper loaded: common_helper
INFO - 2017-08-04 08:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:45:03 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:45:03 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:03 --> Email Class Initialized
INFO - 2017-08-04 08:45:03 --> Form Validation Class Initialized
INFO - 2017-08-04 08:45:03 --> Model Class Initialized
INFO - 2017-08-04 08:45:03 --> Model Class Initialized
INFO - 2017-08-04 08:45:03 --> Model Class Initialized
INFO - 2017-08-04 08:45:03 --> Model Class Initialized
INFO - 2017-08-04 08:45:03 --> Controller Class Initialized
INFO - 2017-08-04 08:45:03 --> Model Class Initialized
INFO - 2017-08-04 08:45:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:45:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:45:03 --> Final output sent to browser
DEBUG - 2017-08-04 08:45:03 --> Total execution time: 0.0266
DEBUG - 2017-08-04 08:45:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:45:03 --> Database Forge Class Initialized
INFO - 2017-08-04 08:45:03 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:45:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:03 --> Config Class Initialized
INFO - 2017-08-04 08:45:03 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:45:03 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:45:03 --> Utf8 Class Initialized
INFO - 2017-08-04 08:45:03 --> URI Class Initialized
INFO - 2017-08-04 08:45:03 --> Router Class Initialized
INFO - 2017-08-04 08:45:03 --> Output Class Initialized
INFO - 2017-08-04 08:45:03 --> Security Class Initialized
DEBUG - 2017-08-04 08:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:45:03 --> Input Class Initialized
INFO - 2017-08-04 08:45:03 --> Language Class Initialized
ERROR - 2017-08-04 08:45:03 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 08:45:41 --> Config Class Initialized
INFO - 2017-08-04 08:45:41 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:45:41 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:45:41 --> Utf8 Class Initialized
INFO - 2017-08-04 08:45:41 --> URI Class Initialized
INFO - 2017-08-04 08:45:41 --> Router Class Initialized
INFO - 2017-08-04 08:45:41 --> Output Class Initialized
INFO - 2017-08-04 08:45:41 --> Security Class Initialized
DEBUG - 2017-08-04 08:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:45:41 --> Input Class Initialized
INFO - 2017-08-04 08:45:41 --> Language Class Initialized
INFO - 2017-08-04 08:45:41 --> Loader Class Initialized
INFO - 2017-08-04 08:45:41 --> Helper loaded: url_helper
INFO - 2017-08-04 08:45:41 --> Helper loaded: form_helper
INFO - 2017-08-04 08:45:41 --> Helper loaded: security_helper
INFO - 2017-08-04 08:45:41 --> Helper loaded: path_helper
INFO - 2017-08-04 08:45:41 --> Helper loaded: common_helper
INFO - 2017-08-04 08:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:45:41 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:45:41 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:41 --> Email Class Initialized
INFO - 2017-08-04 08:45:41 --> Form Validation Class Initialized
INFO - 2017-08-04 08:45:41 --> Model Class Initialized
INFO - 2017-08-04 08:45:41 --> Model Class Initialized
INFO - 2017-08-04 08:45:41 --> Model Class Initialized
INFO - 2017-08-04 08:45:41 --> Model Class Initialized
INFO - 2017-08-04 08:45:41 --> Controller Class Initialized
INFO - 2017-08-04 08:45:41 --> Model Class Initialized
INFO - 2017-08-04 08:45:41 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:45:41 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:45:41 --> Final output sent to browser
DEBUG - 2017-08-04 08:45:41 --> Total execution time: 0.0281
DEBUG - 2017-08-04 08:45:41 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:45:41 --> Database Forge Class Initialized
INFO - 2017-08-04 08:45:41 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:48 --> Config Class Initialized
INFO - 2017-08-04 08:45:48 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:45:48 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:45:48 --> Utf8 Class Initialized
INFO - 2017-08-04 08:45:48 --> URI Class Initialized
INFO - 2017-08-04 08:45:48 --> Router Class Initialized
INFO - 2017-08-04 08:45:48 --> Output Class Initialized
INFO - 2017-08-04 08:45:48 --> Security Class Initialized
DEBUG - 2017-08-04 08:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:45:48 --> Input Class Initialized
INFO - 2017-08-04 08:45:48 --> Language Class Initialized
INFO - 2017-08-04 08:45:48 --> Loader Class Initialized
INFO - 2017-08-04 08:45:48 --> Helper loaded: url_helper
INFO - 2017-08-04 08:45:48 --> Helper loaded: form_helper
INFO - 2017-08-04 08:45:48 --> Helper loaded: security_helper
INFO - 2017-08-04 08:45:48 --> Helper loaded: path_helper
INFO - 2017-08-04 08:45:48 --> Helper loaded: common_helper
INFO - 2017-08-04 08:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:45:48 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:45:48 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:45:48 --> Email Class Initialized
INFO - 2017-08-04 08:45:48 --> Form Validation Class Initialized
INFO - 2017-08-04 08:45:48 --> Model Class Initialized
INFO - 2017-08-04 08:45:48 --> Model Class Initialized
INFO - 2017-08-04 08:45:48 --> Model Class Initialized
INFO - 2017-08-04 08:45:48 --> Model Class Initialized
INFO - 2017-08-04 08:45:48 --> Controller Class Initialized
INFO - 2017-08-04 08:45:48 --> Model Class Initialized
INFO - 2017-08-04 08:45:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:45:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:45:48 --> Final output sent to browser
DEBUG - 2017-08-04 08:45:48 --> Total execution time: 0.0403
DEBUG - 2017-08-04 08:45:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:45:48 --> Database Forge Class Initialized
INFO - 2017-08-04 08:45:48 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:46:06 --> Config Class Initialized
INFO - 2017-08-04 08:46:06 --> Hooks Class Initialized
DEBUG - 2017-08-04 08:46:06 --> UTF-8 Support Enabled
INFO - 2017-08-04 08:46:06 --> Utf8 Class Initialized
INFO - 2017-08-04 08:46:06 --> URI Class Initialized
INFO - 2017-08-04 08:46:06 --> Router Class Initialized
INFO - 2017-08-04 08:46:06 --> Output Class Initialized
INFO - 2017-08-04 08:46:06 --> Security Class Initialized
DEBUG - 2017-08-04 08:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 08:46:06 --> Input Class Initialized
INFO - 2017-08-04 08:46:06 --> Language Class Initialized
INFO - 2017-08-04 08:46:06 --> Loader Class Initialized
INFO - 2017-08-04 08:46:06 --> Helper loaded: url_helper
INFO - 2017-08-04 08:46:06 --> Helper loaded: form_helper
INFO - 2017-08-04 08:46:06 --> Helper loaded: security_helper
INFO - 2017-08-04 08:46:06 --> Helper loaded: path_helper
INFO - 2017-08-04 08:46:06 --> Helper loaded: common_helper
INFO - 2017-08-04 08:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 08:46:06 --> Helper loaded: check_session_helper
INFO - 2017-08-04 08:46:06 --> Database Driver Class Initialized
DEBUG - 2017-08-04 08:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 08:46:06 --> Email Class Initialized
INFO - 2017-08-04 08:46:06 --> Form Validation Class Initialized
INFO - 2017-08-04 08:46:06 --> Model Class Initialized
INFO - 2017-08-04 08:46:06 --> Model Class Initialized
INFO - 2017-08-04 08:46:06 --> Model Class Initialized
INFO - 2017-08-04 08:46:06 --> Model Class Initialized
INFO - 2017-08-04 08:46:06 --> Controller Class Initialized
INFO - 2017-08-04 08:46:06 --> Model Class Initialized
INFO - 2017-08-04 08:46:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 08:46:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 08:46:06 --> Final output sent to browser
DEBUG - 2017-08-04 08:46:06 --> Total execution time: 0.0290
DEBUG - 2017-08-04 08:46:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 08:46:06 --> Database Forge Class Initialized
INFO - 2017-08-04 08:46:06 --> User Agent Class Initialized
DEBUG - 2017-08-04 08:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:10 --> Config Class Initialized
INFO - 2017-08-04 12:46:10 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:46:10 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:46:10 --> Utf8 Class Initialized
INFO - 2017-08-04 12:46:10 --> URI Class Initialized
DEBUG - 2017-08-04 12:46:10 --> No URI present. Default controller set.
INFO - 2017-08-04 12:46:10 --> Router Class Initialized
INFO - 2017-08-04 12:46:10 --> Output Class Initialized
INFO - 2017-08-04 12:46:10 --> Security Class Initialized
DEBUG - 2017-08-04 12:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:46:10 --> Input Class Initialized
INFO - 2017-08-04 12:46:10 --> Language Class Initialized
INFO - 2017-08-04 12:46:10 --> Loader Class Initialized
INFO - 2017-08-04 12:46:10 --> Helper loaded: url_helper
INFO - 2017-08-04 12:46:10 --> Helper loaded: form_helper
INFO - 2017-08-04 12:46:10 --> Helper loaded: security_helper
INFO - 2017-08-04 12:46:10 --> Helper loaded: path_helper
INFO - 2017-08-04 12:46:10 --> Helper loaded: common_helper
INFO - 2017-08-04 12:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:46:10 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:46:10 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:10 --> Email Class Initialized
INFO - 2017-08-04 12:46:10 --> Form Validation Class Initialized
INFO - 2017-08-04 12:46:10 --> Model Class Initialized
INFO - 2017-08-04 12:46:10 --> Model Class Initialized
INFO - 2017-08-04 12:46:10 --> Model Class Initialized
INFO - 2017-08-04 12:46:10 --> Model Class Initialized
INFO - 2017-08-04 12:46:10 --> Controller Class Initialized
DEBUG - 2017-08-04 12:46:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 12:46:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 12:46:10 --> Final output sent to browser
DEBUG - 2017-08-04 12:46:10 --> Total execution time: 0.0274
DEBUG - 2017-08-04 12:46:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:46:10 --> Database Forge Class Initialized
INFO - 2017-08-04 12:46:10 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:46:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:20 --> Config Class Initialized
INFO - 2017-08-04 12:46:20 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:46:20 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:46:20 --> Utf8 Class Initialized
INFO - 2017-08-04 12:46:20 --> URI Class Initialized
INFO - 2017-08-04 12:46:20 --> Router Class Initialized
INFO - 2017-08-04 12:46:20 --> Output Class Initialized
INFO - 2017-08-04 12:46:20 --> Security Class Initialized
DEBUG - 2017-08-04 12:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:46:20 --> Input Class Initialized
INFO - 2017-08-04 12:46:20 --> Language Class Initialized
INFO - 2017-08-04 12:46:20 --> Loader Class Initialized
INFO - 2017-08-04 12:46:20 --> Helper loaded: url_helper
INFO - 2017-08-04 12:46:20 --> Helper loaded: form_helper
INFO - 2017-08-04 12:46:20 --> Helper loaded: security_helper
INFO - 2017-08-04 12:46:20 --> Helper loaded: path_helper
INFO - 2017-08-04 12:46:20 --> Helper loaded: common_helper
INFO - 2017-08-04 12:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:46:20 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:46:20 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:20 --> Email Class Initialized
INFO - 2017-08-04 12:46:20 --> Form Validation Class Initialized
INFO - 2017-08-04 12:46:20 --> Model Class Initialized
INFO - 2017-08-04 12:46:20 --> Model Class Initialized
INFO - 2017-08-04 12:46:20 --> Model Class Initialized
INFO - 2017-08-04 12:46:20 --> Model Class Initialized
INFO - 2017-08-04 12:46:20 --> Controller Class Initialized
INFO - 2017-08-04 12:46:20 --> Model Class Initialized
INFO - 2017-08-04 12:46:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:46:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:46:20 --> Final output sent to browser
DEBUG - 2017-08-04 12:46:20 --> Total execution time: 0.0261
DEBUG - 2017-08-04 12:46:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:46:20 --> Database Forge Class Initialized
INFO - 2017-08-04 12:46:20 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:42 --> Config Class Initialized
INFO - 2017-08-04 12:46:42 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:46:42 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:46:42 --> Utf8 Class Initialized
INFO - 2017-08-04 12:46:42 --> URI Class Initialized
INFO - 2017-08-04 12:46:42 --> Router Class Initialized
INFO - 2017-08-04 12:46:42 --> Output Class Initialized
INFO - 2017-08-04 12:46:42 --> Security Class Initialized
DEBUG - 2017-08-04 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:46:42 --> Input Class Initialized
INFO - 2017-08-04 12:46:42 --> Language Class Initialized
INFO - 2017-08-04 12:46:42 --> Loader Class Initialized
INFO - 2017-08-04 12:46:42 --> Helper loaded: url_helper
INFO - 2017-08-04 12:46:42 --> Helper loaded: form_helper
INFO - 2017-08-04 12:46:42 --> Helper loaded: security_helper
INFO - 2017-08-04 12:46:42 --> Helper loaded: path_helper
INFO - 2017-08-04 12:46:42 --> Helper loaded: common_helper
INFO - 2017-08-04 12:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:46:43 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:46:43 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:43 --> Email Class Initialized
INFO - 2017-08-04 12:46:43 --> Form Validation Class Initialized
INFO - 2017-08-04 12:46:43 --> Model Class Initialized
INFO - 2017-08-04 12:46:43 --> Model Class Initialized
INFO - 2017-08-04 12:46:43 --> Model Class Initialized
INFO - 2017-08-04 12:46:43 --> Model Class Initialized
INFO - 2017-08-04 12:46:43 --> Controller Class Initialized
INFO - 2017-08-04 12:46:43 --> Model Class Initialized
INFO - 2017-08-04 12:46:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:46:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:46:43 --> Final output sent to browser
DEBUG - 2017-08-04 12:46:43 --> Total execution time: 0.0277
DEBUG - 2017-08-04 12:46:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:46:43 --> Database Forge Class Initialized
INFO - 2017-08-04 12:46:43 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:57 --> Config Class Initialized
INFO - 2017-08-04 12:46:57 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:46:57 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:46:57 --> Utf8 Class Initialized
INFO - 2017-08-04 12:46:57 --> URI Class Initialized
INFO - 2017-08-04 12:46:57 --> Router Class Initialized
INFO - 2017-08-04 12:46:57 --> Output Class Initialized
INFO - 2017-08-04 12:46:57 --> Security Class Initialized
DEBUG - 2017-08-04 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:46:57 --> Input Class Initialized
INFO - 2017-08-04 12:46:57 --> Language Class Initialized
INFO - 2017-08-04 12:46:57 --> Loader Class Initialized
INFO - 2017-08-04 12:46:57 --> Helper loaded: url_helper
INFO - 2017-08-04 12:46:57 --> Helper loaded: form_helper
INFO - 2017-08-04 12:46:57 --> Helper loaded: security_helper
INFO - 2017-08-04 12:46:57 --> Helper loaded: path_helper
INFO - 2017-08-04 12:46:57 --> Helper loaded: common_helper
INFO - 2017-08-04 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:46:57 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:46:57 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:46:57 --> Email Class Initialized
INFO - 2017-08-04 12:46:57 --> Form Validation Class Initialized
INFO - 2017-08-04 12:46:57 --> Model Class Initialized
INFO - 2017-08-04 12:46:57 --> Model Class Initialized
INFO - 2017-08-04 12:46:57 --> Model Class Initialized
INFO - 2017-08-04 12:46:57 --> Model Class Initialized
INFO - 2017-08-04 12:46:57 --> Controller Class Initialized
INFO - 2017-08-04 12:46:57 --> Model Class Initialized
INFO - 2017-08-04 12:46:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:46:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:46:57 --> Final output sent to browser
DEBUG - 2017-08-04 12:46:57 --> Total execution time: 0.0276
DEBUG - 2017-08-04 12:46:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:46:57 --> Database Forge Class Initialized
INFO - 2017-08-04 12:46:57 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:46:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:47:23 --> Config Class Initialized
INFO - 2017-08-04 12:47:23 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:47:23 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:47:23 --> Utf8 Class Initialized
INFO - 2017-08-04 12:47:23 --> URI Class Initialized
INFO - 2017-08-04 12:47:23 --> Router Class Initialized
INFO - 2017-08-04 12:47:23 --> Output Class Initialized
INFO - 2017-08-04 12:47:23 --> Security Class Initialized
DEBUG - 2017-08-04 12:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:47:23 --> Input Class Initialized
INFO - 2017-08-04 12:47:23 --> Language Class Initialized
INFO - 2017-08-04 12:47:23 --> Loader Class Initialized
INFO - 2017-08-04 12:47:23 --> Helper loaded: url_helper
INFO - 2017-08-04 12:47:23 --> Helper loaded: form_helper
INFO - 2017-08-04 12:47:23 --> Helper loaded: security_helper
INFO - 2017-08-04 12:47:23 --> Helper loaded: path_helper
INFO - 2017-08-04 12:47:23 --> Helper loaded: common_helper
INFO - 2017-08-04 12:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:47:23 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:47:23 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:47:23 --> Email Class Initialized
INFO - 2017-08-04 12:47:23 --> Form Validation Class Initialized
INFO - 2017-08-04 12:47:23 --> Model Class Initialized
INFO - 2017-08-04 12:47:23 --> Model Class Initialized
INFO - 2017-08-04 12:47:23 --> Model Class Initialized
INFO - 2017-08-04 12:47:23 --> Model Class Initialized
INFO - 2017-08-04 12:47:23 --> Controller Class Initialized
INFO - 2017-08-04 12:47:23 --> Model Class Initialized
INFO - 2017-08-04 12:47:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:47:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:47:23 --> Final output sent to browser
DEBUG - 2017-08-04 12:47:23 --> Total execution time: 0.0264
DEBUG - 2017-08-04 12:47:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:47:23 --> Database Forge Class Initialized
INFO - 2017-08-04 12:47:23 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:50:44 --> Config Class Initialized
INFO - 2017-08-04 12:50:44 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:50:44 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:50:44 --> Utf8 Class Initialized
INFO - 2017-08-04 12:50:44 --> URI Class Initialized
INFO - 2017-08-04 12:50:44 --> Router Class Initialized
INFO - 2017-08-04 12:50:44 --> Output Class Initialized
INFO - 2017-08-04 12:50:44 --> Security Class Initialized
DEBUG - 2017-08-04 12:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:50:44 --> Input Class Initialized
INFO - 2017-08-04 12:50:44 --> Language Class Initialized
INFO - 2017-08-04 12:50:44 --> Loader Class Initialized
INFO - 2017-08-04 12:50:44 --> Helper loaded: url_helper
INFO - 2017-08-04 12:50:44 --> Helper loaded: form_helper
INFO - 2017-08-04 12:50:44 --> Helper loaded: security_helper
INFO - 2017-08-04 12:50:44 --> Helper loaded: path_helper
INFO - 2017-08-04 12:50:44 --> Helper loaded: common_helper
INFO - 2017-08-04 12:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:50:44 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:50:44 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:50:44 --> Email Class Initialized
INFO - 2017-08-04 12:50:44 --> Form Validation Class Initialized
INFO - 2017-08-04 12:50:44 --> Model Class Initialized
INFO - 2017-08-04 12:50:44 --> Model Class Initialized
INFO - 2017-08-04 12:50:44 --> Model Class Initialized
INFO - 2017-08-04 12:50:44 --> Model Class Initialized
INFO - 2017-08-04 12:50:44 --> Controller Class Initialized
INFO - 2017-08-04 12:50:44 --> Model Class Initialized
INFO - 2017-08-04 12:50:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:50:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:50:44 --> Final output sent to browser
DEBUG - 2017-08-04 12:50:44 --> Total execution time: 0.0288
DEBUG - 2017-08-04 12:50:44 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:50:44 --> Database Forge Class Initialized
INFO - 2017-08-04 12:50:44 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:50:56 --> Config Class Initialized
INFO - 2017-08-04 12:50:56 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:50:56 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:50:56 --> Utf8 Class Initialized
INFO - 2017-08-04 12:50:56 --> URI Class Initialized
INFO - 2017-08-04 12:50:56 --> Router Class Initialized
INFO - 2017-08-04 12:50:56 --> Output Class Initialized
INFO - 2017-08-04 12:50:56 --> Security Class Initialized
DEBUG - 2017-08-04 12:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:50:56 --> Input Class Initialized
INFO - 2017-08-04 12:50:56 --> Language Class Initialized
INFO - 2017-08-04 12:50:56 --> Loader Class Initialized
INFO - 2017-08-04 12:50:56 --> Helper loaded: url_helper
INFO - 2017-08-04 12:50:56 --> Helper loaded: form_helper
INFO - 2017-08-04 12:50:56 --> Helper loaded: security_helper
INFO - 2017-08-04 12:50:56 --> Helper loaded: path_helper
INFO - 2017-08-04 12:50:56 --> Helper loaded: common_helper
INFO - 2017-08-04 12:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:50:56 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:50:56 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:50:56 --> Email Class Initialized
INFO - 2017-08-04 12:50:56 --> Form Validation Class Initialized
INFO - 2017-08-04 12:50:56 --> Model Class Initialized
INFO - 2017-08-04 12:50:56 --> Model Class Initialized
INFO - 2017-08-04 12:50:56 --> Model Class Initialized
INFO - 2017-08-04 12:50:56 --> Model Class Initialized
INFO - 2017-08-04 12:50:56 --> Controller Class Initialized
INFO - 2017-08-04 12:50:56 --> Model Class Initialized
INFO - 2017-08-04 12:50:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 12:50:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 12:50:56 --> Final output sent to browser
DEBUG - 2017-08-04 12:50:56 --> Total execution time: 0.0268
DEBUG - 2017-08-04 12:50:56 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:50:56 --> Database Forge Class Initialized
INFO - 2017-08-04 12:50:56 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:53:11 --> Config Class Initialized
INFO - 2017-08-04 12:53:11 --> Hooks Class Initialized
DEBUG - 2017-08-04 12:53:11 --> UTF-8 Support Enabled
INFO - 2017-08-04 12:53:11 --> Utf8 Class Initialized
INFO - 2017-08-04 12:53:11 --> URI Class Initialized
DEBUG - 2017-08-04 12:53:11 --> No URI present. Default controller set.
INFO - 2017-08-04 12:53:11 --> Router Class Initialized
INFO - 2017-08-04 12:53:11 --> Output Class Initialized
INFO - 2017-08-04 12:53:11 --> Security Class Initialized
DEBUG - 2017-08-04 12:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 12:53:11 --> Input Class Initialized
INFO - 2017-08-04 12:53:11 --> Language Class Initialized
INFO - 2017-08-04 12:53:11 --> Loader Class Initialized
INFO - 2017-08-04 12:53:11 --> Helper loaded: url_helper
INFO - 2017-08-04 12:53:11 --> Helper loaded: form_helper
INFO - 2017-08-04 12:53:11 --> Helper loaded: security_helper
INFO - 2017-08-04 12:53:11 --> Helper loaded: path_helper
INFO - 2017-08-04 12:53:11 --> Helper loaded: common_helper
INFO - 2017-08-04 12:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 12:53:11 --> Helper loaded: check_session_helper
INFO - 2017-08-04 12:53:11 --> Database Driver Class Initialized
DEBUG - 2017-08-04 12:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:53:11 --> Email Class Initialized
INFO - 2017-08-04 12:53:11 --> Form Validation Class Initialized
INFO - 2017-08-04 12:53:11 --> Model Class Initialized
INFO - 2017-08-04 12:53:11 --> Model Class Initialized
INFO - 2017-08-04 12:53:11 --> Model Class Initialized
INFO - 2017-08-04 12:53:11 --> Model Class Initialized
INFO - 2017-08-04 12:53:11 --> Controller Class Initialized
DEBUG - 2017-08-04 12:53:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 12:53:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 12:53:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 12:53:11 --> Final output sent to browser
DEBUG - 2017-08-04 12:53:11 --> Total execution time: 0.0273
DEBUG - 2017-08-04 12:53:11 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 12:53:11 --> Database Forge Class Initialized
INFO - 2017-08-04 12:53:11 --> User Agent Class Initialized
DEBUG - 2017-08-04 12:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:13 --> Config Class Initialized
INFO - 2017-08-04 15:37:13 --> Hooks Class Initialized
DEBUG - 2017-08-04 15:37:13 --> UTF-8 Support Enabled
INFO - 2017-08-04 15:37:13 --> Utf8 Class Initialized
INFO - 2017-08-04 15:37:13 --> URI Class Initialized
INFO - 2017-08-04 15:37:13 --> Router Class Initialized
INFO - 2017-08-04 15:37:13 --> Output Class Initialized
INFO - 2017-08-04 15:37:13 --> Security Class Initialized
DEBUG - 2017-08-04 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 15:37:13 --> Input Class Initialized
INFO - 2017-08-04 15:37:13 --> Language Class Initialized
INFO - 2017-08-04 15:37:13 --> Loader Class Initialized
INFO - 2017-08-04 15:37:13 --> Helper loaded: url_helper
INFO - 2017-08-04 15:37:13 --> Helper loaded: form_helper
INFO - 2017-08-04 15:37:13 --> Helper loaded: security_helper
INFO - 2017-08-04 15:37:13 --> Helper loaded: path_helper
INFO - 2017-08-04 15:37:13 --> Helper loaded: common_helper
INFO - 2017-08-04 15:37:14 --> Config Class Initialized
INFO - 2017-08-04 15:37:14 --> Hooks Class Initialized
DEBUG - 2017-08-04 15:37:14 --> UTF-8 Support Enabled
INFO - 2017-08-04 15:37:14 --> Utf8 Class Initialized
INFO - 2017-08-04 15:37:14 --> URI Class Initialized
INFO - 2017-08-04 15:37:14 --> Router Class Initialized
INFO - 2017-08-04 15:37:14 --> Output Class Initialized
INFO - 2017-08-04 15:37:14 --> Security Class Initialized
DEBUG - 2017-08-04 15:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 15:37:14 --> Input Class Initialized
INFO - 2017-08-04 15:37:14 --> Language Class Initialized
INFO - 2017-08-04 15:37:14 --> Loader Class Initialized
INFO - 2017-08-04 15:37:14 --> Helper loaded: url_helper
INFO - 2017-08-04 15:37:14 --> Helper loaded: form_helper
INFO - 2017-08-04 15:37:14 --> Helper loaded: security_helper
INFO - 2017-08-04 15:37:14 --> Helper loaded: path_helper
INFO - 2017-08-04 15:37:14 --> Helper loaded: common_helper
INFO - 2017-08-04 15:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 15:37:15 --> Helper loaded: check_session_helper
INFO - 2017-08-04 15:37:15 --> Database Driver Class Initialized
DEBUG - 2017-08-04 15:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:15 --> Email Class Initialized
INFO - 2017-08-04 15:37:15 --> Form Validation Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Controller Class Initialized
DEBUG - 2017-08-04 15:37:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 15:37:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/user_add.php
INFO - 2017-08-04 15:37:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 15:37:15 --> Final output sent to browser
DEBUG - 2017-08-04 15:37:15 --> Total execution time: 2.8180
DEBUG - 2017-08-04 15:37:15 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 15:37:15 --> Database Forge Class Initialized
INFO - 2017-08-04 15:37:15 --> User Agent Class Initialized
DEBUG - 2017-08-04 15:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 15:37:15 --> Helper loaded: check_session_helper
INFO - 2017-08-04 15:37:15 --> Database Driver Class Initialized
DEBUG - 2017-08-04 15:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:15 --> Email Class Initialized
INFO - 2017-08-04 15:37:15 --> Form Validation Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Model Class Initialized
INFO - 2017-08-04 15:37:15 --> Controller Class Initialized
INFO - 2017-08-04 15:37:15 --> Helper loaded: captcha_helper
INFO - 2017-08-04 15:37:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-08-04 15:37:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 15:37:15 --> Final output sent to browser
DEBUG - 2017-08-04 15:37:15 --> Total execution time: 0.8741
DEBUG - 2017-08-04 15:37:15 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 15:37:15 --> Database Forge Class Initialized
INFO - 2017-08-04 15:37:15 --> User Agent Class Initialized
DEBUG - 2017-08-04 15:37:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 15:37:23 --> Config Class Initialized
INFO - 2017-08-04 15:37:23 --> Hooks Class Initialized
DEBUG - 2017-08-04 15:37:23 --> UTF-8 Support Enabled
INFO - 2017-08-04 15:37:23 --> Utf8 Class Initialized
INFO - 2017-08-04 15:37:23 --> URI Class Initialized
INFO - 2017-08-04 15:37:23 --> Router Class Initialized
INFO - 2017-08-04 15:37:23 --> Output Class Initialized
INFO - 2017-08-04 15:37:23 --> Security Class Initialized
DEBUG - 2017-08-04 15:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 15:37:23 --> Input Class Initialized
INFO - 2017-08-04 15:37:23 --> Language Class Initialized
ERROR - 2017-08-04 15:37:23 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 16:01:48 --> Config Class Initialized
INFO - 2017-08-04 16:01:48 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:01:48 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:01:48 --> Utf8 Class Initialized
INFO - 2017-08-04 16:01:48 --> URI Class Initialized
INFO - 2017-08-04 16:01:48 --> Router Class Initialized
INFO - 2017-08-04 16:01:48 --> Output Class Initialized
INFO - 2017-08-04 16:01:48 --> Security Class Initialized
DEBUG - 2017-08-04 16:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:01:48 --> Input Class Initialized
INFO - 2017-08-04 16:01:48 --> Language Class Initialized
INFO - 2017-08-04 16:01:48 --> Loader Class Initialized
INFO - 2017-08-04 16:01:48 --> Helper loaded: url_helper
INFO - 2017-08-04 16:01:48 --> Helper loaded: form_helper
INFO - 2017-08-04 16:01:48 --> Helper loaded: security_helper
INFO - 2017-08-04 16:01:48 --> Helper loaded: path_helper
INFO - 2017-08-04 16:01:48 --> Helper loaded: common_helper
INFO - 2017-08-04 16:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:01:48 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:01:48 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:01:48 --> Email Class Initialized
INFO - 2017-08-04 16:01:48 --> Form Validation Class Initialized
INFO - 2017-08-04 16:01:48 --> Model Class Initialized
INFO - 2017-08-04 16:01:48 --> Model Class Initialized
INFO - 2017-08-04 16:01:48 --> Model Class Initialized
INFO - 2017-08-04 16:01:48 --> Model Class Initialized
INFO - 2017-08-04 16:01:48 --> Controller Class Initialized
INFO - 2017-08-04 16:01:48 --> Model Class Initialized
INFO - 2017-08-04 16:01:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-04 16:01:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-04 16:01:48 --> Final output sent to browser
DEBUG - 2017-08-04 16:01:48 --> Total execution time: 0.0893
DEBUG - 2017-08-04 16:01:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:01:48 --> Database Forge Class Initialized
INFO - 2017-08-04 16:01:48 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:01:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:02:01 --> Config Class Initialized
INFO - 2017-08-04 16:02:01 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:02:01 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:02:01 --> Utf8 Class Initialized
INFO - 2017-08-04 16:02:01 --> URI Class Initialized
INFO - 2017-08-04 16:02:01 --> Router Class Initialized
INFO - 2017-08-04 16:02:01 --> Output Class Initialized
INFO - 2017-08-04 16:02:01 --> Security Class Initialized
DEBUG - 2017-08-04 16:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:02:01 --> Input Class Initialized
INFO - 2017-08-04 16:02:01 --> Language Class Initialized
ERROR - 2017-08-04 16:02:01 --> 404 Page Not Found: Page/assets
INFO - 2017-08-04 16:02:15 --> Config Class Initialized
INFO - 2017-08-04 16:02:15 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:02:15 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:02:15 --> Utf8 Class Initialized
INFO - 2017-08-04 16:02:15 --> URI Class Initialized
DEBUG - 2017-08-04 16:02:15 --> No URI present. Default controller set.
INFO - 2017-08-04 16:02:15 --> Router Class Initialized
INFO - 2017-08-04 16:02:15 --> Output Class Initialized
INFO - 2017-08-04 16:02:15 --> Security Class Initialized
DEBUG - 2017-08-04 16:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:02:15 --> Input Class Initialized
INFO - 2017-08-04 16:02:15 --> Language Class Initialized
INFO - 2017-08-04 16:02:15 --> Loader Class Initialized
INFO - 2017-08-04 16:02:15 --> Helper loaded: url_helper
INFO - 2017-08-04 16:02:15 --> Helper loaded: form_helper
INFO - 2017-08-04 16:02:15 --> Helper loaded: security_helper
INFO - 2017-08-04 16:02:15 --> Helper loaded: path_helper
INFO - 2017-08-04 16:02:15 --> Helper loaded: common_helper
INFO - 2017-08-04 16:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:02:15 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:02:15 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:02:15 --> Email Class Initialized
INFO - 2017-08-04 16:02:15 --> Form Validation Class Initialized
INFO - 2017-08-04 16:02:15 --> Model Class Initialized
INFO - 2017-08-04 16:02:15 --> Model Class Initialized
INFO - 2017-08-04 16:02:15 --> Model Class Initialized
INFO - 2017-08-04 16:02:15 --> Model Class Initialized
INFO - 2017-08-04 16:02:15 --> Controller Class Initialized
DEBUG - 2017-08-04 16:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:02:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 16:02:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 16:02:15 --> Final output sent to browser
DEBUG - 2017-08-04 16:02:15 --> Total execution time: 0.0281
DEBUG - 2017-08-04 16:02:15 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:02:15 --> Database Forge Class Initialized
INFO - 2017-08-04 16:02:15 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:21:00 --> Config Class Initialized
INFO - 2017-08-04 16:21:00 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:21:00 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:21:00 --> Utf8 Class Initialized
INFO - 2017-08-04 16:21:00 --> URI Class Initialized
INFO - 2017-08-04 16:21:00 --> Router Class Initialized
INFO - 2017-08-04 16:21:00 --> Output Class Initialized
INFO - 2017-08-04 16:21:00 --> Security Class Initialized
DEBUG - 2017-08-04 16:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:21:00 --> Input Class Initialized
INFO - 2017-08-04 16:21:00 --> Language Class Initialized
INFO - 2017-08-04 16:21:00 --> Loader Class Initialized
INFO - 2017-08-04 16:21:00 --> Helper loaded: url_helper
INFO - 2017-08-04 16:21:00 --> Helper loaded: form_helper
INFO - 2017-08-04 16:21:00 --> Helper loaded: security_helper
INFO - 2017-08-04 16:21:00 --> Helper loaded: path_helper
INFO - 2017-08-04 16:21:00 --> Helper loaded: common_helper
INFO - 2017-08-04 16:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:21:00 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:21:00 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:21:00 --> Email Class Initialized
INFO - 2017-08-04 16:21:00 --> Form Validation Class Initialized
INFO - 2017-08-04 16:21:00 --> Model Class Initialized
INFO - 2017-08-04 16:21:00 --> Model Class Initialized
INFO - 2017-08-04 16:21:00 --> Model Class Initialized
INFO - 2017-08-04 16:21:00 --> Model Class Initialized
INFO - 2017-08-04 16:21:00 --> Controller Class Initialized
INFO - 2017-08-04 16:21:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 16:21:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-04 16:21:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 16:21:00 --> Final output sent to browser
DEBUG - 2017-08-04 16:21:00 --> Total execution time: 0.0820
DEBUG - 2017-08-04 16:21:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:21:00 --> Database Forge Class Initialized
INFO - 2017-08-04 16:21:00 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:21:04 --> Config Class Initialized
INFO - 2017-08-04 16:21:04 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:21:04 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:21:04 --> Utf8 Class Initialized
INFO - 2017-08-04 16:21:04 --> URI Class Initialized
INFO - 2017-08-04 16:21:04 --> Router Class Initialized
INFO - 2017-08-04 16:21:04 --> Output Class Initialized
INFO - 2017-08-04 16:21:04 --> Security Class Initialized
DEBUG - 2017-08-04 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:21:04 --> Input Class Initialized
INFO - 2017-08-04 16:21:04 --> Language Class Initialized
INFO - 2017-08-04 16:21:04 --> Loader Class Initialized
INFO - 2017-08-04 16:21:04 --> Helper loaded: url_helper
INFO - 2017-08-04 16:21:04 --> Helper loaded: form_helper
INFO - 2017-08-04 16:21:04 --> Helper loaded: security_helper
INFO - 2017-08-04 16:21:04 --> Helper loaded: path_helper
INFO - 2017-08-04 16:21:04 --> Helper loaded: common_helper
INFO - 2017-08-04 16:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:21:04 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:21:04 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:21:04 --> Email Class Initialized
INFO - 2017-08-04 16:21:04 --> Form Validation Class Initialized
INFO - 2017-08-04 16:21:04 --> Model Class Initialized
INFO - 2017-08-04 16:21:04 --> Model Class Initialized
INFO - 2017-08-04 16:21:04 --> Model Class Initialized
INFO - 2017-08-04 16:21:04 --> Model Class Initialized
INFO - 2017-08-04 16:21:04 --> Controller Class Initialized
DEBUG - 2017-08-04 16:21:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:21:04 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 16:21:04 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 16:21:04 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 16:21:04 --> Final output sent to browser
DEBUG - 2017-08-04 16:21:04 --> Total execution time: 0.0316
DEBUG - 2017-08-04 16:21:04 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:21:04 --> Database Forge Class Initialized
INFO - 2017-08-04 16:21:04 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:21:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:33:24 --> Config Class Initialized
INFO - 2017-08-04 16:33:24 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:33:24 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:33:24 --> Utf8 Class Initialized
INFO - 2017-08-04 16:33:24 --> URI Class Initialized
DEBUG - 2017-08-04 16:33:24 --> No URI present. Default controller set.
INFO - 2017-08-04 16:33:24 --> Router Class Initialized
INFO - 2017-08-04 16:33:24 --> Output Class Initialized
INFO - 2017-08-04 16:33:24 --> Security Class Initialized
DEBUG - 2017-08-04 16:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:33:24 --> Input Class Initialized
INFO - 2017-08-04 16:33:24 --> Language Class Initialized
INFO - 2017-08-04 16:33:24 --> Loader Class Initialized
INFO - 2017-08-04 16:33:24 --> Helper loaded: url_helper
INFO - 2017-08-04 16:33:24 --> Helper loaded: form_helper
INFO - 2017-08-04 16:33:24 --> Helper loaded: security_helper
INFO - 2017-08-04 16:33:24 --> Helper loaded: path_helper
INFO - 2017-08-04 16:33:24 --> Helper loaded: common_helper
INFO - 2017-08-04 16:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:33:24 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:33:24 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:33:24 --> Email Class Initialized
INFO - 2017-08-04 16:33:24 --> Form Validation Class Initialized
INFO - 2017-08-04 16:33:24 --> Model Class Initialized
INFO - 2017-08-04 16:33:24 --> Model Class Initialized
INFO - 2017-08-04 16:33:24 --> Model Class Initialized
INFO - 2017-08-04 16:33:24 --> Model Class Initialized
INFO - 2017-08-04 16:33:24 --> Controller Class Initialized
DEBUG - 2017-08-04 16:33:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:33:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 16:33:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 16:33:24 --> Final output sent to browser
DEBUG - 2017-08-04 16:33:24 --> Total execution time: 0.0290
DEBUG - 2017-08-04 16:33:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:33:24 --> Database Forge Class Initialized
INFO - 2017-08-04 16:33:24 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:45:42 --> Config Class Initialized
INFO - 2017-08-04 16:45:42 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:45:42 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:45:42 --> Utf8 Class Initialized
INFO - 2017-08-04 16:45:42 --> URI Class Initialized
DEBUG - 2017-08-04 16:45:42 --> No URI present. Default controller set.
INFO - 2017-08-04 16:45:42 --> Router Class Initialized
INFO - 2017-08-04 16:45:42 --> Output Class Initialized
INFO - 2017-08-04 16:45:42 --> Security Class Initialized
DEBUG - 2017-08-04 16:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:45:42 --> Input Class Initialized
INFO - 2017-08-04 16:45:42 --> Language Class Initialized
INFO - 2017-08-04 16:45:42 --> Loader Class Initialized
INFO - 2017-08-04 16:45:42 --> Helper loaded: url_helper
INFO - 2017-08-04 16:45:42 --> Helper loaded: form_helper
INFO - 2017-08-04 16:45:42 --> Helper loaded: security_helper
INFO - 2017-08-04 16:45:42 --> Helper loaded: path_helper
INFO - 2017-08-04 16:45:42 --> Helper loaded: common_helper
INFO - 2017-08-04 16:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:45:42 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:45:42 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:45:42 --> Email Class Initialized
INFO - 2017-08-04 16:45:42 --> Form Validation Class Initialized
INFO - 2017-08-04 16:45:42 --> Model Class Initialized
INFO - 2017-08-04 16:45:42 --> Model Class Initialized
INFO - 2017-08-04 16:45:42 --> Model Class Initialized
INFO - 2017-08-04 16:45:42 --> Model Class Initialized
INFO - 2017-08-04 16:45:42 --> Controller Class Initialized
DEBUG - 2017-08-04 16:45:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:45:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 16:45:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 16:45:42 --> Final output sent to browser
DEBUG - 2017-08-04 16:45:42 --> Total execution time: 0.0293
DEBUG - 2017-08-04 16:45:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:45:42 --> Database Forge Class Initialized
INFO - 2017-08-04 16:45:42 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:45:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:45:50 --> Config Class Initialized
INFO - 2017-08-04 16:45:50 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:45:50 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:45:50 --> Utf8 Class Initialized
INFO - 2017-08-04 16:45:50 --> URI Class Initialized
INFO - 2017-08-04 16:45:50 --> Router Class Initialized
INFO - 2017-08-04 16:45:50 --> Output Class Initialized
INFO - 2017-08-04 16:45:50 --> Security Class Initialized
DEBUG - 2017-08-04 16:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:45:50 --> Input Class Initialized
INFO - 2017-08-04 16:45:50 --> Language Class Initialized
ERROR - 2017-08-04 16:45:50 --> 404 Page Not Found: Assets/css
INFO - 2017-08-04 16:46:06 --> Config Class Initialized
INFO - 2017-08-04 16:46:06 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:46:06 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:46:06 --> Utf8 Class Initialized
INFO - 2017-08-04 16:46:06 --> URI Class Initialized
INFO - 2017-08-04 16:46:06 --> Router Class Initialized
INFO - 2017-08-04 16:46:06 --> Output Class Initialized
INFO - 2017-08-04 16:46:06 --> Security Class Initialized
DEBUG - 2017-08-04 16:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:46:06 --> Input Class Initialized
INFO - 2017-08-04 16:46:06 --> Language Class Initialized
ERROR - 2017-08-04 16:46:06 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-04 16:57:03 --> Config Class Initialized
INFO - 2017-08-04 16:57:03 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:57:03 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:57:03 --> Utf8 Class Initialized
INFO - 2017-08-04 16:57:03 --> URI Class Initialized
DEBUG - 2017-08-04 16:57:03 --> No URI present. Default controller set.
INFO - 2017-08-04 16:57:03 --> Router Class Initialized
INFO - 2017-08-04 16:57:03 --> Output Class Initialized
INFO - 2017-08-04 16:57:03 --> Security Class Initialized
DEBUG - 2017-08-04 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:57:03 --> Input Class Initialized
INFO - 2017-08-04 16:57:03 --> Language Class Initialized
INFO - 2017-08-04 16:57:03 --> Loader Class Initialized
INFO - 2017-08-04 16:57:03 --> Helper loaded: url_helper
INFO - 2017-08-04 16:57:03 --> Helper loaded: form_helper
INFO - 2017-08-04 16:57:03 --> Helper loaded: security_helper
INFO - 2017-08-04 16:57:03 --> Helper loaded: path_helper
INFO - 2017-08-04 16:57:03 --> Helper loaded: common_helper
INFO - 2017-08-04 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:57:03 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:57:03 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:03 --> Email Class Initialized
INFO - 2017-08-04 16:57:03 --> Form Validation Class Initialized
INFO - 2017-08-04 16:57:03 --> Model Class Initialized
INFO - 2017-08-04 16:57:03 --> Model Class Initialized
INFO - 2017-08-04 16:57:03 --> Model Class Initialized
INFO - 2017-08-04 16:57:03 --> Model Class Initialized
INFO - 2017-08-04 16:57:03 --> Controller Class Initialized
DEBUG - 2017-08-04 16:57:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-04 16:57:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-04 16:57:03 --> Final output sent to browser
DEBUG - 2017-08-04 16:57:03 --> Total execution time: 0.0271
DEBUG - 2017-08-04 16:57:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:57:03 --> Database Forge Class Initialized
INFO - 2017-08-04 16:57:03 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:10 --> Config Class Initialized
INFO - 2017-08-04 16:57:10 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:57:10 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:57:10 --> Utf8 Class Initialized
INFO - 2017-08-04 16:57:10 --> URI Class Initialized
INFO - 2017-08-04 16:57:10 --> Router Class Initialized
INFO - 2017-08-04 16:57:10 --> Output Class Initialized
INFO - 2017-08-04 16:57:10 --> Security Class Initialized
DEBUG - 2017-08-04 16:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:57:10 --> Input Class Initialized
INFO - 2017-08-04 16:57:10 --> Language Class Initialized
INFO - 2017-08-04 16:57:10 --> Loader Class Initialized
INFO - 2017-08-04 16:57:10 --> Helper loaded: url_helper
INFO - 2017-08-04 16:57:10 --> Helper loaded: form_helper
INFO - 2017-08-04 16:57:10 --> Helper loaded: security_helper
INFO - 2017-08-04 16:57:10 --> Helper loaded: path_helper
INFO - 2017-08-04 16:57:10 --> Helper loaded: common_helper
INFO - 2017-08-04 16:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-04 16:57:10 --> Helper loaded: check_session_helper
INFO - 2017-08-04 16:57:10 --> Database Driver Class Initialized
DEBUG - 2017-08-04 16:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:10 --> Email Class Initialized
INFO - 2017-08-04 16:57:10 --> Form Validation Class Initialized
INFO - 2017-08-04 16:57:10 --> Model Class Initialized
INFO - 2017-08-04 16:57:10 --> Model Class Initialized
INFO - 2017-08-04 16:57:10 --> Model Class Initialized
INFO - 2017-08-04 16:57:10 --> Model Class Initialized
INFO - 2017-08-04 16:57:10 --> Controller Class Initialized
DEBUG - 2017-08-04 16:57:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-04 16:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-04 16:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-04 16:57:10 --> Final output sent to browser
DEBUG - 2017-08-04 16:57:10 --> Total execution time: 0.0278
DEBUG - 2017-08-04 16:57:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-04 16:57:10 --> Database Forge Class Initialized
INFO - 2017-08-04 16:57:10 --> User Agent Class Initialized
DEBUG - 2017-08-04 16:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-04 16:57:14 --> Config Class Initialized
INFO - 2017-08-04 16:57:14 --> Hooks Class Initialized
DEBUG - 2017-08-04 16:57:14 --> UTF-8 Support Enabled
INFO - 2017-08-04 16:57:14 --> Utf8 Class Initialized
INFO - 2017-08-04 16:57:14 --> URI Class Initialized
INFO - 2017-08-04 16:57:14 --> Router Class Initialized
INFO - 2017-08-04 16:57:14 --> Output Class Initialized
INFO - 2017-08-04 16:57:14 --> Security Class Initialized
DEBUG - 2017-08-04 16:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-04 16:57:14 --> Input Class Initialized
INFO - 2017-08-04 16:57:14 --> Language Class Initialized
ERROR - 2017-08-04 16:57:14 --> 404 Page Not Found: Faviconico/index
