<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-10 00:08:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 00:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 00:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 02:18:00 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'b8f6e956b4fa52b5c10a19debb212ceca950c836', '/', 1470820680, '184.105.139.67', NULL, '')
ERROR - 2016-08-10 04:25:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 04:25:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 05:35:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 05:36:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 05:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:00:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:00:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:01:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:01:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-10 06:03:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:03:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:05:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 06:22:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 07:55:35 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-10 08:04:44 --> 404 Page Not Found: Domain_lockjpg/index
ERROR - 2016-08-10 08:04:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 08:04:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 08:04:48 --> 404 Page Not Found: Domain_lockjpg/index
ERROR - 2016-08-10 08:05:53 --> 404 Page Not Found: Domain_lockjpg/index
ERROR - 2016-08-10 08:07:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 09:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-10 11:16:00 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-10 13:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-08-10 13:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-10 16:42:57 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-10 16:42:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-10 16:43:21 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-10 16:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-10 18:36:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-08-10 18:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-10 18:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-10 18:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-10 18:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-10 18:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-08-10 18:50:51 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 295
ERROR - 2016-08-10 18:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 298
ERROR - 2016-08-10 19:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-10 20:19:25 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-10 20:21:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-10 20:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-10 20:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 20:57:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 20:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 20:58:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 20:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 20:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 21:11:02 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 21:11:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 21:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 21:11:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 21:11:49 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 21:11:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 21:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-10 21:12:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-10 21:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-10 23:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 23:30:08 --> 404 Page Not Found: Faviconico/index
