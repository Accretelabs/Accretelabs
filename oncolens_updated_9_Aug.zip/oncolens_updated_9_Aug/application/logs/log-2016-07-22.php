<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-22 00:16:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 00:41:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 01:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-07-22 02:00:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 02:04:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 02:43:40 --> 404 Page Not Found: 1469179969_6_13_image1png/index
ERROR - 2016-07-22 02:43:55 --> 404 Page Not Found: Uploads/1469179969_6_13_image1.png
ERROR - 2016-07-22 02:55:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 03:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 03:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:34:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 03:58:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 03:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:01:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-22 04:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:19:17 --> Severity: Warning --> array_filter() expects parameter 1 to be array, boolean given /var/www/html/application/models/Musers.php 1108
ERROR - 2016-07-22 04:32:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 04:57:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 05:04:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/application/third_party/PHPExcel/PHPExcel/Shared/OLE/PPS/Root.php:228) /var/www/html/system/helpers/url_helper.php 564
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 05:15:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 05:16:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 05:16:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 05:23:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 05:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 05:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 05:42:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 05:43:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-22 05:43:47 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-22 05:44:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-22 05:44:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-22 05:44:54 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 06:36:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 06:41:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 06:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3958
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3959
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3961
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3962
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3964
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3965
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3967
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3968
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3970
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3971
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3973
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3974
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3976
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3977
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3979
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3980
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3992
ERROR - 2016-07-22 06:58:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/application/views/contentpage.php 3996
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 07:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 10:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-22 10:09:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-22 10:09:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 10:11:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-22 10:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 10:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 10:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 10:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 10:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 38
ERROR - 2016-07-22 22:50:30 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'ece573e8661fc54fe3a7ba3f430a2254c531ec75', '/', 1469253030, '216.218.206.68', NULL, '')
