<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-15 03:34:54 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'f1c87fda487ce09f772c4a89520067997e93f527', '/', 1471257294, '74.82.47.3', NULL, '')
ERROR - 2016-08-15 04:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-15 04:43:05 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-08-15 04:44:07 --> 404 Page Not Found: Blog/index
ERROR - 2016-08-15 07:32:35 --> 404 Page Not Found: Well-known/apple-app-site-association
ERROR - 2016-08-15 07:35:35 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-08-15 08:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-15 10:47:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 10:47:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 10:47:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 10:47:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 10:49:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 11:08:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-15 11:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-15 11:08:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 11:08:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-15 11:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-15 11:08:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 14:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-15 14:19:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 14:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-15 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-15 21:00:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:01:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:03:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:04:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:05:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:06:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:06:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-08-15 21:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-15 22:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-15 23:08:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 23:09:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 23:52:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 23:52:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 23:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-15 23:52:41 --> 404 Page Not Found: Faviconico/index
