<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-27 04:52:38 --> Config Class Initialized
INFO - 2017-07-27 04:52:38 --> Hooks Class Initialized
DEBUG - 2017-07-27 04:52:39 --> UTF-8 Support Enabled
INFO - 2017-07-27 04:52:39 --> Utf8 Class Initialized
INFO - 2017-07-27 04:52:39 --> URI Class Initialized
DEBUG - 2017-07-27 04:52:39 --> No URI present. Default controller set.
INFO - 2017-07-27 04:52:39 --> Router Class Initialized
INFO - 2017-07-27 04:52:39 --> Output Class Initialized
INFO - 2017-07-27 04:52:39 --> Security Class Initialized
DEBUG - 2017-07-27 04:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 04:52:39 --> Input Class Initialized
INFO - 2017-07-27 04:52:39 --> Language Class Initialized
INFO - 2017-07-27 04:52:39 --> Loader Class Initialized
INFO - 2017-07-27 04:52:39 --> Helper loaded: url_helper
INFO - 2017-07-27 04:52:39 --> Helper loaded: form_helper
INFO - 2017-07-27 04:52:39 --> Helper loaded: security_helper
INFO - 2017-07-27 04:52:39 --> Helper loaded: path_helper
INFO - 2017-07-27 04:52:39 --> Helper loaded: common_helper
INFO - 2017-07-27 04:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 04:52:39 --> Helper loaded: check_session_helper
INFO - 2017-07-27 04:52:39 --> Database Driver Class Initialized
DEBUG - 2017-07-27 04:52:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 04:52:39 --> Email Class Initialized
INFO - 2017-07-27 04:52:39 --> Form Validation Class Initialized
INFO - 2017-07-27 04:52:39 --> Model Class Initialized
INFO - 2017-07-27 04:52:40 --> Model Class Initialized
INFO - 2017-07-27 04:52:40 --> Model Class Initialized
INFO - 2017-07-27 04:52:40 --> Model Class Initialized
INFO - 2017-07-27 04:52:40 --> Controller Class Initialized
DEBUG - 2017-07-27 04:52:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 04:52:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 04:52:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 04:52:40 --> Final output sent to browser
DEBUG - 2017-07-27 04:52:40 --> Total execution time: 1.4385
DEBUG - 2017-07-27 04:52:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 04:52:40 --> Database Forge Class Initialized
INFO - 2017-07-27 04:52:40 --> User Agent Class Initialized
DEBUG - 2017-07-27 04:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 04:52:54 --> Config Class Initialized
INFO - 2017-07-27 04:52:54 --> Hooks Class Initialized
DEBUG - 2017-07-27 04:52:54 --> UTF-8 Support Enabled
INFO - 2017-07-27 04:52:54 --> Utf8 Class Initialized
INFO - 2017-07-27 04:52:54 --> URI Class Initialized
INFO - 2017-07-27 04:52:55 --> Router Class Initialized
INFO - 2017-07-27 04:52:55 --> Output Class Initialized
INFO - 2017-07-27 04:52:55 --> Security Class Initialized
DEBUG - 2017-07-27 04:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 04:52:55 --> Input Class Initialized
INFO - 2017-07-27 04:52:55 --> Language Class Initialized
INFO - 2017-07-27 04:52:55 --> Loader Class Initialized
INFO - 2017-07-27 04:52:55 --> Helper loaded: url_helper
INFO - 2017-07-27 04:52:55 --> Helper loaded: form_helper
INFO - 2017-07-27 04:52:55 --> Helper loaded: security_helper
INFO - 2017-07-27 04:52:55 --> Helper loaded: path_helper
INFO - 2017-07-27 04:52:55 --> Helper loaded: common_helper
INFO - 2017-07-27 04:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 04:52:55 --> Helper loaded: check_session_helper
INFO - 2017-07-27 04:52:55 --> Database Driver Class Initialized
DEBUG - 2017-07-27 04:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 04:52:55 --> Email Class Initialized
INFO - 2017-07-27 04:52:55 --> Form Validation Class Initialized
INFO - 2017-07-27 04:52:55 --> Model Class Initialized
INFO - 2017-07-27 04:52:55 --> Model Class Initialized
INFO - 2017-07-27 04:52:55 --> Model Class Initialized
INFO - 2017-07-27 04:52:55 --> Model Class Initialized
INFO - 2017-07-27 04:52:55 --> Controller Class Initialized
INFO - 2017-07-27 04:52:55 --> Model Class Initialized
INFO - 2017-07-27 04:52:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-27 04:52:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-27 04:52:55 --> Final output sent to browser
DEBUG - 2017-07-27 04:52:55 --> Total execution time: 1.4807
DEBUG - 2017-07-27 04:52:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 04:52:55 --> Database Forge Class Initialized
INFO - 2017-07-27 04:52:55 --> User Agent Class Initialized
DEBUG - 2017-07-27 04:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 04:53:05 --> Config Class Initialized
INFO - 2017-07-27 04:53:05 --> Hooks Class Initialized
DEBUG - 2017-07-27 04:53:05 --> UTF-8 Support Enabled
INFO - 2017-07-27 04:53:05 --> Utf8 Class Initialized
INFO - 2017-07-27 04:53:05 --> URI Class Initialized
INFO - 2017-07-27 04:53:05 --> Router Class Initialized
INFO - 2017-07-27 04:53:05 --> Output Class Initialized
INFO - 2017-07-27 04:53:05 --> Security Class Initialized
DEBUG - 2017-07-27 04:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 04:53:05 --> Input Class Initialized
INFO - 2017-07-27 04:53:05 --> Language Class Initialized
ERROR - 2017-07-27 04:53:06 --> 404 Page Not Found: Page/assets
INFO - 2017-07-27 06:34:48 --> Config Class Initialized
INFO - 2017-07-27 06:34:48 --> Hooks Class Initialized
DEBUG - 2017-07-27 06:34:48 --> UTF-8 Support Enabled
INFO - 2017-07-27 06:34:48 --> Utf8 Class Initialized
INFO - 2017-07-27 06:34:48 --> URI Class Initialized
INFO - 2017-07-27 06:34:48 --> Router Class Initialized
INFO - 2017-07-27 06:34:48 --> Output Class Initialized
INFO - 2017-07-27 06:34:48 --> Security Class Initialized
DEBUG - 2017-07-27 06:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 06:34:48 --> Input Class Initialized
INFO - 2017-07-27 06:34:48 --> Language Class Initialized
INFO - 2017-07-27 06:34:48 --> Loader Class Initialized
INFO - 2017-07-27 06:34:48 --> Helper loaded: url_helper
INFO - 2017-07-27 06:34:48 --> Helper loaded: form_helper
INFO - 2017-07-27 06:34:48 --> Helper loaded: security_helper
INFO - 2017-07-27 06:34:48 --> Helper loaded: path_helper
INFO - 2017-07-27 06:34:48 --> Helper loaded: common_helper
INFO - 2017-07-27 06:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 06:34:49 --> Helper loaded: check_session_helper
INFO - 2017-07-27 06:34:49 --> Database Driver Class Initialized
DEBUG - 2017-07-27 06:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 06:34:49 --> Email Class Initialized
INFO - 2017-07-27 06:34:49 --> Form Validation Class Initialized
INFO - 2017-07-27 06:34:49 --> Model Class Initialized
INFO - 2017-07-27 06:34:49 --> Model Class Initialized
INFO - 2017-07-27 06:34:49 --> Model Class Initialized
INFO - 2017-07-27 06:34:49 --> Model Class Initialized
INFO - 2017-07-27 06:34:49 --> Controller Class Initialized
INFO - 2017-07-27 06:34:49 --> Model Class Initialized
INFO - 2017-07-27 06:34:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-27 06:34:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-27 06:34:49 --> Final output sent to browser
DEBUG - 2017-07-27 06:34:49 --> Total execution time: 2.1529
DEBUG - 2017-07-27 06:34:51 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 06:34:51 --> Database Forge Class Initialized
INFO - 2017-07-27 06:34:51 --> User Agent Class Initialized
DEBUG - 2017-07-27 06:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 06:35:15 --> Config Class Initialized
INFO - 2017-07-27 06:35:15 --> Hooks Class Initialized
DEBUG - 2017-07-27 06:35:15 --> UTF-8 Support Enabled
INFO - 2017-07-27 06:35:15 --> Utf8 Class Initialized
INFO - 2017-07-27 06:35:15 --> URI Class Initialized
INFO - 2017-07-27 06:35:15 --> Router Class Initialized
INFO - 2017-07-27 06:35:15 --> Output Class Initialized
INFO - 2017-07-27 06:35:15 --> Security Class Initialized
INFO - 2017-07-27 06:35:15 --> Config Class Initialized
INFO - 2017-07-27 06:35:15 --> Hooks Class Initialized
DEBUG - 2017-07-27 06:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 06:35:15 --> Input Class Initialized
INFO - 2017-07-27 06:35:15 --> Language Class Initialized
DEBUG - 2017-07-27 06:35:15 --> UTF-8 Support Enabled
INFO - 2017-07-27 06:35:15 --> Utf8 Class Initialized
INFO - 2017-07-27 06:35:15 --> URI Class Initialized
INFO - 2017-07-27 06:35:15 --> Router Class Initialized
INFO - 2017-07-27 06:35:15 --> Output Class Initialized
INFO - 2017-07-27 06:35:15 --> Security Class Initialized
DEBUG - 2017-07-27 06:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 06:35:15 --> Input Class Initialized
INFO - 2017-07-27 06:35:15 --> Language Class Initialized
ERROR - 2017-07-27 06:35:15 --> 404 Page Not Found: Page/assets
ERROR - 2017-07-27 06:35:15 --> 404 Page Not Found: Page/assets
INFO - 2017-07-27 11:33:31 --> Config Class Initialized
INFO - 2017-07-27 11:33:31 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:33:31 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:33:31 --> Utf8 Class Initialized
INFO - 2017-07-27 11:33:31 --> URI Class Initialized
DEBUG - 2017-07-27 11:33:31 --> No URI present. Default controller set.
INFO - 2017-07-27 11:33:31 --> Router Class Initialized
INFO - 2017-07-27 11:33:31 --> Output Class Initialized
INFO - 2017-07-27 11:33:31 --> Security Class Initialized
DEBUG - 2017-07-27 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:33:31 --> Input Class Initialized
INFO - 2017-07-27 11:33:31 --> Language Class Initialized
INFO - 2017-07-27 11:33:31 --> Loader Class Initialized
INFO - 2017-07-27 11:33:31 --> Helper loaded: url_helper
INFO - 2017-07-27 11:33:31 --> Helper loaded: form_helper
INFO - 2017-07-27 11:33:31 --> Helper loaded: security_helper
INFO - 2017-07-27 11:33:31 --> Helper loaded: path_helper
INFO - 2017-07-27 11:33:31 --> Helper loaded: common_helper
INFO - 2017-07-27 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:33:31 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:33:31 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:31 --> Email Class Initialized
INFO - 2017-07-27 11:33:31 --> Form Validation Class Initialized
INFO - 2017-07-27 11:33:31 --> Model Class Initialized
INFO - 2017-07-27 11:33:31 --> Model Class Initialized
INFO - 2017-07-27 11:33:31 --> Model Class Initialized
INFO - 2017-07-27 11:33:31 --> Model Class Initialized
INFO - 2017-07-27 11:33:31 --> Controller Class Initialized
DEBUG - 2017-07-27 11:33:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:33:31 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:33:31 --> Final output sent to browser
DEBUG - 2017-07-27 11:33:31 --> Total execution time: 0.1636
DEBUG - 2017-07-27 11:33:31 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:33:31 --> Database Forge Class Initialized
INFO - 2017-07-27 11:33:31 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:33:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:32 --> Config Class Initialized
INFO - 2017-07-27 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:33:32 --> Utf8 Class Initialized
INFO - 2017-07-27 11:33:32 --> URI Class Initialized
DEBUG - 2017-07-27 11:33:32 --> No URI present. Default controller set.
INFO - 2017-07-27 11:33:32 --> Router Class Initialized
INFO - 2017-07-27 11:33:32 --> Output Class Initialized
INFO - 2017-07-27 11:33:32 --> Security Class Initialized
DEBUG - 2017-07-27 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:33:32 --> Input Class Initialized
INFO - 2017-07-27 11:33:32 --> Language Class Initialized
INFO - 2017-07-27 11:33:32 --> Loader Class Initialized
INFO - 2017-07-27 11:33:32 --> Helper loaded: url_helper
INFO - 2017-07-27 11:33:32 --> Helper loaded: form_helper
INFO - 2017-07-27 11:33:32 --> Helper loaded: security_helper
INFO - 2017-07-27 11:33:32 --> Helper loaded: path_helper
INFO - 2017-07-27 11:33:32 --> Helper loaded: common_helper
INFO - 2017-07-27 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:33:32 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:33:32 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:32 --> Email Class Initialized
INFO - 2017-07-27 11:33:32 --> Form Validation Class Initialized
INFO - 2017-07-27 11:33:32 --> Model Class Initialized
INFO - 2017-07-27 11:33:32 --> Model Class Initialized
INFO - 2017-07-27 11:33:32 --> Model Class Initialized
INFO - 2017-07-27 11:33:32 --> Model Class Initialized
INFO - 2017-07-27 11:33:32 --> Controller Class Initialized
DEBUG - 2017-07-27 11:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:33:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:33:32 --> Final output sent to browser
DEBUG - 2017-07-27 11:33:32 --> Total execution time: 0.0289
DEBUG - 2017-07-27 11:33:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:33:32 --> Database Forge Class Initialized
INFO - 2017-07-27 11:33:32 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:33:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:33 --> Config Class Initialized
INFO - 2017-07-27 11:33:33 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:33:33 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:33:33 --> Utf8 Class Initialized
INFO - 2017-07-27 11:33:33 --> URI Class Initialized
DEBUG - 2017-07-27 11:33:33 --> No URI present. Default controller set.
INFO - 2017-07-27 11:33:33 --> Router Class Initialized
INFO - 2017-07-27 11:33:33 --> Output Class Initialized
INFO - 2017-07-27 11:33:33 --> Security Class Initialized
DEBUG - 2017-07-27 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:33:33 --> Input Class Initialized
INFO - 2017-07-27 11:33:33 --> Language Class Initialized
INFO - 2017-07-27 11:33:33 --> Loader Class Initialized
INFO - 2017-07-27 11:33:33 --> Helper loaded: url_helper
INFO - 2017-07-27 11:33:33 --> Helper loaded: form_helper
INFO - 2017-07-27 11:33:33 --> Helper loaded: security_helper
INFO - 2017-07-27 11:33:33 --> Helper loaded: path_helper
INFO - 2017-07-27 11:33:33 --> Helper loaded: common_helper
INFO - 2017-07-27 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:33:33 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:33:33 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:33 --> Email Class Initialized
INFO - 2017-07-27 11:33:33 --> Form Validation Class Initialized
INFO - 2017-07-27 11:33:33 --> Model Class Initialized
INFO - 2017-07-27 11:33:33 --> Model Class Initialized
INFO - 2017-07-27 11:33:33 --> Model Class Initialized
INFO - 2017-07-27 11:33:33 --> Model Class Initialized
INFO - 2017-07-27 11:33:33 --> Controller Class Initialized
DEBUG - 2017-07-27 11:33:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:33:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:33:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:33:33 --> Final output sent to browser
DEBUG - 2017-07-27 11:33:33 --> Total execution time: 0.0257
DEBUG - 2017-07-27 11:33:33 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:33:33 --> Database Forge Class Initialized
INFO - 2017-07-27 11:33:33 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:34:38 --> Config Class Initialized
INFO - 2017-07-27 11:34:38 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:34:38 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:34:38 --> Utf8 Class Initialized
INFO - 2017-07-27 11:34:38 --> URI Class Initialized
DEBUG - 2017-07-27 11:34:38 --> No URI present. Default controller set.
INFO - 2017-07-27 11:34:38 --> Router Class Initialized
INFO - 2017-07-27 11:34:38 --> Output Class Initialized
INFO - 2017-07-27 11:34:38 --> Security Class Initialized
DEBUG - 2017-07-27 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:34:38 --> Input Class Initialized
INFO - 2017-07-27 11:34:38 --> Language Class Initialized
INFO - 2017-07-27 11:34:38 --> Loader Class Initialized
INFO - 2017-07-27 11:34:38 --> Helper loaded: url_helper
INFO - 2017-07-27 11:34:38 --> Helper loaded: form_helper
INFO - 2017-07-27 11:34:38 --> Helper loaded: security_helper
INFO - 2017-07-27 11:34:38 --> Helper loaded: path_helper
INFO - 2017-07-27 11:34:38 --> Helper loaded: common_helper
INFO - 2017-07-27 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:34:38 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:34:38 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:34:38 --> Email Class Initialized
INFO - 2017-07-27 11:34:38 --> Form Validation Class Initialized
INFO - 2017-07-27 11:34:38 --> Model Class Initialized
INFO - 2017-07-27 11:34:38 --> Model Class Initialized
INFO - 2017-07-27 11:34:38 --> Model Class Initialized
INFO - 2017-07-27 11:34:38 --> Model Class Initialized
INFO - 2017-07-27 11:34:38 --> Controller Class Initialized
DEBUG - 2017-07-27 11:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:34:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:34:39 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:34:39 --> Final output sent to browser
DEBUG - 2017-07-27 11:34:39 --> Total execution time: 0.0318
DEBUG - 2017-07-27 11:34:39 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:34:39 --> Database Forge Class Initialized
INFO - 2017-07-27 11:34:39 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:34:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:35:53 --> Config Class Initialized
INFO - 2017-07-27 11:35:53 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:35:53 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:35:53 --> Utf8 Class Initialized
INFO - 2017-07-27 11:35:53 --> URI Class Initialized
DEBUG - 2017-07-27 11:35:53 --> No URI present. Default controller set.
INFO - 2017-07-27 11:35:53 --> Router Class Initialized
INFO - 2017-07-27 11:35:53 --> Output Class Initialized
INFO - 2017-07-27 11:35:53 --> Security Class Initialized
DEBUG - 2017-07-27 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:35:53 --> Input Class Initialized
INFO - 2017-07-27 11:35:53 --> Language Class Initialized
INFO - 2017-07-27 11:35:53 --> Loader Class Initialized
INFO - 2017-07-27 11:35:53 --> Helper loaded: url_helper
INFO - 2017-07-27 11:35:53 --> Helper loaded: form_helper
INFO - 2017-07-27 11:35:53 --> Helper loaded: security_helper
INFO - 2017-07-27 11:35:53 --> Helper loaded: path_helper
INFO - 2017-07-27 11:35:53 --> Helper loaded: common_helper
INFO - 2017-07-27 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:35:53 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:35:53 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:35:53 --> Email Class Initialized
INFO - 2017-07-27 11:35:53 --> Form Validation Class Initialized
INFO - 2017-07-27 11:35:53 --> Model Class Initialized
INFO - 2017-07-27 11:35:53 --> Model Class Initialized
INFO - 2017-07-27 11:35:53 --> Model Class Initialized
INFO - 2017-07-27 11:35:53 --> Model Class Initialized
INFO - 2017-07-27 11:35:53 --> Controller Class Initialized
DEBUG - 2017-07-27 11:35:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:35:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:35:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:35:53 --> Final output sent to browser
DEBUG - 2017-07-27 11:35:53 --> Total execution time: 0.0475
DEBUG - 2017-07-27 11:35:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:35:53 --> Database Forge Class Initialized
INFO - 2017-07-27 11:35:53 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:36:22 --> Config Class Initialized
INFO - 2017-07-27 11:36:22 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:36:22 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:36:22 --> Utf8 Class Initialized
INFO - 2017-07-27 11:36:22 --> URI Class Initialized
DEBUG - 2017-07-27 11:36:22 --> No URI present. Default controller set.
INFO - 2017-07-27 11:36:22 --> Router Class Initialized
INFO - 2017-07-27 11:36:22 --> Output Class Initialized
INFO - 2017-07-27 11:36:22 --> Security Class Initialized
DEBUG - 2017-07-27 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:36:22 --> Input Class Initialized
INFO - 2017-07-27 11:36:22 --> Language Class Initialized
INFO - 2017-07-27 11:36:22 --> Loader Class Initialized
INFO - 2017-07-27 11:36:22 --> Helper loaded: url_helper
INFO - 2017-07-27 11:36:22 --> Helper loaded: form_helper
INFO - 2017-07-27 11:36:22 --> Helper loaded: security_helper
INFO - 2017-07-27 11:36:22 --> Helper loaded: path_helper
INFO - 2017-07-27 11:36:22 --> Helper loaded: common_helper
INFO - 2017-07-27 11:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:36:22 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:36:22 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:36:22 --> Email Class Initialized
INFO - 2017-07-27 11:36:22 --> Form Validation Class Initialized
INFO - 2017-07-27 11:36:22 --> Model Class Initialized
INFO - 2017-07-27 11:36:22 --> Model Class Initialized
INFO - 2017-07-27 11:36:22 --> Model Class Initialized
INFO - 2017-07-27 11:36:22 --> Model Class Initialized
INFO - 2017-07-27 11:36:22 --> Controller Class Initialized
DEBUG - 2017-07-27 11:36:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:36:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:36:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:36:22 --> Final output sent to browser
DEBUG - 2017-07-27 11:36:22 --> Total execution time: 0.0590
DEBUG - 2017-07-27 11:36:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:36:22 --> Database Forge Class Initialized
INFO - 2017-07-27 11:36:22 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:36:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:36:25 --> Config Class Initialized
INFO - 2017-07-27 11:36:25 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:36:25 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:36:25 --> Utf8 Class Initialized
INFO - 2017-07-27 11:36:25 --> URI Class Initialized
INFO - 2017-07-27 11:36:25 --> Router Class Initialized
INFO - 2017-07-27 11:36:25 --> Output Class Initialized
INFO - 2017-07-27 11:36:25 --> Security Class Initialized
DEBUG - 2017-07-27 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:36:25 --> Input Class Initialized
INFO - 2017-07-27 11:36:25 --> Language Class Initialized
INFO - 2017-07-27 11:36:25 --> Loader Class Initialized
INFO - 2017-07-27 11:36:25 --> Helper loaded: url_helper
INFO - 2017-07-27 11:36:25 --> Helper loaded: form_helper
INFO - 2017-07-27 11:36:25 --> Helper loaded: security_helper
INFO - 2017-07-27 11:36:25 --> Helper loaded: path_helper
INFO - 2017-07-27 11:36:25 --> Helper loaded: common_helper
INFO - 2017-07-27 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:36:25 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:36:25 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:36:25 --> Email Class Initialized
INFO - 2017-07-27 11:36:25 --> Form Validation Class Initialized
INFO - 2017-07-27 11:36:25 --> Model Class Initialized
INFO - 2017-07-27 11:36:25 --> Model Class Initialized
INFO - 2017-07-27 11:36:25 --> Model Class Initialized
INFO - 2017-07-27 11:36:25 --> Model Class Initialized
INFO - 2017-07-27 11:36:25 --> Controller Class Initialized
INFO - 2017-07-27 11:36:26 --> Helper loaded: captcha_helper
INFO - 2017-07-27 11:36:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-07-27 11:36:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-27 11:36:26 --> Final output sent to browser
DEBUG - 2017-07-27 11:36:26 --> Total execution time: 0.8991
DEBUG - 2017-07-27 11:36:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:36:26 --> Database Forge Class Initialized
INFO - 2017-07-27 11:36:26 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:36:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:39:32 --> Config Class Initialized
INFO - 2017-07-27 11:39:32 --> Hooks Class Initialized
DEBUG - 2017-07-27 11:39:32 --> UTF-8 Support Enabled
INFO - 2017-07-27 11:39:32 --> Utf8 Class Initialized
INFO - 2017-07-27 11:39:32 --> URI Class Initialized
DEBUG - 2017-07-27 11:39:32 --> No URI present. Default controller set.
INFO - 2017-07-27 11:39:32 --> Router Class Initialized
INFO - 2017-07-27 11:39:32 --> Output Class Initialized
INFO - 2017-07-27 11:39:32 --> Security Class Initialized
DEBUG - 2017-07-27 11:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 11:39:32 --> Input Class Initialized
INFO - 2017-07-27 11:39:32 --> Language Class Initialized
INFO - 2017-07-27 11:39:32 --> Loader Class Initialized
INFO - 2017-07-27 11:39:32 --> Helper loaded: url_helper
INFO - 2017-07-27 11:39:32 --> Helper loaded: form_helper
INFO - 2017-07-27 11:39:32 --> Helper loaded: security_helper
INFO - 2017-07-27 11:39:32 --> Helper loaded: path_helper
INFO - 2017-07-27 11:39:32 --> Helper loaded: common_helper
INFO - 2017-07-27 11:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 11:39:32 --> Helper loaded: check_session_helper
INFO - 2017-07-27 11:39:32 --> Database Driver Class Initialized
DEBUG - 2017-07-27 11:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:39:32 --> Email Class Initialized
INFO - 2017-07-27 11:39:32 --> Form Validation Class Initialized
INFO - 2017-07-27 11:39:32 --> Model Class Initialized
INFO - 2017-07-27 11:39:32 --> Model Class Initialized
INFO - 2017-07-27 11:39:32 --> Model Class Initialized
INFO - 2017-07-27 11:39:32 --> Model Class Initialized
INFO - 2017-07-27 11:39:32 --> Controller Class Initialized
DEBUG - 2017-07-27 11:39:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-27 11:39:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-27 11:39:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-27 11:39:32 --> Final output sent to browser
DEBUG - 2017-07-27 11:39:32 --> Total execution time: 0.0296
DEBUG - 2017-07-27 11:39:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 11:39:32 --> Database Forge Class Initialized
INFO - 2017-07-27 11:39:32 --> User Agent Class Initialized
DEBUG - 2017-07-27 11:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 18:40:19 --> Config Class Initialized
INFO - 2017-07-27 18:40:19 --> Hooks Class Initialized
DEBUG - 2017-07-27 18:40:19 --> UTF-8 Support Enabled
INFO - 2017-07-27 18:40:19 --> Utf8 Class Initialized
INFO - 2017-07-27 18:40:19 --> URI Class Initialized
INFO - 2017-07-27 18:40:19 --> Router Class Initialized
INFO - 2017-07-27 18:40:19 --> Output Class Initialized
INFO - 2017-07-27 18:40:19 --> Security Class Initialized
DEBUG - 2017-07-27 18:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-27 18:40:19 --> Input Class Initialized
INFO - 2017-07-27 18:40:19 --> Language Class Initialized
INFO - 2017-07-27 18:40:19 --> Loader Class Initialized
INFO - 2017-07-27 18:40:19 --> Helper loaded: url_helper
INFO - 2017-07-27 18:40:19 --> Helper loaded: form_helper
INFO - 2017-07-27 18:40:19 --> Helper loaded: security_helper
INFO - 2017-07-27 18:40:19 --> Helper loaded: path_helper
INFO - 2017-07-27 18:40:19 --> Helper loaded: common_helper
INFO - 2017-07-27 18:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-27 18:40:19 --> Helper loaded: check_session_helper
INFO - 2017-07-27 18:40:19 --> Database Driver Class Initialized
DEBUG - 2017-07-27 18:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-27 18:40:19 --> Email Class Initialized
INFO - 2017-07-27 18:40:19 --> Form Validation Class Initialized
INFO - 2017-07-27 18:40:19 --> Model Class Initialized
INFO - 2017-07-27 18:40:19 --> Model Class Initialized
INFO - 2017-07-27 18:40:19 --> Model Class Initialized
INFO - 2017-07-27 18:40:19 --> Model Class Initialized
INFO - 2017-07-27 18:40:19 --> Controller Class Initialized
INFO - 2017-07-27 18:40:19 --> Model Class Initialized
INFO - 2017-07-27 18:40:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-27 18:40:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-27 18:40:19 --> Final output sent to browser
DEBUG - 2017-07-27 18:40:19 --> Total execution time: 0.1266
DEBUG - 2017-07-27 18:40:19 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-27 18:40:19 --> Database Forge Class Initialized
INFO - 2017-07-27 18:40:19 --> User Agent Class Initialized
DEBUG - 2017-07-27 18:40:19 --> Session class already loaded. Second attempt ignored.
