<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-09 00:07:39 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '919180accf967cb1ceaaf05cf33ad384972516db', '/?', 1481270859, '10.85.0.229', NULL, '')
ERROR - 2016-12-09 00:07:49 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '1c017fe647905ca8bf38ce2af967539c325bdbf3', '/?', 1481270869, '10.85.0.229', NULL, '')
ERROR - 2016-12-09 00:09:13 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '781fd511c9023e8867042db8025fadb5a843be94', '/?', 1481270953, '10.85.0.229', NULL, '')
ERROR - 2016-12-09 01:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 02:03:09 --> 404 Page Not Found: M/index
ERROR - 2016-12-09 03:34:24 --> 404 Page Not Found: Yghyxhpawtryhtml/index
ERROR - 2016-12-09 03:35:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:36:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:37:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:38:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:39:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:39:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:40:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 03:41:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-09 04:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 05:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 05:43:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-09 08:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 10:30:45 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:30:45 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:30:45 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:35:25 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:35:25 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:35:25 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-09 10:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 13:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 13:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 17:23:45 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-12-09 20:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-09 23:59:09 --> 404 Page Not Found: Robotstxt/index
