<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-12 03:24:35 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '7120269daee02962f3d0dde16bf78c79e16cb59f', '/', 1481541875, '184.105.139.68', NULL, '')
ERROR - 2016-12-12 03:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 03:50:57 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-12 03:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-12 03:51:22 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-12 03:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-12 03:55:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-12 03:55:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-12 03:56:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-12 03:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-12 03:56:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-12 03:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-12 04:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 04:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 06:02:43 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-12 06:02:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-12 06:49:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 07:12:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 07:13:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 07:15:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 07:51:34 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 08:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 08:26:09 --> 404 Page Not Found: Users/assets
ERROR - 2016-12-12 08:26:25 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 08:27:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 08:27:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 08:27:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-12 08:31:26 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-12 08:31:26 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-12 08:31:26 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-12 08:46:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 08:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 09:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 09:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 09:08:21 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-12 11:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 13:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 14:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 19:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-12 20:51:44 --> 404 Page Not Found: Well-known/assetlinks.json
