<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-09 00:07:42 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '20fd3307d1860ed226b6e021781084806e4b1dad', '/?', 1483949262, '10.85.0.229', NULL, '')
ERROR - 2017-01-09 00:07:52 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '8959a0b52478587b5f51fa07e001a565a3e23b2c', '/?', 1483949272, '10.85.0.229', NULL, '')
ERROR - 2017-01-09 00:09:16 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '298e513c929d432084621f5eaa938b22a678ab98', '/?', 1483949356, '10.85.0.229', NULL, '')
ERROR - 2017-01-09 03:42:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:42:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:43:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:44:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:45:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:46:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:47:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 03:48:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 04:43:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 04:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 05:47:49 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '23e87d083a0a8e9d0bb9afcc20d234cfbd48659f', '/', 1483969669, '74.82.47.4', NULL, '')
ERROR - 2017-01-09 06:04:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 06:04:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 06:04:47 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 06:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 06:06:25 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-09 06:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 06:09:58 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-09 07:12:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:12:04 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-09 07:12:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 07:12:20 --> 404 Page Not Found: Users/assets
ERROR - 2017-01-09 07:12:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:12:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 07:13:27 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-09 07:13:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:13:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:14:47 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:14:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:20:16 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-09 07:20:16 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-09 07:26:24 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-09 07:26:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:26:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:43:39 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-09 07:43:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 07:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 07:50:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 09:29:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 09:29:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 09:29:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 09:29:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 09:40:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 09:40:35 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-09 09:40:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 09:43:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-09 11:26:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 11:26:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-09 11:27:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 11:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 11:27:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 11:27:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 12:26:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 12:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 12:31:57 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 12:31:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 12:31:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 12:31:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 12:32:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 12:32:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 12:32:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-09 12:32:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-09 16:34:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:34:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:37:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:37:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:37:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:45:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:47:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:47:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:47:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 16:47:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-09 17:54:08 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
