<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-30 05:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-30 05:48:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-30 06:18:19 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-30 06:18:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-30 06:18:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-30 06:30:01 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-30 11:49:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-30 13:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-30 13:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-30 13:50:59 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-12-30 14:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-30 17:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-30 17:22:50 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'cf40120a09b52418bbf036b1e49278f021b91984', '/', 1483147369, '168.1.128.74', NULL, '')
