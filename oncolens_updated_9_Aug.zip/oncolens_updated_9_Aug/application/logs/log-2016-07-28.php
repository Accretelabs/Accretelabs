<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-28 02:50:15 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '2a7b78fe018684812e2643ca938671d613e17cdd', '/', 1469699415, '62.210.181.123', NULL, '')
