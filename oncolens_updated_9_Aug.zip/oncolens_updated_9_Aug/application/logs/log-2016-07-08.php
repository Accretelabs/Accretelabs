<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-08 17:44:34 --> Query error: Unknown column 'test' in 'where clause' - Invalid query: SELECT 
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  h.case_entered_by,
                  AES_DECRYPT(h.name,'Oncolens') as pname,
                  AES_DECRYPT(h.dob,'Oncolens') as dob,
                       AES_DECRYPT(h.name,'Oncolens') as name,
                        AES_DECRYPT(h.case_description, 'Oncolens') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT 
                    CONCAT(fname, ' ', lname) 
                  FROM
                    users 
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network` 
                FROM
                  case_request_images AS a 
                  INNER JOIN case_assignments AS b 
                    ON a.case_id = b.case_id 
                  INNER JOIN case_history AS h 
                    ON h.id = b.case_id 
                  INNER JOIN users AS d 
                    ON d.id != h.case_entered_by 
                  LEFT JOIN `hospital_network` h1 
                    ON h1.`id` = h.assigned_hospital 
                WHERE a.doctor_id = '6' 
                  AND h.case_status = '1' 
                  AND h.is_deleted = '0' 
                  AND a.is_forwarded = '0' 
                  AND a.case_id NOT IN 
                  (SELECT 
                    case_id 
                  FROM
                    case_save_images 
                  WHERE doctor_id = '6 '
                  UNION
                  SELECT 
                    case_id 
                  FROM
                    case_save_images 
                  WHERE `speciality_id` = 11 
                    AND case_id NOT IN 
                    (SELECT 
                      cs.`case_id` 
                    FROM
                      `case_save_images` cs 
                      INNER JOIN case_history ch 
                        ON cs.`case_id` = ch.`id` 
                        AND cs.`doctor_id` = ch.`case_entered_by` 
                        AND cs.`doctor_id` != 6 
                    GROUP BY case_id)) 
                    and h.id=test
                GROUP BY b.case_id 
                ORDER BY h.case_updated_date DESC 
                 
ERROR - 2016-07-08 17:44:34 --> Severity: Error --> Call to a member function row() on a non-object /home3/rich/public_html/oncolensphp/application/models/Mcase.php 3594
