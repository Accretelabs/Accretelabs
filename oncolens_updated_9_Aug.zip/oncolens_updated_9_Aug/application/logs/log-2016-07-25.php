<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-25 02:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-25 04:26:05 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '18818eac96843c4eba5918148d7a6f8d85475995', '/', 1469445965, '184.105.139.70', NULL, '')
ERROR - 2016-07-25 07:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 10:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-25 10:23:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 10:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-25 10:23:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:23:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 10:24:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 10:24:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-25 10:24:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 10:24:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:24:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:24:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:24:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:25:16 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:25:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:25:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:25:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:26:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:26:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:27:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-25 10:27:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:27:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:27:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 10:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-25 10:27:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-07-25 11:12:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 11:32:30 --> 404 Page Not Found: Page/assets
ERROR - 2016-07-25 16:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-25 18:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 18:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 20:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-07-25 20:31:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 21:22:56 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'c4df27a0d265996c83ad2ae2a3f86f98dd1c10ab', '/', 1469506976, '74.82.47.2', NULL, '')
ERROR - 2016-07-25 22:46:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 22:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 23:14:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 23:14:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 23:14:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 23:14:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 23:18:10 --> 404 Page Not Found: Robotstxt/index
