<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-26 04:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 06:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 11:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 17:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 19:08:58 --> 404 Page Not Found: Page/assets
ERROR - 2016-12-26 22:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-26 23:38:56 --> 404 Page Not Found: Robotstxt/index
