<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-19 01:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-19 04:39:05 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-19 04:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 04:45:07 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-19 06:45:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 07:00:27 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 08:48:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-19 10:09:23 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-19 10:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-19 10:10:10 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-19 10:10:10 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-19 10:10:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-19 10:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-19 10:10:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-19 10:10:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-19 10:11:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-19 10:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-19 10:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 10:49:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 10:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 10:49:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 10:59:20 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-19 10:59:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-19 12:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 13:37:33 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 13:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-19 13:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 14:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-19 19:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-19 21:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-19 22:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-19 22:27:57 --> 404 Page Not Found: Robotstxt/index
