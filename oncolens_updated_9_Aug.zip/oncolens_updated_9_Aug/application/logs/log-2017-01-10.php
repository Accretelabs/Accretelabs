<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-10 02:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-10 02:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-10 05:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 06:49:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 06:49:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 06:49:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 06:50:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 06:50:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 06:50:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-10 06:50:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-10 06:50:51 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-10 06:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-10 07:07:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 08:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-10 08:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 08:06:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 08:09:09 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-10 08:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-10 08:16:06 --> Severity: Warning --> filesize(): stat failed for /var/lib/php/session/ci_sessiond42fb603a6ed3646743f530c46acccfaa361afa8 /var/www/html/system/libraries/Session/drivers/Session_files_driver.php 192
ERROR - 2017-01-10 09:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-10 09:33:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-10 09:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-10 09:34:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-10 09:34:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-10 09:34:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 09:34:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 09:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 09:52:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 12:32:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 12:50:31 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-10 12:50:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:13:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 13:36:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:36:52 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-10 13:37:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:37:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:37:37 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:40:49 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-10 13:40:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:43:16 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:53:12 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-10 13:53:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 13:53:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 14:04:35 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-10 14:04:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-10 15:06:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:06:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:11:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:11:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:16:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:21:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:27:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 15:32:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 16:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-10 16:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-10 18:14:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:14:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 18:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 18:15:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:15:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:16:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:17:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-10 18:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:17:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:18:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:18:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:33:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-10 18:39:29 --> Severity: Warning --> filesize(): stat failed for /var/lib/php/session/ci_session79f35efb7aa0326179651ee5786ac3a9e6a6b453 /var/www/html/system/libraries/Session/drivers/Session_files_driver.php 192
ERROR - 2017-01-10 21:55:57 --> 404 Page Not Found: Page/assets
