<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-02 12:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-02 12:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-02 12:30:53 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-02 12:30:53 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-02 12:30:53 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-02 15:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-02 16:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-02 22:44:57 --> 404 Page Not Found: Robotstxt/index
