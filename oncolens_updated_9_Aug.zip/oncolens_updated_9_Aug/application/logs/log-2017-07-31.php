<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-31 08:09:50 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-31 08:09:50 --> Config Class Initialized
INFO - 2017-07-31 08:09:50 --> Hooks Class Initialized
INFO - 2017-07-31 08:09:50 --> Hooks Class Initialized
DEBUG - 2017-07-31 08:09:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-31 08:09:51 --> UTF-8 Support Enabled
INFO - 2017-07-31 08:09:51 --> Utf8 Class Initialized
INFO - 2017-07-31 08:09:51 --> Utf8 Class Initialized
INFO - 2017-07-31 08:09:51 --> URI Class Initialized
INFO - 2017-07-31 08:09:51 --> URI Class Initialized
INFO - 2017-07-31 08:09:51 --> Router Class Initialized
INFO - 2017-07-31 08:09:51 --> Router Class Initialized
INFO - 2017-07-31 08:09:52 --> Output Class Initialized
INFO - 2017-07-31 08:09:52 --> Output Class Initialized
INFO - 2017-07-31 08:09:53 --> Security Class Initialized
INFO - 2017-07-31 08:09:53 --> Security Class Initialized
DEBUG - 2017-07-31 08:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-31 08:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-31 08:09:53 --> Input Class Initialized
INFO - 2017-07-31 08:09:53 --> Input Class Initialized
INFO - 2017-07-31 08:09:53 --> Language Class Initialized
INFO - 2017-07-31 08:09:53 --> Language Class Initialized
INFO - 2017-07-31 08:09:53 --> Loader Class Initialized
INFO - 2017-07-31 08:09:53 --> Loader Class Initialized
INFO - 2017-07-31 08:09:53 --> Helper loaded: url_helper
INFO - 2017-07-31 08:09:53 --> Helper loaded: url_helper
INFO - 2017-07-31 08:09:53 --> Helper loaded: form_helper
INFO - 2017-07-31 08:09:53 --> Helper loaded: form_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: security_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: path_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: security_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: path_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: common_helper
INFO - 2017-07-31 08:09:54 --> Helper loaded: common_helper
INFO - 2017-07-31 08:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-31 08:09:54 --> Helper loaded: check_session_helper
INFO - 2017-07-31 08:09:54 --> Database Driver Class Initialized
DEBUG - 2017-07-31 08:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-31 08:09:54 --> Email Class Initialized
INFO - 2017-07-31 08:09:55 --> Form Validation Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Controller Class Initialized
INFO - 2017-07-31 08:09:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-31 08:09:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-31 08:09:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-31 08:09:55 --> Final output sent to browser
DEBUG - 2017-07-31 08:09:55 --> Total execution time: 5.8935
DEBUG - 2017-07-31 08:09:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-31 08:09:55 --> Database Forge Class Initialized
INFO - 2017-07-31 08:09:55 --> User Agent Class Initialized
DEBUG - 2017-07-31 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-31 08:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-31 08:09:55 --> Helper loaded: check_session_helper
INFO - 2017-07-31 08:09:55 --> Database Driver Class Initialized
DEBUG - 2017-07-31 08:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-31 08:09:55 --> Email Class Initialized
INFO - 2017-07-31 08:09:55 --> Form Validation Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> Controller Class Initialized
INFO - 2017-07-31 08:09:55 --> Model Class Initialized
INFO - 2017-07-31 08:09:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-31 08:09:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-31 08:09:55 --> Final output sent to browser
DEBUG - 2017-07-31 08:09:55 --> Total execution time: 6.0272
DEBUG - 2017-07-31 08:09:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-31 08:09:55 --> Database Forge Class Initialized
INFO - 2017-07-31 08:09:55 --> User Agent Class Initialized
DEBUG - 2017-07-31 08:09:55 --> Session class already loaded. Second attempt ignored.
