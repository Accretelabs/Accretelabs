<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-29 03:13:40 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'fc471e325bf690a665910d487676a305d790dc38', '/', 1483010020, '216.218.206.68', NULL, '')
ERROR - 2016-12-29 05:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-29 06:11:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-29 06:41:02 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-29 06:41:02 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-29 06:41:02 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-29 06:54:16 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-29 06:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-29 08:24:10 --> 404 Page Not Found: Page/assets
ERROR - 2016-12-29 09:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-29 09:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-29 10:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-29 10:28:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-12-29 12:32:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-29 17:28:23 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2016-12-29 17:28:23 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2016-12-29 17:28:23 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
