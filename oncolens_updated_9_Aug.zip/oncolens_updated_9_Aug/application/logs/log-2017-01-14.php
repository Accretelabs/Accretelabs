<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-14 07:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-14 07:30:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-14 07:32:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-14 08:18:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1230
ERROR - 2017-01-14 08:39:51 --> 404 Page Not Found: Faviconico/index
