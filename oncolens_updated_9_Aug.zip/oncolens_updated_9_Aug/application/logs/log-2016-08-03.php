<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-03 04:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-03 08:54:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:54:04 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-03 08:54:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-03 08:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-03 08:55:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:55:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-03 08:55:35 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:22 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-03 08:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-03 08:56:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-03 08:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-03 08:56:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:56:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-03 08:57:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:58:45 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-03 08:58:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-08-03 08:58:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-03 13:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-03 14:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-03 14:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-03 19:29:55 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'e76c44da85712c4f56106f7618733a81acad1470', '/', 1470277795, '184.105.247.194', NULL, '')
