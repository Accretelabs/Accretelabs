<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-25 06:50:38 --> Config Class Initialized
INFO - 2017-07-25 06:50:38 --> Hooks Class Initialized
DEBUG - 2017-07-25 06:50:38 --> UTF-8 Support Enabled
INFO - 2017-07-25 06:50:38 --> Utf8 Class Initialized
INFO - 2017-07-25 06:50:38 --> URI Class Initialized
DEBUG - 2017-07-25 06:50:38 --> No URI present. Default controller set.
INFO - 2017-07-25 06:50:38 --> Router Class Initialized
INFO - 2017-07-25 06:50:38 --> Output Class Initialized
INFO - 2017-07-25 06:50:38 --> Security Class Initialized
DEBUG - 2017-07-25 06:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 06:50:38 --> Input Class Initialized
INFO - 2017-07-25 06:50:38 --> Language Class Initialized
INFO - 2017-07-25 06:50:38 --> Loader Class Initialized
INFO - 2017-07-25 06:50:38 --> Helper loaded: url_helper
INFO - 2017-07-25 06:50:38 --> Helper loaded: form_helper
INFO - 2017-07-25 06:50:38 --> Helper loaded: security_helper
INFO - 2017-07-25 06:50:38 --> Helper loaded: path_helper
INFO - 2017-07-25 06:50:38 --> Helper loaded: common_helper
INFO - 2017-07-25 06:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 06:50:39 --> Helper loaded: check_session_helper
INFO - 2017-07-25 06:50:39 --> Database Driver Class Initialized
DEBUG - 2017-07-25 06:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:50:39 --> Email Class Initialized
INFO - 2017-07-25 06:50:39 --> Form Validation Class Initialized
INFO - 2017-07-25 06:50:39 --> Model Class Initialized
INFO - 2017-07-25 06:50:40 --> Model Class Initialized
INFO - 2017-07-25 06:50:40 --> Model Class Initialized
INFO - 2017-07-25 06:50:41 --> Model Class Initialized
INFO - 2017-07-25 06:50:41 --> Controller Class Initialized
DEBUG - 2017-07-25 06:50:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:50:41 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-25 06:50:41 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-25 06:50:41 --> Final output sent to browser
DEBUG - 2017-07-25 06:50:41 --> Total execution time: 2.8560
DEBUG - 2017-07-25 06:50:41 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 06:50:41 --> Database Forge Class Initialized
INFO - 2017-07-25 06:50:41 --> User Agent Class Initialized
DEBUG - 2017-07-25 06:50:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:50:49 --> Config Class Initialized
INFO - 2017-07-25 06:50:49 --> Hooks Class Initialized
DEBUG - 2017-07-25 06:50:49 --> UTF-8 Support Enabled
INFO - 2017-07-25 06:50:49 --> Utf8 Class Initialized
INFO - 2017-07-25 06:50:49 --> URI Class Initialized
INFO - 2017-07-25 06:50:49 --> Router Class Initialized
INFO - 2017-07-25 06:50:49 --> Output Class Initialized
INFO - 2017-07-25 06:50:49 --> Security Class Initialized
DEBUG - 2017-07-25 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 06:50:49 --> Input Class Initialized
INFO - 2017-07-25 06:50:49 --> Language Class Initialized
ERROR - 2017-07-25 06:50:49 --> 404 Page Not Found: admin/Indexphp/index
INFO - 2017-07-25 06:50:49 --> Config Class Initialized
INFO - 2017-07-25 06:50:49 --> Hooks Class Initialized
DEBUG - 2017-07-25 06:50:49 --> UTF-8 Support Enabled
INFO - 2017-07-25 06:50:49 --> Utf8 Class Initialized
INFO - 2017-07-25 06:50:49 --> URI Class Initialized
INFO - 2017-07-25 06:50:49 --> Router Class Initialized
INFO - 2017-07-25 06:50:49 --> Output Class Initialized
INFO - 2017-07-25 06:50:49 --> Security Class Initialized
DEBUG - 2017-07-25 06:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 06:50:49 --> Input Class Initialized
INFO - 2017-07-25 06:50:49 --> Language Class Initialized
ERROR - 2017-07-25 06:50:49 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-25 06:50:52 --> Config Class Initialized
INFO - 2017-07-25 06:50:52 --> Hooks Class Initialized
DEBUG - 2017-07-25 06:50:52 --> UTF-8 Support Enabled
INFO - 2017-07-25 06:50:52 --> Utf8 Class Initialized
INFO - 2017-07-25 06:50:52 --> URI Class Initialized
INFO - 2017-07-25 06:50:52 --> Router Class Initialized
INFO - 2017-07-25 06:50:52 --> Output Class Initialized
INFO - 2017-07-25 06:50:52 --> Security Class Initialized
DEBUG - 2017-07-25 06:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 06:50:52 --> Input Class Initialized
INFO - 2017-07-25 06:50:52 --> Language Class Initialized
INFO - 2017-07-25 06:50:53 --> Loader Class Initialized
INFO - 2017-07-25 06:50:53 --> Helper loaded: url_helper
INFO - 2017-07-25 06:50:53 --> Helper loaded: form_helper
INFO - 2017-07-25 06:50:53 --> Helper loaded: security_helper
INFO - 2017-07-25 06:50:53 --> Helper loaded: path_helper
INFO - 2017-07-25 06:50:53 --> Helper loaded: common_helper
INFO - 2017-07-25 06:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 06:50:53 --> Helper loaded: check_session_helper
INFO - 2017-07-25 06:50:53 --> Database Driver Class Initialized
DEBUG - 2017-07-25 06:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:50:53 --> Email Class Initialized
INFO - 2017-07-25 06:50:53 --> Form Validation Class Initialized
INFO - 2017-07-25 06:50:53 --> Model Class Initialized
INFO - 2017-07-25 06:50:53 --> Model Class Initialized
INFO - 2017-07-25 06:50:53 --> Model Class Initialized
INFO - 2017-07-25 06:50:53 --> Model Class Initialized
INFO - 2017-07-25 06:50:53 --> Controller Class Initialized
INFO - 2017-07-25 06:50:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-25 06:50:53 --> Final output sent to browser
DEBUG - 2017-07-25 06:50:53 --> Total execution time: 0.8869
DEBUG - 2017-07-25 06:50:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 06:50:53 --> Database Forge Class Initialized
INFO - 2017-07-25 06:50:53 --> User Agent Class Initialized
DEBUG - 2017-07-25 06:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:51:20 --> Config Class Initialized
INFO - 2017-07-25 06:51:20 --> Hooks Class Initialized
DEBUG - 2017-07-25 06:51:20 --> UTF-8 Support Enabled
INFO - 2017-07-25 06:51:20 --> Utf8 Class Initialized
INFO - 2017-07-25 06:51:20 --> URI Class Initialized
INFO - 2017-07-25 06:51:20 --> Router Class Initialized
INFO - 2017-07-25 06:51:20 --> Output Class Initialized
INFO - 2017-07-25 06:51:20 --> Security Class Initialized
DEBUG - 2017-07-25 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 06:51:20 --> Input Class Initialized
INFO - 2017-07-25 06:51:20 --> Language Class Initialized
INFO - 2017-07-25 06:51:20 --> Loader Class Initialized
INFO - 2017-07-25 06:51:20 --> Helper loaded: url_helper
INFO - 2017-07-25 06:51:20 --> Helper loaded: form_helper
INFO - 2017-07-25 06:51:20 --> Helper loaded: security_helper
INFO - 2017-07-25 06:51:20 --> Helper loaded: path_helper
INFO - 2017-07-25 06:51:20 --> Helper loaded: common_helper
INFO - 2017-07-25 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 06:51:20 --> Helper loaded: check_session_helper
INFO - 2017-07-25 06:51:20 --> Database Driver Class Initialized
DEBUG - 2017-07-25 06:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 06:51:20 --> Email Class Initialized
INFO - 2017-07-25 06:51:20 --> Form Validation Class Initialized
INFO - 2017-07-25 06:51:20 --> Model Class Initialized
INFO - 2017-07-25 06:51:20 --> Model Class Initialized
INFO - 2017-07-25 06:51:20 --> Model Class Initialized
INFO - 2017-07-25 06:51:20 --> Model Class Initialized
INFO - 2017-07-25 06:51:20 --> Controller Class Initialized
INFO - 2017-07-25 06:51:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-25 06:51:20 --> Final output sent to browser
DEBUG - 2017-07-25 06:51:20 --> Total execution time: 0.1129
DEBUG - 2017-07-25 06:51:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 06:51:20 --> Database Forge Class Initialized
INFO - 2017-07-25 06:51:20 --> User Agent Class Initialized
DEBUG - 2017-07-25 06:51:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:20 --> Config Class Initialized
INFO - 2017-07-25 08:39:20 --> Hooks Class Initialized
DEBUG - 2017-07-25 08:39:21 --> UTF-8 Support Enabled
INFO - 2017-07-25 08:39:21 --> Utf8 Class Initialized
INFO - 2017-07-25 08:39:21 --> URI Class Initialized
INFO - 2017-07-25 08:39:21 --> Router Class Initialized
INFO - 2017-07-25 08:39:21 --> Output Class Initialized
INFO - 2017-07-25 08:39:22 --> Security Class Initialized
DEBUG - 2017-07-25 08:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 08:39:22 --> Input Class Initialized
INFO - 2017-07-25 08:39:22 --> Language Class Initialized
INFO - 2017-07-25 08:39:22 --> Loader Class Initialized
INFO - 2017-07-25 08:39:22 --> Helper loaded: url_helper
INFO - 2017-07-25 08:39:23 --> Helper loaded: form_helper
INFO - 2017-07-25 08:39:23 --> Helper loaded: security_helper
INFO - 2017-07-25 08:39:23 --> Helper loaded: path_helper
INFO - 2017-07-25 08:39:23 --> Helper loaded: common_helper
INFO - 2017-07-25 08:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 08:39:24 --> Helper loaded: check_session_helper
INFO - 2017-07-25 08:39:25 --> Database Driver Class Initialized
DEBUG - 2017-07-25 08:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:25 --> Email Class Initialized
INFO - 2017-07-25 08:39:25 --> Form Validation Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Controller Class Initialized
INFO - 2017-07-25 08:39:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-25 08:39:25 --> Final output sent to browser
DEBUG - 2017-07-25 08:39:25 --> Total execution time: 4.8894
DEBUG - 2017-07-25 08:39:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 08:39:25 --> Database Forge Class Initialized
INFO - 2017-07-25 08:39:25 --> User Agent Class Initialized
DEBUG - 2017-07-25 08:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:25 --> Config Class Initialized
INFO - 2017-07-25 08:39:25 --> Hooks Class Initialized
DEBUG - 2017-07-25 08:39:25 --> UTF-8 Support Enabled
INFO - 2017-07-25 08:39:25 --> Utf8 Class Initialized
INFO - 2017-07-25 08:39:25 --> URI Class Initialized
DEBUG - 2017-07-25 08:39:25 --> No URI present. Default controller set.
INFO - 2017-07-25 08:39:25 --> Router Class Initialized
INFO - 2017-07-25 08:39:25 --> Output Class Initialized
INFO - 2017-07-25 08:39:25 --> Security Class Initialized
DEBUG - 2017-07-25 08:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 08:39:25 --> Input Class Initialized
INFO - 2017-07-25 08:39:25 --> Language Class Initialized
INFO - 2017-07-25 08:39:25 --> Loader Class Initialized
INFO - 2017-07-25 08:39:25 --> Helper loaded: url_helper
INFO - 2017-07-25 08:39:25 --> Helper loaded: form_helper
INFO - 2017-07-25 08:39:25 --> Helper loaded: security_helper
INFO - 2017-07-25 08:39:25 --> Helper loaded: path_helper
INFO - 2017-07-25 08:39:25 --> Helper loaded: common_helper
INFO - 2017-07-25 08:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 08:39:25 --> Helper loaded: check_session_helper
INFO - 2017-07-25 08:39:25 --> Database Driver Class Initialized
DEBUG - 2017-07-25 08:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:25 --> Email Class Initialized
INFO - 2017-07-25 08:39:25 --> Form Validation Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Model Class Initialized
INFO - 2017-07-25 08:39:25 --> Controller Class Initialized
DEBUG - 2017-07-25 08:39:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-25 08:39:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-25 08:39:26 --> Final output sent to browser
DEBUG - 2017-07-25 08:39:26 --> Total execution time: 0.0430
DEBUG - 2017-07-25 08:39:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 08:39:26 --> Database Forge Class Initialized
INFO - 2017-07-25 08:39:26 --> User Agent Class Initialized
DEBUG - 2017-07-25 08:39:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:29 --> Config Class Initialized
INFO - 2017-07-25 08:39:29 --> Hooks Class Initialized
DEBUG - 2017-07-25 08:39:29 --> UTF-8 Support Enabled
INFO - 2017-07-25 08:39:29 --> Utf8 Class Initialized
INFO - 2017-07-25 08:39:29 --> URI Class Initialized
DEBUG - 2017-07-25 08:39:29 --> No URI present. Default controller set.
INFO - 2017-07-25 08:39:29 --> Router Class Initialized
INFO - 2017-07-25 08:39:29 --> Output Class Initialized
INFO - 2017-07-25 08:39:29 --> Security Class Initialized
DEBUG - 2017-07-25 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 08:39:29 --> Input Class Initialized
INFO - 2017-07-25 08:39:29 --> Language Class Initialized
INFO - 2017-07-25 08:39:29 --> Loader Class Initialized
INFO - 2017-07-25 08:39:29 --> Helper loaded: url_helper
INFO - 2017-07-25 08:39:29 --> Helper loaded: form_helper
INFO - 2017-07-25 08:39:29 --> Helper loaded: security_helper
INFO - 2017-07-25 08:39:29 --> Helper loaded: path_helper
INFO - 2017-07-25 08:39:29 --> Helper loaded: common_helper
INFO - 2017-07-25 08:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 08:39:29 --> Helper loaded: check_session_helper
INFO - 2017-07-25 08:39:29 --> Database Driver Class Initialized
DEBUG - 2017-07-25 08:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:29 --> Email Class Initialized
INFO - 2017-07-25 08:39:29 --> Form Validation Class Initialized
INFO - 2017-07-25 08:39:29 --> Model Class Initialized
INFO - 2017-07-25 08:39:29 --> Model Class Initialized
INFO - 2017-07-25 08:39:29 --> Model Class Initialized
INFO - 2017-07-25 08:39:29 --> Model Class Initialized
INFO - 2017-07-25 08:39:29 --> Controller Class Initialized
DEBUG - 2017-07-25 08:39:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-25 08:39:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-25 08:39:29 --> Final output sent to browser
DEBUG - 2017-07-25 08:39:29 --> Total execution time: 0.0267
DEBUG - 2017-07-25 08:39:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 08:39:29 --> Database Forge Class Initialized
INFO - 2017-07-25 08:39:29 --> User Agent Class Initialized
DEBUG - 2017-07-25 08:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:32 --> Config Class Initialized
INFO - 2017-07-25 08:39:32 --> Hooks Class Initialized
DEBUG - 2017-07-25 08:39:32 --> UTF-8 Support Enabled
INFO - 2017-07-25 08:39:32 --> Utf8 Class Initialized
INFO - 2017-07-25 08:39:32 --> URI Class Initialized
INFO - 2017-07-25 08:39:32 --> Router Class Initialized
INFO - 2017-07-25 08:39:32 --> Output Class Initialized
INFO - 2017-07-25 08:39:32 --> Security Class Initialized
DEBUG - 2017-07-25 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 08:39:32 --> Input Class Initialized
INFO - 2017-07-25 08:39:32 --> Language Class Initialized
INFO - 2017-07-25 08:39:32 --> Loader Class Initialized
INFO - 2017-07-25 08:39:32 --> Helper loaded: url_helper
INFO - 2017-07-25 08:39:32 --> Helper loaded: form_helper
INFO - 2017-07-25 08:39:32 --> Helper loaded: security_helper
INFO - 2017-07-25 08:39:32 --> Helper loaded: path_helper
INFO - 2017-07-25 08:39:32 --> Helper loaded: common_helper
INFO - 2017-07-25 08:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 08:39:32 --> Helper loaded: check_session_helper
INFO - 2017-07-25 08:39:32 --> Database Driver Class Initialized
DEBUG - 2017-07-25 08:39:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:32 --> Email Class Initialized
INFO - 2017-07-25 08:39:32 --> Form Validation Class Initialized
INFO - 2017-07-25 08:39:32 --> Model Class Initialized
INFO - 2017-07-25 08:39:32 --> Model Class Initialized
INFO - 2017-07-25 08:39:32 --> Model Class Initialized
INFO - 2017-07-25 08:39:32 --> Model Class Initialized
INFO - 2017-07-25 08:39:32 --> Controller Class Initialized
INFO - 2017-07-25 08:39:33 --> Model Class Initialized
INFO - 2017-07-25 08:39:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-25 08:39:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-25 08:39:33 --> Final output sent to browser
DEBUG - 2017-07-25 08:39:33 --> Total execution time: 0.2982
DEBUG - 2017-07-25 08:39:33 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 08:39:33 --> Database Forge Class Initialized
INFO - 2017-07-25 08:39:33 --> User Agent Class Initialized
DEBUG - 2017-07-25 08:39:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 08:39:35 --> Config Class Initialized
INFO - 2017-07-25 08:39:35 --> Hooks Class Initialized
DEBUG - 2017-07-25 08:39:35 --> UTF-8 Support Enabled
INFO - 2017-07-25 08:39:35 --> Utf8 Class Initialized
INFO - 2017-07-25 08:39:35 --> URI Class Initialized
INFO - 2017-07-25 08:39:35 --> Router Class Initialized
INFO - 2017-07-25 08:39:35 --> Output Class Initialized
INFO - 2017-07-25 08:39:35 --> Security Class Initialized
DEBUG - 2017-07-25 08:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 08:39:35 --> Input Class Initialized
INFO - 2017-07-25 08:39:35 --> Language Class Initialized
ERROR - 2017-07-25 08:39:35 --> 404 Page Not Found: Page/assets
INFO - 2017-07-25 10:07:04 --> Config Class Initialized
INFO - 2017-07-25 10:07:04 --> Hooks Class Initialized
DEBUG - 2017-07-25 10:07:04 --> UTF-8 Support Enabled
INFO - 2017-07-25 10:07:04 --> Utf8 Class Initialized
INFO - 2017-07-25 10:07:04 --> URI Class Initialized
DEBUG - 2017-07-25 10:07:04 --> No URI present. Default controller set.
INFO - 2017-07-25 10:07:04 --> Router Class Initialized
INFO - 2017-07-25 10:07:04 --> Output Class Initialized
INFO - 2017-07-25 10:07:04 --> Security Class Initialized
DEBUG - 2017-07-25 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 10:07:04 --> Input Class Initialized
INFO - 2017-07-25 10:07:04 --> Language Class Initialized
INFO - 2017-07-25 10:07:05 --> Loader Class Initialized
INFO - 2017-07-25 10:07:05 --> Helper loaded: url_helper
INFO - 2017-07-25 10:07:05 --> Helper loaded: form_helper
INFO - 2017-07-25 10:07:05 --> Helper loaded: security_helper
INFO - 2017-07-25 10:07:05 --> Helper loaded: path_helper
INFO - 2017-07-25 10:07:05 --> Helper loaded: common_helper
INFO - 2017-07-25 10:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 10:07:05 --> Helper loaded: check_session_helper
INFO - 2017-07-25 10:07:05 --> Database Driver Class Initialized
DEBUG - 2017-07-25 10:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 10:07:05 --> Email Class Initialized
INFO - 2017-07-25 10:07:05 --> Form Validation Class Initialized
INFO - 2017-07-25 10:07:05 --> Model Class Initialized
INFO - 2017-07-25 10:07:05 --> Model Class Initialized
INFO - 2017-07-25 10:07:05 --> Model Class Initialized
INFO - 2017-07-25 10:07:05 --> Model Class Initialized
INFO - 2017-07-25 10:07:05 --> Controller Class Initialized
DEBUG - 2017-07-25 10:07:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-25 10:07:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-25 10:07:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-25 10:07:05 --> Final output sent to browser
DEBUG - 2017-07-25 10:07:05 --> Total execution time: 1.3118
DEBUG - 2017-07-25 10:07:05 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 10:07:05 --> Database Forge Class Initialized
INFO - 2017-07-25 10:07:05 --> User Agent Class Initialized
DEBUG - 2017-07-25 10:07:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 13:16:47 --> Config Class Initialized
INFO - 2017-07-25 13:16:47 --> Hooks Class Initialized
DEBUG - 2017-07-25 13:16:47 --> UTF-8 Support Enabled
INFO - 2017-07-25 13:16:47 --> Utf8 Class Initialized
INFO - 2017-07-25 13:16:47 --> URI Class Initialized
DEBUG - 2017-07-25 13:16:47 --> No URI present. Default controller set.
INFO - 2017-07-25 13:16:47 --> Router Class Initialized
INFO - 2017-07-25 13:16:47 --> Output Class Initialized
INFO - 2017-07-25 13:16:47 --> Security Class Initialized
DEBUG - 2017-07-25 13:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-25 13:16:47 --> Input Class Initialized
INFO - 2017-07-25 13:16:47 --> Language Class Initialized
INFO - 2017-07-25 13:16:47 --> Loader Class Initialized
INFO - 2017-07-25 13:16:47 --> Helper loaded: url_helper
INFO - 2017-07-25 13:16:47 --> Helper loaded: form_helper
INFO - 2017-07-25 13:16:47 --> Helper loaded: security_helper
INFO - 2017-07-25 13:16:47 --> Helper loaded: path_helper
INFO - 2017-07-25 13:16:47 --> Helper loaded: common_helper
INFO - 2017-07-25 13:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-25 13:16:47 --> Helper loaded: check_session_helper
INFO - 2017-07-25 13:16:47 --> Database Driver Class Initialized
DEBUG - 2017-07-25 13:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-25 13:16:47 --> Email Class Initialized
INFO - 2017-07-25 13:16:47 --> Form Validation Class Initialized
INFO - 2017-07-25 13:16:47 --> Model Class Initialized
INFO - 2017-07-25 13:16:47 --> Model Class Initialized
INFO - 2017-07-25 13:16:47 --> Model Class Initialized
INFO - 2017-07-25 13:16:47 --> Model Class Initialized
INFO - 2017-07-25 13:16:47 --> Controller Class Initialized
DEBUG - 2017-07-25 13:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-25 13:16:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-25 13:16:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-25 13:16:47 --> Final output sent to browser
DEBUG - 2017-07-25 13:16:47 --> Total execution time: 0.2382
DEBUG - 2017-07-25 13:16:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-25 13:16:47 --> Database Forge Class Initialized
INFO - 2017-07-25 13:16:47 --> User Agent Class Initialized
DEBUG - 2017-07-25 13:16:47 --> Session class already loaded. Second attempt ignored.
