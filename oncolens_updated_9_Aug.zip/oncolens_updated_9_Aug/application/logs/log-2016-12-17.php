<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-17 02:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-17 04:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-17 04:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-17 07:18:29 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '6279110ff6f3b4ba1bda618c129d0562f54f86bd', '/', 1481987909, '216.218.206.68', NULL, '')
ERROR - 2016-12-17 11:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-17 12:33:42 --> 404 Page Not Found: Robotstxt/index
