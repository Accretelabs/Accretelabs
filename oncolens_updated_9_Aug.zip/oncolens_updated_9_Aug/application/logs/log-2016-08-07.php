<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-07 14:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-07 14:45:58 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-08-07 14:48:58 --> 404 Page Not Found: Well-known/apple-app-site-association
ERROR - 2016-08-07 15:35:08 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-08-07 18:24:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-08-07 18:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mcase.php 1255
ERROR - 2016-08-07 19:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-07 20:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-07 23:19:10 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '421791b5e91e73e3f8b8c1ee7fa6451bb23a3de9', '/', 1470637150, '184.105.247.194', NULL, '')
