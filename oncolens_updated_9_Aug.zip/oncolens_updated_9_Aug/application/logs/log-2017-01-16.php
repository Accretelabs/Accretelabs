<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-16 00:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-16 00:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-16 03:16:34 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2017-01-16 03:37:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:38:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:38:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:38:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:39:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:40:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:41:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:42:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 03:52:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-16 04:52:12 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 04:52:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 04:52:34 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 04:54:12 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 04:55:10 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 04:56:36 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 04:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/views/case_list_page.php 42
ERROR - 2017-01-16 05:54:57 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:00:11 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:05:28 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:09:16 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:31:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 06:31:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 06:31:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 06:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 06:31:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 06:31:31 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 06:31:32 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 06:44:40 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:50:07 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-16 06:50:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-16 06:55:10 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 06:56:16 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-16 06:56:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-16 07:02:30 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 07:02:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-16 07:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-16 07:03:05 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 07:03:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 07:04:35 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-16 07:24:16 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 07:29:20 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 07:33:22 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 07:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 07:53:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 07:53:56 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 07:53:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 07:54:09 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 07:54:22 --> 404 Page Not Found: Users/assets
ERROR - 2017-01-16 07:54:31 --> 404 Page Not Found: Users/assets
ERROR - 2017-01-16 07:55:08 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 08:08:03 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-16 08:08:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-16 10:02:19 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'b7057c3a00dda9ccde1d906aa315770263b7cfae', '/', 1484589739, '184.105.247.195', NULL, '')
ERROR - 2017-01-16 11:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 11:23:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-16 11:23:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-16 11:58:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 15:49:55 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Connection refused) /var/www/html/application/models/Mcase.php 1180
ERROR - 2017-01-16 16:21:55 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 16:35:44 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 16:35:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 16:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 16:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 16:36:30 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 16:42:12 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-16 19:27:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 19:27:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 19:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 19:27:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 19:27:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 19:27:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-16 23:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-16 23:34:27 --> 404 Page Not Found: Robotstxt/index
