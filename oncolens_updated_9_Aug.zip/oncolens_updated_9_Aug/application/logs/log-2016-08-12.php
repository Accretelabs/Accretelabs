<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-12 06:49:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 06:49:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 09:02:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 09:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 09:03:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 09:04:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 12:37:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-12 12:37:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-12 12:38:13 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-12 12:38:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-12 12:59:44 --> 404 Page Not Found: Apple-touch-icon-152x152-precomposedpng/index
ERROR - 2016-08-12 12:59:44 --> 404 Page Not Found: Apple-touch-icon-152x152png/index
ERROR - 2016-08-12 12:59:44 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-12 12:59:44 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-12 12:59:45 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2016-08-12 12:59:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 16:34:59 --> 404 Page Not Found: Apple-touch-icon-152x152-precomposedpng/index
ERROR - 2016-08-12 16:34:59 --> 404 Page Not Found: Apple-touch-icon-152x152png/index
ERROR - 2016-08-12 16:34:59 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-12 16:34:59 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2016-08-12 18:30:20 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '86e7e6ae8d313ff7e09d7f960eb7567a19d000f8', '/', 1471051819, '74.82.47.2', NULL, '')
ERROR - 2016-08-12 23:52:17 --> 404 Page Not Found: Robotstxt/index
