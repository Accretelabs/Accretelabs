<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-09 05:59:25 --> Config Class Initialized
INFO - 2017-08-09 05:59:25 --> Hooks Class Initialized
DEBUG - 2017-08-09 05:59:25 --> UTF-8 Support Enabled
INFO - 2017-08-09 05:59:25 --> Utf8 Class Initialized
INFO - 2017-08-09 05:59:26 --> URI Class Initialized
DEBUG - 2017-08-09 05:59:26 --> No URI present. Default controller set.
INFO - 2017-08-09 05:59:26 --> Router Class Initialized
INFO - 2017-08-09 05:59:26 --> Output Class Initialized
INFO - 2017-08-09 05:59:26 --> Security Class Initialized
DEBUG - 2017-08-09 05:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-09 05:59:26 --> Input Class Initialized
INFO - 2017-08-09 05:59:26 --> Language Class Initialized
INFO - 2017-08-09 05:59:28 --> Loader Class Initialized
INFO - 2017-08-09 05:59:29 --> Helper loaded: url_helper
INFO - 2017-08-09 05:59:30 --> Helper loaded: form_helper
INFO - 2017-08-09 05:59:32 --> Helper loaded: security_helper
INFO - 2017-08-09 05:59:33 --> Helper loaded: path_helper
INFO - 2017-08-09 05:59:33 --> Helper loaded: common_helper
INFO - 2017-08-09 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-09 05:59:34 --> Helper loaded: check_session_helper
INFO - 2017-08-09 05:59:35 --> Database Driver Class Initialized
DEBUG - 2017-08-09 05:59:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 05:59:35 --> Email Class Initialized
INFO - 2017-08-09 05:59:35 --> Form Validation Class Initialized
INFO - 2017-08-09 05:59:35 --> Model Class Initialized
INFO - 2017-08-09 05:59:35 --> Model Class Initialized
INFO - 2017-08-09 05:59:35 --> Model Class Initialized
INFO - 2017-08-09 05:59:35 --> Model Class Initialized
INFO - 2017-08-09 05:59:35 --> Controller Class Initialized
DEBUG - 2017-08-09 05:59:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-09 05:59:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-09 05:59:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-09 05:59:35 --> Final output sent to browser
DEBUG - 2017-08-09 05:59:35 --> Total execution time: 10.3738
DEBUG - 2017-08-09 05:59:35 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-09 05:59:35 --> Database Forge Class Initialized
INFO - 2017-08-09 05:59:37 --> User Agent Class Initialized
DEBUG - 2017-08-09 05:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:19 --> Config Class Initialized
INFO - 2017-08-09 06:06:19 --> Hooks Class Initialized
DEBUG - 2017-08-09 06:06:19 --> UTF-8 Support Enabled
INFO - 2017-08-09 06:06:19 --> Utf8 Class Initialized
INFO - 2017-08-09 06:06:19 --> URI Class Initialized
DEBUG - 2017-08-09 06:06:19 --> No URI present. Default controller set.
INFO - 2017-08-09 06:06:19 --> Router Class Initialized
INFO - 2017-08-09 06:06:19 --> Output Class Initialized
INFO - 2017-08-09 06:06:19 --> Security Class Initialized
DEBUG - 2017-08-09 06:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-09 06:06:19 --> Input Class Initialized
INFO - 2017-08-09 06:06:19 --> Language Class Initialized
INFO - 2017-08-09 06:06:19 --> Loader Class Initialized
INFO - 2017-08-09 06:06:19 --> Helper loaded: url_helper
INFO - 2017-08-09 06:06:19 --> Helper loaded: form_helper
INFO - 2017-08-09 06:06:19 --> Helper loaded: security_helper
INFO - 2017-08-09 06:06:19 --> Helper loaded: path_helper
INFO - 2017-08-09 06:06:19 --> Helper loaded: common_helper
INFO - 2017-08-09 06:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-09 06:06:19 --> Helper loaded: check_session_helper
INFO - 2017-08-09 06:06:19 --> Database Driver Class Initialized
DEBUG - 2017-08-09 06:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:19 --> Email Class Initialized
INFO - 2017-08-09 06:06:19 --> Form Validation Class Initialized
INFO - 2017-08-09 06:06:19 --> Model Class Initialized
INFO - 2017-08-09 06:06:19 --> Model Class Initialized
INFO - 2017-08-09 06:06:19 --> Model Class Initialized
INFO - 2017-08-09 06:06:19 --> Model Class Initialized
INFO - 2017-08-09 06:06:19 --> Controller Class Initialized
DEBUG - 2017-08-09 06:06:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-09 06:06:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-09 06:06:19 --> Final output sent to browser
DEBUG - 2017-08-09 06:06:19 --> Total execution time: 0.0477
DEBUG - 2017-08-09 06:06:19 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-09 06:06:19 --> Database Forge Class Initialized
INFO - 2017-08-09 06:06:19 --> User Agent Class Initialized
DEBUG - 2017-08-09 06:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:24 --> Config Class Initialized
INFO - 2017-08-09 06:06:24 --> Hooks Class Initialized
DEBUG - 2017-08-09 06:06:24 --> UTF-8 Support Enabled
INFO - 2017-08-09 06:06:24 --> Utf8 Class Initialized
INFO - 2017-08-09 06:06:24 --> URI Class Initialized
INFO - 2017-08-09 06:06:24 --> Router Class Initialized
INFO - 2017-08-09 06:06:24 --> Output Class Initialized
INFO - 2017-08-09 06:06:24 --> Security Class Initialized
DEBUG - 2017-08-09 06:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-09 06:06:24 --> Input Class Initialized
INFO - 2017-08-09 06:06:24 --> Language Class Initialized
INFO - 2017-08-09 06:06:24 --> Loader Class Initialized
INFO - 2017-08-09 06:06:24 --> Helper loaded: url_helper
INFO - 2017-08-09 06:06:24 --> Helper loaded: form_helper
INFO - 2017-08-09 06:06:24 --> Helper loaded: security_helper
INFO - 2017-08-09 06:06:24 --> Helper loaded: path_helper
INFO - 2017-08-09 06:06:24 --> Helper loaded: common_helper
INFO - 2017-08-09 06:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-09 06:06:24 --> Helper loaded: check_session_helper
INFO - 2017-08-09 06:06:24 --> Database Driver Class Initialized
DEBUG - 2017-08-09 06:06:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:24 --> Email Class Initialized
INFO - 2017-08-09 06:06:24 --> Form Validation Class Initialized
INFO - 2017-08-09 06:06:24 --> Model Class Initialized
INFO - 2017-08-09 06:06:24 --> Model Class Initialized
INFO - 2017-08-09 06:06:24 --> Model Class Initialized
INFO - 2017-08-09 06:06:24 --> Model Class Initialized
INFO - 2017-08-09 06:06:24 --> Controller Class Initialized
INFO - 2017-08-09 06:06:25 --> Model Class Initialized
INFO - 2017-08-09 06:06:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-09 06:06:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-09 06:06:25 --> Final output sent to browser
DEBUG - 2017-08-09 06:06:25 --> Total execution time: 1.3289
DEBUG - 2017-08-09 06:06:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-09 06:06:25 --> Database Forge Class Initialized
INFO - 2017-08-09 06:06:25 --> User Agent Class Initialized
DEBUG - 2017-08-09 06:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-09 06:06:26 --> Config Class Initialized
INFO - 2017-08-09 06:06:26 --> Hooks Class Initialized
DEBUG - 2017-08-09 06:06:26 --> UTF-8 Support Enabled
INFO - 2017-08-09 06:06:26 --> Utf8 Class Initialized
INFO - 2017-08-09 06:06:26 --> URI Class Initialized
INFO - 2017-08-09 06:06:26 --> Router Class Initialized
INFO - 2017-08-09 06:06:26 --> Output Class Initialized
INFO - 2017-08-09 06:06:26 --> Security Class Initialized
DEBUG - 2017-08-09 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-09 06:06:26 --> Input Class Initialized
INFO - 2017-08-09 06:06:26 --> Language Class Initialized
ERROR - 2017-08-09 06:06:26 --> 404 Page Not Found: Page/assets
