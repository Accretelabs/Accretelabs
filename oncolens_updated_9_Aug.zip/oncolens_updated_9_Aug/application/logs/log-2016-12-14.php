<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-14 02:12:20 --> 404 Page Not Found: Mailtestphp/index
ERROR - 2016-12-14 02:12:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 04:17:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 04:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 05:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-14 06:16:39 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 06:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 06:17:05 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 06:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 06:17:58 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 06:19:48 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'de0d8d6314afba09b398a18dd7f4deb7418136a5', '/', 1481725188, '74.82.47.2', NULL, '')
ERROR - 2016-12-14 06:22:54 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 06:22:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:23:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:23:48 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 07:23:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 07:25:57 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 07:30:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:30:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:30:23 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 07:30:23 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 07:30:23 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 07:31:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:31:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:31:38 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:31:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:32:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:32:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:32:51 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:32:51 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:32:54 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:32:54 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:32:57 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:33:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:36:21 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 07:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 07:55:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 07:56:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 08:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-14 08:12:08 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2016-12-14 08:12:15 --> 404 Page Not Found: Upcoming-in-person-tumor-boardshtml/index
ERROR - 2016-12-14 08:12:19 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-12-14 08:19:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 08:38:25 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:38:25 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:38:25 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 08:50:11 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:50:11 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:50:11 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:53:45 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:53:45 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 08:53:45 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:02:32 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:02:32 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:02:32 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:06:58 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:06:58 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:06:58 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:07:05 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2016-12-14 09:07:05 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2016-12-14 09:07:05 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
ERROR - 2016-12-14 09:19:41 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:19:41 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:19:41 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:24:40 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:24:40 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:24:40 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:25:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 09:25:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 09:25:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 09:29:31 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 09:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 09:34:09 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:34:09 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:34:09 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:34:48 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 09:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 09:46:14 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 09:46:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 09:47:31 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:47:31 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:47:31 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:56:00 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:56:00 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 09:56:00 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 10:09:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 10:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 10:30:31 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 10:30:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 11:25:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 11:25:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 11:25:40 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 11:25:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 11:29:01 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 11:29:01 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 11:29:01 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-14 12:04:13 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-14 12:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-14 12:04:23 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 12:04:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 12:05:08 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 13:32:22 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 13:32:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-14 13:33:10 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-14 18:15:20 --> 404 Page Not Found: Robotstxt/index
