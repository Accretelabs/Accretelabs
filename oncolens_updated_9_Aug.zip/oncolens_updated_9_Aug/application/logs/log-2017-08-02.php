<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-02 01:56:23 --> Config Class Initialized
INFO - 2017-08-02 01:56:23 --> Hooks Class Initialized
DEBUG - 2017-08-02 01:56:23 --> UTF-8 Support Enabled
INFO - 2017-08-02 01:56:23 --> Utf8 Class Initialized
INFO - 2017-08-02 01:56:23 --> URI Class Initialized
INFO - 2017-08-02 01:56:23 --> Router Class Initialized
INFO - 2017-08-02 01:56:23 --> Output Class Initialized
INFO - 2017-08-02 01:56:23 --> Security Class Initialized
DEBUG - 2017-08-02 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 01:56:23 --> Input Class Initialized
INFO - 2017-08-02 01:56:23 --> Language Class Initialized
INFO - 2017-08-02 01:56:23 --> Loader Class Initialized
INFO - 2017-08-02 01:56:23 --> Helper loaded: url_helper
INFO - 2017-08-02 01:56:23 --> Helper loaded: form_helper
INFO - 2017-08-02 01:56:23 --> Helper loaded: security_helper
INFO - 2017-08-02 01:56:23 --> Helper loaded: path_helper
INFO - 2017-08-02 01:56:23 --> Helper loaded: common_helper
INFO - 2017-08-02 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 01:56:24 --> Helper loaded: check_session_helper
INFO - 2017-08-02 01:56:24 --> Database Driver Class Initialized
DEBUG - 2017-08-02 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 01:56:24 --> Email Class Initialized
INFO - 2017-08-02 01:56:24 --> Form Validation Class Initialized
INFO - 2017-08-02 01:56:24 --> Model Class Initialized
INFO - 2017-08-02 01:56:24 --> Model Class Initialized
INFO - 2017-08-02 01:56:24 --> Model Class Initialized
INFO - 2017-08-02 01:56:24 --> Model Class Initialized
INFO - 2017-08-02 01:56:24 --> Controller Class Initialized
INFO - 2017-08-02 01:56:24 --> Model Class Initialized
INFO - 2017-08-02 01:56:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 01:56:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 01:56:24 --> Final output sent to browser
DEBUG - 2017-08-02 01:56:24 --> Total execution time: 1.4252
DEBUG - 2017-08-02 01:56:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 01:56:24 --> Database Forge Class Initialized
INFO - 2017-08-02 01:56:24 --> User Agent Class Initialized
DEBUG - 2017-08-02 01:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 01:57:02 --> Config Class Initialized
INFO - 2017-08-02 01:57:02 --> Hooks Class Initialized
DEBUG - 2017-08-02 01:57:02 --> UTF-8 Support Enabled
INFO - 2017-08-02 01:57:02 --> Utf8 Class Initialized
INFO - 2017-08-02 01:57:02 --> URI Class Initialized
INFO - 2017-08-02 01:57:02 --> Router Class Initialized
INFO - 2017-08-02 01:57:02 --> Output Class Initialized
INFO - 2017-08-02 01:57:02 --> Security Class Initialized
DEBUG - 2017-08-02 01:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 01:57:02 --> Input Class Initialized
INFO - 2017-08-02 01:57:02 --> Language Class Initialized
INFO - 2017-08-02 01:57:02 --> Loader Class Initialized
INFO - 2017-08-02 01:57:02 --> Helper loaded: url_helper
INFO - 2017-08-02 01:57:02 --> Helper loaded: form_helper
INFO - 2017-08-02 01:57:02 --> Helper loaded: security_helper
INFO - 2017-08-02 01:57:02 --> Helper loaded: path_helper
INFO - 2017-08-02 01:57:02 --> Helper loaded: common_helper
INFO - 2017-08-02 01:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 01:57:02 --> Helper loaded: check_session_helper
INFO - 2017-08-02 01:57:02 --> Database Driver Class Initialized
DEBUG - 2017-08-02 01:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 01:57:02 --> Email Class Initialized
INFO - 2017-08-02 01:57:02 --> Form Validation Class Initialized
INFO - 2017-08-02 01:57:02 --> Model Class Initialized
INFO - 2017-08-02 01:57:02 --> Model Class Initialized
INFO - 2017-08-02 01:57:02 --> Model Class Initialized
INFO - 2017-08-02 01:57:02 --> Model Class Initialized
INFO - 2017-08-02 01:57:02 --> Controller Class Initialized
INFO - 2017-08-02 01:57:02 --> Model Class Initialized
INFO - 2017-08-02 01:57:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 01:57:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 01:57:02 --> Final output sent to browser
DEBUG - 2017-08-02 01:57:02 --> Total execution time: 0.0300
DEBUG - 2017-08-02 01:57:02 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 01:57:02 --> Database Forge Class Initialized
INFO - 2017-08-02 01:57:02 --> User Agent Class Initialized
DEBUG - 2017-08-02 01:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 01:58:49 --> Config Class Initialized
INFO - 2017-08-02 01:58:49 --> Hooks Class Initialized
DEBUG - 2017-08-02 01:58:49 --> UTF-8 Support Enabled
INFO - 2017-08-02 01:58:49 --> Utf8 Class Initialized
INFO - 2017-08-02 01:58:49 --> URI Class Initialized
INFO - 2017-08-02 01:58:49 --> Router Class Initialized
INFO - 2017-08-02 01:58:49 --> Output Class Initialized
INFO - 2017-08-02 01:58:49 --> Security Class Initialized
DEBUG - 2017-08-02 01:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 01:58:49 --> Input Class Initialized
INFO - 2017-08-02 01:58:49 --> Language Class Initialized
INFO - 2017-08-02 01:58:49 --> Loader Class Initialized
INFO - 2017-08-02 01:58:49 --> Helper loaded: url_helper
INFO - 2017-08-02 01:58:49 --> Helper loaded: form_helper
INFO - 2017-08-02 01:58:49 --> Helper loaded: security_helper
INFO - 2017-08-02 01:58:49 --> Helper loaded: path_helper
INFO - 2017-08-02 01:58:49 --> Helper loaded: common_helper
INFO - 2017-08-02 01:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 01:58:49 --> Helper loaded: check_session_helper
INFO - 2017-08-02 01:58:49 --> Database Driver Class Initialized
DEBUG - 2017-08-02 01:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 01:58:49 --> Email Class Initialized
INFO - 2017-08-02 01:58:49 --> Form Validation Class Initialized
INFO - 2017-08-02 01:58:49 --> Model Class Initialized
INFO - 2017-08-02 01:58:49 --> Model Class Initialized
INFO - 2017-08-02 01:58:49 --> Model Class Initialized
INFO - 2017-08-02 01:58:49 --> Model Class Initialized
INFO - 2017-08-02 01:58:49 --> Controller Class Initialized
INFO - 2017-08-02 01:58:49 --> Model Class Initialized
INFO - 2017-08-02 01:58:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 01:58:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 01:58:49 --> Final output sent to browser
DEBUG - 2017-08-02 01:58:49 --> Total execution time: 0.0321
DEBUG - 2017-08-02 01:58:49 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 01:58:49 --> Database Forge Class Initialized
INFO - 2017-08-02 01:58:49 --> User Agent Class Initialized
DEBUG - 2017-08-02 01:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:02:32 --> Config Class Initialized
INFO - 2017-08-02 02:02:32 --> Hooks Class Initialized
DEBUG - 2017-08-02 02:02:32 --> UTF-8 Support Enabled
INFO - 2017-08-02 02:02:32 --> Utf8 Class Initialized
INFO - 2017-08-02 02:02:32 --> URI Class Initialized
INFO - 2017-08-02 02:02:32 --> Router Class Initialized
INFO - 2017-08-02 02:02:32 --> Output Class Initialized
INFO - 2017-08-02 02:02:32 --> Security Class Initialized
DEBUG - 2017-08-02 02:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 02:02:32 --> Input Class Initialized
INFO - 2017-08-02 02:02:32 --> Language Class Initialized
INFO - 2017-08-02 02:02:32 --> Loader Class Initialized
INFO - 2017-08-02 02:02:32 --> Helper loaded: url_helper
INFO - 2017-08-02 02:02:32 --> Helper loaded: form_helper
INFO - 2017-08-02 02:02:32 --> Helper loaded: security_helper
INFO - 2017-08-02 02:02:32 --> Helper loaded: path_helper
INFO - 2017-08-02 02:02:32 --> Helper loaded: common_helper
INFO - 2017-08-02 02:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 02:02:32 --> Helper loaded: check_session_helper
INFO - 2017-08-02 02:02:32 --> Database Driver Class Initialized
DEBUG - 2017-08-02 02:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:02:32 --> Email Class Initialized
INFO - 2017-08-02 02:02:32 --> Form Validation Class Initialized
INFO - 2017-08-02 02:02:32 --> Model Class Initialized
INFO - 2017-08-02 02:02:32 --> Model Class Initialized
INFO - 2017-08-02 02:02:32 --> Model Class Initialized
INFO - 2017-08-02 02:02:32 --> Model Class Initialized
INFO - 2017-08-02 02:02:32 --> Controller Class Initialized
INFO - 2017-08-02 02:02:32 --> Model Class Initialized
INFO - 2017-08-02 02:02:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 02:02:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 02:02:32 --> Final output sent to browser
DEBUG - 2017-08-02 02:02:32 --> Total execution time: 0.0419
DEBUG - 2017-08-02 02:02:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 02:02:32 --> Database Forge Class Initialized
INFO - 2017-08-02 02:02:32 --> User Agent Class Initialized
DEBUG - 2017-08-02 02:02:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:03:14 --> Config Class Initialized
INFO - 2017-08-02 02:03:14 --> Hooks Class Initialized
DEBUG - 2017-08-02 02:03:14 --> UTF-8 Support Enabled
INFO - 2017-08-02 02:03:14 --> Utf8 Class Initialized
INFO - 2017-08-02 02:03:14 --> URI Class Initialized
INFO - 2017-08-02 02:03:14 --> Router Class Initialized
INFO - 2017-08-02 02:03:14 --> Output Class Initialized
INFO - 2017-08-02 02:03:14 --> Security Class Initialized
DEBUG - 2017-08-02 02:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 02:03:14 --> Input Class Initialized
INFO - 2017-08-02 02:03:14 --> Language Class Initialized
INFO - 2017-08-02 02:03:14 --> Loader Class Initialized
INFO - 2017-08-02 02:03:14 --> Helper loaded: url_helper
INFO - 2017-08-02 02:03:14 --> Helper loaded: form_helper
INFO - 2017-08-02 02:03:14 --> Helper loaded: security_helper
INFO - 2017-08-02 02:03:14 --> Helper loaded: path_helper
INFO - 2017-08-02 02:03:14 --> Helper loaded: common_helper
INFO - 2017-08-02 02:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 02:03:14 --> Helper loaded: check_session_helper
INFO - 2017-08-02 02:03:14 --> Database Driver Class Initialized
DEBUG - 2017-08-02 02:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:03:14 --> Email Class Initialized
INFO - 2017-08-02 02:03:14 --> Form Validation Class Initialized
INFO - 2017-08-02 02:03:14 --> Model Class Initialized
INFO - 2017-08-02 02:03:14 --> Model Class Initialized
INFO - 2017-08-02 02:03:14 --> Model Class Initialized
INFO - 2017-08-02 02:03:14 --> Model Class Initialized
INFO - 2017-08-02 02:03:14 --> Controller Class Initialized
INFO - 2017-08-02 02:03:14 --> Model Class Initialized
INFO - 2017-08-02 02:03:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 02:03:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 02:03:14 --> Final output sent to browser
DEBUG - 2017-08-02 02:03:14 --> Total execution time: 0.0348
DEBUG - 2017-08-02 02:03:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 02:03:14 --> Database Forge Class Initialized
INFO - 2017-08-02 02:03:14 --> User Agent Class Initialized
DEBUG - 2017-08-02 02:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:07:01 --> Config Class Initialized
INFO - 2017-08-02 02:07:01 --> Hooks Class Initialized
DEBUG - 2017-08-02 02:07:01 --> UTF-8 Support Enabled
INFO - 2017-08-02 02:07:01 --> Utf8 Class Initialized
INFO - 2017-08-02 02:07:01 --> URI Class Initialized
DEBUG - 2017-08-02 02:07:01 --> No URI present. Default controller set.
INFO - 2017-08-02 02:07:01 --> Router Class Initialized
INFO - 2017-08-02 02:07:01 --> Output Class Initialized
INFO - 2017-08-02 02:07:01 --> Security Class Initialized
DEBUG - 2017-08-02 02:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 02:07:01 --> Input Class Initialized
INFO - 2017-08-02 02:07:01 --> Language Class Initialized
INFO - 2017-08-02 02:07:01 --> Loader Class Initialized
INFO - 2017-08-02 02:07:01 --> Helper loaded: url_helper
INFO - 2017-08-02 02:07:01 --> Helper loaded: form_helper
INFO - 2017-08-02 02:07:01 --> Helper loaded: security_helper
INFO - 2017-08-02 02:07:01 --> Helper loaded: path_helper
INFO - 2017-08-02 02:07:01 --> Helper loaded: common_helper
INFO - 2017-08-02 02:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 02:07:01 --> Helper loaded: check_session_helper
INFO - 2017-08-02 02:07:01 --> Database Driver Class Initialized
DEBUG - 2017-08-02 02:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:07:01 --> Email Class Initialized
INFO - 2017-08-02 02:07:01 --> Form Validation Class Initialized
INFO - 2017-08-02 02:07:01 --> Model Class Initialized
INFO - 2017-08-02 02:07:01 --> Model Class Initialized
INFO - 2017-08-02 02:07:01 --> Model Class Initialized
INFO - 2017-08-02 02:07:01 --> Model Class Initialized
INFO - 2017-08-02 02:07:01 --> Controller Class Initialized
DEBUG - 2017-08-02 02:07:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 02:07:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-02 02:07:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-02 02:07:02 --> Final output sent to browser
DEBUG - 2017-08-02 02:07:02 --> Total execution time: 0.0625
DEBUG - 2017-08-02 02:07:02 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 02:07:02 --> Database Forge Class Initialized
INFO - 2017-08-02 02:07:02 --> User Agent Class Initialized
DEBUG - 2017-08-02 02:07:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:29 --> Config Class Initialized
INFO - 2017-08-02 09:30:29 --> Hooks Class Initialized
DEBUG - 2017-08-02 09:30:29 --> UTF-8 Support Enabled
INFO - 2017-08-02 09:30:29 --> Utf8 Class Initialized
INFO - 2017-08-02 09:30:30 --> URI Class Initialized
DEBUG - 2017-08-02 09:30:30 --> No URI present. Default controller set.
INFO - 2017-08-02 09:30:30 --> Router Class Initialized
INFO - 2017-08-02 09:30:30 --> Output Class Initialized
INFO - 2017-08-02 09:30:30 --> Security Class Initialized
DEBUG - 2017-08-02 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 09:30:30 --> Input Class Initialized
INFO - 2017-08-02 09:30:30 --> Language Class Initialized
INFO - 2017-08-02 09:30:30 --> Loader Class Initialized
INFO - 2017-08-02 09:30:30 --> Helper loaded: url_helper
INFO - 2017-08-02 09:30:30 --> Helper loaded: form_helper
INFO - 2017-08-02 09:30:30 --> Helper loaded: security_helper
INFO - 2017-08-02 09:30:30 --> Helper loaded: path_helper
INFO - 2017-08-02 09:30:30 --> Helper loaded: common_helper
INFO - 2017-08-02 09:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 09:30:30 --> Helper loaded: check_session_helper
INFO - 2017-08-02 09:30:30 --> Database Driver Class Initialized
DEBUG - 2017-08-02 09:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:30 --> Email Class Initialized
INFO - 2017-08-02 09:30:30 --> Form Validation Class Initialized
INFO - 2017-08-02 09:30:30 --> Model Class Initialized
INFO - 2017-08-02 09:30:30 --> Model Class Initialized
INFO - 2017-08-02 09:30:30 --> Model Class Initialized
INFO - 2017-08-02 09:30:30 --> Model Class Initialized
INFO - 2017-08-02 09:30:30 --> Controller Class Initialized
DEBUG - 2017-08-02 09:30:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-02 09:30:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-02 09:30:30 --> Final output sent to browser
DEBUG - 2017-08-02 09:30:30 --> Total execution time: 0.8718
DEBUG - 2017-08-02 09:30:30 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 09:30:30 --> Database Forge Class Initialized
INFO - 2017-08-02 09:30:30 --> User Agent Class Initialized
DEBUG - 2017-08-02 09:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:38 --> Config Class Initialized
INFO - 2017-08-02 09:30:38 --> Hooks Class Initialized
DEBUG - 2017-08-02 09:30:38 --> UTF-8 Support Enabled
INFO - 2017-08-02 09:30:38 --> Utf8 Class Initialized
INFO - 2017-08-02 09:30:38 --> URI Class Initialized
INFO - 2017-08-02 09:30:38 --> Router Class Initialized
INFO - 2017-08-02 09:30:38 --> Output Class Initialized
INFO - 2017-08-02 09:30:38 --> Security Class Initialized
DEBUG - 2017-08-02 09:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 09:30:38 --> Input Class Initialized
INFO - 2017-08-02 09:30:38 --> Language Class Initialized
INFO - 2017-08-02 09:30:38 --> Loader Class Initialized
INFO - 2017-08-02 09:30:38 --> Helper loaded: url_helper
INFO - 2017-08-02 09:30:38 --> Helper loaded: form_helper
INFO - 2017-08-02 09:30:38 --> Helper loaded: security_helper
INFO - 2017-08-02 09:30:38 --> Helper loaded: path_helper
INFO - 2017-08-02 09:30:38 --> Helper loaded: common_helper
INFO - 2017-08-02 09:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 09:30:38 --> Helper loaded: check_session_helper
INFO - 2017-08-02 09:30:38 --> Database Driver Class Initialized
DEBUG - 2017-08-02 09:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:38 --> Email Class Initialized
INFO - 2017-08-02 09:30:38 --> Form Validation Class Initialized
INFO - 2017-08-02 09:30:38 --> Model Class Initialized
INFO - 2017-08-02 09:30:38 --> Model Class Initialized
INFO - 2017-08-02 09:30:38 --> Model Class Initialized
INFO - 2017-08-02 09:30:38 --> Model Class Initialized
INFO - 2017-08-02 09:30:38 --> Controller Class Initialized
INFO - 2017-08-02 09:30:38 --> Model Class Initialized
INFO - 2017-08-02 09:30:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 09:30:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 09:30:38 --> Final output sent to browser
DEBUG - 2017-08-02 09:30:38 --> Total execution time: 0.0525
DEBUG - 2017-08-02 09:30:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 09:30:38 --> Database Forge Class Initialized
INFO - 2017-08-02 09:30:38 --> User Agent Class Initialized
DEBUG - 2017-08-02 09:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:30:47 --> Config Class Initialized
INFO - 2017-08-02 09:30:47 --> Hooks Class Initialized
DEBUG - 2017-08-02 09:30:47 --> UTF-8 Support Enabled
INFO - 2017-08-02 09:30:47 --> Utf8 Class Initialized
INFO - 2017-08-02 09:30:47 --> URI Class Initialized
INFO - 2017-08-02 09:30:47 --> Router Class Initialized
INFO - 2017-08-02 09:30:47 --> Output Class Initialized
INFO - 2017-08-02 09:30:47 --> Security Class Initialized
DEBUG - 2017-08-02 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 09:30:47 --> Input Class Initialized
INFO - 2017-08-02 09:30:47 --> Language Class Initialized
ERROR - 2017-08-02 09:30:48 --> 404 Page Not Found: Page/assets
INFO - 2017-08-02 09:31:09 --> Config Class Initialized
INFO - 2017-08-02 09:31:09 --> Hooks Class Initialized
DEBUG - 2017-08-02 09:31:09 --> UTF-8 Support Enabled
INFO - 2017-08-02 09:31:09 --> Utf8 Class Initialized
INFO - 2017-08-02 09:31:09 --> URI Class Initialized
INFO - 2017-08-02 09:31:09 --> Router Class Initialized
INFO - 2017-08-02 09:31:09 --> Output Class Initialized
INFO - 2017-08-02 09:31:09 --> Security Class Initialized
DEBUG - 2017-08-02 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 09:31:09 --> Input Class Initialized
INFO - 2017-08-02 09:31:09 --> Language Class Initialized
INFO - 2017-08-02 09:31:09 --> Loader Class Initialized
INFO - 2017-08-02 09:31:09 --> Helper loaded: url_helper
INFO - 2017-08-02 09:31:09 --> Helper loaded: form_helper
INFO - 2017-08-02 09:31:09 --> Helper loaded: security_helper
INFO - 2017-08-02 09:31:09 --> Helper loaded: path_helper
INFO - 2017-08-02 09:31:09 --> Helper loaded: common_helper
INFO - 2017-08-02 09:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 09:31:09 --> Helper loaded: check_session_helper
INFO - 2017-08-02 09:31:09 --> Database Driver Class Initialized
DEBUG - 2017-08-02 09:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 09:31:09 --> Email Class Initialized
INFO - 2017-08-02 09:31:09 --> Form Validation Class Initialized
INFO - 2017-08-02 09:31:09 --> Model Class Initialized
INFO - 2017-08-02 09:31:09 --> Model Class Initialized
INFO - 2017-08-02 09:31:09 --> Model Class Initialized
INFO - 2017-08-02 09:31:09 --> Model Class Initialized
INFO - 2017-08-02 09:31:09 --> Controller Class Initialized
INFO - 2017-08-02 09:31:09 --> Model Class Initialized
INFO - 2017-08-02 09:31:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 09:31:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 09:31:09 --> Final output sent to browser
DEBUG - 2017-08-02 09:31:09 --> Total execution time: 0.0304
DEBUG - 2017-08-02 09:31:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 09:31:09 --> Database Forge Class Initialized
INFO - 2017-08-02 09:31:09 --> User Agent Class Initialized
DEBUG - 2017-08-02 09:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:25:26 --> Config Class Initialized
INFO - 2017-08-02 16:25:26 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:25:26 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:25:26 --> Utf8 Class Initialized
INFO - 2017-08-02 16:25:26 --> URI Class Initialized
INFO - 2017-08-02 16:25:26 --> Router Class Initialized
INFO - 2017-08-02 16:25:26 --> Output Class Initialized
INFO - 2017-08-02 16:25:26 --> Security Class Initialized
DEBUG - 2017-08-02 16:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:25:26 --> Input Class Initialized
INFO - 2017-08-02 16:25:27 --> Language Class Initialized
INFO - 2017-08-02 16:25:27 --> Loader Class Initialized
INFO - 2017-08-02 16:25:27 --> Helper loaded: url_helper
INFO - 2017-08-02 16:25:27 --> Helper loaded: form_helper
INFO - 2017-08-02 16:25:27 --> Helper loaded: security_helper
INFO - 2017-08-02 16:25:27 --> Helper loaded: path_helper
INFO - 2017-08-02 16:25:27 --> Helper loaded: common_helper
INFO - 2017-08-02 16:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:25:27 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:25:27 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:25:27 --> Email Class Initialized
INFO - 2017-08-02 16:25:27 --> Form Validation Class Initialized
INFO - 2017-08-02 16:25:27 --> Model Class Initialized
INFO - 2017-08-02 16:25:27 --> Model Class Initialized
INFO - 2017-08-02 16:25:27 --> Model Class Initialized
INFO - 2017-08-02 16:25:27 --> Model Class Initialized
INFO - 2017-08-02 16:25:27 --> Controller Class Initialized
INFO - 2017-08-02 16:25:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-08-02 16:25:27 --> Final output sent to browser
DEBUG - 2017-08-02 16:25:27 --> Total execution time: 1.1871
DEBUG - 2017-08-02 16:25:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:25:28 --> Database Forge Class Initialized
INFO - 2017-08-02 16:25:29 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:25:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:25:32 --> Config Class Initialized
INFO - 2017-08-02 16:25:32 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:25:32 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:25:32 --> Utf8 Class Initialized
INFO - 2017-08-02 16:25:32 --> URI Class Initialized
INFO - 2017-08-02 16:25:32 --> Router Class Initialized
INFO - 2017-08-02 16:25:32 --> Output Class Initialized
INFO - 2017-08-02 16:25:32 --> Security Class Initialized
DEBUG - 2017-08-02 16:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:25:32 --> Input Class Initialized
INFO - 2017-08-02 16:25:32 --> Language Class Initialized
ERROR - 2017-08-02 16:25:32 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-02 16:25:40 --> Config Class Initialized
INFO - 2017-08-02 16:25:40 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:25:40 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:25:40 --> Utf8 Class Initialized
INFO - 2017-08-02 16:25:40 --> URI Class Initialized
INFO - 2017-08-02 16:25:40 --> Router Class Initialized
INFO - 2017-08-02 16:25:40 --> Output Class Initialized
INFO - 2017-08-02 16:25:40 --> Security Class Initialized
DEBUG - 2017-08-02 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:25:40 --> Input Class Initialized
INFO - 2017-08-02 16:25:40 --> Language Class Initialized
INFO - 2017-08-02 16:25:40 --> Loader Class Initialized
INFO - 2017-08-02 16:25:40 --> Helper loaded: url_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: form_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: security_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: path_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: common_helper
INFO - 2017-08-02 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:25:40 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:25:40 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:25:40 --> Email Class Initialized
INFO - 2017-08-02 16:25:40 --> Form Validation Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Controller Class Initialized
INFO - 2017-08-02 16:25:40 --> Config Class Initialized
INFO - 2017-08-02 16:25:40 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:25:40 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:25:40 --> Utf8 Class Initialized
INFO - 2017-08-02 16:25:40 --> URI Class Initialized
INFO - 2017-08-02 16:25:40 --> Router Class Initialized
INFO - 2017-08-02 16:25:40 --> Output Class Initialized
INFO - 2017-08-02 16:25:40 --> Security Class Initialized
DEBUG - 2017-08-02 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:25:40 --> Input Class Initialized
INFO - 2017-08-02 16:25:40 --> Language Class Initialized
INFO - 2017-08-02 16:25:40 --> Loader Class Initialized
INFO - 2017-08-02 16:25:40 --> Helper loaded: url_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: form_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: security_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: path_helper
INFO - 2017-08-02 16:25:40 --> Helper loaded: common_helper
INFO - 2017-08-02 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:25:40 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:25:40 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:25:40 --> Email Class Initialized
INFO - 2017-08-02 16:25:40 --> Form Validation Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Model Class Initialized
INFO - 2017-08-02 16:25:40 --> Controller Class Initialized
INFO - 2017-08-02 16:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 16:25:40 --> Pagination Class Initialized
INFO - 2017-08-02 16:25:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:25:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-02 16:25:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:25:40 --> Final output sent to browser
DEBUG - 2017-08-02 16:25:40 --> Total execution time: 0.1226
DEBUG - 2017-08-02 16:25:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:25:40 --> Database Forge Class Initialized
INFO - 2017-08-02 16:25:40 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:00 --> Config Class Initialized
INFO - 2017-08-02 16:26:00 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:26:00 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:26:00 --> Utf8 Class Initialized
INFO - 2017-08-02 16:26:00 --> URI Class Initialized
INFO - 2017-08-02 16:26:00 --> Router Class Initialized
INFO - 2017-08-02 16:26:00 --> Output Class Initialized
INFO - 2017-08-02 16:26:00 --> Security Class Initialized
DEBUG - 2017-08-02 16:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:26:00 --> Input Class Initialized
INFO - 2017-08-02 16:26:00 --> Language Class Initialized
INFO - 2017-08-02 16:26:00 --> Loader Class Initialized
INFO - 2017-08-02 16:26:00 --> Helper loaded: url_helper
INFO - 2017-08-02 16:26:00 --> Helper loaded: form_helper
INFO - 2017-08-02 16:26:00 --> Helper loaded: security_helper
INFO - 2017-08-02 16:26:00 --> Helper loaded: path_helper
INFO - 2017-08-02 16:26:00 --> Helper loaded: common_helper
INFO - 2017-08-02 16:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:26:00 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:26:00 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:00 --> Email Class Initialized
INFO - 2017-08-02 16:26:00 --> Form Validation Class Initialized
INFO - 2017-08-02 16:26:00 --> Model Class Initialized
INFO - 2017-08-02 16:26:00 --> Model Class Initialized
INFO - 2017-08-02 16:26:00 --> Model Class Initialized
INFO - 2017-08-02 16:26:00 --> Model Class Initialized
INFO - 2017-08-02 16:26:00 --> Controller Class Initialized
INFO - 2017-08-02 16:26:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:26:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:26:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:26:00 --> Final output sent to browser
DEBUG - 2017-08-02 16:26:00 --> Total execution time: 0.5783
DEBUG - 2017-08-02 16:26:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:26:00 --> Database Forge Class Initialized
INFO - 2017-08-02 16:26:00 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:26:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:01 --> Config Class Initialized
INFO - 2017-08-02 16:26:01 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:26:01 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:26:01 --> Utf8 Class Initialized
INFO - 2017-08-02 16:26:01 --> URI Class Initialized
INFO - 2017-08-02 16:26:01 --> Router Class Initialized
INFO - 2017-08-02 16:26:01 --> Output Class Initialized
INFO - 2017-08-02 16:26:01 --> Security Class Initialized
DEBUG - 2017-08-02 16:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:26:01 --> Input Class Initialized
INFO - 2017-08-02 16:26:01 --> Language Class Initialized
INFO - 2017-08-02 16:26:01 --> Loader Class Initialized
INFO - 2017-08-02 16:26:01 --> Helper loaded: url_helper
INFO - 2017-08-02 16:26:01 --> Helper loaded: form_helper
INFO - 2017-08-02 16:26:01 --> Helper loaded: security_helper
INFO - 2017-08-02 16:26:01 --> Helper loaded: path_helper
INFO - 2017-08-02 16:26:01 --> Helper loaded: common_helper
INFO - 2017-08-02 16:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:26:01 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:26:01 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:01 --> Email Class Initialized
INFO - 2017-08-02 16:26:01 --> Form Validation Class Initialized
INFO - 2017-08-02 16:26:01 --> Model Class Initialized
INFO - 2017-08-02 16:26:01 --> Model Class Initialized
INFO - 2017-08-02 16:26:01 --> Model Class Initialized
INFO - 2017-08-02 16:26:01 --> Model Class Initialized
INFO - 2017-08-02 16:26:01 --> Controller Class Initialized
INFO - 2017-08-02 16:26:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:26:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:26:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:26:01 --> Final output sent to browser
DEBUG - 2017-08-02 16:26:01 --> Total execution time: 0.0282
DEBUG - 2017-08-02 16:26:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:26:01 --> Database Forge Class Initialized
INFO - 2017-08-02 16:26:01 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:26:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:06 --> Config Class Initialized
INFO - 2017-08-02 16:26:06 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:26:06 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:26:06 --> Utf8 Class Initialized
INFO - 2017-08-02 16:26:06 --> URI Class Initialized
INFO - 2017-08-02 16:26:06 --> Router Class Initialized
INFO - 2017-08-02 16:26:06 --> Output Class Initialized
INFO - 2017-08-02 16:26:06 --> Security Class Initialized
DEBUG - 2017-08-02 16:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:26:06 --> Input Class Initialized
INFO - 2017-08-02 16:26:06 --> Language Class Initialized
INFO - 2017-08-02 16:26:06 --> Loader Class Initialized
INFO - 2017-08-02 16:26:06 --> Helper loaded: url_helper
INFO - 2017-08-02 16:26:06 --> Helper loaded: form_helper
INFO - 2017-08-02 16:26:06 --> Helper loaded: security_helper
INFO - 2017-08-02 16:26:06 --> Helper loaded: path_helper
INFO - 2017-08-02 16:26:06 --> Helper loaded: common_helper
INFO - 2017-08-02 16:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:26:06 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:26:06 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:06 --> Email Class Initialized
INFO - 2017-08-02 16:26:06 --> Form Validation Class Initialized
INFO - 2017-08-02 16:26:06 --> Model Class Initialized
INFO - 2017-08-02 16:26:06 --> Model Class Initialized
INFO - 2017-08-02 16:26:06 --> Model Class Initialized
INFO - 2017-08-02 16:26:06 --> Model Class Initialized
INFO - 2017-08-02 16:26:06 --> Controller Class Initialized
DEBUG - 2017-08-02 16:26:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:26:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:26:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:26:06 --> Final output sent to browser
DEBUG - 2017-08-02 16:26:06 --> Total execution time: 0.0465
DEBUG - 2017-08-02 16:26:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:26:06 --> Database Forge Class Initialized
INFO - 2017-08-02 16:26:06 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:54 --> Config Class Initialized
INFO - 2017-08-02 16:26:54 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:26:54 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:26:54 --> Utf8 Class Initialized
INFO - 2017-08-02 16:26:54 --> URI Class Initialized
INFO - 2017-08-02 16:26:54 --> Router Class Initialized
INFO - 2017-08-02 16:26:54 --> Output Class Initialized
INFO - 2017-08-02 16:26:54 --> Security Class Initialized
DEBUG - 2017-08-02 16:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:26:54 --> Input Class Initialized
INFO - 2017-08-02 16:26:54 --> Language Class Initialized
INFO - 2017-08-02 16:26:54 --> Loader Class Initialized
INFO - 2017-08-02 16:26:54 --> Helper loaded: url_helper
INFO - 2017-08-02 16:26:54 --> Helper loaded: form_helper
INFO - 2017-08-02 16:26:54 --> Helper loaded: security_helper
INFO - 2017-08-02 16:26:54 --> Helper loaded: path_helper
INFO - 2017-08-02 16:26:54 --> Helper loaded: common_helper
INFO - 2017-08-02 16:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:26:54 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:26:54 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:54 --> Email Class Initialized
INFO - 2017-08-02 16:26:54 --> Form Validation Class Initialized
INFO - 2017-08-02 16:26:54 --> Model Class Initialized
INFO - 2017-08-02 16:26:54 --> Model Class Initialized
INFO - 2017-08-02 16:26:54 --> Model Class Initialized
INFO - 2017-08-02 16:26:54 --> Model Class Initialized
INFO - 2017-08-02 16:26:54 --> Controller Class Initialized
INFO - 2017-08-02 16:26:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:26:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:26:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:26:54 --> Final output sent to browser
DEBUG - 2017-08-02 16:26:54 --> Total execution time: 0.0287
DEBUG - 2017-08-02 16:26:54 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:26:54 --> Database Forge Class Initialized
INFO - 2017-08-02 16:26:54 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:59 --> Config Class Initialized
INFO - 2017-08-02 16:26:59 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:26:59 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:26:59 --> Utf8 Class Initialized
INFO - 2017-08-02 16:26:59 --> URI Class Initialized
INFO - 2017-08-02 16:26:59 --> Router Class Initialized
INFO - 2017-08-02 16:26:59 --> Output Class Initialized
INFO - 2017-08-02 16:26:59 --> Security Class Initialized
DEBUG - 2017-08-02 16:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:26:59 --> Input Class Initialized
INFO - 2017-08-02 16:26:59 --> Language Class Initialized
INFO - 2017-08-02 16:26:59 --> Loader Class Initialized
INFO - 2017-08-02 16:26:59 --> Helper loaded: url_helper
INFO - 2017-08-02 16:26:59 --> Helper loaded: form_helper
INFO - 2017-08-02 16:26:59 --> Helper loaded: security_helper
INFO - 2017-08-02 16:26:59 --> Helper loaded: path_helper
INFO - 2017-08-02 16:26:59 --> Helper loaded: common_helper
INFO - 2017-08-02 16:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:26:59 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:26:59 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:59 --> Email Class Initialized
INFO - 2017-08-02 16:26:59 --> Form Validation Class Initialized
INFO - 2017-08-02 16:26:59 --> Model Class Initialized
INFO - 2017-08-02 16:26:59 --> Model Class Initialized
INFO - 2017-08-02 16:26:59 --> Model Class Initialized
INFO - 2017-08-02 16:26:59 --> Model Class Initialized
INFO - 2017-08-02 16:26:59 --> Controller Class Initialized
DEBUG - 2017-08-02 16:26:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:26:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:26:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:26:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:26:59 --> Final output sent to browser
DEBUG - 2017-08-02 16:26:59 --> Total execution time: 0.0318
DEBUG - 2017-08-02 16:26:59 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:26:59 --> Database Forge Class Initialized
INFO - 2017-08-02 16:26:59 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:27:00 --> Config Class Initialized
INFO - 2017-08-02 16:27:00 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:27:00 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:27:00 --> Utf8 Class Initialized
INFO - 2017-08-02 16:27:00 --> URI Class Initialized
INFO - 2017-08-02 16:27:00 --> Router Class Initialized
INFO - 2017-08-02 16:27:00 --> Output Class Initialized
INFO - 2017-08-02 16:27:00 --> Security Class Initialized
DEBUG - 2017-08-02 16:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:27:00 --> Input Class Initialized
INFO - 2017-08-02 16:27:00 --> Language Class Initialized
ERROR - 2017-08-02 16:27:00 --> 404 Page Not Found: admin/Page/assets
INFO - 2017-08-02 16:27:09 --> Config Class Initialized
INFO - 2017-08-02 16:27:09 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:27:10 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:27:10 --> Utf8 Class Initialized
INFO - 2017-08-02 16:27:10 --> URI Class Initialized
INFO - 2017-08-02 16:27:10 --> Router Class Initialized
INFO - 2017-08-02 16:27:10 --> Output Class Initialized
INFO - 2017-08-02 16:27:10 --> Security Class Initialized
DEBUG - 2017-08-02 16:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:27:10 --> Input Class Initialized
INFO - 2017-08-02 16:27:10 --> Language Class Initialized
INFO - 2017-08-02 16:27:10 --> Loader Class Initialized
INFO - 2017-08-02 16:27:10 --> Helper loaded: url_helper
INFO - 2017-08-02 16:27:10 --> Helper loaded: form_helper
INFO - 2017-08-02 16:27:10 --> Helper loaded: security_helper
INFO - 2017-08-02 16:27:10 --> Helper loaded: path_helper
INFO - 2017-08-02 16:27:10 --> Helper loaded: common_helper
INFO - 2017-08-02 16:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:27:10 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:27:10 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:27:10 --> Email Class Initialized
INFO - 2017-08-02 16:27:10 --> Form Validation Class Initialized
INFO - 2017-08-02 16:27:10 --> Model Class Initialized
INFO - 2017-08-02 16:27:10 --> Model Class Initialized
INFO - 2017-08-02 16:27:10 --> Model Class Initialized
INFO - 2017-08-02 16:27:10 --> Model Class Initialized
INFO - 2017-08-02 16:27:10 --> Controller Class Initialized
DEBUG - 2017-08-02 16:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:27:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:27:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:27:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:27:10 --> Final output sent to browser
DEBUG - 2017-08-02 16:27:10 --> Total execution time: 0.0505
DEBUG - 2017-08-02 16:27:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:27:10 --> Database Forge Class Initialized
INFO - 2017-08-02 16:27:10 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:27:11 --> Config Class Initialized
INFO - 2017-08-02 16:27:11 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:27:11 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:27:11 --> Utf8 Class Initialized
INFO - 2017-08-02 16:27:11 --> URI Class Initialized
INFO - 2017-08-02 16:27:11 --> Router Class Initialized
INFO - 2017-08-02 16:27:11 --> Output Class Initialized
INFO - 2017-08-02 16:27:11 --> Security Class Initialized
DEBUG - 2017-08-02 16:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:27:11 --> Input Class Initialized
INFO - 2017-08-02 16:27:11 --> Language Class Initialized
ERROR - 2017-08-02 16:27:11 --> 404 Page Not Found: admin/Page/assets
INFO - 2017-08-02 16:27:17 --> Config Class Initialized
INFO - 2017-08-02 16:27:17 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:27:17 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:27:17 --> Utf8 Class Initialized
INFO - 2017-08-02 16:27:17 --> URI Class Initialized
INFO - 2017-08-02 16:27:17 --> Router Class Initialized
INFO - 2017-08-02 16:27:17 --> Output Class Initialized
INFO - 2017-08-02 16:27:17 --> Security Class Initialized
DEBUG - 2017-08-02 16:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:27:17 --> Input Class Initialized
INFO - 2017-08-02 16:27:17 --> Language Class Initialized
INFO - 2017-08-02 16:27:17 --> Loader Class Initialized
INFO - 2017-08-02 16:27:17 --> Helper loaded: url_helper
INFO - 2017-08-02 16:27:17 --> Helper loaded: form_helper
INFO - 2017-08-02 16:27:17 --> Helper loaded: security_helper
INFO - 2017-08-02 16:27:17 --> Helper loaded: path_helper
INFO - 2017-08-02 16:27:17 --> Helper loaded: common_helper
INFO - 2017-08-02 16:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:27:17 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:27:17 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:27:17 --> Email Class Initialized
INFO - 2017-08-02 16:27:17 --> Form Validation Class Initialized
INFO - 2017-08-02 16:27:17 --> Model Class Initialized
INFO - 2017-08-02 16:27:17 --> Model Class Initialized
INFO - 2017-08-02 16:27:17 --> Model Class Initialized
INFO - 2017-08-02 16:27:17 --> Model Class Initialized
INFO - 2017-08-02 16:27:17 --> Controller Class Initialized
INFO - 2017-08-02 16:27:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:27:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:27:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:27:17 --> Final output sent to browser
DEBUG - 2017-08-02 16:27:17 --> Total execution time: 0.0279
DEBUG - 2017-08-02 16:27:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:27:17 --> Database Forge Class Initialized
INFO - 2017-08-02 16:27:17 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:13 --> Config Class Initialized
INFO - 2017-08-02 16:34:13 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:13 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:13 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:13 --> URI Class Initialized
DEBUG - 2017-08-02 16:34:13 --> No URI present. Default controller set.
INFO - 2017-08-02 16:34:13 --> Router Class Initialized
INFO - 2017-08-02 16:34:13 --> Output Class Initialized
INFO - 2017-08-02 16:34:13 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:13 --> Input Class Initialized
INFO - 2017-08-02 16:34:13 --> Language Class Initialized
INFO - 2017-08-02 16:34:13 --> Loader Class Initialized
INFO - 2017-08-02 16:34:13 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:13 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:13 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:13 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:13 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:13 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:13 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:13 --> Email Class Initialized
INFO - 2017-08-02 16:34:13 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:13 --> Model Class Initialized
INFO - 2017-08-02 16:34:13 --> Model Class Initialized
INFO - 2017-08-02 16:34:13 --> Model Class Initialized
INFO - 2017-08-02 16:34:13 --> Model Class Initialized
INFO - 2017-08-02 16:34:13 --> Controller Class Initialized
DEBUG - 2017-08-02 16:34:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-02 16:34:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-02 16:34:13 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:13 --> Total execution time: 0.1574
DEBUG - 2017-08-02 16:34:13 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:13 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:13 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:17 --> Config Class Initialized
INFO - 2017-08-02 16:34:17 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:17 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:17 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:17 --> URI Class Initialized
INFO - 2017-08-02 16:34:17 --> Router Class Initialized
INFO - 2017-08-02 16:34:17 --> Output Class Initialized
INFO - 2017-08-02 16:34:17 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:17 --> Input Class Initialized
INFO - 2017-08-02 16:34:17 --> Language Class Initialized
INFO - 2017-08-02 16:34:17 --> Loader Class Initialized
INFO - 2017-08-02 16:34:17 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:17 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:17 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:17 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:17 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:17 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:17 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:17 --> Email Class Initialized
INFO - 2017-08-02 16:34:17 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:17 --> Model Class Initialized
INFO - 2017-08-02 16:34:17 --> Model Class Initialized
INFO - 2017-08-02 16:34:17 --> Model Class Initialized
INFO - 2017-08-02 16:34:17 --> Model Class Initialized
INFO - 2017-08-02 16:34:17 --> Controller Class Initialized
DEBUG - 2017-08-02 16:34:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:34:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:34:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:34:17 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:17 --> Total execution time: 0.0300
DEBUG - 2017-08-02 16:34:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:17 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:17 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:33 --> Config Class Initialized
INFO - 2017-08-02 16:34:33 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:33 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:33 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:33 --> URI Class Initialized
INFO - 2017-08-02 16:34:33 --> Router Class Initialized
INFO - 2017-08-02 16:34:33 --> Output Class Initialized
INFO - 2017-08-02 16:34:33 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:33 --> Input Class Initialized
INFO - 2017-08-02 16:34:33 --> Language Class Initialized
INFO - 2017-08-02 16:34:33 --> Loader Class Initialized
INFO - 2017-08-02 16:34:33 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:33 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:33 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:33 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:33 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:34 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:34 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:34 --> Email Class Initialized
INFO - 2017-08-02 16:34:34 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:34 --> Model Class Initialized
INFO - 2017-08-02 16:34:34 --> Model Class Initialized
INFO - 2017-08-02 16:34:34 --> Model Class Initialized
INFO - 2017-08-02 16:34:34 --> Model Class Initialized
INFO - 2017-08-02 16:34:34 --> Controller Class Initialized
INFO - 2017-08-02 16:34:34 --> Model Class Initialized
INFO - 2017-08-02 16:34:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:34:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:34:34 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:34 --> Total execution time: 0.1760
DEBUG - 2017-08-02 16:34:34 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:34 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:34 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:35 --> Config Class Initialized
INFO - 2017-08-02 16:34:35 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:35 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:35 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:35 --> URI Class Initialized
INFO - 2017-08-02 16:34:35 --> Router Class Initialized
INFO - 2017-08-02 16:34:35 --> Output Class Initialized
INFO - 2017-08-02 16:34:35 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:35 --> Input Class Initialized
INFO - 2017-08-02 16:34:35 --> Language Class Initialized
ERROR - 2017-08-02 16:34:35 --> 404 Page Not Found: Page/assets
INFO - 2017-08-02 16:34:53 --> Config Class Initialized
INFO - 2017-08-02 16:34:53 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:53 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:53 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:53 --> URI Class Initialized
INFO - 2017-08-02 16:34:53 --> Router Class Initialized
INFO - 2017-08-02 16:34:53 --> Output Class Initialized
INFO - 2017-08-02 16:34:53 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:53 --> Input Class Initialized
INFO - 2017-08-02 16:34:53 --> Language Class Initialized
INFO - 2017-08-02 16:34:53 --> Loader Class Initialized
INFO - 2017-08-02 16:34:53 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:53 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:53 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:53 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:53 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:53 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:53 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:53 --> Email Class Initialized
INFO - 2017-08-02 16:34:53 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:53 --> Model Class Initialized
INFO - 2017-08-02 16:34:53 --> Model Class Initialized
INFO - 2017-08-02 16:34:53 --> Model Class Initialized
INFO - 2017-08-02 16:34:53 --> Model Class Initialized
INFO - 2017-08-02 16:34:53 --> Controller Class Initialized
DEBUG - 2017-08-02 16:34:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:34:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:34:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:34:53 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:53 --> Total execution time: 0.0339
DEBUG - 2017-08-02 16:34:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:53 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:53 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:56 --> Config Class Initialized
INFO - 2017-08-02 16:34:56 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:56 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:56 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:56 --> URI Class Initialized
INFO - 2017-08-02 16:34:56 --> Router Class Initialized
INFO - 2017-08-02 16:34:56 --> Output Class Initialized
INFO - 2017-08-02 16:34:56 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:56 --> Input Class Initialized
INFO - 2017-08-02 16:34:56 --> Language Class Initialized
INFO - 2017-08-02 16:34:56 --> Loader Class Initialized
INFO - 2017-08-02 16:34:56 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:56 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:56 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:56 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:56 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:56 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:56 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:56 --> Email Class Initialized
INFO - 2017-08-02 16:34:56 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:56 --> Model Class Initialized
INFO - 2017-08-02 16:34:56 --> Model Class Initialized
INFO - 2017-08-02 16:34:56 --> Model Class Initialized
INFO - 2017-08-02 16:34:56 --> Model Class Initialized
INFO - 2017-08-02 16:34:56 --> Controller Class Initialized
INFO - 2017-08-02 16:34:56 --> Model Class Initialized
INFO - 2017-08-02 16:34:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:34:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:34:56 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:56 --> Total execution time: 0.0263
DEBUG - 2017-08-02 16:34:56 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:56 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:56 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:59 --> Config Class Initialized
INFO - 2017-08-02 16:34:59 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:34:59 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:34:59 --> Utf8 Class Initialized
INFO - 2017-08-02 16:34:59 --> URI Class Initialized
INFO - 2017-08-02 16:34:59 --> Router Class Initialized
INFO - 2017-08-02 16:34:59 --> Output Class Initialized
INFO - 2017-08-02 16:34:59 --> Security Class Initialized
DEBUG - 2017-08-02 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:34:59 --> Input Class Initialized
INFO - 2017-08-02 16:34:59 --> Language Class Initialized
INFO - 2017-08-02 16:34:59 --> Loader Class Initialized
INFO - 2017-08-02 16:34:59 --> Helper loaded: url_helper
INFO - 2017-08-02 16:34:59 --> Helper loaded: form_helper
INFO - 2017-08-02 16:34:59 --> Helper loaded: security_helper
INFO - 2017-08-02 16:34:59 --> Helper loaded: path_helper
INFO - 2017-08-02 16:34:59 --> Helper loaded: common_helper
INFO - 2017-08-02 16:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:34:59 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:34:59 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:34:59 --> Email Class Initialized
INFO - 2017-08-02 16:34:59 --> Form Validation Class Initialized
INFO - 2017-08-02 16:34:59 --> Model Class Initialized
INFO - 2017-08-02 16:34:59 --> Model Class Initialized
INFO - 2017-08-02 16:34:59 --> Model Class Initialized
INFO - 2017-08-02 16:34:59 --> Model Class Initialized
INFO - 2017-08-02 16:34:59 --> Controller Class Initialized
INFO - 2017-08-02 16:34:59 --> Model Class Initialized
INFO - 2017-08-02 16:34:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:34:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:34:59 --> Final output sent to browser
DEBUG - 2017-08-02 16:34:59 --> Total execution time: 0.0264
DEBUG - 2017-08-02 16:34:59 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:34:59 --> Database Forge Class Initialized
INFO - 2017-08-02 16:34:59 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:35:02 --> Config Class Initialized
INFO - 2017-08-02 16:35:02 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:35:02 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:35:02 --> Utf8 Class Initialized
INFO - 2017-08-02 16:35:02 --> URI Class Initialized
INFO - 2017-08-02 16:35:02 --> Router Class Initialized
INFO - 2017-08-02 16:35:02 --> Output Class Initialized
INFO - 2017-08-02 16:35:02 --> Security Class Initialized
DEBUG - 2017-08-02 16:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:35:02 --> Input Class Initialized
INFO - 2017-08-02 16:35:02 --> Language Class Initialized
ERROR - 2017-08-02 16:35:02 --> 404 Page Not Found: Page/assets
INFO - 2017-08-02 16:36:08 --> Config Class Initialized
INFO - 2017-08-02 16:36:08 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:36:08 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:36:08 --> Utf8 Class Initialized
INFO - 2017-08-02 16:36:08 --> URI Class Initialized
INFO - 2017-08-02 16:36:08 --> Router Class Initialized
INFO - 2017-08-02 16:36:08 --> Output Class Initialized
INFO - 2017-08-02 16:36:08 --> Security Class Initialized
DEBUG - 2017-08-02 16:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:36:08 --> Input Class Initialized
INFO - 2017-08-02 16:36:08 --> Language Class Initialized
INFO - 2017-08-02 16:36:08 --> Loader Class Initialized
INFO - 2017-08-02 16:36:08 --> Helper loaded: url_helper
INFO - 2017-08-02 16:36:08 --> Helper loaded: form_helper
INFO - 2017-08-02 16:36:08 --> Helper loaded: security_helper
INFO - 2017-08-02 16:36:08 --> Helper loaded: path_helper
INFO - 2017-08-02 16:36:08 --> Helper loaded: common_helper
INFO - 2017-08-02 16:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:36:08 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:36:08 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:08 --> Email Class Initialized
INFO - 2017-08-02 16:36:08 --> Form Validation Class Initialized
INFO - 2017-08-02 16:36:08 --> Model Class Initialized
INFO - 2017-08-02 16:36:08 --> Model Class Initialized
INFO - 2017-08-02 16:36:08 --> Model Class Initialized
INFO - 2017-08-02 16:36:08 --> Model Class Initialized
INFO - 2017-08-02 16:36:08 --> Controller Class Initialized
DEBUG - 2017-08-02 16:36:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:36:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:36:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:36:08 --> Final output sent to browser
DEBUG - 2017-08-02 16:36:08 --> Total execution time: 0.0334
DEBUG - 2017-08-02 16:36:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:36:08 --> Database Forge Class Initialized
INFO - 2017-08-02 16:36:08 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:36:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:08 --> Config Class Initialized
INFO - 2017-08-02 16:36:08 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:36:08 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:36:08 --> Utf8 Class Initialized
INFO - 2017-08-02 16:36:08 --> URI Class Initialized
INFO - 2017-08-02 16:36:08 --> Router Class Initialized
INFO - 2017-08-02 16:36:08 --> Output Class Initialized
INFO - 2017-08-02 16:36:08 --> Security Class Initialized
DEBUG - 2017-08-02 16:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:36:08 --> Input Class Initialized
INFO - 2017-08-02 16:36:08 --> Language Class Initialized
ERROR - 2017-08-02 16:36:08 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-02 16:36:13 --> Config Class Initialized
INFO - 2017-08-02 16:36:13 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:36:13 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:36:13 --> Utf8 Class Initialized
INFO - 2017-08-02 16:36:13 --> URI Class Initialized
INFO - 2017-08-02 16:36:13 --> Router Class Initialized
INFO - 2017-08-02 16:36:13 --> Output Class Initialized
INFO - 2017-08-02 16:36:13 --> Security Class Initialized
DEBUG - 2017-08-02 16:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:36:13 --> Input Class Initialized
INFO - 2017-08-02 16:36:13 --> Language Class Initialized
INFO - 2017-08-02 16:36:13 --> Loader Class Initialized
INFO - 2017-08-02 16:36:13 --> Helper loaded: url_helper
INFO - 2017-08-02 16:36:13 --> Helper loaded: form_helper
INFO - 2017-08-02 16:36:13 --> Helper loaded: security_helper
INFO - 2017-08-02 16:36:13 --> Helper loaded: path_helper
INFO - 2017-08-02 16:36:13 --> Helper loaded: common_helper
INFO - 2017-08-02 16:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:36:13 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:36:13 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:13 --> Email Class Initialized
INFO - 2017-08-02 16:36:13 --> Form Validation Class Initialized
INFO - 2017-08-02 16:36:13 --> Model Class Initialized
INFO - 2017-08-02 16:36:13 --> Model Class Initialized
INFO - 2017-08-02 16:36:13 --> Model Class Initialized
INFO - 2017-08-02 16:36:13 --> Model Class Initialized
INFO - 2017-08-02 16:36:13 --> Controller Class Initialized
INFO - 2017-08-02 16:36:13 --> Model Class Initialized
INFO - 2017-08-02 16:36:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:36:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:36:13 --> Final output sent to browser
DEBUG - 2017-08-02 16:36:13 --> Total execution time: 0.0281
DEBUG - 2017-08-02 16:36:13 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:36:13 --> Database Forge Class Initialized
INFO - 2017-08-02 16:36:13 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:40 --> Config Class Initialized
INFO - 2017-08-02 16:36:40 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:36:40 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:36:40 --> Utf8 Class Initialized
INFO - 2017-08-02 16:36:40 --> URI Class Initialized
INFO - 2017-08-02 16:36:40 --> Router Class Initialized
INFO - 2017-08-02 16:36:40 --> Output Class Initialized
INFO - 2017-08-02 16:36:40 --> Security Class Initialized
DEBUG - 2017-08-02 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:36:40 --> Input Class Initialized
INFO - 2017-08-02 16:36:40 --> Language Class Initialized
INFO - 2017-08-02 16:36:40 --> Loader Class Initialized
INFO - 2017-08-02 16:36:40 --> Helper loaded: url_helper
INFO - 2017-08-02 16:36:40 --> Helper loaded: form_helper
INFO - 2017-08-02 16:36:40 --> Helper loaded: security_helper
INFO - 2017-08-02 16:36:40 --> Helper loaded: path_helper
INFO - 2017-08-02 16:36:40 --> Helper loaded: common_helper
INFO - 2017-08-02 16:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:36:40 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:36:40 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:36:40 --> Email Class Initialized
INFO - 2017-08-02 16:36:40 --> Form Validation Class Initialized
INFO - 2017-08-02 16:36:40 --> Model Class Initialized
INFO - 2017-08-02 16:36:40 --> Model Class Initialized
INFO - 2017-08-02 16:36:40 --> Model Class Initialized
INFO - 2017-08-02 16:36:40 --> Model Class Initialized
INFO - 2017-08-02 16:36:40 --> Controller Class Initialized
INFO - 2017-08-02 16:36:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:36:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:36:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:36:40 --> Final output sent to browser
DEBUG - 2017-08-02 16:36:40 --> Total execution time: 0.0280
DEBUG - 2017-08-02 16:36:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:36:40 --> Database Forge Class Initialized
INFO - 2017-08-02 16:36:40 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:18 --> Config Class Initialized
INFO - 2017-08-02 16:37:18 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:37:18 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:37:18 --> Utf8 Class Initialized
INFO - 2017-08-02 16:37:18 --> URI Class Initialized
INFO - 2017-08-02 16:37:18 --> Router Class Initialized
INFO - 2017-08-02 16:37:18 --> Output Class Initialized
INFO - 2017-08-02 16:37:18 --> Security Class Initialized
DEBUG - 2017-08-02 16:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:37:18 --> Input Class Initialized
INFO - 2017-08-02 16:37:18 --> Language Class Initialized
INFO - 2017-08-02 16:37:18 --> Loader Class Initialized
INFO - 2017-08-02 16:37:18 --> Helper loaded: url_helper
INFO - 2017-08-02 16:37:18 --> Helper loaded: form_helper
INFO - 2017-08-02 16:37:18 --> Helper loaded: security_helper
INFO - 2017-08-02 16:37:18 --> Helper loaded: path_helper
INFO - 2017-08-02 16:37:18 --> Helper loaded: common_helper
INFO - 2017-08-02 16:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:37:18 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:37:18 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:18 --> Email Class Initialized
INFO - 2017-08-02 16:37:18 --> Form Validation Class Initialized
INFO - 2017-08-02 16:37:18 --> Model Class Initialized
INFO - 2017-08-02 16:37:18 --> Model Class Initialized
INFO - 2017-08-02 16:37:18 --> Model Class Initialized
INFO - 2017-08-02 16:37:18 --> Model Class Initialized
INFO - 2017-08-02 16:37:18 --> Controller Class Initialized
INFO - 2017-08-02 16:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 16:37:18 --> Pagination Class Initialized
INFO - 2017-08-02 16:37:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:37:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managetumorboards.php
INFO - 2017-08-02 16:37:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:37:19 --> Final output sent to browser
DEBUG - 2017-08-02 16:37:19 --> Total execution time: 0.0658
DEBUG - 2017-08-02 16:37:19 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:37:19 --> Database Forge Class Initialized
INFO - 2017-08-02 16:37:19 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:37:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:21 --> Config Class Initialized
INFO - 2017-08-02 16:37:21 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:37:21 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:37:22 --> Utf8 Class Initialized
INFO - 2017-08-02 16:37:22 --> URI Class Initialized
INFO - 2017-08-02 16:37:22 --> Router Class Initialized
INFO - 2017-08-02 16:37:22 --> Output Class Initialized
INFO - 2017-08-02 16:37:22 --> Security Class Initialized
DEBUG - 2017-08-02 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:37:22 --> Input Class Initialized
INFO - 2017-08-02 16:37:22 --> Language Class Initialized
INFO - 2017-08-02 16:37:22 --> Loader Class Initialized
INFO - 2017-08-02 16:37:22 --> Helper loaded: url_helper
INFO - 2017-08-02 16:37:22 --> Helper loaded: form_helper
INFO - 2017-08-02 16:37:22 --> Helper loaded: security_helper
INFO - 2017-08-02 16:37:22 --> Helper loaded: path_helper
INFO - 2017-08-02 16:37:22 --> Helper loaded: common_helper
INFO - 2017-08-02 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:37:22 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:37:22 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:22 --> Email Class Initialized
INFO - 2017-08-02 16:37:22 --> Form Validation Class Initialized
INFO - 2017-08-02 16:37:22 --> Model Class Initialized
INFO - 2017-08-02 16:37:22 --> Model Class Initialized
INFO - 2017-08-02 16:37:22 --> Model Class Initialized
INFO - 2017-08-02 16:37:22 --> Model Class Initialized
INFO - 2017-08-02 16:37:22 --> Controller Class Initialized
DEBUG - 2017-08-02 16:37:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
ERROR - 2017-08-02 16:37:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/tumorboard_add.php 49
INFO - 2017-08-02 16:37:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/tumorboard_add.php
INFO - 2017-08-02 16:37:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:37:22 --> Final output sent to browser
DEBUG - 2017-08-02 16:37:22 --> Total execution time: 0.0639
DEBUG - 2017-08-02 16:37:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:37:22 --> Database Forge Class Initialized
INFO - 2017-08-02 16:37:22 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:37:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:24 --> Config Class Initialized
INFO - 2017-08-02 16:37:24 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:37:24 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:37:24 --> Utf8 Class Initialized
INFO - 2017-08-02 16:37:24 --> URI Class Initialized
INFO - 2017-08-02 16:37:24 --> Router Class Initialized
INFO - 2017-08-02 16:37:24 --> Output Class Initialized
INFO - 2017-08-02 16:37:24 --> Security Class Initialized
DEBUG - 2017-08-02 16:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:37:24 --> Input Class Initialized
INFO - 2017-08-02 16:37:24 --> Language Class Initialized
INFO - 2017-08-02 16:37:24 --> Loader Class Initialized
INFO - 2017-08-02 16:37:24 --> Helper loaded: url_helper
INFO - 2017-08-02 16:37:24 --> Helper loaded: form_helper
INFO - 2017-08-02 16:37:24 --> Helper loaded: security_helper
INFO - 2017-08-02 16:37:24 --> Helper loaded: path_helper
INFO - 2017-08-02 16:37:24 --> Helper loaded: common_helper
INFO - 2017-08-02 16:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:37:24 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:37:24 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:24 --> Email Class Initialized
INFO - 2017-08-02 16:37:24 --> Form Validation Class Initialized
INFO - 2017-08-02 16:37:24 --> Model Class Initialized
INFO - 2017-08-02 16:37:24 --> Model Class Initialized
INFO - 2017-08-02 16:37:24 --> Model Class Initialized
INFO - 2017-08-02 16:37:24 --> Model Class Initialized
INFO - 2017-08-02 16:37:24 --> Controller Class Initialized
INFO - 2017-08-02 16:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 16:37:24 --> Pagination Class Initialized
INFO - 2017-08-02 16:37:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:37:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-08-02 16:37:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:37:24 --> Final output sent to browser
DEBUG - 2017-08-02 16:37:24 --> Total execution time: 0.0437
DEBUG - 2017-08-02 16:37:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:37:24 --> Database Forge Class Initialized
INFO - 2017-08-02 16:37:24 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:32 --> Config Class Initialized
INFO - 2017-08-02 16:37:32 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:37:32 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:37:32 --> Utf8 Class Initialized
INFO - 2017-08-02 16:37:32 --> URI Class Initialized
INFO - 2017-08-02 16:37:32 --> Router Class Initialized
INFO - 2017-08-02 16:37:32 --> Output Class Initialized
INFO - 2017-08-02 16:37:32 --> Security Class Initialized
DEBUG - 2017-08-02 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:37:32 --> Input Class Initialized
INFO - 2017-08-02 16:37:32 --> Language Class Initialized
INFO - 2017-08-02 16:37:32 --> Loader Class Initialized
INFO - 2017-08-02 16:37:32 --> Helper loaded: url_helper
INFO - 2017-08-02 16:37:32 --> Helper loaded: form_helper
INFO - 2017-08-02 16:37:32 --> Helper loaded: security_helper
INFO - 2017-08-02 16:37:32 --> Helper loaded: path_helper
INFO - 2017-08-02 16:37:32 --> Helper loaded: common_helper
INFO - 2017-08-02 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:37:32 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:37:32 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:37:32 --> Email Class Initialized
INFO - 2017-08-02 16:37:32 --> Form Validation Class Initialized
INFO - 2017-08-02 16:37:32 --> Model Class Initialized
INFO - 2017-08-02 16:37:32 --> Model Class Initialized
INFO - 2017-08-02 16:37:32 --> Model Class Initialized
INFO - 2017-08-02 16:37:32 --> Model Class Initialized
INFO - 2017-08-02 16:37:32 --> Controller Class Initialized
INFO - 2017-08-02 16:37:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:37:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 16:37:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:37:32 --> Final output sent to browser
DEBUG - 2017-08-02 16:37:32 --> Total execution time: 0.0281
DEBUG - 2017-08-02 16:37:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:37:32 --> Database Forge Class Initialized
INFO - 2017-08-02 16:37:32 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:46:45 --> Config Class Initialized
INFO - 2017-08-02 16:46:45 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:46:45 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:46:45 --> Utf8 Class Initialized
INFO - 2017-08-02 16:46:45 --> URI Class Initialized
INFO - 2017-08-02 16:46:45 --> Router Class Initialized
INFO - 2017-08-02 16:46:45 --> Output Class Initialized
INFO - 2017-08-02 16:46:45 --> Security Class Initialized
DEBUG - 2017-08-02 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:46:45 --> Input Class Initialized
INFO - 2017-08-02 16:46:45 --> Language Class Initialized
INFO - 2017-08-02 16:46:45 --> Loader Class Initialized
INFO - 2017-08-02 16:46:45 --> Helper loaded: url_helper
INFO - 2017-08-02 16:46:45 --> Helper loaded: form_helper
INFO - 2017-08-02 16:46:45 --> Helper loaded: security_helper
INFO - 2017-08-02 16:46:45 --> Helper loaded: path_helper
INFO - 2017-08-02 16:46:45 --> Helper loaded: common_helper
INFO - 2017-08-02 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:46:45 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:46:45 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:46:45 --> Email Class Initialized
INFO - 2017-08-02 16:46:45 --> Form Validation Class Initialized
INFO - 2017-08-02 16:46:45 --> Model Class Initialized
INFO - 2017-08-02 16:46:45 --> Model Class Initialized
INFO - 2017-08-02 16:46:45 --> Model Class Initialized
INFO - 2017-08-02 16:46:45 --> Model Class Initialized
INFO - 2017-08-02 16:46:45 --> Controller Class Initialized
INFO - 2017-08-02 16:46:45 --> Model Class Initialized
INFO - 2017-08-02 16:46:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:46:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:46:45 --> Final output sent to browser
DEBUG - 2017-08-02 16:46:45 --> Total execution time: 0.0299
DEBUG - 2017-08-02 16:46:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:46:45 --> Database Forge Class Initialized
INFO - 2017-08-02 16:46:45 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:46:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:47:14 --> Config Class Initialized
INFO - 2017-08-02 16:47:14 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:47:14 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:47:14 --> Utf8 Class Initialized
INFO - 2017-08-02 16:47:14 --> URI Class Initialized
INFO - 2017-08-02 16:47:14 --> Router Class Initialized
INFO - 2017-08-02 16:47:14 --> Output Class Initialized
INFO - 2017-08-02 16:47:14 --> Security Class Initialized
DEBUG - 2017-08-02 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:47:14 --> Input Class Initialized
INFO - 2017-08-02 16:47:14 --> Language Class Initialized
INFO - 2017-08-02 16:47:14 --> Loader Class Initialized
INFO - 2017-08-02 16:47:14 --> Helper loaded: url_helper
INFO - 2017-08-02 16:47:14 --> Helper loaded: form_helper
INFO - 2017-08-02 16:47:14 --> Helper loaded: security_helper
INFO - 2017-08-02 16:47:14 --> Helper loaded: path_helper
INFO - 2017-08-02 16:47:14 --> Helper loaded: common_helper
INFO - 2017-08-02 16:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:47:14 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:47:14 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:47:14 --> Email Class Initialized
INFO - 2017-08-02 16:47:14 --> Form Validation Class Initialized
INFO - 2017-08-02 16:47:14 --> Model Class Initialized
INFO - 2017-08-02 16:47:14 --> Model Class Initialized
INFO - 2017-08-02 16:47:14 --> Model Class Initialized
INFO - 2017-08-02 16:47:14 --> Model Class Initialized
INFO - 2017-08-02 16:47:14 --> Controller Class Initialized
INFO - 2017-08-02 16:47:14 --> Model Class Initialized
INFO - 2017-08-02 16:47:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:47:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:47:14 --> Final output sent to browser
DEBUG - 2017-08-02 16:47:14 --> Total execution time: 0.0264
DEBUG - 2017-08-02 16:47:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:47:14 --> Database Forge Class Initialized
INFO - 2017-08-02 16:47:14 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:48:48 --> Config Class Initialized
INFO - 2017-08-02 16:48:48 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:48:48 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:48:48 --> Utf8 Class Initialized
INFO - 2017-08-02 16:48:48 --> URI Class Initialized
INFO - 2017-08-02 16:48:48 --> Router Class Initialized
INFO - 2017-08-02 16:48:48 --> Output Class Initialized
INFO - 2017-08-02 16:48:48 --> Security Class Initialized
DEBUG - 2017-08-02 16:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:48:48 --> Input Class Initialized
INFO - 2017-08-02 16:48:48 --> Language Class Initialized
INFO - 2017-08-02 16:48:48 --> Loader Class Initialized
INFO - 2017-08-02 16:48:48 --> Helper loaded: url_helper
INFO - 2017-08-02 16:48:48 --> Helper loaded: form_helper
INFO - 2017-08-02 16:48:48 --> Helper loaded: security_helper
INFO - 2017-08-02 16:48:48 --> Helper loaded: path_helper
INFO - 2017-08-02 16:48:48 --> Helper loaded: common_helper
INFO - 2017-08-02 16:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:48:48 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:48:48 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:48:48 --> Email Class Initialized
INFO - 2017-08-02 16:48:48 --> Form Validation Class Initialized
INFO - 2017-08-02 16:48:48 --> Model Class Initialized
INFO - 2017-08-02 16:48:48 --> Model Class Initialized
INFO - 2017-08-02 16:48:48 --> Model Class Initialized
INFO - 2017-08-02 16:48:48 --> Model Class Initialized
INFO - 2017-08-02 16:48:48 --> Controller Class Initialized
INFO - 2017-08-02 16:48:48 --> Model Class Initialized
INFO - 2017-08-02 16:48:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:48:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:48:48 --> Final output sent to browser
DEBUG - 2017-08-02 16:48:48 --> Total execution time: 0.0290
DEBUG - 2017-08-02 16:48:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:48:48 --> Database Forge Class Initialized
INFO - 2017-08-02 16:48:48 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:48:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:53:48 --> Config Class Initialized
INFO - 2017-08-02 16:53:48 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:53:48 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:53:48 --> Utf8 Class Initialized
INFO - 2017-08-02 16:53:48 --> URI Class Initialized
INFO - 2017-08-02 16:53:48 --> Router Class Initialized
INFO - 2017-08-02 16:53:48 --> Output Class Initialized
INFO - 2017-08-02 16:53:48 --> Security Class Initialized
DEBUG - 2017-08-02 16:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:53:48 --> Input Class Initialized
INFO - 2017-08-02 16:53:48 --> Language Class Initialized
INFO - 2017-08-02 16:53:48 --> Loader Class Initialized
INFO - 2017-08-02 16:53:48 --> Helper loaded: url_helper
INFO - 2017-08-02 16:53:48 --> Helper loaded: form_helper
INFO - 2017-08-02 16:53:48 --> Helper loaded: security_helper
INFO - 2017-08-02 16:53:48 --> Helper loaded: path_helper
INFO - 2017-08-02 16:53:48 --> Helper loaded: common_helper
INFO - 2017-08-02 16:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:53:48 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:53:48 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:53:48 --> Email Class Initialized
INFO - 2017-08-02 16:53:48 --> Form Validation Class Initialized
INFO - 2017-08-02 16:53:48 --> Model Class Initialized
INFO - 2017-08-02 16:53:48 --> Model Class Initialized
INFO - 2017-08-02 16:53:48 --> Model Class Initialized
INFO - 2017-08-02 16:53:48 --> Model Class Initialized
INFO - 2017-08-02 16:53:48 --> Controller Class Initialized
INFO - 2017-08-02 16:53:48 --> Model Class Initialized
INFO - 2017-08-02 16:53:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:53:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:53:48 --> Final output sent to browser
DEBUG - 2017-08-02 16:53:48 --> Total execution time: 0.0289
DEBUG - 2017-08-02 16:53:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:53:48 --> Database Forge Class Initialized
INFO - 2017-08-02 16:53:48 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:22 --> Config Class Initialized
INFO - 2017-08-02 16:54:22 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:54:22 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:54:22 --> Utf8 Class Initialized
INFO - 2017-08-02 16:54:22 --> URI Class Initialized
INFO - 2017-08-02 16:54:22 --> Router Class Initialized
INFO - 2017-08-02 16:54:22 --> Output Class Initialized
INFO - 2017-08-02 16:54:22 --> Security Class Initialized
DEBUG - 2017-08-02 16:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:54:22 --> Input Class Initialized
INFO - 2017-08-02 16:54:22 --> Language Class Initialized
INFO - 2017-08-02 16:54:22 --> Loader Class Initialized
INFO - 2017-08-02 16:54:22 --> Helper loaded: url_helper
INFO - 2017-08-02 16:54:22 --> Helper loaded: form_helper
INFO - 2017-08-02 16:54:22 --> Helper loaded: security_helper
INFO - 2017-08-02 16:54:22 --> Helper loaded: path_helper
INFO - 2017-08-02 16:54:22 --> Helper loaded: common_helper
INFO - 2017-08-02 16:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:54:22 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:54:22 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:22 --> Email Class Initialized
INFO - 2017-08-02 16:54:22 --> Form Validation Class Initialized
INFO - 2017-08-02 16:54:22 --> Model Class Initialized
INFO - 2017-08-02 16:54:22 --> Model Class Initialized
INFO - 2017-08-02 16:54:22 --> Model Class Initialized
INFO - 2017-08-02 16:54:22 --> Model Class Initialized
INFO - 2017-08-02 16:54:22 --> Controller Class Initialized
DEBUG - 2017-08-02 16:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:54:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:54:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:54:22 --> Final output sent to browser
DEBUG - 2017-08-02 16:54:22 --> Total execution time: 0.0267
DEBUG - 2017-08-02 16:54:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:54:22 --> Database Forge Class Initialized
INFO - 2017-08-02 16:54:22 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:55 --> Config Class Initialized
INFO - 2017-08-02 16:54:55 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:54:55 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:54:55 --> Utf8 Class Initialized
INFO - 2017-08-02 16:54:55 --> URI Class Initialized
INFO - 2017-08-02 16:54:55 --> Router Class Initialized
INFO - 2017-08-02 16:54:55 --> Output Class Initialized
INFO - 2017-08-02 16:54:55 --> Security Class Initialized
DEBUG - 2017-08-02 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:54:55 --> Input Class Initialized
INFO - 2017-08-02 16:54:55 --> Language Class Initialized
INFO - 2017-08-02 16:54:55 --> Loader Class Initialized
INFO - 2017-08-02 16:54:55 --> Helper loaded: url_helper
INFO - 2017-08-02 16:54:55 --> Helper loaded: form_helper
INFO - 2017-08-02 16:54:55 --> Helper loaded: security_helper
INFO - 2017-08-02 16:54:55 --> Helper loaded: path_helper
INFO - 2017-08-02 16:54:55 --> Helper loaded: common_helper
INFO - 2017-08-02 16:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:54:55 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:54:55 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:55 --> Email Class Initialized
INFO - 2017-08-02 16:54:55 --> Form Validation Class Initialized
INFO - 2017-08-02 16:54:55 --> Model Class Initialized
INFO - 2017-08-02 16:54:55 --> Model Class Initialized
INFO - 2017-08-02 16:54:55 --> Model Class Initialized
INFO - 2017-08-02 16:54:55 --> Model Class Initialized
INFO - 2017-08-02 16:54:55 --> Controller Class Initialized
DEBUG - 2017-08-02 16:54:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:54:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:54:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:54:55 --> Final output sent to browser
DEBUG - 2017-08-02 16:54:55 --> Total execution time: 0.0524
DEBUG - 2017-08-02 16:54:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:54:55 --> Database Forge Class Initialized
INFO - 2017-08-02 16:54:55 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:54:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:58 --> Config Class Initialized
INFO - 2017-08-02 16:54:58 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:54:58 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:54:58 --> Utf8 Class Initialized
INFO - 2017-08-02 16:54:58 --> URI Class Initialized
INFO - 2017-08-02 16:54:58 --> Router Class Initialized
INFO - 2017-08-02 16:54:58 --> Output Class Initialized
INFO - 2017-08-02 16:54:58 --> Security Class Initialized
DEBUG - 2017-08-02 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:54:58 --> Input Class Initialized
INFO - 2017-08-02 16:54:58 --> Language Class Initialized
INFO - 2017-08-02 16:54:58 --> Loader Class Initialized
INFO - 2017-08-02 16:54:58 --> Helper loaded: url_helper
INFO - 2017-08-02 16:54:58 --> Helper loaded: form_helper
INFO - 2017-08-02 16:54:58 --> Helper loaded: security_helper
INFO - 2017-08-02 16:54:58 --> Helper loaded: path_helper
INFO - 2017-08-02 16:54:58 --> Helper loaded: common_helper
INFO - 2017-08-02 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:54:58 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:54:58 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:54:58 --> Email Class Initialized
INFO - 2017-08-02 16:54:58 --> Form Validation Class Initialized
INFO - 2017-08-02 16:54:58 --> Model Class Initialized
INFO - 2017-08-02 16:54:58 --> Model Class Initialized
INFO - 2017-08-02 16:54:58 --> Model Class Initialized
INFO - 2017-08-02 16:54:58 --> Model Class Initialized
INFO - 2017-08-02 16:54:58 --> Controller Class Initialized
INFO - 2017-08-02 16:54:58 --> Model Class Initialized
INFO - 2017-08-02 16:54:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:54:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:54:58 --> Final output sent to browser
DEBUG - 2017-08-02 16:54:58 --> Total execution time: 0.0267
DEBUG - 2017-08-02 16:54:58 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:54:58 --> Database Forge Class Initialized
INFO - 2017-08-02 16:54:58 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:55:26 --> Config Class Initialized
INFO - 2017-08-02 16:55:26 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:55:26 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:55:26 --> Utf8 Class Initialized
INFO - 2017-08-02 16:55:26 --> URI Class Initialized
INFO - 2017-08-02 16:55:26 --> Router Class Initialized
INFO - 2017-08-02 16:55:26 --> Output Class Initialized
INFO - 2017-08-02 16:55:26 --> Security Class Initialized
DEBUG - 2017-08-02 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:55:26 --> Input Class Initialized
INFO - 2017-08-02 16:55:26 --> Language Class Initialized
INFO - 2017-08-02 16:55:26 --> Loader Class Initialized
INFO - 2017-08-02 16:55:26 --> Helper loaded: url_helper
INFO - 2017-08-02 16:55:26 --> Helper loaded: form_helper
INFO - 2017-08-02 16:55:26 --> Helper loaded: security_helper
INFO - 2017-08-02 16:55:26 --> Helper loaded: path_helper
INFO - 2017-08-02 16:55:26 --> Helper loaded: common_helper
INFO - 2017-08-02 16:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:55:26 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:55:26 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:55:26 --> Email Class Initialized
INFO - 2017-08-02 16:55:26 --> Form Validation Class Initialized
INFO - 2017-08-02 16:55:26 --> Model Class Initialized
INFO - 2017-08-02 16:55:26 --> Model Class Initialized
INFO - 2017-08-02 16:55:26 --> Model Class Initialized
INFO - 2017-08-02 16:55:26 --> Model Class Initialized
INFO - 2017-08-02 16:55:26 --> Controller Class Initialized
DEBUG - 2017-08-02 16:55:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:55:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:55:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:55:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:55:26 --> Final output sent to browser
DEBUG - 2017-08-02 16:55:26 --> Total execution time: 0.0298
DEBUG - 2017-08-02 16:55:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:55:26 --> Database Forge Class Initialized
INFO - 2017-08-02 16:55:26 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:55:29 --> Config Class Initialized
INFO - 2017-08-02 16:55:29 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:55:29 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:55:29 --> Utf8 Class Initialized
INFO - 2017-08-02 16:55:29 --> URI Class Initialized
INFO - 2017-08-02 16:55:29 --> Router Class Initialized
INFO - 2017-08-02 16:55:29 --> Output Class Initialized
INFO - 2017-08-02 16:55:29 --> Security Class Initialized
DEBUG - 2017-08-02 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:55:29 --> Input Class Initialized
INFO - 2017-08-02 16:55:29 --> Language Class Initialized
INFO - 2017-08-02 16:55:29 --> Loader Class Initialized
INFO - 2017-08-02 16:55:29 --> Helper loaded: url_helper
INFO - 2017-08-02 16:55:29 --> Helper loaded: form_helper
INFO - 2017-08-02 16:55:29 --> Helper loaded: security_helper
INFO - 2017-08-02 16:55:29 --> Helper loaded: path_helper
INFO - 2017-08-02 16:55:29 --> Helper loaded: common_helper
INFO - 2017-08-02 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:55:29 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:55:29 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:55:29 --> Email Class Initialized
INFO - 2017-08-02 16:55:29 --> Form Validation Class Initialized
INFO - 2017-08-02 16:55:29 --> Model Class Initialized
INFO - 2017-08-02 16:55:29 --> Model Class Initialized
INFO - 2017-08-02 16:55:29 --> Model Class Initialized
INFO - 2017-08-02 16:55:29 --> Model Class Initialized
INFO - 2017-08-02 16:55:29 --> Controller Class Initialized
INFO - 2017-08-02 16:55:29 --> Model Class Initialized
INFO - 2017-08-02 16:55:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:55:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:55:29 --> Final output sent to browser
DEBUG - 2017-08-02 16:55:29 --> Total execution time: 0.0317
DEBUG - 2017-08-02 16:55:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:55:29 --> Database Forge Class Initialized
INFO - 2017-08-02 16:55:29 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:55:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:56:46 --> Config Class Initialized
INFO - 2017-08-02 16:56:46 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:56:46 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:56:46 --> Utf8 Class Initialized
INFO - 2017-08-02 16:56:46 --> URI Class Initialized
INFO - 2017-08-02 16:56:46 --> Router Class Initialized
INFO - 2017-08-02 16:56:46 --> Output Class Initialized
INFO - 2017-08-02 16:56:46 --> Security Class Initialized
DEBUG - 2017-08-02 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:56:46 --> Input Class Initialized
INFO - 2017-08-02 16:56:46 --> Language Class Initialized
INFO - 2017-08-02 16:56:46 --> Loader Class Initialized
INFO - 2017-08-02 16:56:46 --> Helper loaded: url_helper
INFO - 2017-08-02 16:56:46 --> Helper loaded: form_helper
INFO - 2017-08-02 16:56:46 --> Helper loaded: security_helper
INFO - 2017-08-02 16:56:46 --> Helper loaded: path_helper
INFO - 2017-08-02 16:56:46 --> Helper loaded: common_helper
INFO - 2017-08-02 16:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:56:46 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:56:46 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:56:46 --> Email Class Initialized
INFO - 2017-08-02 16:56:46 --> Form Validation Class Initialized
INFO - 2017-08-02 16:56:46 --> Model Class Initialized
INFO - 2017-08-02 16:56:46 --> Model Class Initialized
INFO - 2017-08-02 16:56:46 --> Model Class Initialized
INFO - 2017-08-02 16:56:46 --> Model Class Initialized
INFO - 2017-08-02 16:56:46 --> Controller Class Initialized
DEBUG - 2017-08-02 16:56:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:56:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:56:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:56:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:56:46 --> Final output sent to browser
DEBUG - 2017-08-02 16:56:46 --> Total execution time: 0.0311
DEBUG - 2017-08-02 16:56:46 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:56:46 --> Database Forge Class Initialized
INFO - 2017-08-02 16:56:46 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:56:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:56:48 --> Config Class Initialized
INFO - 2017-08-02 16:56:48 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:56:48 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:56:48 --> Utf8 Class Initialized
INFO - 2017-08-02 16:56:48 --> URI Class Initialized
INFO - 2017-08-02 16:56:48 --> Router Class Initialized
INFO - 2017-08-02 16:56:48 --> Output Class Initialized
INFO - 2017-08-02 16:56:48 --> Security Class Initialized
DEBUG - 2017-08-02 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:56:48 --> Input Class Initialized
INFO - 2017-08-02 16:56:48 --> Language Class Initialized
INFO - 2017-08-02 16:56:48 --> Loader Class Initialized
INFO - 2017-08-02 16:56:48 --> Helper loaded: url_helper
INFO - 2017-08-02 16:56:48 --> Helper loaded: form_helper
INFO - 2017-08-02 16:56:48 --> Helper loaded: security_helper
INFO - 2017-08-02 16:56:48 --> Helper loaded: path_helper
INFO - 2017-08-02 16:56:48 --> Helper loaded: common_helper
INFO - 2017-08-02 16:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:56:48 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:56:48 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:56:48 --> Email Class Initialized
INFO - 2017-08-02 16:56:48 --> Form Validation Class Initialized
INFO - 2017-08-02 16:56:48 --> Model Class Initialized
INFO - 2017-08-02 16:56:48 --> Model Class Initialized
INFO - 2017-08-02 16:56:48 --> Model Class Initialized
INFO - 2017-08-02 16:56:48 --> Model Class Initialized
INFO - 2017-08-02 16:56:48 --> Controller Class Initialized
INFO - 2017-08-02 16:56:48 --> Model Class Initialized
INFO - 2017-08-02 16:56:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:56:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:56:48 --> Final output sent to browser
DEBUG - 2017-08-02 16:56:48 --> Total execution time: 0.0303
DEBUG - 2017-08-02 16:56:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:56:48 --> Database Forge Class Initialized
INFO - 2017-08-02 16:56:48 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:56:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:57:03 --> Config Class Initialized
INFO - 2017-08-02 16:57:03 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:57:03 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:57:03 --> Utf8 Class Initialized
INFO - 2017-08-02 16:57:03 --> URI Class Initialized
INFO - 2017-08-02 16:57:03 --> Router Class Initialized
INFO - 2017-08-02 16:57:03 --> Output Class Initialized
INFO - 2017-08-02 16:57:03 --> Security Class Initialized
DEBUG - 2017-08-02 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:57:03 --> Input Class Initialized
INFO - 2017-08-02 16:57:03 --> Language Class Initialized
INFO - 2017-08-02 16:57:03 --> Loader Class Initialized
INFO - 2017-08-02 16:57:03 --> Helper loaded: url_helper
INFO - 2017-08-02 16:57:03 --> Helper loaded: form_helper
INFO - 2017-08-02 16:57:03 --> Helper loaded: security_helper
INFO - 2017-08-02 16:57:03 --> Helper loaded: path_helper
INFO - 2017-08-02 16:57:03 --> Helper loaded: common_helper
INFO - 2017-08-02 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:57:03 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:57:03 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:57:03 --> Email Class Initialized
INFO - 2017-08-02 16:57:03 --> Form Validation Class Initialized
INFO - 2017-08-02 16:57:03 --> Model Class Initialized
INFO - 2017-08-02 16:57:03 --> Model Class Initialized
INFO - 2017-08-02 16:57:03 --> Model Class Initialized
INFO - 2017-08-02 16:57:03 --> Model Class Initialized
INFO - 2017-08-02 16:57:03 --> Controller Class Initialized
DEBUG - 2017-08-02 16:57:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:57:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 16:57:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 16:57:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 16:57:03 --> Final output sent to browser
DEBUG - 2017-08-02 16:57:03 --> Total execution time: 0.0301
DEBUG - 2017-08-02 16:57:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:57:03 --> Database Forge Class Initialized
INFO - 2017-08-02 16:57:03 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:57:05 --> Config Class Initialized
INFO - 2017-08-02 16:57:05 --> Hooks Class Initialized
DEBUG - 2017-08-02 16:57:05 --> UTF-8 Support Enabled
INFO - 2017-08-02 16:57:05 --> Utf8 Class Initialized
INFO - 2017-08-02 16:57:05 --> URI Class Initialized
INFO - 2017-08-02 16:57:05 --> Router Class Initialized
INFO - 2017-08-02 16:57:05 --> Output Class Initialized
INFO - 2017-08-02 16:57:05 --> Security Class Initialized
DEBUG - 2017-08-02 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 16:57:05 --> Input Class Initialized
INFO - 2017-08-02 16:57:05 --> Language Class Initialized
INFO - 2017-08-02 16:57:05 --> Loader Class Initialized
INFO - 2017-08-02 16:57:05 --> Helper loaded: url_helper
INFO - 2017-08-02 16:57:05 --> Helper loaded: form_helper
INFO - 2017-08-02 16:57:05 --> Helper loaded: security_helper
INFO - 2017-08-02 16:57:05 --> Helper loaded: path_helper
INFO - 2017-08-02 16:57:05 --> Helper loaded: common_helper
INFO - 2017-08-02 16:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 16:57:05 --> Helper loaded: check_session_helper
INFO - 2017-08-02 16:57:05 --> Database Driver Class Initialized
DEBUG - 2017-08-02 16:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 16:57:05 --> Email Class Initialized
INFO - 2017-08-02 16:57:05 --> Form Validation Class Initialized
INFO - 2017-08-02 16:57:05 --> Model Class Initialized
INFO - 2017-08-02 16:57:05 --> Model Class Initialized
INFO - 2017-08-02 16:57:05 --> Model Class Initialized
INFO - 2017-08-02 16:57:05 --> Model Class Initialized
INFO - 2017-08-02 16:57:05 --> Controller Class Initialized
INFO - 2017-08-02 16:57:05 --> Model Class Initialized
INFO - 2017-08-02 16:57:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 16:57:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 16:57:05 --> Final output sent to browser
DEBUG - 2017-08-02 16:57:05 --> Total execution time: 0.0335
DEBUG - 2017-08-02 16:57:05 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 16:57:05 --> Database Forge Class Initialized
INFO - 2017-08-02 16:57:05 --> User Agent Class Initialized
DEBUG - 2017-08-02 16:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:00:49 --> Config Class Initialized
INFO - 2017-08-02 17:00:49 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:00:49 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:00:49 --> Utf8 Class Initialized
INFO - 2017-08-02 17:00:49 --> URI Class Initialized
INFO - 2017-08-02 17:00:49 --> Router Class Initialized
INFO - 2017-08-02 17:00:49 --> Output Class Initialized
INFO - 2017-08-02 17:00:49 --> Security Class Initialized
DEBUG - 2017-08-02 17:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:00:49 --> Input Class Initialized
INFO - 2017-08-02 17:00:49 --> Language Class Initialized
INFO - 2017-08-02 17:00:49 --> Loader Class Initialized
INFO - 2017-08-02 17:00:49 --> Helper loaded: url_helper
INFO - 2017-08-02 17:00:49 --> Helper loaded: form_helper
INFO - 2017-08-02 17:00:49 --> Helper loaded: security_helper
INFO - 2017-08-02 17:00:49 --> Helper loaded: path_helper
INFO - 2017-08-02 17:00:49 --> Helper loaded: common_helper
INFO - 2017-08-02 17:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:00:49 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:00:49 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:00:49 --> Email Class Initialized
INFO - 2017-08-02 17:00:49 --> Form Validation Class Initialized
INFO - 2017-08-02 17:00:49 --> Model Class Initialized
INFO - 2017-08-02 17:00:49 --> Model Class Initialized
INFO - 2017-08-02 17:00:49 --> Model Class Initialized
INFO - 2017-08-02 17:00:49 --> Model Class Initialized
INFO - 2017-08-02 17:00:49 --> Controller Class Initialized
INFO - 2017-08-02 17:00:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:00:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 17:00:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:00:49 --> Final output sent to browser
DEBUG - 2017-08-02 17:00:49 --> Total execution time: 0.0288
DEBUG - 2017-08-02 17:00:49 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:00:49 --> Database Forge Class Initialized
INFO - 2017-08-02 17:00:49 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:00:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:00:58 --> Config Class Initialized
INFO - 2017-08-02 17:00:58 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:00:58 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:00:58 --> Utf8 Class Initialized
INFO - 2017-08-02 17:00:58 --> URI Class Initialized
INFO - 2017-08-02 17:00:58 --> Router Class Initialized
INFO - 2017-08-02 17:00:58 --> Output Class Initialized
INFO - 2017-08-02 17:00:58 --> Security Class Initialized
DEBUG - 2017-08-02 17:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:00:58 --> Input Class Initialized
INFO - 2017-08-02 17:00:58 --> Language Class Initialized
INFO - 2017-08-02 17:00:58 --> Loader Class Initialized
INFO - 2017-08-02 17:00:58 --> Helper loaded: url_helper
INFO - 2017-08-02 17:00:58 --> Helper loaded: form_helper
INFO - 2017-08-02 17:00:58 --> Helper loaded: security_helper
INFO - 2017-08-02 17:00:58 --> Helper loaded: path_helper
INFO - 2017-08-02 17:00:58 --> Helper loaded: common_helper
INFO - 2017-08-02 17:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:00:58 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:00:58 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:00:58 --> Email Class Initialized
INFO - 2017-08-02 17:00:58 --> Form Validation Class Initialized
INFO - 2017-08-02 17:00:58 --> Model Class Initialized
INFO - 2017-08-02 17:00:58 --> Model Class Initialized
INFO - 2017-08-02 17:00:58 --> Model Class Initialized
INFO - 2017-08-02 17:00:58 --> Model Class Initialized
INFO - 2017-08-02 17:00:58 --> Controller Class Initialized
DEBUG - 2017-08-02 17:00:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:00:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:00:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-08-02 17:00:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:00:58 --> Final output sent to browser
DEBUG - 2017-08-02 17:00:58 --> Total execution time: 0.0320
DEBUG - 2017-08-02 17:00:58 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:00:58 --> Database Forge Class Initialized
INFO - 2017-08-02 17:00:58 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:00:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:03 --> Config Class Initialized
INFO - 2017-08-02 17:01:03 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:03 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:03 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:03 --> URI Class Initialized
INFO - 2017-08-02 17:01:03 --> Router Class Initialized
INFO - 2017-08-02 17:01:03 --> Output Class Initialized
INFO - 2017-08-02 17:01:03 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:03 --> Input Class Initialized
INFO - 2017-08-02 17:01:03 --> Language Class Initialized
INFO - 2017-08-02 17:01:03 --> Loader Class Initialized
INFO - 2017-08-02 17:01:03 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:03 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:03 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:03 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:03 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:03 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:03 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:03 --> Email Class Initialized
INFO - 2017-08-02 17:01:03 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:03 --> Model Class Initialized
INFO - 2017-08-02 17:01:03 --> Model Class Initialized
INFO - 2017-08-02 17:01:03 --> Model Class Initialized
INFO - 2017-08-02 17:01:03 --> Model Class Initialized
INFO - 2017-08-02 17:01:03 --> Controller Class Initialized
INFO - 2017-08-02 17:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 17:01:03 --> Pagination Class Initialized
INFO - 2017-08-02 17:01:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-08-02 17:01:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:03 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:03 --> Total execution time: 0.0310
DEBUG - 2017-08-02 17:01:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:03 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:03 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:06 --> Config Class Initialized
INFO - 2017-08-02 17:01:06 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:06 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:06 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:06 --> URI Class Initialized
INFO - 2017-08-02 17:01:06 --> Router Class Initialized
INFO - 2017-08-02 17:01:06 --> Output Class Initialized
INFO - 2017-08-02 17:01:06 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:06 --> Input Class Initialized
INFO - 2017-08-02 17:01:06 --> Language Class Initialized
INFO - 2017-08-02 17:01:06 --> Loader Class Initialized
INFO - 2017-08-02 17:01:06 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:06 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:06 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:06 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:06 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:06 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:06 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:06 --> Email Class Initialized
INFO - 2017-08-02 17:01:06 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:06 --> Model Class Initialized
INFO - 2017-08-02 17:01:06 --> Model Class Initialized
INFO - 2017-08-02 17:01:06 --> Model Class Initialized
INFO - 2017-08-02 17:01:06 --> Model Class Initialized
INFO - 2017-08-02 17:01:06 --> Controller Class Initialized
INFO - 2017-08-02 17:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 17:01:06 --> Pagination Class Initialized
INFO - 2017-08-02 17:01:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-08-02 17:01:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:06 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:06 --> Total execution time: 0.0283
DEBUG - 2017-08-02 17:01:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:06 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:06 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:09 --> Config Class Initialized
INFO - 2017-08-02 17:01:09 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:09 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:09 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:09 --> URI Class Initialized
INFO - 2017-08-02 17:01:09 --> Router Class Initialized
INFO - 2017-08-02 17:01:09 --> Output Class Initialized
INFO - 2017-08-02 17:01:09 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:09 --> Input Class Initialized
INFO - 2017-08-02 17:01:09 --> Language Class Initialized
INFO - 2017-08-02 17:01:09 --> Loader Class Initialized
INFO - 2017-08-02 17:01:09 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:09 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:09 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:09 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:09 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:09 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:09 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:09 --> Email Class Initialized
INFO - 2017-08-02 17:01:09 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:09 --> Model Class Initialized
INFO - 2017-08-02 17:01:09 --> Model Class Initialized
INFO - 2017-08-02 17:01:09 --> Model Class Initialized
INFO - 2017-08-02 17:01:09 --> Model Class Initialized
INFO - 2017-08-02 17:01:09 --> Controller Class Initialized
INFO - 2017-08-02 17:01:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-08-02 17:01:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:09 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:09 --> Total execution time: 0.0325
DEBUG - 2017-08-02 17:01:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:09 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:09 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:12 --> Config Class Initialized
INFO - 2017-08-02 17:01:12 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:12 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:12 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:12 --> URI Class Initialized
INFO - 2017-08-02 17:01:12 --> Router Class Initialized
INFO - 2017-08-02 17:01:12 --> Output Class Initialized
INFO - 2017-08-02 17:01:12 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:12 --> Input Class Initialized
INFO - 2017-08-02 17:01:12 --> Language Class Initialized
INFO - 2017-08-02 17:01:12 --> Loader Class Initialized
INFO - 2017-08-02 17:01:12 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:12 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:12 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:12 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:12 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:12 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:12 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:12 --> Email Class Initialized
INFO - 2017-08-02 17:01:12 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:12 --> Model Class Initialized
INFO - 2017-08-02 17:01:12 --> Model Class Initialized
INFO - 2017-08-02 17:01:12 --> Model Class Initialized
INFO - 2017-08-02 17:01:12 --> Model Class Initialized
INFO - 2017-08-02 17:01:12 --> Controller Class Initialized
INFO - 2017-08-02 17:01:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/usertrackingbackup.php
INFO - 2017-08-02 17:01:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:12 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:12 --> Total execution time: 0.0952
DEBUG - 2017-08-02 17:01:12 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:12 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:12 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:14 --> Config Class Initialized
INFO - 2017-08-02 17:01:14 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:14 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:14 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:14 --> URI Class Initialized
INFO - 2017-08-02 17:01:14 --> Router Class Initialized
INFO - 2017-08-02 17:01:14 --> Output Class Initialized
INFO - 2017-08-02 17:01:14 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:14 --> Input Class Initialized
INFO - 2017-08-02 17:01:14 --> Language Class Initialized
INFO - 2017-08-02 17:01:14 --> Loader Class Initialized
INFO - 2017-08-02 17:01:14 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:14 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:14 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:14 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:14 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:14 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:14 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:14 --> Email Class Initialized
INFO - 2017-08-02 17:01:14 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:14 --> Model Class Initialized
INFO - 2017-08-02 17:01:14 --> Model Class Initialized
INFO - 2017-08-02 17:01:14 --> Model Class Initialized
INFO - 2017-08-02 17:01:14 --> Model Class Initialized
INFO - 2017-08-02 17:01:14 --> Controller Class Initialized
INFO - 2017-08-02 17:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-08-02 17:01:14 --> Pagination Class Initialized
INFO - 2017-08-02 17:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/audit_log.php
INFO - 2017-08-02 17:01:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:14 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:14 --> Total execution time: 0.3927
DEBUG - 2017-08-02 17:01:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:14 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:14 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:16 --> Config Class Initialized
INFO - 2017-08-02 17:01:16 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:16 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:16 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:16 --> URI Class Initialized
INFO - 2017-08-02 17:01:16 --> Router Class Initialized
INFO - 2017-08-02 17:01:16 --> Output Class Initialized
INFO - 2017-08-02 17:01:16 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:16 --> Input Class Initialized
INFO - 2017-08-02 17:01:16 --> Language Class Initialized
INFO - 2017-08-02 17:01:16 --> Loader Class Initialized
INFO - 2017-08-02 17:01:16 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:16 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:16 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:16 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:16 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:16 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:16 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:16 --> Email Class Initialized
INFO - 2017-08-02 17:01:16 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:16 --> Model Class Initialized
INFO - 2017-08-02 17:01:16 --> Model Class Initialized
INFO - 2017-08-02 17:01:16 --> Model Class Initialized
INFO - 2017-08-02 17:01:16 --> Model Class Initialized
INFO - 2017-08-02 17:01:16 --> Controller Class Initialized
INFO - 2017-08-02 17:01:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/notification_form.php
INFO - 2017-08-02 17:01:16 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:16 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:16 --> Total execution time: 0.0415
DEBUG - 2017-08-02 17:01:16 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:16 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:16 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:20 --> Config Class Initialized
INFO - 2017-08-02 17:01:20 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:20 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:20 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:20 --> URI Class Initialized
INFO - 2017-08-02 17:01:20 --> Router Class Initialized
INFO - 2017-08-02 17:01:20 --> Output Class Initialized
INFO - 2017-08-02 17:01:20 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:20 --> Input Class Initialized
INFO - 2017-08-02 17:01:20 --> Language Class Initialized
INFO - 2017-08-02 17:01:20 --> Loader Class Initialized
INFO - 2017-08-02 17:01:20 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:20 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:20 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:20 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:20 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:20 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:20 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:20 --> Email Class Initialized
INFO - 2017-08-02 17:01:20 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:20 --> Model Class Initialized
INFO - 2017-08-02 17:01:20 --> Model Class Initialized
INFO - 2017-08-02 17:01:20 --> Model Class Initialized
INFO - 2017-08-02 17:01:20 --> Model Class Initialized
INFO - 2017-08-02 17:01:20 --> Controller Class Initialized
INFO - 2017-08-02 17:01:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/completereport.php
INFO - 2017-08-02 17:01:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:20 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:20 --> Total execution time: 0.0392
DEBUG - 2017-08-02 17:01:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:20 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:20 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:24 --> Config Class Initialized
INFO - 2017-08-02 17:01:24 --> Hooks Class Initialized
DEBUG - 2017-08-02 17:01:24 --> UTF-8 Support Enabled
INFO - 2017-08-02 17:01:24 --> Utf8 Class Initialized
INFO - 2017-08-02 17:01:24 --> URI Class Initialized
INFO - 2017-08-02 17:01:24 --> Router Class Initialized
INFO - 2017-08-02 17:01:24 --> Output Class Initialized
INFO - 2017-08-02 17:01:24 --> Security Class Initialized
DEBUG - 2017-08-02 17:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 17:01:24 --> Input Class Initialized
INFO - 2017-08-02 17:01:24 --> Language Class Initialized
INFO - 2017-08-02 17:01:24 --> Loader Class Initialized
INFO - 2017-08-02 17:01:24 --> Helper loaded: url_helper
INFO - 2017-08-02 17:01:24 --> Helper loaded: form_helper
INFO - 2017-08-02 17:01:24 --> Helper loaded: security_helper
INFO - 2017-08-02 17:01:24 --> Helper loaded: path_helper
INFO - 2017-08-02 17:01:24 --> Helper loaded: common_helper
INFO - 2017-08-02 17:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 17:01:24 --> Helper loaded: check_session_helper
INFO - 2017-08-02 17:01:24 --> Database Driver Class Initialized
DEBUG - 2017-08-02 17:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 17:01:24 --> Email Class Initialized
INFO - 2017-08-02 17:01:24 --> Form Validation Class Initialized
INFO - 2017-08-02 17:01:24 --> Model Class Initialized
INFO - 2017-08-02 17:01:24 --> Model Class Initialized
INFO - 2017-08-02 17:01:24 --> Model Class Initialized
INFO - 2017-08-02 17:01:24 --> Model Class Initialized
INFO - 2017-08-02 17:01:24 --> Controller Class Initialized
INFO - 2017-08-02 17:01:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-08-02 17:01:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/report.php
INFO - 2017-08-02 17:01:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-08-02 17:01:24 --> Final output sent to browser
DEBUG - 2017-08-02 17:01:24 --> Total execution time: 0.3187
DEBUG - 2017-08-02 17:01:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 17:01:24 --> Database Forge Class Initialized
INFO - 2017-08-02 17:01:24 --> User Agent Class Initialized
DEBUG - 2017-08-02 17:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 20:06:20 --> Config Class Initialized
INFO - 2017-08-02 20:06:20 --> Hooks Class Initialized
DEBUG - 2017-08-02 20:06:20 --> UTF-8 Support Enabled
INFO - 2017-08-02 20:06:20 --> Utf8 Class Initialized
INFO - 2017-08-02 20:06:20 --> URI Class Initialized
INFO - 2017-08-02 20:06:20 --> Router Class Initialized
INFO - 2017-08-02 20:06:20 --> Output Class Initialized
INFO - 2017-08-02 20:06:20 --> Security Class Initialized
DEBUG - 2017-08-02 20:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-02 20:06:20 --> Input Class Initialized
INFO - 2017-08-02 20:06:20 --> Language Class Initialized
INFO - 2017-08-02 20:06:20 --> Loader Class Initialized
INFO - 2017-08-02 20:06:20 --> Helper loaded: url_helper
INFO - 2017-08-02 20:06:20 --> Helper loaded: form_helper
INFO - 2017-08-02 20:06:21 --> Helper loaded: security_helper
INFO - 2017-08-02 20:06:21 --> Helper loaded: path_helper
INFO - 2017-08-02 20:06:21 --> Helper loaded: common_helper
INFO - 2017-08-02 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-02 20:06:21 --> Helper loaded: check_session_helper
INFO - 2017-08-02 20:06:21 --> Database Driver Class Initialized
DEBUG - 2017-08-02 20:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-02 20:06:21 --> Email Class Initialized
INFO - 2017-08-02 20:06:21 --> Form Validation Class Initialized
INFO - 2017-08-02 20:06:21 --> Model Class Initialized
INFO - 2017-08-02 20:06:21 --> Model Class Initialized
INFO - 2017-08-02 20:06:21 --> Model Class Initialized
INFO - 2017-08-02 20:06:21 --> Model Class Initialized
INFO - 2017-08-02 20:06:21 --> Controller Class Initialized
INFO - 2017-08-02 20:06:21 --> Model Class Initialized
INFO - 2017-08-02 20:06:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-02 20:06:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-02 20:06:21 --> Final output sent to browser
DEBUG - 2017-08-02 20:06:21 --> Total execution time: 1.7718
DEBUG - 2017-08-02 20:06:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-02 20:06:22 --> Database Forge Class Initialized
INFO - 2017-08-02 20:06:22 --> User Agent Class Initialized
DEBUG - 2017-08-02 20:06:22 --> Session class already loaded. Second attempt ignored.
