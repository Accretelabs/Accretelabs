<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-08 02:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-08 07:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-08 07:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-08 08:27:43 --> 404 Page Not Found: Irj/portal
ERROR - 2016-08-08 13:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-08 13:29:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-08 13:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-08 13:29:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-08 13:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-08 13:29:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-08 13:41:15 --> 404 Page Not Found: Assets/css
ERROR - 2016-08-08 13:59:31 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2016-08-08 19:50:01 --> 404 Page Not Found: Faviconico/index
