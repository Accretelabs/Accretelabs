<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-01 14:28:22 --> Config Class Initialized
INFO - 2017-08-01 14:28:22 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:28:22 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:28:22 --> Utf8 Class Initialized
INFO - 2017-08-01 14:28:22 --> URI Class Initialized
DEBUG - 2017-08-01 14:28:24 --> No URI present. Default controller set.
INFO - 2017-08-01 14:28:24 --> Router Class Initialized
INFO - 2017-08-01 14:28:24 --> Output Class Initialized
INFO - 2017-08-01 14:28:24 --> Security Class Initialized
DEBUG - 2017-08-01 14:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:28:24 --> Input Class Initialized
INFO - 2017-08-01 14:28:24 --> Language Class Initialized
INFO - 2017-08-01 14:28:24 --> Loader Class Initialized
INFO - 2017-08-01 14:28:24 --> Helper loaded: url_helper
INFO - 2017-08-01 14:28:24 --> Helper loaded: form_helper
INFO - 2017-08-01 14:28:24 --> Helper loaded: security_helper
INFO - 2017-08-01 14:28:24 --> Helper loaded: path_helper
INFO - 2017-08-01 14:28:24 --> Helper loaded: common_helper
INFO - 2017-08-01 14:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-01 14:28:25 --> Helper loaded: check_session_helper
INFO - 2017-08-01 14:28:25 --> Database Driver Class Initialized
DEBUG - 2017-08-01 14:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:28:25 --> Email Class Initialized
INFO - 2017-08-01 14:28:25 --> Form Validation Class Initialized
INFO - 2017-08-01 14:28:25 --> Model Class Initialized
INFO - 2017-08-01 14:28:25 --> Model Class Initialized
INFO - 2017-08-01 14:28:25 --> Model Class Initialized
INFO - 2017-08-01 14:28:25 --> Model Class Initialized
INFO - 2017-08-01 14:28:25 --> Controller Class Initialized
DEBUG - 2017-08-01 14:28:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:28:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-08-01 14:28:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-08-01 14:28:25 --> Final output sent to browser
DEBUG - 2017-08-01 14:28:25 --> Total execution time: 2.7235
DEBUG - 2017-08-01 14:28:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-01 14:28:25 --> Database Forge Class Initialized
INFO - 2017-08-01 14:28:25 --> User Agent Class Initialized
DEBUG - 2017-08-01 14:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:34:37 --> Config Class Initialized
INFO - 2017-08-01 14:34:37 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:34:37 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:34:37 --> Utf8 Class Initialized
INFO - 2017-08-01 14:34:37 --> URI Class Initialized
INFO - 2017-08-01 14:34:37 --> Router Class Initialized
INFO - 2017-08-01 14:34:37 --> Output Class Initialized
INFO - 2017-08-01 14:34:37 --> Security Class Initialized
DEBUG - 2017-08-01 14:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:34:37 --> Input Class Initialized
INFO - 2017-08-01 14:34:37 --> Language Class Initialized
INFO - 2017-08-01 14:34:37 --> Loader Class Initialized
INFO - 2017-08-01 14:34:37 --> Helper loaded: url_helper
INFO - 2017-08-01 14:34:37 --> Helper loaded: form_helper
INFO - 2017-08-01 14:34:37 --> Helper loaded: security_helper
INFO - 2017-08-01 14:34:37 --> Helper loaded: path_helper
INFO - 2017-08-01 14:34:37 --> Helper loaded: common_helper
INFO - 2017-08-01 14:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-01 14:34:37 --> Helper loaded: check_session_helper
INFO - 2017-08-01 14:34:37 --> Database Driver Class Initialized
DEBUG - 2017-08-01 14:34:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:34:37 --> Email Class Initialized
INFO - 2017-08-01 14:34:37 --> Form Validation Class Initialized
INFO - 2017-08-01 14:34:37 --> Model Class Initialized
INFO - 2017-08-01 14:34:37 --> Model Class Initialized
INFO - 2017-08-01 14:34:37 --> Model Class Initialized
INFO - 2017-08-01 14:34:37 --> Model Class Initialized
INFO - 2017-08-01 14:34:37 --> Controller Class Initialized
INFO - 2017-08-01 14:34:37 --> Model Class Initialized
INFO - 2017-08-01 14:34:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-01 14:34:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-01 14:34:38 --> Final output sent to browser
DEBUG - 2017-08-01 14:34:38 --> Total execution time: 0.1331
DEBUG - 2017-08-01 14:34:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-01 14:34:38 --> Database Forge Class Initialized
INFO - 2017-08-01 14:34:38 --> User Agent Class Initialized
DEBUG - 2017-08-01 14:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:34:39 --> Config Class Initialized
INFO - 2017-08-01 14:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:34:39 --> Utf8 Class Initialized
INFO - 2017-08-01 14:34:39 --> URI Class Initialized
INFO - 2017-08-01 14:34:39 --> Router Class Initialized
INFO - 2017-08-01 14:34:39 --> Output Class Initialized
INFO - 2017-08-01 14:34:39 --> Security Class Initialized
DEBUG - 2017-08-01 14:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:34:39 --> Input Class Initialized
INFO - 2017-08-01 14:34:39 --> Language Class Initialized
ERROR - 2017-08-01 14:34:39 --> 404 Page Not Found: Page/assets
INFO - 2017-08-01 14:34:39 --> Config Class Initialized
INFO - 2017-08-01 14:34:39 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:34:39 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:34:39 --> Utf8 Class Initialized
INFO - 2017-08-01 14:34:39 --> URI Class Initialized
INFO - 2017-08-01 14:34:39 --> Router Class Initialized
INFO - 2017-08-01 14:34:39 --> Output Class Initialized
INFO - 2017-08-01 14:34:39 --> Security Class Initialized
DEBUG - 2017-08-01 14:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:34:39 --> Input Class Initialized
INFO - 2017-08-01 14:34:39 --> Language Class Initialized
ERROR - 2017-08-01 14:34:39 --> 404 Page Not Found: Faviconico/index
INFO - 2017-08-01 14:35:29 --> Config Class Initialized
INFO - 2017-08-01 14:35:29 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:35:29 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:35:29 --> Utf8 Class Initialized
INFO - 2017-08-01 14:35:29 --> URI Class Initialized
INFO - 2017-08-01 14:35:29 --> Router Class Initialized
INFO - 2017-08-01 14:35:29 --> Output Class Initialized
INFO - 2017-08-01 14:35:29 --> Security Class Initialized
DEBUG - 2017-08-01 14:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:35:29 --> Input Class Initialized
INFO - 2017-08-01 14:35:29 --> Language Class Initialized
INFO - 2017-08-01 14:35:29 --> Loader Class Initialized
INFO - 2017-08-01 14:35:29 --> Helper loaded: url_helper
INFO - 2017-08-01 14:35:29 --> Helper loaded: form_helper
INFO - 2017-08-01 14:35:29 --> Helper loaded: security_helper
INFO - 2017-08-01 14:35:29 --> Helper loaded: path_helper
INFO - 2017-08-01 14:35:29 --> Helper loaded: common_helper
INFO - 2017-08-01 14:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-01 14:35:29 --> Helper loaded: check_session_helper
INFO - 2017-08-01 14:35:29 --> Database Driver Class Initialized
DEBUG - 2017-08-01 14:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:35:29 --> Email Class Initialized
INFO - 2017-08-01 14:35:29 --> Form Validation Class Initialized
INFO - 2017-08-01 14:35:29 --> Model Class Initialized
INFO - 2017-08-01 14:35:29 --> Model Class Initialized
INFO - 2017-08-01 14:35:29 --> Model Class Initialized
INFO - 2017-08-01 14:35:29 --> Model Class Initialized
INFO - 2017-08-01 14:35:29 --> Controller Class Initialized
INFO - 2017-08-01 14:35:29 --> Model Class Initialized
INFO - 2017-08-01 14:35:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-08-01 14:35:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-08-01 14:35:29 --> Final output sent to browser
DEBUG - 2017-08-01 14:35:29 --> Total execution time: 0.0302
DEBUG - 2017-08-01 14:35:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-08-01 14:35:29 --> Database Forge Class Initialized
INFO - 2017-08-01 14:35:29 --> User Agent Class Initialized
DEBUG - 2017-08-01 14:35:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-01 14:35:30 --> Config Class Initialized
INFO - 2017-08-01 14:35:30 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:35:30 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:35:30 --> Utf8 Class Initialized
INFO - 2017-08-01 14:35:30 --> URI Class Initialized
INFO - 2017-08-01 14:35:30 --> Router Class Initialized
INFO - 2017-08-01 14:35:30 --> Output Class Initialized
INFO - 2017-08-01 14:35:30 --> Security Class Initialized
DEBUG - 2017-08-01 14:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:35:30 --> Input Class Initialized
INFO - 2017-08-01 14:35:30 --> Language Class Initialized
ERROR - 2017-08-01 14:35:30 --> 404 Page Not Found: Page/assets
INFO - 2017-08-01 14:35:30 --> Config Class Initialized
INFO - 2017-08-01 14:35:30 --> Hooks Class Initialized
DEBUG - 2017-08-01 14:35:30 --> UTF-8 Support Enabled
INFO - 2017-08-01 14:35:30 --> Utf8 Class Initialized
INFO - 2017-08-01 14:35:30 --> URI Class Initialized
INFO - 2017-08-01 14:35:30 --> Router Class Initialized
INFO - 2017-08-01 14:35:30 --> Output Class Initialized
INFO - 2017-08-01 14:35:30 --> Security Class Initialized
DEBUG - 2017-08-01 14:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-01 14:35:30 --> Input Class Initialized
INFO - 2017-08-01 14:35:30 --> Language Class Initialized
ERROR - 2017-08-01 14:35:30 --> 404 Page Not Found: Faviconico/index
