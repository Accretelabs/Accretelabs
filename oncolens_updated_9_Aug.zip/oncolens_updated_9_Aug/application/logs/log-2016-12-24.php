<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-24 01:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 01:26:54 --> 404 Page Not Found: Tydrqpjrdmaslyhtml/index
ERROR - 2016-12-24 01:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 02:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 04:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 06:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 07:48:59 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '9f8de2095b1e7e29d3d6df4df542e0d19a66b3fb', '/', 1482594539, '216.218.206.66', NULL, '')
ERROR - 2016-12-24 13:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 16:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-24 20:23:56 --> 404 Page Not Found: Sap/hana
