<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-22 09:28:46 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2016-12-22 09:28:47 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2016-12-22 09:28:47 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
ERROR - 2016-12-22 23:34:45 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '4ef15157cd35c12325ade4ae29b7e172ea8fcc0c', '/', 1482478485, '5.189.190.67', NULL, '')
