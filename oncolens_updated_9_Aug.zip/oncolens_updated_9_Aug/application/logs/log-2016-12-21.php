<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-21 01:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 02:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 02:40:46 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-12-21 02:55:45 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-12-21 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 06:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 07:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 07:52:25 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'c410c1eac3e0120f47f485fa6130437b85b6bf9b', '/', 1482335545, '184.105.139.70', NULL, '')
ERROR - 2016-12-21 08:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 11:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 16:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 20:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-21 21:42:46 --> 404 Page Not Found: Services/MyICOffice
ERROR - 2016-12-21 22:25:41 --> 404 Page Not Found: Robotstxt/index
