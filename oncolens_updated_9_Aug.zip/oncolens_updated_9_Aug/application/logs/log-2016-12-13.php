<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-13 02:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 04:54:42 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-13 04:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-13 04:57:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-13 04:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-13 05:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 07:46:10 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-13 07:46:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 07:46:41 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-13 08:51:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 08:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-13 08:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 08:52:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 08:52:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 08:53:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 08:54:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:00:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:00:50 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:10:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:10:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:21:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 09:21:51 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-13 10:31:38 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-13 10:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-13 10:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 10:51:30 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-12-13 11:55:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 11:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-13 11:55:49 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 11:58:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:04:19 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:04:19 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:04:19 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:04:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:04:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:08:38 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:08:38 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:08:38 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:08:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:08:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:13:05 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:13:05 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:13:05 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:13:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:17:12 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-13 12:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 12:18:09 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-13 12:18:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-13 12:24:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-13 12:27:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:27:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 12:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 12:31:58 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:31:58 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:31:58 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:33:39 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:33:39 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:33:39 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:36:36 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:36:36 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:36:36 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-13 12:36:36 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-13 12:39:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-13 12:39:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-13 13:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 15:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 17:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-13 21:34:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-13 23:27:31 --> 404 Page Not Found: Robotstxt/index
