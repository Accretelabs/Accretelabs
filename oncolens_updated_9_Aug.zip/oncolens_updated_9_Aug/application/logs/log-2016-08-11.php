<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-11 00:38:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 00:38:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 00:56:51 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'e0526fe276147ecd81392d0f61e7a7f3244ebaeb', '/', 1470902211, '74.82.47.3', NULL, '')
ERROR - 2016-08-11 01:55:19 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-11 06:07:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 06:21:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 06:21:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:19:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:19:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:33:59 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-11 19:38:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:38:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:39:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:39:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:54:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY b.case_id 
                ORDER BY h.case_updated_date DESC' at line 63 - Invalid query: SELECT 
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  h.case_entered_by,
                  AES_DECRYPT(h.name,'Oncolens') as pname,
                  AES_DECRYPT(h.dob,'Oncolens') as dob,
                       AES_DECRYPT(h.name,'Oncolens') as name,
                        AES_DECRYPT(h.case_description, 'Oncolens') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT 
                    CONCAT(fname, ' ', lname) 
                  FROM
                    users 
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network` 
                FROM
                  case_request_images AS a 
                  INNER JOIN case_assignments AS b 
                    ON a.case_id = b.case_id 
                  INNER JOIN case_history AS h 
                    ON h.id = b.case_id 
                  INNER JOIN users AS d 
                    ON d.id != h.case_entered_by 
                  LEFT JOIN `hospital_network` h1 
                    ON h1.`id` = h.assigned_hospital 
                WHERE a.doctor_id = '32' 
                  AND h.case_status = '1' 
                  AND h.is_deleted = '0' 
                  AND a.is_forwarded = '0' 
                  AND a.case_id NOT IN 
                  (SELECT 
                    case_id 
                  FROM
                    case_save_images 
                  WHERE doctor_id = '32 '
                  UNION
                  SELECT 
                    case_id 
                  FROM
                    case_save_images 
                  WHERE `speciality_id` = 6 
                    AND case_id NOT IN 
                    (SELECT 
                      cs.`case_id` 
                    FROM
                      `case_save_images` cs 
                      INNER JOIN case_history ch 
                        ON cs.`case_id` = ch.`id` 
                        AND cs.`doctor_id` = ch.`case_entered_by` 
                        AND cs.`doctor_id` != 32 
                    GROUP BY case_id)) 
                    and h.id=
                GROUP BY b.case_id 
                ORDER BY h.case_updated_date DESC 
                 
ERROR - 2016-08-11 19:54:14 --> Severity: Error --> Call to a member function row() on boolean /var/www/html/application/models/Mcase.php 3594
ERROR - 2016-08-11 19:54:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-11 19:58:58 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-11 19:58:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
ERROR - 2016-08-11 20:05:30 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '93fa1708aab1a1d6bc45ecca85667b302c1146dd', '/', 1470971130, '184.105.247.194', NULL, '')
ERROR - 2016-08-11 20:06:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Minperson.php 100
ERROR - 2016-08-11 20:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Minperson.php 103
