<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-29 04:38:53 --> Config Class Initialized
INFO - 2017-07-29 04:38:53 --> Hooks Class Initialized
DEBUG - 2017-07-29 04:38:54 --> UTF-8 Support Enabled
INFO - 2017-07-29 04:38:54 --> Utf8 Class Initialized
INFO - 2017-07-29 04:38:54 --> URI Class Initialized
DEBUG - 2017-07-29 04:38:54 --> No URI present. Default controller set.
INFO - 2017-07-29 04:38:54 --> Router Class Initialized
INFO - 2017-07-29 04:38:54 --> Output Class Initialized
INFO - 2017-07-29 04:38:54 --> Security Class Initialized
DEBUG - 2017-07-29 04:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-29 04:38:55 --> Input Class Initialized
INFO - 2017-07-29 04:38:55 --> Language Class Initialized
INFO - 2017-07-29 04:38:55 --> Loader Class Initialized
INFO - 2017-07-29 04:38:57 --> Helper loaded: url_helper
INFO - 2017-07-29 04:38:57 --> Helper loaded: form_helper
INFO - 2017-07-29 04:38:57 --> Helper loaded: security_helper
INFO - 2017-07-29 04:38:57 --> Helper loaded: path_helper
INFO - 2017-07-29 04:38:57 --> Helper loaded: common_helper
INFO - 2017-07-29 04:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-29 04:38:58 --> Helper loaded: check_session_helper
INFO - 2017-07-29 04:38:59 --> Database Driver Class Initialized
DEBUG - 2017-07-29 04:38:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-29 04:38:59 --> Email Class Initialized
INFO - 2017-07-29 04:38:59 --> Form Validation Class Initialized
INFO - 2017-07-29 04:38:59 --> Model Class Initialized
INFO - 2017-07-29 04:38:59 --> Model Class Initialized
INFO - 2017-07-29 04:38:59 --> Model Class Initialized
INFO - 2017-07-29 04:38:59 --> Model Class Initialized
INFO - 2017-07-29 04:38:59 --> Controller Class Initialized
DEBUG - 2017-07-29 04:38:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-29 04:39:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-29 04:39:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-29 04:39:00 --> Final output sent to browser
DEBUG - 2017-07-29 04:39:00 --> Total execution time: 8.7795
DEBUG - 2017-07-29 04:39:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-29 04:39:01 --> Database Forge Class Initialized
INFO - 2017-07-29 04:39:02 --> User Agent Class Initialized
DEBUG - 2017-07-29 04:39:02 --> Session class already loaded. Second attempt ignored.
