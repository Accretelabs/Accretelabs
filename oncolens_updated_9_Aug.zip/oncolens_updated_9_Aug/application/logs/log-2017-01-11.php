<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-11 00:32:56 --> 404 Page Not Found: Page/assets
ERROR - 2017-01-11 02:36:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-11 04:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-11 05:48:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-11 06:59:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-11 06:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-11 07:21:41 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-11 07:21:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-11 08:34:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-11 10:23:18 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '39e4c8a689636bacaa6923813fb7212a7216ab41', '/', 1484158998, '169.54.233.126', NULL, '')
ERROR - 2017-01-11 11:16:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-11 11:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-11 12:17:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2017-01-11 12:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2017-01-11 12:18:22 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-11 12:18:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-11 14:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-11 17:28:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-11 19:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-11 19:36:18 --> 404 Page Not Found: Robotstxt/index
