<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-26 06:46:01 --> Config Class Initialized
INFO - 2017-07-26 06:46:01 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:46:01 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:46:01 --> Utf8 Class Initialized
INFO - 2017-07-26 06:46:01 --> URI Class Initialized
DEBUG - 2017-07-26 06:46:01 --> No URI present. Default controller set.
INFO - 2017-07-26 06:46:01 --> Router Class Initialized
INFO - 2017-07-26 06:46:01 --> Output Class Initialized
INFO - 2017-07-26 06:46:02 --> Security Class Initialized
DEBUG - 2017-07-26 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:46:02 --> Input Class Initialized
INFO - 2017-07-26 06:46:02 --> Language Class Initialized
INFO - 2017-07-26 06:46:02 --> Loader Class Initialized
INFO - 2017-07-26 06:46:02 --> Helper loaded: url_helper
INFO - 2017-07-26 06:46:02 --> Helper loaded: form_helper
INFO - 2017-07-26 06:46:02 --> Helper loaded: security_helper
INFO - 2017-07-26 06:46:02 --> Helper loaded: path_helper
INFO - 2017-07-26 06:46:02 --> Helper loaded: common_helper
INFO - 2017-07-26 06:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:46:05 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:46:05 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:05 --> Email Class Initialized
INFO - 2017-07-26 06:46:06 --> Form Validation Class Initialized
INFO - 2017-07-26 06:46:06 --> Model Class Initialized
INFO - 2017-07-26 06:46:06 --> Model Class Initialized
INFO - 2017-07-26 06:46:06 --> Model Class Initialized
INFO - 2017-07-26 06:46:06 --> Model Class Initialized
INFO - 2017-07-26 06:46:06 --> Controller Class Initialized
DEBUG - 2017-07-26 06:46:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 06:46:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 06:46:06 --> Final output sent to browser
DEBUG - 2017-07-26 06:46:06 --> Total execution time: 4.8470
DEBUG - 2017-07-26 06:46:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:46:06 --> Database Forge Class Initialized
INFO - 2017-07-26 06:46:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:18 --> Config Class Initialized
INFO - 2017-07-26 06:46:18 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:46:18 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:46:18 --> Utf8 Class Initialized
INFO - 2017-07-26 06:46:18 --> URI Class Initialized
DEBUG - 2017-07-26 06:46:18 --> No URI present. Default controller set.
INFO - 2017-07-26 06:46:18 --> Router Class Initialized
INFO - 2017-07-26 06:46:18 --> Output Class Initialized
INFO - 2017-07-26 06:46:18 --> Security Class Initialized
DEBUG - 2017-07-26 06:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:46:18 --> Input Class Initialized
INFO - 2017-07-26 06:46:18 --> Language Class Initialized
INFO - 2017-07-26 06:46:18 --> Loader Class Initialized
INFO - 2017-07-26 06:46:18 --> Helper loaded: url_helper
INFO - 2017-07-26 06:46:18 --> Helper loaded: form_helper
INFO - 2017-07-26 06:46:18 --> Helper loaded: security_helper
INFO - 2017-07-26 06:46:18 --> Helper loaded: path_helper
INFO - 2017-07-26 06:46:18 --> Helper loaded: common_helper
INFO - 2017-07-26 06:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:46:18 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:46:18 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:18 --> Email Class Initialized
INFO - 2017-07-26 06:46:18 --> Form Validation Class Initialized
INFO - 2017-07-26 06:46:18 --> Model Class Initialized
INFO - 2017-07-26 06:46:18 --> Model Class Initialized
INFO - 2017-07-26 06:46:18 --> Model Class Initialized
INFO - 2017-07-26 06:46:18 --> Model Class Initialized
INFO - 2017-07-26 06:46:18 --> Controller Class Initialized
DEBUG - 2017-07-26 06:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 06:46:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 06:46:18 --> Final output sent to browser
DEBUG - 2017-07-26 06:46:18 --> Total execution time: 0.0315
DEBUG - 2017-07-26 06:46:18 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:46:18 --> Database Forge Class Initialized
INFO - 2017-07-26 06:46:18 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:46:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:33 --> Config Class Initialized
INFO - 2017-07-26 06:46:33 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:46:33 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:46:33 --> Utf8 Class Initialized
INFO - 2017-07-26 06:46:33 --> URI Class Initialized
INFO - 2017-07-26 06:46:33 --> Router Class Initialized
INFO - 2017-07-26 06:46:33 --> Output Class Initialized
INFO - 2017-07-26 06:46:33 --> Security Class Initialized
DEBUG - 2017-07-26 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:46:33 --> Input Class Initialized
INFO - 2017-07-26 06:46:33 --> Language Class Initialized
INFO - 2017-07-26 06:46:33 --> Loader Class Initialized
INFO - 2017-07-26 06:46:33 --> Helper loaded: url_helper
INFO - 2017-07-26 06:46:33 --> Helper loaded: form_helper
INFO - 2017-07-26 06:46:33 --> Helper loaded: security_helper
INFO - 2017-07-26 06:46:33 --> Helper loaded: path_helper
INFO - 2017-07-26 06:46:33 --> Helper loaded: common_helper
INFO - 2017-07-26 06:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:46:33 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:46:33 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:46:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:33 --> Email Class Initialized
INFO - 2017-07-26 06:46:33 --> Form Validation Class Initialized
INFO - 2017-07-26 06:46:33 --> Model Class Initialized
INFO - 2017-07-26 06:46:33 --> Model Class Initialized
INFO - 2017-07-26 06:46:33 --> Model Class Initialized
INFO - 2017-07-26 06:46:33 --> Model Class Initialized
INFO - 2017-07-26 06:46:33 --> Controller Class Initialized
INFO - 2017-07-26 06:46:34 --> Model Class Initialized
INFO - 2017-07-26 06:46:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 06:46:34 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 06:46:34 --> Final output sent to browser
DEBUG - 2017-07-26 06:46:34 --> Total execution time: 1.0090
DEBUG - 2017-07-26 06:46:34 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:46:34 --> Database Forge Class Initialized
INFO - 2017-07-26 06:46:34 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:46:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:46:35 --> Config Class Initialized
INFO - 2017-07-26 06:46:35 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:46:35 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:46:35 --> Utf8 Class Initialized
INFO - 2017-07-26 06:46:35 --> URI Class Initialized
INFO - 2017-07-26 06:46:35 --> Router Class Initialized
INFO - 2017-07-26 06:46:35 --> Output Class Initialized
INFO - 2017-07-26 06:46:35 --> Security Class Initialized
DEBUG - 2017-07-26 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:46:35 --> Input Class Initialized
INFO - 2017-07-26 06:46:35 --> Language Class Initialized
ERROR - 2017-07-26 06:46:35 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 06:46:38 --> Config Class Initialized
INFO - 2017-07-26 06:46:38 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:46:38 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:46:38 --> Utf8 Class Initialized
INFO - 2017-07-26 06:46:38 --> URI Class Initialized
INFO - 2017-07-26 06:46:38 --> Router Class Initialized
INFO - 2017-07-26 06:46:38 --> Output Class Initialized
INFO - 2017-07-26 06:46:38 --> Security Class Initialized
DEBUG - 2017-07-26 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:46:38 --> Input Class Initialized
INFO - 2017-07-26 06:46:38 --> Language Class Initialized
ERROR - 2017-07-26 06:46:38 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 06:56:17 --> Config Class Initialized
INFO - 2017-07-26 06:56:17 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:56:17 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:56:17 --> Utf8 Class Initialized
INFO - 2017-07-26 06:56:17 --> URI Class Initialized
DEBUG - 2017-07-26 06:56:17 --> No URI present. Default controller set.
INFO - 2017-07-26 06:56:17 --> Router Class Initialized
INFO - 2017-07-26 06:56:17 --> Output Class Initialized
INFO - 2017-07-26 06:56:17 --> Security Class Initialized
DEBUG - 2017-07-26 06:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:56:17 --> Input Class Initialized
INFO - 2017-07-26 06:56:17 --> Language Class Initialized
INFO - 2017-07-26 06:56:17 --> Loader Class Initialized
INFO - 2017-07-26 06:56:17 --> Helper loaded: url_helper
INFO - 2017-07-26 06:56:17 --> Helper loaded: form_helper
INFO - 2017-07-26 06:56:17 --> Helper loaded: security_helper
INFO - 2017-07-26 06:56:17 --> Helper loaded: path_helper
INFO - 2017-07-26 06:56:17 --> Helper loaded: common_helper
INFO - 2017-07-26 06:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:56:17 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:56:17 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:56:17 --> Email Class Initialized
INFO - 2017-07-26 06:56:17 --> Form Validation Class Initialized
INFO - 2017-07-26 06:56:17 --> Model Class Initialized
INFO - 2017-07-26 06:56:17 --> Model Class Initialized
INFO - 2017-07-26 06:56:17 --> Model Class Initialized
INFO - 2017-07-26 06:56:17 --> Model Class Initialized
INFO - 2017-07-26 06:56:17 --> Controller Class Initialized
DEBUG - 2017-07-26 06:56:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:56:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 06:56:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 06:56:17 --> Final output sent to browser
DEBUG - 2017-07-26 06:56:17 --> Total execution time: 0.0325
DEBUG - 2017-07-26 06:56:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:56:17 --> Database Forge Class Initialized
INFO - 2017-07-26 06:56:17 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:56:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:58:45 --> Config Class Initialized
INFO - 2017-07-26 06:58:45 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:58:45 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:58:45 --> Utf8 Class Initialized
INFO - 2017-07-26 06:58:45 --> URI Class Initialized
INFO - 2017-07-26 06:58:45 --> Router Class Initialized
INFO - 2017-07-26 06:58:45 --> Output Class Initialized
INFO - 2017-07-26 06:58:45 --> Security Class Initialized
DEBUG - 2017-07-26 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:58:45 --> Input Class Initialized
INFO - 2017-07-26 06:58:45 --> Language Class Initialized
INFO - 2017-07-26 06:58:45 --> Loader Class Initialized
INFO - 2017-07-26 06:58:45 --> Helper loaded: url_helper
INFO - 2017-07-26 06:58:45 --> Helper loaded: form_helper
INFO - 2017-07-26 06:58:45 --> Helper loaded: security_helper
INFO - 2017-07-26 06:58:45 --> Helper loaded: path_helper
INFO - 2017-07-26 06:58:45 --> Helper loaded: common_helper
INFO - 2017-07-26 06:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:58:45 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:58:45 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:58:45 --> Email Class Initialized
INFO - 2017-07-26 06:58:45 --> Form Validation Class Initialized
INFO - 2017-07-26 06:58:45 --> Model Class Initialized
INFO - 2017-07-26 06:58:45 --> Model Class Initialized
INFO - 2017-07-26 06:58:45 --> Model Class Initialized
INFO - 2017-07-26 06:58:45 --> Model Class Initialized
INFO - 2017-07-26 06:58:45 --> Controller Class Initialized
INFO - 2017-07-26 06:58:45 --> Model Class Initialized
INFO - 2017-07-26 06:58:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 06:58:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 06:58:45 --> Final output sent to browser
DEBUG - 2017-07-26 06:58:45 --> Total execution time: 0.0285
DEBUG - 2017-07-26 06:58:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:58:45 --> Database Forge Class Initialized
INFO - 2017-07-26 06:58:45 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:58:47 --> Config Class Initialized
INFO - 2017-07-26 06:58:47 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:58:47 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:58:47 --> Utf8 Class Initialized
INFO - 2017-07-26 06:58:47 --> URI Class Initialized
INFO - 2017-07-26 06:58:47 --> Router Class Initialized
INFO - 2017-07-26 06:58:47 --> Output Class Initialized
INFO - 2017-07-26 06:58:47 --> Security Class Initialized
DEBUG - 2017-07-26 06:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:58:47 --> Input Class Initialized
INFO - 2017-07-26 06:58:47 --> Language Class Initialized
ERROR - 2017-07-26 06:58:47 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 06:58:57 --> Config Class Initialized
INFO - 2017-07-26 06:58:57 --> Hooks Class Initialized
DEBUG - 2017-07-26 06:58:57 --> UTF-8 Support Enabled
INFO - 2017-07-26 06:58:57 --> Utf8 Class Initialized
INFO - 2017-07-26 06:58:57 --> URI Class Initialized
INFO - 2017-07-26 06:58:57 --> Router Class Initialized
INFO - 2017-07-26 06:58:57 --> Output Class Initialized
INFO - 2017-07-26 06:58:57 --> Security Class Initialized
DEBUG - 2017-07-26 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 06:58:57 --> Input Class Initialized
INFO - 2017-07-26 06:58:57 --> Language Class Initialized
INFO - 2017-07-26 06:58:57 --> Loader Class Initialized
INFO - 2017-07-26 06:58:57 --> Helper loaded: url_helper
INFO - 2017-07-26 06:58:57 --> Helper loaded: form_helper
INFO - 2017-07-26 06:58:57 --> Helper loaded: security_helper
INFO - 2017-07-26 06:58:57 --> Helper loaded: path_helper
INFO - 2017-07-26 06:58:57 --> Helper loaded: common_helper
INFO - 2017-07-26 06:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 06:58:57 --> Helper loaded: check_session_helper
INFO - 2017-07-26 06:58:57 --> Database Driver Class Initialized
DEBUG - 2017-07-26 06:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 06:58:57 --> Email Class Initialized
INFO - 2017-07-26 06:58:57 --> Form Validation Class Initialized
INFO - 2017-07-26 06:58:57 --> Model Class Initialized
INFO - 2017-07-26 06:58:57 --> Model Class Initialized
INFO - 2017-07-26 06:58:57 --> Model Class Initialized
INFO - 2017-07-26 06:58:57 --> Model Class Initialized
INFO - 2017-07-26 06:58:57 --> Controller Class Initialized
INFO - 2017-07-26 06:58:57 --> Model Class Initialized
INFO - 2017-07-26 06:58:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 06:58:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 06:58:57 --> Final output sent to browser
DEBUG - 2017-07-26 06:58:57 --> Total execution time: 0.0314
DEBUG - 2017-07-26 06:58:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 06:58:57 --> Database Forge Class Initialized
INFO - 2017-07-26 06:58:57 --> User Agent Class Initialized
DEBUG - 2017-07-26 06:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:11:59 --> Config Class Initialized
INFO - 2017-07-26 07:11:59 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:11:59 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:11:59 --> Utf8 Class Initialized
INFO - 2017-07-26 07:11:59 --> URI Class Initialized
INFO - 2017-07-26 07:11:59 --> Router Class Initialized
INFO - 2017-07-26 07:11:59 --> Output Class Initialized
INFO - 2017-07-26 07:11:59 --> Security Class Initialized
DEBUG - 2017-07-26 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:11:59 --> Input Class Initialized
INFO - 2017-07-26 07:11:59 --> Language Class Initialized
INFO - 2017-07-26 07:11:59 --> Loader Class Initialized
INFO - 2017-07-26 07:11:59 --> Helper loaded: url_helper
INFO - 2017-07-26 07:11:59 --> Helper loaded: form_helper
INFO - 2017-07-26 07:11:59 --> Helper loaded: security_helper
INFO - 2017-07-26 07:11:59 --> Helper loaded: path_helper
INFO - 2017-07-26 07:11:59 --> Helper loaded: common_helper
INFO - 2017-07-26 07:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:11:59 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:11:59 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:11:59 --> Email Class Initialized
INFO - 2017-07-26 07:11:59 --> Form Validation Class Initialized
INFO - 2017-07-26 07:11:59 --> Model Class Initialized
INFO - 2017-07-26 07:11:59 --> Model Class Initialized
INFO - 2017-07-26 07:11:59 --> Model Class Initialized
INFO - 2017-07-26 07:11:59 --> Model Class Initialized
INFO - 2017-07-26 07:11:59 --> Controller Class Initialized
INFO - 2017-07-26 07:11:59 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 07:11:59 --> Final output sent to browser
DEBUG - 2017-07-26 07:11:59 --> Total execution time: 0.0485
DEBUG - 2017-07-26 07:11:59 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:11:59 --> Database Forge Class Initialized
INFO - 2017-07-26 07:11:59 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:00 --> Config Class Initialized
INFO - 2017-07-26 07:12:00 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:00 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:00 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:00 --> URI Class Initialized
INFO - 2017-07-26 07:12:00 --> Router Class Initialized
INFO - 2017-07-26 07:12:00 --> Output Class Initialized
INFO - 2017-07-26 07:12:00 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:00 --> Input Class Initialized
INFO - 2017-07-26 07:12:00 --> Language Class Initialized
ERROR - 2017-07-26 07:12:00 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 07:12:02 --> Config Class Initialized
INFO - 2017-07-26 07:12:02 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:02 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:02 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:02 --> URI Class Initialized
DEBUG - 2017-07-26 07:12:02 --> No URI present. Default controller set.
INFO - 2017-07-26 07:12:02 --> Router Class Initialized
INFO - 2017-07-26 07:12:02 --> Output Class Initialized
INFO - 2017-07-26 07:12:02 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:02 --> Input Class Initialized
INFO - 2017-07-26 07:12:02 --> Language Class Initialized
INFO - 2017-07-26 07:12:02 --> Loader Class Initialized
INFO - 2017-07-26 07:12:02 --> Helper loaded: url_helper
INFO - 2017-07-26 07:12:02 --> Helper loaded: form_helper
INFO - 2017-07-26 07:12:02 --> Helper loaded: security_helper
INFO - 2017-07-26 07:12:02 --> Helper loaded: path_helper
INFO - 2017-07-26 07:12:02 --> Helper loaded: common_helper
INFO - 2017-07-26 07:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:12:02 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:12:02 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:02 --> Email Class Initialized
INFO - 2017-07-26 07:12:02 --> Form Validation Class Initialized
INFO - 2017-07-26 07:12:02 --> Model Class Initialized
INFO - 2017-07-26 07:12:02 --> Model Class Initialized
INFO - 2017-07-26 07:12:02 --> Model Class Initialized
INFO - 2017-07-26 07:12:02 --> Model Class Initialized
INFO - 2017-07-26 07:12:02 --> Controller Class Initialized
DEBUG - 2017-07-26 07:12:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 07:12:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 07:12:02 --> Final output sent to browser
DEBUG - 2017-07-26 07:12:02 --> Total execution time: 0.0293
DEBUG - 2017-07-26 07:12:02 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:12:02 --> Database Forge Class Initialized
INFO - 2017-07-26 07:12:02 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:09 --> Config Class Initialized
INFO - 2017-07-26 07:12:09 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:09 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:09 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:09 --> URI Class Initialized
INFO - 2017-07-26 07:12:09 --> Router Class Initialized
INFO - 2017-07-26 07:12:09 --> Output Class Initialized
INFO - 2017-07-26 07:12:09 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:09 --> Input Class Initialized
INFO - 2017-07-26 07:12:09 --> Language Class Initialized
INFO - 2017-07-26 07:12:09 --> Loader Class Initialized
INFO - 2017-07-26 07:12:09 --> Helper loaded: url_helper
INFO - 2017-07-26 07:12:09 --> Helper loaded: form_helper
INFO - 2017-07-26 07:12:09 --> Helper loaded: security_helper
INFO - 2017-07-26 07:12:09 --> Helper loaded: path_helper
INFO - 2017-07-26 07:12:09 --> Helper loaded: common_helper
INFO - 2017-07-26 07:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:12:09 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:12:09 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:09 --> Email Class Initialized
INFO - 2017-07-26 07:12:09 --> Form Validation Class Initialized
INFO - 2017-07-26 07:12:09 --> Model Class Initialized
INFO - 2017-07-26 07:12:09 --> Model Class Initialized
INFO - 2017-07-26 07:12:09 --> Model Class Initialized
INFO - 2017-07-26 07:12:09 --> Model Class Initialized
INFO - 2017-07-26 07:12:09 --> Controller Class Initialized
INFO - 2017-07-26 07:12:09 --> Model Class Initialized
INFO - 2017-07-26 07:12:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:12:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:12:09 --> Final output sent to browser
DEBUG - 2017-07-26 07:12:09 --> Total execution time: 0.0262
DEBUG - 2017-07-26 07:12:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:12:09 --> Database Forge Class Initialized
INFO - 2017-07-26 07:12:09 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:15 --> Config Class Initialized
INFO - 2017-07-26 07:12:15 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:15 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:15 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:15 --> URI Class Initialized
INFO - 2017-07-26 07:12:15 --> Router Class Initialized
INFO - 2017-07-26 07:12:15 --> Output Class Initialized
INFO - 2017-07-26 07:12:15 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:15 --> Input Class Initialized
INFO - 2017-07-26 07:12:15 --> Language Class Initialized
ERROR - 2017-07-26 07:12:15 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 07:12:23 --> Config Class Initialized
INFO - 2017-07-26 07:12:23 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:23 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:23 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:23 --> URI Class Initialized
INFO - 2017-07-26 07:12:23 --> Router Class Initialized
INFO - 2017-07-26 07:12:23 --> Output Class Initialized
INFO - 2017-07-26 07:12:23 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:23 --> Input Class Initialized
INFO - 2017-07-26 07:12:23 --> Language Class Initialized
INFO - 2017-07-26 07:12:23 --> Loader Class Initialized
INFO - 2017-07-26 07:12:23 --> Helper loaded: url_helper
INFO - 2017-07-26 07:12:23 --> Helper loaded: form_helper
INFO - 2017-07-26 07:12:23 --> Helper loaded: security_helper
INFO - 2017-07-26 07:12:23 --> Helper loaded: path_helper
INFO - 2017-07-26 07:12:23 --> Helper loaded: common_helper
INFO - 2017-07-26 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:12:23 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:12:23 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:23 --> Email Class Initialized
INFO - 2017-07-26 07:12:23 --> Form Validation Class Initialized
INFO - 2017-07-26 07:12:23 --> Model Class Initialized
INFO - 2017-07-26 07:12:23 --> Model Class Initialized
INFO - 2017-07-26 07:12:23 --> Model Class Initialized
INFO - 2017-07-26 07:12:23 --> Model Class Initialized
INFO - 2017-07-26 07:12:23 --> Controller Class Initialized
INFO - 2017-07-26 07:12:23 --> Model Class Initialized
INFO - 2017-07-26 07:12:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:12:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:12:23 --> Final output sent to browser
DEBUG - 2017-07-26 07:12:23 --> Total execution time: 0.0288
DEBUG - 2017-07-26 07:12:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:12:23 --> Database Forge Class Initialized
INFO - 2017-07-26 07:12:23 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:47 --> Config Class Initialized
INFO - 2017-07-26 07:12:47 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:12:47 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:12:47 --> Utf8 Class Initialized
INFO - 2017-07-26 07:12:47 --> URI Class Initialized
DEBUG - 2017-07-26 07:12:47 --> No URI present. Default controller set.
INFO - 2017-07-26 07:12:47 --> Router Class Initialized
INFO - 2017-07-26 07:12:47 --> Output Class Initialized
INFO - 2017-07-26 07:12:47 --> Security Class Initialized
DEBUG - 2017-07-26 07:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:12:47 --> Input Class Initialized
INFO - 2017-07-26 07:12:47 --> Language Class Initialized
INFO - 2017-07-26 07:12:47 --> Loader Class Initialized
INFO - 2017-07-26 07:12:47 --> Helper loaded: url_helper
INFO - 2017-07-26 07:12:47 --> Helper loaded: form_helper
INFO - 2017-07-26 07:12:47 --> Helper loaded: security_helper
INFO - 2017-07-26 07:12:47 --> Helper loaded: path_helper
INFO - 2017-07-26 07:12:47 --> Helper loaded: common_helper
INFO - 2017-07-26 07:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:12:47 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:12:47 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:47 --> Email Class Initialized
INFO - 2017-07-26 07:12:47 --> Form Validation Class Initialized
INFO - 2017-07-26 07:12:47 --> Model Class Initialized
INFO - 2017-07-26 07:12:47 --> Model Class Initialized
INFO - 2017-07-26 07:12:47 --> Model Class Initialized
INFO - 2017-07-26 07:12:47 --> Model Class Initialized
INFO - 2017-07-26 07:12:47 --> Controller Class Initialized
DEBUG - 2017-07-26 07:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:12:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 07:12:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 07:12:47 --> Final output sent to browser
DEBUG - 2017-07-26 07:12:47 --> Total execution time: 0.0318
DEBUG - 2017-07-26 07:12:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:12:47 --> Database Forge Class Initialized
INFO - 2017-07-26 07:12:47 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:12:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:13:43 --> Config Class Initialized
INFO - 2017-07-26 07:13:43 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:13:43 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:13:43 --> Utf8 Class Initialized
INFO - 2017-07-26 07:13:43 --> URI Class Initialized
INFO - 2017-07-26 07:13:43 --> Router Class Initialized
INFO - 2017-07-26 07:13:43 --> Output Class Initialized
INFO - 2017-07-26 07:13:43 --> Security Class Initialized
DEBUG - 2017-07-26 07:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:13:43 --> Input Class Initialized
INFO - 2017-07-26 07:13:43 --> Language Class Initialized
INFO - 2017-07-26 07:13:43 --> Loader Class Initialized
INFO - 2017-07-26 07:13:43 --> Helper loaded: url_helper
INFO - 2017-07-26 07:13:43 --> Helper loaded: form_helper
INFO - 2017-07-26 07:13:43 --> Helper loaded: security_helper
INFO - 2017-07-26 07:13:43 --> Helper loaded: path_helper
INFO - 2017-07-26 07:13:43 --> Helper loaded: common_helper
INFO - 2017-07-26 07:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:13:43 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:13:43 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:13:43 --> Email Class Initialized
INFO - 2017-07-26 07:13:43 --> Form Validation Class Initialized
INFO - 2017-07-26 07:13:43 --> Model Class Initialized
INFO - 2017-07-26 07:13:43 --> Model Class Initialized
INFO - 2017-07-26 07:13:43 --> Model Class Initialized
INFO - 2017-07-26 07:13:43 --> Model Class Initialized
INFO - 2017-07-26 07:13:43 --> Controller Class Initialized
INFO - 2017-07-26 07:13:43 --> Model Class Initialized
INFO - 2017-07-26 07:13:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:13:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:13:43 --> Final output sent to browser
DEBUG - 2017-07-26 07:13:43 --> Total execution time: 0.0312
DEBUG - 2017-07-26 07:13:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:13:43 --> Database Forge Class Initialized
INFO - 2017-07-26 07:13:43 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:17:40 --> Config Class Initialized
INFO - 2017-07-26 07:17:40 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:17:40 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:17:40 --> Utf8 Class Initialized
INFO - 2017-07-26 07:17:40 --> URI Class Initialized
INFO - 2017-07-26 07:17:40 --> Router Class Initialized
INFO - 2017-07-26 07:17:40 --> Output Class Initialized
INFO - 2017-07-26 07:17:40 --> Security Class Initialized
DEBUG - 2017-07-26 07:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:17:40 --> Input Class Initialized
INFO - 2017-07-26 07:17:40 --> Language Class Initialized
INFO - 2017-07-26 07:17:40 --> Loader Class Initialized
INFO - 2017-07-26 07:17:40 --> Helper loaded: url_helper
INFO - 2017-07-26 07:17:40 --> Helper loaded: form_helper
INFO - 2017-07-26 07:17:40 --> Helper loaded: security_helper
INFO - 2017-07-26 07:17:40 --> Helper loaded: path_helper
INFO - 2017-07-26 07:17:40 --> Helper loaded: common_helper
INFO - 2017-07-26 07:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:17:40 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:17:40 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:17:40 --> Email Class Initialized
INFO - 2017-07-26 07:17:40 --> Form Validation Class Initialized
INFO - 2017-07-26 07:17:40 --> Model Class Initialized
INFO - 2017-07-26 07:17:40 --> Model Class Initialized
INFO - 2017-07-26 07:17:40 --> Model Class Initialized
INFO - 2017-07-26 07:17:40 --> Model Class Initialized
INFO - 2017-07-26 07:17:40 --> Controller Class Initialized
INFO - 2017-07-26 07:17:40 --> Model Class Initialized
INFO - 2017-07-26 07:17:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:17:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:17:40 --> Final output sent to browser
DEBUG - 2017-07-26 07:17:40 --> Total execution time: 0.0418
DEBUG - 2017-07-26 07:17:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:17:40 --> Database Forge Class Initialized
INFO - 2017-07-26 07:17:40 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:18:06 --> Config Class Initialized
INFO - 2017-07-26 07:18:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:18:06 --> Utf8 Class Initialized
INFO - 2017-07-26 07:18:06 --> URI Class Initialized
INFO - 2017-07-26 07:18:06 --> Router Class Initialized
INFO - 2017-07-26 07:18:06 --> Output Class Initialized
INFO - 2017-07-26 07:18:06 --> Security Class Initialized
DEBUG - 2017-07-26 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:18:06 --> Input Class Initialized
INFO - 2017-07-26 07:18:06 --> Language Class Initialized
INFO - 2017-07-26 07:18:06 --> Loader Class Initialized
INFO - 2017-07-26 07:18:06 --> Helper loaded: url_helper
INFO - 2017-07-26 07:18:06 --> Helper loaded: form_helper
INFO - 2017-07-26 07:18:06 --> Helper loaded: security_helper
INFO - 2017-07-26 07:18:06 --> Helper loaded: path_helper
INFO - 2017-07-26 07:18:06 --> Helper loaded: common_helper
INFO - 2017-07-26 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:18:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:18:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:18:06 --> Email Class Initialized
INFO - 2017-07-26 07:18:06 --> Form Validation Class Initialized
INFO - 2017-07-26 07:18:06 --> Model Class Initialized
INFO - 2017-07-26 07:18:06 --> Model Class Initialized
INFO - 2017-07-26 07:18:06 --> Model Class Initialized
INFO - 2017-07-26 07:18:06 --> Model Class Initialized
INFO - 2017-07-26 07:18:06 --> Controller Class Initialized
INFO - 2017-07-26 07:18:06 --> Model Class Initialized
INFO - 2017-07-26 07:18:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:18:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:18:06 --> Final output sent to browser
DEBUG - 2017-07-26 07:18:06 --> Total execution time: 0.0289
DEBUG - 2017-07-26 07:18:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:18:06 --> Database Forge Class Initialized
INFO - 2017-07-26 07:18:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:33:25 --> Config Class Initialized
INFO - 2017-07-26 07:33:25 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:33:25 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:33:25 --> Utf8 Class Initialized
INFO - 2017-07-26 07:33:25 --> URI Class Initialized
INFO - 2017-07-26 07:33:25 --> Router Class Initialized
INFO - 2017-07-26 07:33:25 --> Output Class Initialized
INFO - 2017-07-26 07:33:25 --> Security Class Initialized
DEBUG - 2017-07-26 07:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:33:25 --> Input Class Initialized
INFO - 2017-07-26 07:33:25 --> Language Class Initialized
INFO - 2017-07-26 07:33:25 --> Loader Class Initialized
INFO - 2017-07-26 07:33:25 --> Helper loaded: url_helper
INFO - 2017-07-26 07:33:25 --> Helper loaded: form_helper
INFO - 2017-07-26 07:33:25 --> Helper loaded: security_helper
INFO - 2017-07-26 07:33:25 --> Helper loaded: path_helper
INFO - 2017-07-26 07:33:25 --> Helper loaded: common_helper
INFO - 2017-07-26 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:33:25 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:33:25 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:33:25 --> Email Class Initialized
INFO - 2017-07-26 07:33:25 --> Form Validation Class Initialized
INFO - 2017-07-26 07:33:25 --> Model Class Initialized
INFO - 2017-07-26 07:33:25 --> Model Class Initialized
INFO - 2017-07-26 07:33:25 --> Model Class Initialized
INFO - 2017-07-26 07:33:25 --> Model Class Initialized
INFO - 2017-07-26 07:33:25 --> Controller Class Initialized
INFO - 2017-07-26 07:33:25 --> Model Class Initialized
INFO - 2017-07-26 07:33:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:33:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:33:25 --> Final output sent to browser
DEBUG - 2017-07-26 07:33:25 --> Total execution time: 0.0279
DEBUG - 2017-07-26 07:33:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:33:25 --> Database Forge Class Initialized
INFO - 2017-07-26 07:33:25 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:33:29 --> Config Class Initialized
INFO - 2017-07-26 07:33:29 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:33:29 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:33:29 --> Utf8 Class Initialized
INFO - 2017-07-26 07:33:29 --> URI Class Initialized
INFO - 2017-07-26 07:33:29 --> Router Class Initialized
INFO - 2017-07-26 07:33:29 --> Output Class Initialized
INFO - 2017-07-26 07:33:29 --> Security Class Initialized
DEBUG - 2017-07-26 07:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:33:29 --> Input Class Initialized
INFO - 2017-07-26 07:33:29 --> Language Class Initialized
ERROR - 2017-07-26 07:33:29 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 07:34:42 --> Config Class Initialized
INFO - 2017-07-26 07:34:42 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:34:42 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:34:42 --> Utf8 Class Initialized
INFO - 2017-07-26 07:34:42 --> URI Class Initialized
INFO - 2017-07-26 07:34:42 --> Router Class Initialized
INFO - 2017-07-26 07:34:42 --> Output Class Initialized
INFO - 2017-07-26 07:34:42 --> Security Class Initialized
DEBUG - 2017-07-26 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:34:42 --> Input Class Initialized
INFO - 2017-07-26 07:34:42 --> Language Class Initialized
INFO - 2017-07-26 07:34:42 --> Loader Class Initialized
INFO - 2017-07-26 07:34:42 --> Helper loaded: url_helper
INFO - 2017-07-26 07:34:42 --> Helper loaded: form_helper
INFO - 2017-07-26 07:34:42 --> Helper loaded: security_helper
INFO - 2017-07-26 07:34:42 --> Helper loaded: path_helper
INFO - 2017-07-26 07:34:42 --> Helper loaded: common_helper
INFO - 2017-07-26 07:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:34:42 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:34:42 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:34:42 --> Email Class Initialized
INFO - 2017-07-26 07:34:42 --> Form Validation Class Initialized
INFO - 2017-07-26 07:34:42 --> Model Class Initialized
INFO - 2017-07-26 07:34:42 --> Model Class Initialized
INFO - 2017-07-26 07:34:42 --> Model Class Initialized
INFO - 2017-07-26 07:34:42 --> Model Class Initialized
INFO - 2017-07-26 07:34:42 --> Controller Class Initialized
INFO - 2017-07-26 07:34:42 --> Model Class Initialized
INFO - 2017-07-26 07:34:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:34:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:34:42 --> Final output sent to browser
DEBUG - 2017-07-26 07:34:42 --> Total execution time: 0.0297
DEBUG - 2017-07-26 07:34:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:34:42 --> Database Forge Class Initialized
INFO - 2017-07-26 07:34:42 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:36:28 --> Config Class Initialized
INFO - 2017-07-26 07:36:28 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:36:28 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:36:28 --> Utf8 Class Initialized
INFO - 2017-07-26 07:36:28 --> URI Class Initialized
INFO - 2017-07-26 07:36:28 --> Router Class Initialized
INFO - 2017-07-26 07:36:28 --> Output Class Initialized
INFO - 2017-07-26 07:36:28 --> Security Class Initialized
DEBUG - 2017-07-26 07:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:36:28 --> Input Class Initialized
INFO - 2017-07-26 07:36:28 --> Language Class Initialized
INFO - 2017-07-26 07:36:28 --> Loader Class Initialized
INFO - 2017-07-26 07:36:28 --> Helper loaded: url_helper
INFO - 2017-07-26 07:36:28 --> Helper loaded: form_helper
INFO - 2017-07-26 07:36:28 --> Helper loaded: security_helper
INFO - 2017-07-26 07:36:28 --> Helper loaded: path_helper
INFO - 2017-07-26 07:36:28 --> Helper loaded: common_helper
INFO - 2017-07-26 07:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:36:28 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:36:28 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:36:28 --> Email Class Initialized
INFO - 2017-07-26 07:36:28 --> Form Validation Class Initialized
INFO - 2017-07-26 07:36:28 --> Model Class Initialized
INFO - 2017-07-26 07:36:28 --> Model Class Initialized
INFO - 2017-07-26 07:36:28 --> Model Class Initialized
INFO - 2017-07-26 07:36:28 --> Model Class Initialized
INFO - 2017-07-26 07:36:28 --> Controller Class Initialized
INFO - 2017-07-26 07:36:28 --> Model Class Initialized
INFO - 2017-07-26 07:36:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:36:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:36:28 --> Final output sent to browser
DEBUG - 2017-07-26 07:36:28 --> Total execution time: 0.0275
DEBUG - 2017-07-26 07:36:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:36:28 --> Database Forge Class Initialized
INFO - 2017-07-26 07:36:28 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:36:32 --> Config Class Initialized
INFO - 2017-07-26 07:36:32 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:36:32 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:36:32 --> Utf8 Class Initialized
INFO - 2017-07-26 07:36:32 --> URI Class Initialized
INFO - 2017-07-26 07:36:32 --> Router Class Initialized
INFO - 2017-07-26 07:36:32 --> Output Class Initialized
INFO - 2017-07-26 07:36:32 --> Security Class Initialized
DEBUG - 2017-07-26 07:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:36:32 --> Input Class Initialized
INFO - 2017-07-26 07:36:32 --> Language Class Initialized
ERROR - 2017-07-26 07:36:32 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 07:53:13 --> Config Class Initialized
INFO - 2017-07-26 07:53:13 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:53:13 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:53:13 --> Utf8 Class Initialized
INFO - 2017-07-26 07:53:13 --> URI Class Initialized
INFO - 2017-07-26 07:53:13 --> Router Class Initialized
INFO - 2017-07-26 07:53:13 --> Output Class Initialized
INFO - 2017-07-26 07:53:13 --> Security Class Initialized
DEBUG - 2017-07-26 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:53:13 --> Input Class Initialized
INFO - 2017-07-26 07:53:13 --> Language Class Initialized
INFO - 2017-07-26 07:53:13 --> Loader Class Initialized
INFO - 2017-07-26 07:53:13 --> Helper loaded: url_helper
INFO - 2017-07-26 07:53:13 --> Helper loaded: form_helper
INFO - 2017-07-26 07:53:13 --> Helper loaded: security_helper
INFO - 2017-07-26 07:53:13 --> Helper loaded: path_helper
INFO - 2017-07-26 07:53:13 --> Helper loaded: common_helper
INFO - 2017-07-26 07:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 07:53:13 --> Helper loaded: check_session_helper
INFO - 2017-07-26 07:53:13 --> Database Driver Class Initialized
DEBUG - 2017-07-26 07:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:53:13 --> Email Class Initialized
INFO - 2017-07-26 07:53:13 --> Form Validation Class Initialized
INFO - 2017-07-26 07:53:13 --> Model Class Initialized
INFO - 2017-07-26 07:53:13 --> Model Class Initialized
INFO - 2017-07-26 07:53:13 --> Model Class Initialized
INFO - 2017-07-26 07:53:13 --> Model Class Initialized
INFO - 2017-07-26 07:53:13 --> Controller Class Initialized
INFO - 2017-07-26 07:53:13 --> Model Class Initialized
INFO - 2017-07-26 07:53:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 07:53:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 07:53:13 --> Final output sent to browser
DEBUG - 2017-07-26 07:53:13 --> Total execution time: 0.0358
DEBUG - 2017-07-26 07:53:13 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 07:53:13 --> Database Forge Class Initialized
INFO - 2017-07-26 07:53:13 --> User Agent Class Initialized
DEBUG - 2017-07-26 07:53:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 07:53:19 --> Config Class Initialized
INFO - 2017-07-26 07:53:19 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:53:19 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:53:19 --> Utf8 Class Initialized
INFO - 2017-07-26 07:53:19 --> URI Class Initialized
INFO - 2017-07-26 07:53:19 --> Router Class Initialized
INFO - 2017-07-26 07:53:19 --> Output Class Initialized
INFO - 2017-07-26 07:53:19 --> Security Class Initialized
DEBUG - 2017-07-26 07:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:53:19 --> Input Class Initialized
INFO - 2017-07-26 07:53:19 --> Language Class Initialized
ERROR - 2017-07-26 07:53:19 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 07:59:58 --> Config Class Initialized
INFO - 2017-07-26 07:59:58 --> Hooks Class Initialized
DEBUG - 2017-07-26 07:59:58 --> UTF-8 Support Enabled
INFO - 2017-07-26 07:59:58 --> Utf8 Class Initialized
INFO - 2017-07-26 07:59:58 --> URI Class Initialized
INFO - 2017-07-26 07:59:58 --> Router Class Initialized
INFO - 2017-07-26 07:59:58 --> Output Class Initialized
INFO - 2017-07-26 07:59:58 --> Security Class Initialized
DEBUG - 2017-07-26 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 07:59:58 --> Input Class Initialized
INFO - 2017-07-26 07:59:58 --> Language Class Initialized
ERROR - 2017-07-26 07:59:58 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 08:00:07 --> Config Class Initialized
INFO - 2017-07-26 08:00:07 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:00:07 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:00:07 --> Utf8 Class Initialized
INFO - 2017-07-26 08:00:07 --> URI Class Initialized
INFO - 2017-07-26 08:00:07 --> Router Class Initialized
INFO - 2017-07-26 08:00:07 --> Output Class Initialized
INFO - 2017-07-26 08:00:07 --> Security Class Initialized
DEBUG - 2017-07-26 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:00:07 --> Input Class Initialized
INFO - 2017-07-26 08:00:07 --> Language Class Initialized
INFO - 2017-07-26 08:00:07 --> Loader Class Initialized
INFO - 2017-07-26 08:00:07 --> Helper loaded: url_helper
INFO - 2017-07-26 08:00:07 --> Helper loaded: form_helper
INFO - 2017-07-26 08:00:07 --> Helper loaded: security_helper
INFO - 2017-07-26 08:00:07 --> Helper loaded: path_helper
INFO - 2017-07-26 08:00:07 --> Helper loaded: common_helper
INFO - 2017-07-26 08:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:00:07 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:00:07 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:00:07 --> Email Class Initialized
INFO - 2017-07-26 08:00:07 --> Form Validation Class Initialized
INFO - 2017-07-26 08:00:07 --> Model Class Initialized
INFO - 2017-07-26 08:00:07 --> Model Class Initialized
INFO - 2017-07-26 08:00:07 --> Model Class Initialized
INFO - 2017-07-26 08:00:07 --> Model Class Initialized
INFO - 2017-07-26 08:00:07 --> Controller Class Initialized
INFO - 2017-07-26 08:00:07 --> Model Class Initialized
INFO - 2017-07-26 08:00:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:00:07 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:00:07 --> Final output sent to browser
DEBUG - 2017-07-26 08:00:07 --> Total execution time: 0.0283
DEBUG - 2017-07-26 08:00:07 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:00:07 --> Database Forge Class Initialized
INFO - 2017-07-26 08:00:07 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:05:06 --> Config Class Initialized
INFO - 2017-07-26 08:05:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:05:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:05:06 --> Utf8 Class Initialized
INFO - 2017-07-26 08:05:06 --> URI Class Initialized
INFO - 2017-07-26 08:05:06 --> Router Class Initialized
INFO - 2017-07-26 08:05:06 --> Output Class Initialized
INFO - 2017-07-26 08:05:06 --> Security Class Initialized
DEBUG - 2017-07-26 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:05:06 --> Input Class Initialized
INFO - 2017-07-26 08:05:06 --> Language Class Initialized
INFO - 2017-07-26 08:05:06 --> Loader Class Initialized
INFO - 2017-07-26 08:05:06 --> Helper loaded: url_helper
INFO - 2017-07-26 08:05:06 --> Helper loaded: form_helper
INFO - 2017-07-26 08:05:06 --> Helper loaded: security_helper
INFO - 2017-07-26 08:05:06 --> Helper loaded: path_helper
INFO - 2017-07-26 08:05:06 --> Helper loaded: common_helper
INFO - 2017-07-26 08:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:05:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:05:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:05:06 --> Email Class Initialized
INFO - 2017-07-26 08:05:06 --> Form Validation Class Initialized
INFO - 2017-07-26 08:05:06 --> Model Class Initialized
INFO - 2017-07-26 08:05:06 --> Model Class Initialized
INFO - 2017-07-26 08:05:06 --> Model Class Initialized
INFO - 2017-07-26 08:05:06 --> Model Class Initialized
INFO - 2017-07-26 08:05:06 --> Controller Class Initialized
INFO - 2017-07-26 08:05:06 --> Model Class Initialized
INFO - 2017-07-26 08:05:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:05:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:05:06 --> Final output sent to browser
DEBUG - 2017-07-26 08:05:06 --> Total execution time: 0.0267
DEBUG - 2017-07-26 08:05:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:05:06 --> Database Forge Class Initialized
INFO - 2017-07-26 08:05:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:05:11 --> Config Class Initialized
INFO - 2017-07-26 08:05:11 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:05:11 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:05:11 --> Utf8 Class Initialized
INFO - 2017-07-26 08:05:11 --> URI Class Initialized
INFO - 2017-07-26 08:05:11 --> Router Class Initialized
INFO - 2017-07-26 08:05:11 --> Output Class Initialized
INFO - 2017-07-26 08:05:11 --> Security Class Initialized
DEBUG - 2017-07-26 08:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:05:11 --> Input Class Initialized
INFO - 2017-07-26 08:05:11 --> Language Class Initialized
ERROR - 2017-07-26 08:05:11 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:14:45 --> Config Class Initialized
INFO - 2017-07-26 08:14:45 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:14:45 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:14:45 --> Utf8 Class Initialized
INFO - 2017-07-26 08:14:45 --> URI Class Initialized
INFO - 2017-07-26 08:14:45 --> Router Class Initialized
INFO - 2017-07-26 08:14:45 --> Output Class Initialized
INFO - 2017-07-26 08:14:45 --> Security Class Initialized
DEBUG - 2017-07-26 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:14:45 --> Input Class Initialized
INFO - 2017-07-26 08:14:45 --> Language Class Initialized
INFO - 2017-07-26 08:14:45 --> Loader Class Initialized
INFO - 2017-07-26 08:14:45 --> Helper loaded: url_helper
INFO - 2017-07-26 08:14:45 --> Helper loaded: form_helper
INFO - 2017-07-26 08:14:45 --> Helper loaded: security_helper
INFO - 2017-07-26 08:14:45 --> Helper loaded: path_helper
INFO - 2017-07-26 08:14:45 --> Helper loaded: common_helper
INFO - 2017-07-26 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:14:45 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:14:45 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:14:45 --> Email Class Initialized
INFO - 2017-07-26 08:14:45 --> Form Validation Class Initialized
INFO - 2017-07-26 08:14:45 --> Model Class Initialized
INFO - 2017-07-26 08:14:45 --> Model Class Initialized
INFO - 2017-07-26 08:14:45 --> Model Class Initialized
INFO - 2017-07-26 08:14:45 --> Model Class Initialized
INFO - 2017-07-26 08:14:45 --> Controller Class Initialized
INFO - 2017-07-26 08:14:45 --> Model Class Initialized
INFO - 2017-07-26 08:14:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:14:45 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:14:45 --> Final output sent to browser
DEBUG - 2017-07-26 08:14:45 --> Total execution time: 0.0277
DEBUG - 2017-07-26 08:14:45 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:14:45 --> Database Forge Class Initialized
INFO - 2017-07-26 08:14:45 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:14:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:14:50 --> Config Class Initialized
INFO - 2017-07-26 08:14:50 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:14:50 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:14:50 --> Utf8 Class Initialized
INFO - 2017-07-26 08:14:50 --> URI Class Initialized
INFO - 2017-07-26 08:14:50 --> Router Class Initialized
INFO - 2017-07-26 08:14:50 --> Output Class Initialized
INFO - 2017-07-26 08:14:50 --> Security Class Initialized
DEBUG - 2017-07-26 08:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:14:50 --> Input Class Initialized
INFO - 2017-07-26 08:14:50 --> Language Class Initialized
INFO - 2017-07-26 08:14:50 --> Loader Class Initialized
INFO - 2017-07-26 08:14:50 --> Helper loaded: url_helper
INFO - 2017-07-26 08:14:50 --> Helper loaded: form_helper
INFO - 2017-07-26 08:14:50 --> Helper loaded: security_helper
INFO - 2017-07-26 08:14:50 --> Helper loaded: path_helper
INFO - 2017-07-26 08:14:50 --> Helper loaded: common_helper
INFO - 2017-07-26 08:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:14:50 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:14:50 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:14:50 --> Email Class Initialized
INFO - 2017-07-26 08:14:50 --> Form Validation Class Initialized
INFO - 2017-07-26 08:14:50 --> Model Class Initialized
INFO - 2017-07-26 08:14:50 --> Model Class Initialized
INFO - 2017-07-26 08:14:50 --> Model Class Initialized
INFO - 2017-07-26 08:14:50 --> Model Class Initialized
INFO - 2017-07-26 08:14:50 --> Controller Class Initialized
INFO - 2017-07-26 08:14:50 --> Model Class Initialized
INFO - 2017-07-26 08:14:50 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:14:50 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:14:50 --> Final output sent to browser
DEBUG - 2017-07-26 08:14:50 --> Total execution time: 0.0304
DEBUG - 2017-07-26 08:14:50 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:14:50 --> Database Forge Class Initialized
INFO - 2017-07-26 08:14:50 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:15:13 --> Config Class Initialized
INFO - 2017-07-26 08:15:13 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:15:13 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:15:13 --> Utf8 Class Initialized
INFO - 2017-07-26 08:15:13 --> URI Class Initialized
INFO - 2017-07-26 08:15:13 --> Router Class Initialized
INFO - 2017-07-26 08:15:13 --> Output Class Initialized
INFO - 2017-07-26 08:15:13 --> Security Class Initialized
DEBUG - 2017-07-26 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:15:13 --> Input Class Initialized
INFO - 2017-07-26 08:15:13 --> Language Class Initialized
ERROR - 2017-07-26 08:15:13 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:19:56 --> Config Class Initialized
INFO - 2017-07-26 08:19:56 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:19:56 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:19:56 --> Utf8 Class Initialized
INFO - 2017-07-26 08:19:56 --> URI Class Initialized
INFO - 2017-07-26 08:19:56 --> Router Class Initialized
INFO - 2017-07-26 08:19:56 --> Output Class Initialized
INFO - 2017-07-26 08:19:56 --> Security Class Initialized
DEBUG - 2017-07-26 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:19:56 --> Input Class Initialized
INFO - 2017-07-26 08:19:56 --> Language Class Initialized
INFO - 2017-07-26 08:19:56 --> Loader Class Initialized
INFO - 2017-07-26 08:19:56 --> Helper loaded: url_helper
INFO - 2017-07-26 08:19:56 --> Helper loaded: form_helper
INFO - 2017-07-26 08:19:56 --> Helper loaded: security_helper
INFO - 2017-07-26 08:19:56 --> Helper loaded: path_helper
INFO - 2017-07-26 08:19:56 --> Helper loaded: common_helper
INFO - 2017-07-26 08:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:19:56 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:19:56 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:19:56 --> Email Class Initialized
INFO - 2017-07-26 08:19:56 --> Form Validation Class Initialized
INFO - 2017-07-26 08:19:56 --> Model Class Initialized
INFO - 2017-07-26 08:19:56 --> Model Class Initialized
INFO - 2017-07-26 08:19:56 --> Model Class Initialized
INFO - 2017-07-26 08:19:56 --> Model Class Initialized
INFO - 2017-07-26 08:19:56 --> Controller Class Initialized
INFO - 2017-07-26 08:19:56 --> Model Class Initialized
INFO - 2017-07-26 08:19:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:19:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:19:56 --> Final output sent to browser
DEBUG - 2017-07-26 08:19:56 --> Total execution time: 0.0283
DEBUG - 2017-07-26 08:19:56 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:19:56 --> Database Forge Class Initialized
INFO - 2017-07-26 08:19:56 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:21:06 --> Config Class Initialized
INFO - 2017-07-26 08:21:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:21:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:21:06 --> Utf8 Class Initialized
INFO - 2017-07-26 08:21:06 --> URI Class Initialized
INFO - 2017-07-26 08:21:06 --> Router Class Initialized
INFO - 2017-07-26 08:21:06 --> Output Class Initialized
INFO - 2017-07-26 08:21:06 --> Security Class Initialized
DEBUG - 2017-07-26 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:21:06 --> Input Class Initialized
INFO - 2017-07-26 08:21:06 --> Language Class Initialized
INFO - 2017-07-26 08:21:06 --> Loader Class Initialized
INFO - 2017-07-26 08:21:06 --> Helper loaded: url_helper
INFO - 2017-07-26 08:21:06 --> Helper loaded: form_helper
INFO - 2017-07-26 08:21:06 --> Helper loaded: security_helper
INFO - 2017-07-26 08:21:06 --> Helper loaded: path_helper
INFO - 2017-07-26 08:21:06 --> Helper loaded: common_helper
INFO - 2017-07-26 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:21:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:21:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:21:06 --> Email Class Initialized
INFO - 2017-07-26 08:21:06 --> Form Validation Class Initialized
INFO - 2017-07-26 08:21:06 --> Model Class Initialized
INFO - 2017-07-26 08:21:06 --> Model Class Initialized
INFO - 2017-07-26 08:21:06 --> Model Class Initialized
INFO - 2017-07-26 08:21:06 --> Model Class Initialized
INFO - 2017-07-26 08:21:06 --> Controller Class Initialized
INFO - 2017-07-26 08:21:06 --> Model Class Initialized
INFO - 2017-07-26 08:21:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:21:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:21:06 --> Final output sent to browser
DEBUG - 2017-07-26 08:21:06 --> Total execution time: 0.0318
DEBUG - 2017-07-26 08:21:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:21:06 --> Database Forge Class Initialized
INFO - 2017-07-26 08:21:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:21:37 --> Config Class Initialized
INFO - 2017-07-26 08:21:37 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:21:37 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:21:37 --> Utf8 Class Initialized
INFO - 2017-07-26 08:21:37 --> URI Class Initialized
INFO - 2017-07-26 08:21:37 --> Router Class Initialized
INFO - 2017-07-26 08:21:37 --> Output Class Initialized
INFO - 2017-07-26 08:21:37 --> Security Class Initialized
DEBUG - 2017-07-26 08:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:21:37 --> Input Class Initialized
INFO - 2017-07-26 08:21:37 --> Language Class Initialized
INFO - 2017-07-26 08:21:37 --> Loader Class Initialized
INFO - 2017-07-26 08:21:37 --> Helper loaded: url_helper
INFO - 2017-07-26 08:21:37 --> Helper loaded: form_helper
INFO - 2017-07-26 08:21:37 --> Helper loaded: security_helper
INFO - 2017-07-26 08:21:37 --> Helper loaded: path_helper
INFO - 2017-07-26 08:21:37 --> Helper loaded: common_helper
INFO - 2017-07-26 08:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:21:37 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:21:37 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:21:37 --> Email Class Initialized
INFO - 2017-07-26 08:21:37 --> Form Validation Class Initialized
INFO - 2017-07-26 08:21:37 --> Model Class Initialized
INFO - 2017-07-26 08:21:37 --> Model Class Initialized
INFO - 2017-07-26 08:21:37 --> Model Class Initialized
INFO - 2017-07-26 08:21:37 --> Model Class Initialized
INFO - 2017-07-26 08:21:37 --> Controller Class Initialized
INFO - 2017-07-26 08:21:37 --> Model Class Initialized
INFO - 2017-07-26 08:21:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:21:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:21:37 --> Final output sent to browser
DEBUG - 2017-07-26 08:21:37 --> Total execution time: 0.0369
DEBUG - 2017-07-26 08:21:37 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:21:37 --> Database Forge Class Initialized
INFO - 2017-07-26 08:21:37 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:21:55 --> Config Class Initialized
INFO - 2017-07-26 08:21:55 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:21:55 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:21:55 --> Utf8 Class Initialized
INFO - 2017-07-26 08:21:55 --> URI Class Initialized
INFO - 2017-07-26 08:21:55 --> Router Class Initialized
INFO - 2017-07-26 08:21:55 --> Output Class Initialized
INFO - 2017-07-26 08:21:55 --> Security Class Initialized
DEBUG - 2017-07-26 08:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:21:55 --> Input Class Initialized
INFO - 2017-07-26 08:21:55 --> Language Class Initialized
ERROR - 2017-07-26 08:21:55 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:23:37 --> Config Class Initialized
INFO - 2017-07-26 08:23:37 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:23:37 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:23:37 --> Utf8 Class Initialized
INFO - 2017-07-26 08:23:37 --> URI Class Initialized
INFO - 2017-07-26 08:23:37 --> Router Class Initialized
INFO - 2017-07-26 08:23:37 --> Output Class Initialized
INFO - 2017-07-26 08:23:37 --> Security Class Initialized
DEBUG - 2017-07-26 08:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:23:37 --> Input Class Initialized
INFO - 2017-07-26 08:23:37 --> Language Class Initialized
INFO - 2017-07-26 08:23:37 --> Loader Class Initialized
INFO - 2017-07-26 08:23:37 --> Helper loaded: url_helper
INFO - 2017-07-26 08:23:37 --> Helper loaded: form_helper
INFO - 2017-07-26 08:23:37 --> Helper loaded: security_helper
INFO - 2017-07-26 08:23:37 --> Helper loaded: path_helper
INFO - 2017-07-26 08:23:37 --> Helper loaded: common_helper
INFO - 2017-07-26 08:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:23:37 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:23:37 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:23:37 --> Email Class Initialized
INFO - 2017-07-26 08:23:37 --> Form Validation Class Initialized
INFO - 2017-07-26 08:23:37 --> Model Class Initialized
INFO - 2017-07-26 08:23:37 --> Model Class Initialized
INFO - 2017-07-26 08:23:37 --> Model Class Initialized
INFO - 2017-07-26 08:23:37 --> Model Class Initialized
INFO - 2017-07-26 08:23:37 --> Controller Class Initialized
INFO - 2017-07-26 08:23:37 --> Model Class Initialized
INFO - 2017-07-26 08:23:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:23:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:23:37 --> Final output sent to browser
DEBUG - 2017-07-26 08:23:37 --> Total execution time: 0.0287
DEBUG - 2017-07-26 08:23:37 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:23:37 --> Database Forge Class Initialized
INFO - 2017-07-26 08:23:37 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:24:18 --> Config Class Initialized
INFO - 2017-07-26 08:24:18 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:24:18 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:24:18 --> Utf8 Class Initialized
INFO - 2017-07-26 08:24:18 --> URI Class Initialized
INFO - 2017-07-26 08:24:18 --> Router Class Initialized
INFO - 2017-07-26 08:24:18 --> Output Class Initialized
INFO - 2017-07-26 08:24:18 --> Security Class Initialized
DEBUG - 2017-07-26 08:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:24:18 --> Input Class Initialized
INFO - 2017-07-26 08:24:18 --> Language Class Initialized
INFO - 2017-07-26 08:24:18 --> Loader Class Initialized
INFO - 2017-07-26 08:24:18 --> Helper loaded: url_helper
INFO - 2017-07-26 08:24:18 --> Helper loaded: form_helper
INFO - 2017-07-26 08:24:18 --> Helper loaded: security_helper
INFO - 2017-07-26 08:24:18 --> Helper loaded: path_helper
INFO - 2017-07-26 08:24:18 --> Helper loaded: common_helper
INFO - 2017-07-26 08:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:24:18 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:24:18 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:24:18 --> Email Class Initialized
INFO - 2017-07-26 08:24:18 --> Form Validation Class Initialized
INFO - 2017-07-26 08:24:18 --> Model Class Initialized
INFO - 2017-07-26 08:24:18 --> Model Class Initialized
INFO - 2017-07-26 08:24:18 --> Model Class Initialized
INFO - 2017-07-26 08:24:18 --> Model Class Initialized
INFO - 2017-07-26 08:24:18 --> Controller Class Initialized
INFO - 2017-07-26 08:24:18 --> Model Class Initialized
INFO - 2017-07-26 08:24:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:24:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:24:18 --> Final output sent to browser
DEBUG - 2017-07-26 08:24:18 --> Total execution time: 0.0280
DEBUG - 2017-07-26 08:24:18 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:24:18 --> Database Forge Class Initialized
INFO - 2017-07-26 08:24:18 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:35:00 --> Config Class Initialized
INFO - 2017-07-26 08:35:00 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:35:00 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:35:00 --> Utf8 Class Initialized
INFO - 2017-07-26 08:35:00 --> URI Class Initialized
INFO - 2017-07-26 08:35:00 --> Router Class Initialized
INFO - 2017-07-26 08:35:00 --> Output Class Initialized
INFO - 2017-07-26 08:35:00 --> Security Class Initialized
DEBUG - 2017-07-26 08:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:35:00 --> Input Class Initialized
INFO - 2017-07-26 08:35:00 --> Language Class Initialized
INFO - 2017-07-26 08:35:00 --> Loader Class Initialized
INFO - 2017-07-26 08:35:00 --> Helper loaded: url_helper
INFO - 2017-07-26 08:35:00 --> Helper loaded: form_helper
INFO - 2017-07-26 08:35:00 --> Helper loaded: security_helper
INFO - 2017-07-26 08:35:00 --> Helper loaded: path_helper
INFO - 2017-07-26 08:35:00 --> Helper loaded: common_helper
INFO - 2017-07-26 08:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:35:00 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:35:00 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:35:00 --> Email Class Initialized
INFO - 2017-07-26 08:35:00 --> Form Validation Class Initialized
INFO - 2017-07-26 08:35:00 --> Model Class Initialized
INFO - 2017-07-26 08:35:00 --> Model Class Initialized
INFO - 2017-07-26 08:35:00 --> Model Class Initialized
INFO - 2017-07-26 08:35:00 --> Model Class Initialized
INFO - 2017-07-26 08:35:00 --> Controller Class Initialized
INFO - 2017-07-26 08:35:00 --> Model Class Initialized
INFO - 2017-07-26 08:35:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:35:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:35:00 --> Final output sent to browser
DEBUG - 2017-07-26 08:35:00 --> Total execution time: 0.0316
DEBUG - 2017-07-26 08:35:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:35:00 --> Database Forge Class Initialized
INFO - 2017-07-26 08:35:00 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:35:06 --> Config Class Initialized
INFO - 2017-07-26 08:35:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:35:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:35:06 --> Utf8 Class Initialized
INFO - 2017-07-26 08:35:06 --> URI Class Initialized
INFO - 2017-07-26 08:35:06 --> Router Class Initialized
INFO - 2017-07-26 08:35:06 --> Output Class Initialized
INFO - 2017-07-26 08:35:06 --> Security Class Initialized
DEBUG - 2017-07-26 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:35:06 --> Input Class Initialized
INFO - 2017-07-26 08:35:06 --> Language Class Initialized
INFO - 2017-07-26 08:35:06 --> Loader Class Initialized
INFO - 2017-07-26 08:35:06 --> Helper loaded: url_helper
INFO - 2017-07-26 08:35:06 --> Helper loaded: form_helper
INFO - 2017-07-26 08:35:06 --> Helper loaded: security_helper
INFO - 2017-07-26 08:35:06 --> Helper loaded: path_helper
INFO - 2017-07-26 08:35:06 --> Helper loaded: common_helper
INFO - 2017-07-26 08:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:35:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:35:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:35:06 --> Email Class Initialized
INFO - 2017-07-26 08:35:06 --> Form Validation Class Initialized
INFO - 2017-07-26 08:35:06 --> Model Class Initialized
INFO - 2017-07-26 08:35:06 --> Model Class Initialized
INFO - 2017-07-26 08:35:06 --> Model Class Initialized
INFO - 2017-07-26 08:35:06 --> Model Class Initialized
INFO - 2017-07-26 08:35:06 --> Controller Class Initialized
INFO - 2017-07-26 08:35:06 --> Model Class Initialized
INFO - 2017-07-26 08:35:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:35:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:35:06 --> Final output sent to browser
DEBUG - 2017-07-26 08:35:06 --> Total execution time: 0.0265
DEBUG - 2017-07-26 08:35:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:35:06 --> Database Forge Class Initialized
INFO - 2017-07-26 08:35:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:35:11 --> Config Class Initialized
INFO - 2017-07-26 08:35:11 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:35:11 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:35:11 --> Utf8 Class Initialized
INFO - 2017-07-26 08:35:11 --> URI Class Initialized
INFO - 2017-07-26 08:35:11 --> Router Class Initialized
INFO - 2017-07-26 08:35:11 --> Output Class Initialized
INFO - 2017-07-26 08:35:11 --> Security Class Initialized
DEBUG - 2017-07-26 08:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:35:11 --> Input Class Initialized
INFO - 2017-07-26 08:35:11 --> Language Class Initialized
ERROR - 2017-07-26 08:35:11 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:37:54 --> Config Class Initialized
INFO - 2017-07-26 08:37:54 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:37:54 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:37:54 --> Utf8 Class Initialized
INFO - 2017-07-26 08:37:54 --> URI Class Initialized
INFO - 2017-07-26 08:37:54 --> Router Class Initialized
INFO - 2017-07-26 08:37:54 --> Output Class Initialized
INFO - 2017-07-26 08:37:54 --> Security Class Initialized
DEBUG - 2017-07-26 08:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:37:54 --> Input Class Initialized
INFO - 2017-07-26 08:37:54 --> Language Class Initialized
INFO - 2017-07-26 08:37:54 --> Loader Class Initialized
INFO - 2017-07-26 08:37:54 --> Helper loaded: url_helper
INFO - 2017-07-26 08:37:54 --> Helper loaded: form_helper
INFO - 2017-07-26 08:37:54 --> Helper loaded: security_helper
INFO - 2017-07-26 08:37:54 --> Helper loaded: path_helper
INFO - 2017-07-26 08:37:54 --> Helper loaded: common_helper
INFO - 2017-07-26 08:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:37:54 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:37:54 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:37:54 --> Email Class Initialized
INFO - 2017-07-26 08:37:54 --> Form Validation Class Initialized
INFO - 2017-07-26 08:37:54 --> Model Class Initialized
INFO - 2017-07-26 08:37:54 --> Model Class Initialized
INFO - 2017-07-26 08:37:54 --> Model Class Initialized
INFO - 2017-07-26 08:37:54 --> Model Class Initialized
INFO - 2017-07-26 08:37:54 --> Controller Class Initialized
INFO - 2017-07-26 08:37:54 --> Model Class Initialized
INFO - 2017-07-26 08:37:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:37:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:37:54 --> Final output sent to browser
DEBUG - 2017-07-26 08:37:54 --> Total execution time: 0.0276
DEBUG - 2017-07-26 08:37:54 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:37:54 --> Database Forge Class Initialized
INFO - 2017-07-26 08:37:54 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:38:30 --> Config Class Initialized
INFO - 2017-07-26 08:38:30 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:38:30 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:38:30 --> Utf8 Class Initialized
INFO - 2017-07-26 08:38:30 --> URI Class Initialized
DEBUG - 2017-07-26 08:38:30 --> No URI present. Default controller set.
INFO - 2017-07-26 08:38:30 --> Router Class Initialized
INFO - 2017-07-26 08:38:30 --> Output Class Initialized
INFO - 2017-07-26 08:38:30 --> Security Class Initialized
DEBUG - 2017-07-26 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:38:30 --> Input Class Initialized
INFO - 2017-07-26 08:38:30 --> Language Class Initialized
INFO - 2017-07-26 08:38:30 --> Loader Class Initialized
INFO - 2017-07-26 08:38:30 --> Helper loaded: url_helper
INFO - 2017-07-26 08:38:30 --> Helper loaded: form_helper
INFO - 2017-07-26 08:38:30 --> Helper loaded: security_helper
INFO - 2017-07-26 08:38:30 --> Helper loaded: path_helper
INFO - 2017-07-26 08:38:30 --> Helper loaded: common_helper
INFO - 2017-07-26 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:38:30 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:38:30 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:38:30 --> Email Class Initialized
INFO - 2017-07-26 08:38:30 --> Form Validation Class Initialized
INFO - 2017-07-26 08:38:30 --> Model Class Initialized
INFO - 2017-07-26 08:38:30 --> Model Class Initialized
INFO - 2017-07-26 08:38:30 --> Model Class Initialized
INFO - 2017-07-26 08:38:30 --> Model Class Initialized
INFO - 2017-07-26 08:38:30 --> Controller Class Initialized
DEBUG - 2017-07-26 08:38:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:38:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 08:38:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 08:38:30 --> Final output sent to browser
DEBUG - 2017-07-26 08:38:30 --> Total execution time: 0.1413
DEBUG - 2017-07-26 08:38:30 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:38:30 --> Database Forge Class Initialized
INFO - 2017-07-26 08:38:30 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:45:47 --> Config Class Initialized
INFO - 2017-07-26 08:45:47 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:45:47 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:45:47 --> Utf8 Class Initialized
INFO - 2017-07-26 08:45:47 --> URI Class Initialized
INFO - 2017-07-26 08:45:47 --> Router Class Initialized
INFO - 2017-07-26 08:45:47 --> Output Class Initialized
INFO - 2017-07-26 08:45:47 --> Security Class Initialized
DEBUG - 2017-07-26 08:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:45:47 --> Input Class Initialized
INFO - 2017-07-26 08:45:47 --> Language Class Initialized
INFO - 2017-07-26 08:45:47 --> Loader Class Initialized
INFO - 2017-07-26 08:45:47 --> Helper loaded: url_helper
INFO - 2017-07-26 08:45:47 --> Helper loaded: form_helper
INFO - 2017-07-26 08:45:47 --> Helper loaded: security_helper
INFO - 2017-07-26 08:45:47 --> Helper loaded: path_helper
INFO - 2017-07-26 08:45:47 --> Helper loaded: common_helper
INFO - 2017-07-26 08:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:45:47 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:45:47 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:45:47 --> Email Class Initialized
INFO - 2017-07-26 08:45:47 --> Form Validation Class Initialized
INFO - 2017-07-26 08:45:47 --> Model Class Initialized
INFO - 2017-07-26 08:45:47 --> Model Class Initialized
INFO - 2017-07-26 08:45:47 --> Model Class Initialized
INFO - 2017-07-26 08:45:47 --> Model Class Initialized
INFO - 2017-07-26 08:45:47 --> Controller Class Initialized
INFO - 2017-07-26 08:45:47 --> Model Class Initialized
INFO - 2017-07-26 08:45:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:45:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:45:47 --> Final output sent to browser
DEBUG - 2017-07-26 08:45:47 --> Total execution time: 0.0289
DEBUG - 2017-07-26 08:45:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:45:47 --> Database Forge Class Initialized
INFO - 2017-07-26 08:45:47 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:45:50 --> Config Class Initialized
INFO - 2017-07-26 08:45:50 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:45:50 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:45:50 --> Utf8 Class Initialized
INFO - 2017-07-26 08:45:50 --> URI Class Initialized
INFO - 2017-07-26 08:45:50 --> Router Class Initialized
INFO - 2017-07-26 08:45:50 --> Output Class Initialized
INFO - 2017-07-26 08:45:50 --> Security Class Initialized
DEBUG - 2017-07-26 08:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:45:50 --> Input Class Initialized
INFO - 2017-07-26 08:45:50 --> Language Class Initialized
ERROR - 2017-07-26 08:45:50 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:48:35 --> Config Class Initialized
INFO - 2017-07-26 08:48:35 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:48:35 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:48:35 --> Utf8 Class Initialized
INFO - 2017-07-26 08:48:35 --> URI Class Initialized
INFO - 2017-07-26 08:48:35 --> Router Class Initialized
INFO - 2017-07-26 08:48:35 --> Output Class Initialized
INFO - 2017-07-26 08:48:35 --> Security Class Initialized
DEBUG - 2017-07-26 08:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:48:35 --> Input Class Initialized
INFO - 2017-07-26 08:48:35 --> Language Class Initialized
INFO - 2017-07-26 08:48:35 --> Loader Class Initialized
INFO - 2017-07-26 08:48:35 --> Helper loaded: url_helper
INFO - 2017-07-26 08:48:35 --> Helper loaded: form_helper
INFO - 2017-07-26 08:48:35 --> Helper loaded: security_helper
INFO - 2017-07-26 08:48:35 --> Helper loaded: path_helper
INFO - 2017-07-26 08:48:35 --> Helper loaded: common_helper
INFO - 2017-07-26 08:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:48:35 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:48:35 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:48:35 --> Email Class Initialized
INFO - 2017-07-26 08:48:35 --> Form Validation Class Initialized
INFO - 2017-07-26 08:48:35 --> Model Class Initialized
INFO - 2017-07-26 08:48:35 --> Model Class Initialized
INFO - 2017-07-26 08:48:35 --> Model Class Initialized
INFO - 2017-07-26 08:48:35 --> Model Class Initialized
INFO - 2017-07-26 08:48:35 --> Controller Class Initialized
INFO - 2017-07-26 08:48:35 --> Model Class Initialized
INFO - 2017-07-26 08:48:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:48:35 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:48:35 --> Config Class Initialized
INFO - 2017-07-26 08:48:35 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:48:35 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:48:35 --> Utf8 Class Initialized
INFO - 2017-07-26 08:48:35 --> URI Class Initialized
INFO - 2017-07-26 08:48:35 --> Router Class Initialized
INFO - 2017-07-26 08:48:35 --> Output Class Initialized
INFO - 2017-07-26 08:48:35 --> Security Class Initialized
DEBUG - 2017-07-26 08:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:48:35 --> Input Class Initialized
INFO - 2017-07-26 08:48:35 --> Language Class Initialized
ERROR - 2017-07-26 08:48:35 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 08:56:06 --> Config Class Initialized
INFO - 2017-07-26 08:56:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:56:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:56:06 --> Utf8 Class Initialized
INFO - 2017-07-26 08:56:06 --> URI Class Initialized
INFO - 2017-07-26 08:56:06 --> Router Class Initialized
INFO - 2017-07-26 08:56:06 --> Output Class Initialized
INFO - 2017-07-26 08:56:06 --> Security Class Initialized
DEBUG - 2017-07-26 08:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:56:06 --> Input Class Initialized
INFO - 2017-07-26 08:56:06 --> Language Class Initialized
INFO - 2017-07-26 08:56:06 --> Loader Class Initialized
INFO - 2017-07-26 08:56:06 --> Helper loaded: url_helper
INFO - 2017-07-26 08:56:06 --> Helper loaded: form_helper
INFO - 2017-07-26 08:56:06 --> Helper loaded: security_helper
INFO - 2017-07-26 08:56:06 --> Helper loaded: path_helper
INFO - 2017-07-26 08:56:06 --> Helper loaded: common_helper
INFO - 2017-07-26 08:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:56:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:56:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:56:06 --> Email Class Initialized
INFO - 2017-07-26 08:56:06 --> Form Validation Class Initialized
INFO - 2017-07-26 08:56:06 --> Model Class Initialized
INFO - 2017-07-26 08:56:06 --> Model Class Initialized
INFO - 2017-07-26 08:56:06 --> Model Class Initialized
INFO - 2017-07-26 08:56:06 --> Model Class Initialized
INFO - 2017-07-26 08:56:06 --> Controller Class Initialized
INFO - 2017-07-26 08:56:06 --> Model Class Initialized
INFO - 2017-07-26 08:56:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:56:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:56:06 --> Final output sent to browser
DEBUG - 2017-07-26 08:56:06 --> Total execution time: 0.0310
DEBUG - 2017-07-26 08:56:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:56:06 --> Database Forge Class Initialized
INFO - 2017-07-26 08:56:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:56:08 --> Config Class Initialized
INFO - 2017-07-26 08:56:08 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:56:08 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:56:08 --> Utf8 Class Initialized
INFO - 2017-07-26 08:56:08 --> URI Class Initialized
INFO - 2017-07-26 08:56:08 --> Router Class Initialized
INFO - 2017-07-26 08:56:08 --> Output Class Initialized
INFO - 2017-07-26 08:56:08 --> Security Class Initialized
DEBUG - 2017-07-26 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:56:08 --> Input Class Initialized
INFO - 2017-07-26 08:56:08 --> Language Class Initialized
ERROR - 2017-07-26 08:56:08 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 08:57:08 --> Config Class Initialized
INFO - 2017-07-26 08:57:08 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:08 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:08 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:08 --> URI Class Initialized
INFO - 2017-07-26 08:57:08 --> Router Class Initialized
INFO - 2017-07-26 08:57:08 --> Output Class Initialized
INFO - 2017-07-26 08:57:08 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:08 --> Input Class Initialized
INFO - 2017-07-26 08:57:08 --> Language Class Initialized
INFO - 2017-07-26 08:57:08 --> Loader Class Initialized
INFO - 2017-07-26 08:57:08 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:08 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:08 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:08 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:08 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:08 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:08 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:08 --> Email Class Initialized
INFO - 2017-07-26 08:57:08 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:08 --> Model Class Initialized
INFO - 2017-07-26 08:57:08 --> Model Class Initialized
INFO - 2017-07-26 08:57:08 --> Model Class Initialized
INFO - 2017-07-26 08:57:08 --> Model Class Initialized
INFO - 2017-07-26 08:57:08 --> Controller Class Initialized
INFO - 2017-07-26 08:57:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 08:57:08 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:08 --> Total execution time: 0.0295
DEBUG - 2017-07-26 08:57:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:08 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:08 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:10 --> Config Class Initialized
INFO - 2017-07-26 08:57:10 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:10 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:10 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:10 --> URI Class Initialized
INFO - 2017-07-26 08:57:10 --> Router Class Initialized
INFO - 2017-07-26 08:57:10 --> Output Class Initialized
INFO - 2017-07-26 08:57:10 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:10 --> Input Class Initialized
INFO - 2017-07-26 08:57:10 --> Language Class Initialized
ERROR - 2017-07-26 08:57:10 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 08:57:10 --> Config Class Initialized
INFO - 2017-07-26 08:57:10 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:10 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:10 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:10 --> URI Class Initialized
INFO - 2017-07-26 08:57:10 --> Router Class Initialized
INFO - 2017-07-26 08:57:10 --> Output Class Initialized
INFO - 2017-07-26 08:57:10 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:10 --> Input Class Initialized
INFO - 2017-07-26 08:57:10 --> Language Class Initialized
ERROR - 2017-07-26 08:57:10 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 08:57:14 --> Config Class Initialized
INFO - 2017-07-26 08:57:14 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:14 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:14 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:14 --> URI Class Initialized
INFO - 2017-07-26 08:57:14 --> Router Class Initialized
INFO - 2017-07-26 08:57:14 --> Output Class Initialized
INFO - 2017-07-26 08:57:14 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:14 --> Input Class Initialized
INFO - 2017-07-26 08:57:14 --> Language Class Initialized
INFO - 2017-07-26 08:57:14 --> Loader Class Initialized
INFO - 2017-07-26 08:57:14 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:14 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:14 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:14 --> Email Class Initialized
INFO - 2017-07-26 08:57:14 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Controller Class Initialized
INFO - 2017-07-26 08:57:14 --> Config Class Initialized
INFO - 2017-07-26 08:57:14 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:14 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:14 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:14 --> URI Class Initialized
INFO - 2017-07-26 08:57:14 --> Router Class Initialized
INFO - 2017-07-26 08:57:14 --> Output Class Initialized
INFO - 2017-07-26 08:57:14 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:14 --> Input Class Initialized
INFO - 2017-07-26 08:57:14 --> Language Class Initialized
INFO - 2017-07-26 08:57:14 --> Loader Class Initialized
INFO - 2017-07-26 08:57:14 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:14 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:14 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:14 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:14 --> Email Class Initialized
INFO - 2017-07-26 08:57:14 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Model Class Initialized
INFO - 2017-07-26 08:57:14 --> Controller Class Initialized
INFO - 2017-07-26 08:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-26 08:57:14 --> Pagination Class Initialized
INFO - 2017-07-26 08:57:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 08:57:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-07-26 08:57:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 08:57:14 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:14 --> Total execution time: 0.1264
DEBUG - 2017-07-26 08:57:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:14 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:14 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:37 --> Config Class Initialized
INFO - 2017-07-26 08:57:37 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:37 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:37 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:37 --> URI Class Initialized
INFO - 2017-07-26 08:57:37 --> Router Class Initialized
INFO - 2017-07-26 08:57:38 --> Output Class Initialized
INFO - 2017-07-26 08:57:38 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:38 --> Input Class Initialized
INFO - 2017-07-26 08:57:38 --> Language Class Initialized
INFO - 2017-07-26 08:57:38 --> Loader Class Initialized
INFO - 2017-07-26 08:57:38 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:38 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:38 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:38 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:38 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:38 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:38 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:38 --> Email Class Initialized
INFO - 2017-07-26 08:57:38 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:38 --> Model Class Initialized
INFO - 2017-07-26 08:57:38 --> Model Class Initialized
INFO - 2017-07-26 08:57:38 --> Model Class Initialized
INFO - 2017-07-26 08:57:38 --> Model Class Initialized
INFO - 2017-07-26 08:57:38 --> Controller Class Initialized
INFO - 2017-07-26 08:57:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 08:57:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-26 08:57:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 08:57:38 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:38 --> Total execution time: 0.0878
DEBUG - 2017-07-26 08:57:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:38 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:38 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:43 --> Config Class Initialized
INFO - 2017-07-26 08:57:43 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:43 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:43 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:43 --> URI Class Initialized
INFO - 2017-07-26 08:57:43 --> Router Class Initialized
INFO - 2017-07-26 08:57:43 --> Output Class Initialized
INFO - 2017-07-26 08:57:43 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:43 --> Input Class Initialized
INFO - 2017-07-26 08:57:43 --> Language Class Initialized
INFO - 2017-07-26 08:57:43 --> Loader Class Initialized
INFO - 2017-07-26 08:57:43 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:43 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:43 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:43 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:43 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:43 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:43 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:43 --> Email Class Initialized
INFO - 2017-07-26 08:57:43 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:43 --> Model Class Initialized
INFO - 2017-07-26 08:57:43 --> Model Class Initialized
INFO - 2017-07-26 08:57:43 --> Model Class Initialized
INFO - 2017-07-26 08:57:43 --> Model Class Initialized
INFO - 2017-07-26 08:57:43 --> Controller Class Initialized
DEBUG - 2017-07-26 08:57:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 08:57:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-07-26 08:57:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 08:57:43 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:43 --> Total execution time: 0.0458
DEBUG - 2017-07-26 08:57:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:43 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:43 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:53 --> Config Class Initialized
INFO - 2017-07-26 08:57:53 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:53 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:53 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:53 --> URI Class Initialized
INFO - 2017-07-26 08:57:53 --> Router Class Initialized
INFO - 2017-07-26 08:57:53 --> Output Class Initialized
INFO - 2017-07-26 08:57:53 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:53 --> Input Class Initialized
INFO - 2017-07-26 08:57:53 --> Language Class Initialized
INFO - 2017-07-26 08:57:53 --> Loader Class Initialized
INFO - 2017-07-26 08:57:53 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:53 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:53 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:53 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:53 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:53 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:53 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:53 --> Email Class Initialized
INFO - 2017-07-26 08:57:53 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:53 --> Model Class Initialized
INFO - 2017-07-26 08:57:53 --> Model Class Initialized
INFO - 2017-07-26 08:57:53 --> Model Class Initialized
INFO - 2017-07-26 08:57:53 --> Model Class Initialized
INFO - 2017-07-26 08:57:53 --> Controller Class Initialized
DEBUG - 2017-07-26 08:57:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 08:57:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-07-26 08:57:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 08:57:53 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:53 --> Total execution time: 0.0363
DEBUG - 2017-07-26 08:57:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:53 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:53 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:57 --> Config Class Initialized
INFO - 2017-07-26 08:57:57 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:57:57 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:57:57 --> Utf8 Class Initialized
INFO - 2017-07-26 08:57:57 --> URI Class Initialized
INFO - 2017-07-26 08:57:57 --> Router Class Initialized
INFO - 2017-07-26 08:57:57 --> Output Class Initialized
INFO - 2017-07-26 08:57:57 --> Security Class Initialized
DEBUG - 2017-07-26 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:57:57 --> Input Class Initialized
INFO - 2017-07-26 08:57:57 --> Language Class Initialized
INFO - 2017-07-26 08:57:57 --> Loader Class Initialized
INFO - 2017-07-26 08:57:57 --> Helper loaded: url_helper
INFO - 2017-07-26 08:57:57 --> Helper loaded: form_helper
INFO - 2017-07-26 08:57:57 --> Helper loaded: security_helper
INFO - 2017-07-26 08:57:57 --> Helper loaded: path_helper
INFO - 2017-07-26 08:57:57 --> Helper loaded: common_helper
INFO - 2017-07-26 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:57:57 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:57:57 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:57:57 --> Email Class Initialized
INFO - 2017-07-26 08:57:57 --> Form Validation Class Initialized
INFO - 2017-07-26 08:57:57 --> Model Class Initialized
INFO - 2017-07-26 08:57:57 --> Model Class Initialized
INFO - 2017-07-26 08:57:57 --> Model Class Initialized
INFO - 2017-07-26 08:57:57 --> Model Class Initialized
INFO - 2017-07-26 08:57:57 --> Controller Class Initialized
INFO - 2017-07-26 08:57:57 --> Model Class Initialized
INFO - 2017-07-26 08:57:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:57:57 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:57:57 --> Final output sent to browser
DEBUG - 2017-07-26 08:57:57 --> Total execution time: 0.0272
DEBUG - 2017-07-26 08:57:57 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:57:57 --> Database Forge Class Initialized
INFO - 2017-07-26 08:57:57 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:59:42 --> Config Class Initialized
INFO - 2017-07-26 08:59:42 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:59:42 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:59:42 --> Utf8 Class Initialized
INFO - 2017-07-26 08:59:42 --> URI Class Initialized
INFO - 2017-07-26 08:59:42 --> Router Class Initialized
INFO - 2017-07-26 08:59:42 --> Output Class Initialized
INFO - 2017-07-26 08:59:42 --> Security Class Initialized
DEBUG - 2017-07-26 08:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:59:42 --> Input Class Initialized
INFO - 2017-07-26 08:59:42 --> Language Class Initialized
INFO - 2017-07-26 08:59:42 --> Loader Class Initialized
INFO - 2017-07-26 08:59:42 --> Helper loaded: url_helper
INFO - 2017-07-26 08:59:42 --> Helper loaded: form_helper
INFO - 2017-07-26 08:59:42 --> Helper loaded: security_helper
INFO - 2017-07-26 08:59:42 --> Helper loaded: path_helper
INFO - 2017-07-26 08:59:42 --> Helper loaded: common_helper
INFO - 2017-07-26 08:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 08:59:42 --> Helper loaded: check_session_helper
INFO - 2017-07-26 08:59:42 --> Database Driver Class Initialized
DEBUG - 2017-07-26 08:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:59:42 --> Email Class Initialized
INFO - 2017-07-26 08:59:42 --> Form Validation Class Initialized
INFO - 2017-07-26 08:59:42 --> Model Class Initialized
INFO - 2017-07-26 08:59:42 --> Model Class Initialized
INFO - 2017-07-26 08:59:42 --> Model Class Initialized
INFO - 2017-07-26 08:59:42 --> Model Class Initialized
INFO - 2017-07-26 08:59:42 --> Controller Class Initialized
INFO - 2017-07-26 08:59:42 --> Model Class Initialized
INFO - 2017-07-26 08:59:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 08:59:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 08:59:42 --> Final output sent to browser
DEBUG - 2017-07-26 08:59:42 --> Total execution time: 0.0314
DEBUG - 2017-07-26 08:59:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 08:59:42 --> Database Forge Class Initialized
INFO - 2017-07-26 08:59:42 --> User Agent Class Initialized
DEBUG - 2017-07-26 08:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 08:59:45 --> Config Class Initialized
INFO - 2017-07-26 08:59:45 --> Hooks Class Initialized
DEBUG - 2017-07-26 08:59:45 --> UTF-8 Support Enabled
INFO - 2017-07-26 08:59:45 --> Utf8 Class Initialized
INFO - 2017-07-26 08:59:45 --> URI Class Initialized
INFO - 2017-07-26 08:59:45 --> Router Class Initialized
INFO - 2017-07-26 08:59:45 --> Output Class Initialized
INFO - 2017-07-26 08:59:45 --> Security Class Initialized
DEBUG - 2017-07-26 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 08:59:45 --> Input Class Initialized
INFO - 2017-07-26 08:59:45 --> Language Class Initialized
ERROR - 2017-07-26 08:59:45 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 09:02:54 --> Config Class Initialized
INFO - 2017-07-26 09:02:54 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:02:54 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:02:54 --> Utf8 Class Initialized
INFO - 2017-07-26 09:02:54 --> URI Class Initialized
INFO - 2017-07-26 09:02:54 --> Router Class Initialized
INFO - 2017-07-26 09:02:54 --> Output Class Initialized
INFO - 2017-07-26 09:02:54 --> Security Class Initialized
DEBUG - 2017-07-26 09:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:02:54 --> Input Class Initialized
INFO - 2017-07-26 09:02:54 --> Language Class Initialized
INFO - 2017-07-26 09:02:54 --> Loader Class Initialized
INFO - 2017-07-26 09:02:54 --> Helper loaded: url_helper
INFO - 2017-07-26 09:02:54 --> Helper loaded: form_helper
INFO - 2017-07-26 09:02:54 --> Helper loaded: security_helper
INFO - 2017-07-26 09:02:54 --> Helper loaded: path_helper
INFO - 2017-07-26 09:02:54 --> Helper loaded: common_helper
INFO - 2017-07-26 09:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:02:54 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:02:54 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:02:54 --> Email Class Initialized
INFO - 2017-07-26 09:02:54 --> Form Validation Class Initialized
INFO - 2017-07-26 09:02:54 --> Model Class Initialized
INFO - 2017-07-26 09:02:54 --> Model Class Initialized
INFO - 2017-07-26 09:02:54 --> Model Class Initialized
INFO - 2017-07-26 09:02:54 --> Model Class Initialized
INFO - 2017-07-26 09:02:54 --> Controller Class Initialized
INFO - 2017-07-26 09:02:54 --> Model Class Initialized
INFO - 2017-07-26 09:02:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 09:02:54 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 09:02:54 --> Final output sent to browser
DEBUG - 2017-07-26 09:02:54 --> Total execution time: 0.0294
DEBUG - 2017-07-26 09:02:54 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:02:54 --> Database Forge Class Initialized
INFO - 2017-07-26 09:02:54 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:07:26 --> Config Class Initialized
INFO - 2017-07-26 09:07:26 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:07:26 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:07:26 --> Utf8 Class Initialized
INFO - 2017-07-26 09:07:26 --> URI Class Initialized
DEBUG - 2017-07-26 09:07:26 --> No URI present. Default controller set.
INFO - 2017-07-26 09:07:26 --> Router Class Initialized
INFO - 2017-07-26 09:07:26 --> Output Class Initialized
INFO - 2017-07-26 09:07:26 --> Security Class Initialized
DEBUG - 2017-07-26 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:07:26 --> Input Class Initialized
INFO - 2017-07-26 09:07:26 --> Language Class Initialized
INFO - 2017-07-26 09:07:26 --> Loader Class Initialized
INFO - 2017-07-26 09:07:26 --> Helper loaded: url_helper
INFO - 2017-07-26 09:07:26 --> Helper loaded: form_helper
INFO - 2017-07-26 09:07:26 --> Helper loaded: security_helper
INFO - 2017-07-26 09:07:26 --> Helper loaded: path_helper
INFO - 2017-07-26 09:07:26 --> Helper loaded: common_helper
INFO - 2017-07-26 09:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:07:26 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:07:26 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:07:26 --> Email Class Initialized
INFO - 2017-07-26 09:07:26 --> Form Validation Class Initialized
INFO - 2017-07-26 09:07:26 --> Model Class Initialized
INFO - 2017-07-26 09:07:26 --> Model Class Initialized
INFO - 2017-07-26 09:07:26 --> Model Class Initialized
INFO - 2017-07-26 09:07:26 --> Model Class Initialized
INFO - 2017-07-26 09:07:26 --> Controller Class Initialized
DEBUG - 2017-07-26 09:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:07:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 09:07:26 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 09:07:26 --> Final output sent to browser
DEBUG - 2017-07-26 09:07:26 --> Total execution time: 0.0288
DEBUG - 2017-07-26 09:07:26 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:07:26 --> Database Forge Class Initialized
INFO - 2017-07-26 09:07:26 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:06 --> Config Class Initialized
INFO - 2017-07-26 09:10:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:06 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:06 --> URI Class Initialized
INFO - 2017-07-26 09:10:06 --> Router Class Initialized
INFO - 2017-07-26 09:10:06 --> Output Class Initialized
INFO - 2017-07-26 09:10:06 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:06 --> Input Class Initialized
INFO - 2017-07-26 09:10:06 --> Language Class Initialized
INFO - 2017-07-26 09:10:06 --> Loader Class Initialized
INFO - 2017-07-26 09:10:06 --> Helper loaded: url_helper
INFO - 2017-07-26 09:10:06 --> Helper loaded: form_helper
INFO - 2017-07-26 09:10:06 --> Helper loaded: security_helper
INFO - 2017-07-26 09:10:06 --> Helper loaded: path_helper
INFO - 2017-07-26 09:10:06 --> Helper loaded: common_helper
INFO - 2017-07-26 09:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:10:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:10:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:06 --> Email Class Initialized
INFO - 2017-07-26 09:10:06 --> Form Validation Class Initialized
INFO - 2017-07-26 09:10:06 --> Model Class Initialized
INFO - 2017-07-26 09:10:06 --> Model Class Initialized
INFO - 2017-07-26 09:10:06 --> Model Class Initialized
INFO - 2017-07-26 09:10:06 --> Model Class Initialized
INFO - 2017-07-26 09:10:06 --> Controller Class Initialized
INFO - 2017-07-26 09:10:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 09:10:06 --> Final output sent to browser
DEBUG - 2017-07-26 09:10:06 --> Total execution time: 0.0281
DEBUG - 2017-07-26 09:10:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:10:06 --> Database Forge Class Initialized
INFO - 2017-07-26 09:10:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:06 --> Config Class Initialized
INFO - 2017-07-26 09:10:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:06 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:06 --> URI Class Initialized
INFO - 2017-07-26 09:10:06 --> Router Class Initialized
INFO - 2017-07-26 09:10:06 --> Output Class Initialized
INFO - 2017-07-26 09:10:06 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:06 --> Input Class Initialized
INFO - 2017-07-26 09:10:06 --> Language Class Initialized
ERROR - 2017-07-26 09:10:06 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 09:10:08 --> Config Class Initialized
INFO - 2017-07-26 09:10:08 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:08 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:08 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:08 --> URI Class Initialized
DEBUG - 2017-07-26 09:10:08 --> No URI present. Default controller set.
INFO - 2017-07-26 09:10:08 --> Router Class Initialized
INFO - 2017-07-26 09:10:08 --> Output Class Initialized
INFO - 2017-07-26 09:10:08 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:08 --> Input Class Initialized
INFO - 2017-07-26 09:10:08 --> Language Class Initialized
INFO - 2017-07-26 09:10:09 --> Loader Class Initialized
INFO - 2017-07-26 09:10:09 --> Helper loaded: url_helper
INFO - 2017-07-26 09:10:09 --> Helper loaded: form_helper
INFO - 2017-07-26 09:10:09 --> Helper loaded: security_helper
INFO - 2017-07-26 09:10:09 --> Helper loaded: path_helper
INFO - 2017-07-26 09:10:09 --> Helper loaded: common_helper
INFO - 2017-07-26 09:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:10:09 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:10:09 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:09 --> Email Class Initialized
INFO - 2017-07-26 09:10:09 --> Form Validation Class Initialized
INFO - 2017-07-26 09:10:09 --> Model Class Initialized
INFO - 2017-07-26 09:10:09 --> Model Class Initialized
INFO - 2017-07-26 09:10:09 --> Model Class Initialized
INFO - 2017-07-26 09:10:09 --> Model Class Initialized
INFO - 2017-07-26 09:10:09 --> Controller Class Initialized
DEBUG - 2017-07-26 09:10:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 09:10:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 09:10:09 --> Final output sent to browser
DEBUG - 2017-07-26 09:10:09 --> Total execution time: 0.0266
DEBUG - 2017-07-26 09:10:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:10:09 --> Database Forge Class Initialized
INFO - 2017-07-26 09:10:09 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:12 --> Config Class Initialized
INFO - 2017-07-26 09:10:12 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:12 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:12 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:12 --> URI Class Initialized
INFO - 2017-07-26 09:10:12 --> Router Class Initialized
INFO - 2017-07-26 09:10:12 --> Output Class Initialized
INFO - 2017-07-26 09:10:12 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:12 --> Input Class Initialized
INFO - 2017-07-26 09:10:12 --> Language Class Initialized
INFO - 2017-07-26 09:10:12 --> Loader Class Initialized
INFO - 2017-07-26 09:10:12 --> Helper loaded: url_helper
INFO - 2017-07-26 09:10:12 --> Helper loaded: form_helper
INFO - 2017-07-26 09:10:12 --> Helper loaded: security_helper
INFO - 2017-07-26 09:10:12 --> Helper loaded: path_helper
INFO - 2017-07-26 09:10:12 --> Helper loaded: common_helper
INFO - 2017-07-26 09:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:10:12 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:10:12 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:12 --> Email Class Initialized
INFO - 2017-07-26 09:10:12 --> Form Validation Class Initialized
INFO - 2017-07-26 09:10:12 --> Model Class Initialized
INFO - 2017-07-26 09:10:12 --> Model Class Initialized
INFO - 2017-07-26 09:10:12 --> Model Class Initialized
INFO - 2017-07-26 09:10:12 --> Model Class Initialized
INFO - 2017-07-26 09:10:12 --> Controller Class Initialized
INFO - 2017-07-26 09:10:12 --> Model Class Initialized
INFO - 2017-07-26 09:10:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 09:10:12 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 09:10:12 --> Final output sent to browser
DEBUG - 2017-07-26 09:10:12 --> Total execution time: 0.0335
DEBUG - 2017-07-26 09:10:12 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:10:12 --> Database Forge Class Initialized
INFO - 2017-07-26 09:10:12 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:27 --> Config Class Initialized
INFO - 2017-07-26 09:10:27 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:27 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:27 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:27 --> URI Class Initialized
INFO - 2017-07-26 09:10:27 --> Router Class Initialized
INFO - 2017-07-26 09:10:27 --> Output Class Initialized
INFO - 2017-07-26 09:10:27 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:27 --> Input Class Initialized
INFO - 2017-07-26 09:10:27 --> Language Class Initialized
INFO - 2017-07-26 09:10:27 --> Loader Class Initialized
INFO - 2017-07-26 09:10:27 --> Helper loaded: url_helper
INFO - 2017-07-26 09:10:27 --> Helper loaded: form_helper
INFO - 2017-07-26 09:10:27 --> Helper loaded: security_helper
INFO - 2017-07-26 09:10:27 --> Helper loaded: path_helper
INFO - 2017-07-26 09:10:27 --> Helper loaded: common_helper
INFO - 2017-07-26 09:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:10:27 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:10:27 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:27 --> Email Class Initialized
INFO - 2017-07-26 09:10:27 --> Form Validation Class Initialized
INFO - 2017-07-26 09:10:27 --> Model Class Initialized
INFO - 2017-07-26 09:10:27 --> Model Class Initialized
INFO - 2017-07-26 09:10:27 --> Model Class Initialized
INFO - 2017-07-26 09:10:27 --> Model Class Initialized
INFO - 2017-07-26 09:10:27 --> Controller Class Initialized
INFO - 2017-07-26 09:10:27 --> Model Class Initialized
INFO - 2017-07-26 09:10:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 09:10:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 09:10:27 --> Final output sent to browser
DEBUG - 2017-07-26 09:10:27 --> Total execution time: 0.0289
DEBUG - 2017-07-26 09:10:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:10:27 --> Database Forge Class Initialized
INFO - 2017-07-26 09:10:27 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:10:29 --> Config Class Initialized
INFO - 2017-07-26 09:10:29 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:10:29 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:10:29 --> Utf8 Class Initialized
INFO - 2017-07-26 09:10:29 --> URI Class Initialized
INFO - 2017-07-26 09:10:29 --> Router Class Initialized
INFO - 2017-07-26 09:10:29 --> Output Class Initialized
INFO - 2017-07-26 09:10:29 --> Security Class Initialized
DEBUG - 2017-07-26 09:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:10:29 --> Input Class Initialized
INFO - 2017-07-26 09:10:29 --> Language Class Initialized
ERROR - 2017-07-26 09:10:29 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 09:15:28 --> Config Class Initialized
INFO - 2017-07-26 09:15:28 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:28 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:28 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:28 --> URI Class Initialized
INFO - 2017-07-26 09:15:28 --> Router Class Initialized
INFO - 2017-07-26 09:15:28 --> Output Class Initialized
INFO - 2017-07-26 09:15:28 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:28 --> Input Class Initialized
INFO - 2017-07-26 09:15:28 --> Language Class Initialized
INFO - 2017-07-26 09:15:28 --> Loader Class Initialized
INFO - 2017-07-26 09:15:28 --> Helper loaded: url_helper
INFO - 2017-07-26 09:15:28 --> Helper loaded: form_helper
INFO - 2017-07-26 09:15:28 --> Helper loaded: security_helper
INFO - 2017-07-26 09:15:28 --> Helper loaded: path_helper
INFO - 2017-07-26 09:15:28 --> Helper loaded: common_helper
INFO - 2017-07-26 09:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:15:28 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:15:28 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:28 --> Email Class Initialized
INFO - 2017-07-26 09:15:28 --> Form Validation Class Initialized
INFO - 2017-07-26 09:15:28 --> Model Class Initialized
INFO - 2017-07-26 09:15:28 --> Model Class Initialized
INFO - 2017-07-26 09:15:28 --> Model Class Initialized
INFO - 2017-07-26 09:15:28 --> Model Class Initialized
INFO - 2017-07-26 09:15:28 --> Controller Class Initialized
INFO - 2017-07-26 09:15:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 09:15:28 --> Final output sent to browser
DEBUG - 2017-07-26 09:15:28 --> Total execution time: 0.0292
DEBUG - 2017-07-26 09:15:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:15:28 --> Database Forge Class Initialized
INFO - 2017-07-26 09:15:28 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:28 --> Config Class Initialized
INFO - 2017-07-26 09:15:28 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:28 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:28 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:28 --> URI Class Initialized
INFO - 2017-07-26 09:15:28 --> Router Class Initialized
INFO - 2017-07-26 09:15:28 --> Output Class Initialized
INFO - 2017-07-26 09:15:28 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:28 --> Input Class Initialized
INFO - 2017-07-26 09:15:28 --> Language Class Initialized
ERROR - 2017-07-26 09:15:28 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 09:15:36 --> Config Class Initialized
INFO - 2017-07-26 09:15:36 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:36 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:36 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:36 --> URI Class Initialized
INFO - 2017-07-26 09:15:36 --> Router Class Initialized
INFO - 2017-07-26 09:15:36 --> Output Class Initialized
INFO - 2017-07-26 09:15:36 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:36 --> Input Class Initialized
INFO - 2017-07-26 09:15:36 --> Language Class Initialized
INFO - 2017-07-26 09:15:36 --> Loader Class Initialized
INFO - 2017-07-26 09:15:36 --> Helper loaded: url_helper
INFO - 2017-07-26 09:15:36 --> Helper loaded: form_helper
INFO - 2017-07-26 09:15:36 --> Helper loaded: security_helper
INFO - 2017-07-26 09:15:36 --> Helper loaded: path_helper
INFO - 2017-07-26 09:15:36 --> Helper loaded: common_helper
INFO - 2017-07-26 09:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:15:36 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:15:36 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:36 --> Email Class Initialized
INFO - 2017-07-26 09:15:36 --> Form Validation Class Initialized
INFO - 2017-07-26 09:15:36 --> Model Class Initialized
INFO - 2017-07-26 09:15:36 --> Model Class Initialized
INFO - 2017-07-26 09:15:36 --> Model Class Initialized
INFO - 2017-07-26 09:15:36 --> Model Class Initialized
INFO - 2017-07-26 09:15:36 --> Controller Class Initialized
INFO - 2017-07-26 09:15:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 09:15:36 --> Final output sent to browser
DEBUG - 2017-07-26 09:15:36 --> Total execution time: 0.0296
DEBUG - 2017-07-26 09:15:36 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:15:36 --> Database Forge Class Initialized
INFO - 2017-07-26 09:15:36 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:38 --> Config Class Initialized
INFO - 2017-07-26 09:15:38 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:38 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:38 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:38 --> URI Class Initialized
INFO - 2017-07-26 09:15:38 --> Router Class Initialized
INFO - 2017-07-26 09:15:38 --> Output Class Initialized
INFO - 2017-07-26 09:15:38 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:38 --> Input Class Initialized
INFO - 2017-07-26 09:15:38 --> Language Class Initialized
ERROR - 2017-07-26 09:15:38 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 09:15:51 --> Config Class Initialized
INFO - 2017-07-26 09:15:51 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:51 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:51 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:51 --> URI Class Initialized
INFO - 2017-07-26 09:15:51 --> Router Class Initialized
INFO - 2017-07-26 09:15:51 --> Output Class Initialized
INFO - 2017-07-26 09:15:51 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:51 --> Input Class Initialized
INFO - 2017-07-26 09:15:51 --> Language Class Initialized
INFO - 2017-07-26 09:15:51 --> Loader Class Initialized
INFO - 2017-07-26 09:15:51 --> Helper loaded: url_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: form_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: security_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: path_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: common_helper
INFO - 2017-07-26 09:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:15:51 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:15:51 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:51 --> Email Class Initialized
INFO - 2017-07-26 09:15:51 --> Form Validation Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:51 --> Controller Class Initialized
INFO - 2017-07-26 09:15:51 --> Config Class Initialized
INFO - 2017-07-26 09:15:51 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:15:51 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:15:51 --> Utf8 Class Initialized
INFO - 2017-07-26 09:15:51 --> URI Class Initialized
INFO - 2017-07-26 09:15:51 --> Router Class Initialized
INFO - 2017-07-26 09:15:51 --> Output Class Initialized
INFO - 2017-07-26 09:15:51 --> Security Class Initialized
DEBUG - 2017-07-26 09:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:15:51 --> Input Class Initialized
INFO - 2017-07-26 09:15:51 --> Language Class Initialized
INFO - 2017-07-26 09:15:51 --> Loader Class Initialized
INFO - 2017-07-26 09:15:51 --> Helper loaded: url_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: form_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: security_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: path_helper
INFO - 2017-07-26 09:15:51 --> Helper loaded: common_helper
INFO - 2017-07-26 09:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:15:51 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:15:51 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:15:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:15:51 --> Email Class Initialized
INFO - 2017-07-26 09:15:51 --> Form Validation Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:51 --> Model Class Initialized
INFO - 2017-07-26 09:15:52 --> Model Class Initialized
INFO - 2017-07-26 09:15:52 --> Model Class Initialized
INFO - 2017-07-26 09:15:52 --> Controller Class Initialized
INFO - 2017-07-26 09:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-26 09:15:52 --> Pagination Class Initialized
INFO - 2017-07-26 09:15:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 09:15:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-07-26 09:15:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 09:15:52 --> Final output sent to browser
DEBUG - 2017-07-26 09:15:52 --> Total execution time: 0.0330
DEBUG - 2017-07-26 09:15:52 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:15:52 --> Database Forge Class Initialized
INFO - 2017-07-26 09:15:52 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:15:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:42 --> Config Class Initialized
INFO - 2017-07-26 09:16:42 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:16:42 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:16:42 --> Utf8 Class Initialized
INFO - 2017-07-26 09:16:42 --> URI Class Initialized
INFO - 2017-07-26 09:16:42 --> Router Class Initialized
INFO - 2017-07-26 09:16:42 --> Output Class Initialized
INFO - 2017-07-26 09:16:42 --> Security Class Initialized
DEBUG - 2017-07-26 09:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:16:42 --> Input Class Initialized
INFO - 2017-07-26 09:16:42 --> Language Class Initialized
INFO - 2017-07-26 09:16:42 --> Loader Class Initialized
INFO - 2017-07-26 09:16:42 --> Helper loaded: url_helper
INFO - 2017-07-26 09:16:42 --> Helper loaded: form_helper
INFO - 2017-07-26 09:16:42 --> Helper loaded: security_helper
INFO - 2017-07-26 09:16:42 --> Helper loaded: path_helper
INFO - 2017-07-26 09:16:42 --> Helper loaded: common_helper
INFO - 2017-07-26 09:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:16:42 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:16:42 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:16:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:42 --> Email Class Initialized
INFO - 2017-07-26 09:16:42 --> Form Validation Class Initialized
INFO - 2017-07-26 09:16:42 --> Model Class Initialized
INFO - 2017-07-26 09:16:42 --> Model Class Initialized
INFO - 2017-07-26 09:16:42 --> Model Class Initialized
INFO - 2017-07-26 09:16:42 --> Model Class Initialized
INFO - 2017-07-26 09:16:42 --> Controller Class Initialized
INFO - 2017-07-26 09:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-26 09:16:42 --> Pagination Class Initialized
INFO - 2017-07-26 09:16:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 09:16:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-07-26 09:16:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 09:16:43 --> Final output sent to browser
DEBUG - 2017-07-26 09:16:43 --> Total execution time: 1.0751
DEBUG - 2017-07-26 09:16:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:16:43 --> Database Forge Class Initialized
INFO - 2017-07-26 09:16:43 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:16:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:47 --> Config Class Initialized
INFO - 2017-07-26 09:16:47 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:16:47 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:16:47 --> Utf8 Class Initialized
INFO - 2017-07-26 09:16:47 --> URI Class Initialized
INFO - 2017-07-26 09:16:47 --> Router Class Initialized
INFO - 2017-07-26 09:16:47 --> Output Class Initialized
INFO - 2017-07-26 09:16:47 --> Security Class Initialized
DEBUG - 2017-07-26 09:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:16:47 --> Input Class Initialized
INFO - 2017-07-26 09:16:47 --> Language Class Initialized
INFO - 2017-07-26 09:16:48 --> Loader Class Initialized
INFO - 2017-07-26 09:16:48 --> Helper loaded: url_helper
INFO - 2017-07-26 09:16:48 --> Helper loaded: form_helper
INFO - 2017-07-26 09:16:48 --> Helper loaded: security_helper
INFO - 2017-07-26 09:16:48 --> Helper loaded: path_helper
INFO - 2017-07-26 09:16:48 --> Helper loaded: common_helper
INFO - 2017-07-26 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:16:48 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:16:48 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:48 --> Email Class Initialized
INFO - 2017-07-26 09:16:48 --> Form Validation Class Initialized
INFO - 2017-07-26 09:16:48 --> Model Class Initialized
INFO - 2017-07-26 09:16:48 --> Model Class Initialized
INFO - 2017-07-26 09:16:48 --> Model Class Initialized
INFO - 2017-07-26 09:16:48 --> Model Class Initialized
INFO - 2017-07-26 09:16:48 --> Controller Class Initialized
INFO - 2017-07-26 09:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-26 09:16:48 --> Pagination Class Initialized
INFO - 2017-07-26 09:16:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 09:16:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managetumorboards.php
INFO - 2017-07-26 09:16:48 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 09:16:48 --> Final output sent to browser
DEBUG - 2017-07-26 09:16:48 --> Total execution time: 0.3332
DEBUG - 2017-07-26 09:16:48 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:16:48 --> Database Forge Class Initialized
INFO - 2017-07-26 09:16:48 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:53 --> Config Class Initialized
INFO - 2017-07-26 09:16:53 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:16:53 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:16:53 --> Utf8 Class Initialized
INFO - 2017-07-26 09:16:53 --> URI Class Initialized
INFO - 2017-07-26 09:16:53 --> Router Class Initialized
INFO - 2017-07-26 09:16:53 --> Output Class Initialized
INFO - 2017-07-26 09:16:53 --> Security Class Initialized
DEBUG - 2017-07-26 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:16:53 --> Input Class Initialized
INFO - 2017-07-26 09:16:53 --> Language Class Initialized
INFO - 2017-07-26 09:16:53 --> Loader Class Initialized
INFO - 2017-07-26 09:16:53 --> Helper loaded: url_helper
INFO - 2017-07-26 09:16:53 --> Helper loaded: form_helper
INFO - 2017-07-26 09:16:53 --> Helper loaded: security_helper
INFO - 2017-07-26 09:16:53 --> Helper loaded: path_helper
INFO - 2017-07-26 09:16:53 --> Helper loaded: common_helper
INFO - 2017-07-26 09:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:16:53 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:16:53 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:16:53 --> Email Class Initialized
INFO - 2017-07-26 09:16:53 --> Form Validation Class Initialized
INFO - 2017-07-26 09:16:53 --> Model Class Initialized
INFO - 2017-07-26 09:16:53 --> Model Class Initialized
INFO - 2017-07-26 09:16:53 --> Model Class Initialized
INFO - 2017-07-26 09:16:53 --> Model Class Initialized
INFO - 2017-07-26 09:16:53 --> Controller Class Initialized
INFO - 2017-07-26 09:16:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-26 09:16:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-26 09:16:53 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 09:16:53 --> Final output sent to browser
DEBUG - 2017-07-26 09:16:53 --> Total execution time: 0.0262
DEBUG - 2017-07-26 09:16:53 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:16:53 --> Database Forge Class Initialized
INFO - 2017-07-26 09:16:53 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:17:14 --> Config Class Initialized
INFO - 2017-07-26 09:17:14 --> Hooks Class Initialized
DEBUG - 2017-07-26 09:17:14 --> UTF-8 Support Enabled
INFO - 2017-07-26 09:17:14 --> Utf8 Class Initialized
INFO - 2017-07-26 09:17:14 --> URI Class Initialized
INFO - 2017-07-26 09:17:14 --> Router Class Initialized
INFO - 2017-07-26 09:17:14 --> Output Class Initialized
INFO - 2017-07-26 09:17:14 --> Security Class Initialized
DEBUG - 2017-07-26 09:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 09:17:14 --> Input Class Initialized
INFO - 2017-07-26 09:17:14 --> Language Class Initialized
INFO - 2017-07-26 09:17:14 --> Loader Class Initialized
INFO - 2017-07-26 09:17:14 --> Helper loaded: url_helper
INFO - 2017-07-26 09:17:14 --> Helper loaded: form_helper
INFO - 2017-07-26 09:17:14 --> Helper loaded: security_helper
INFO - 2017-07-26 09:17:14 --> Helper loaded: path_helper
INFO - 2017-07-26 09:17:14 --> Helper loaded: common_helper
INFO - 2017-07-26 09:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 09:17:14 --> Helper loaded: check_session_helper
INFO - 2017-07-26 09:17:14 --> Database Driver Class Initialized
DEBUG - 2017-07-26 09:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 09:17:14 --> Email Class Initialized
INFO - 2017-07-26 09:17:14 --> Form Validation Class Initialized
INFO - 2017-07-26 09:17:14 --> Model Class Initialized
INFO - 2017-07-26 09:17:14 --> Model Class Initialized
INFO - 2017-07-26 09:17:14 --> Model Class Initialized
INFO - 2017-07-26 09:17:14 --> Model Class Initialized
INFO - 2017-07-26 09:17:14 --> Controller Class Initialized
INFO - 2017-07-26 09:17:15 --> Model Class Initialized
INFO - 2017-07-26 09:17:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
ERROR - 2017-07-26 09:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/regimens.php 57
INFO - 2017-07-26 09:17:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/regimens.php
INFO - 2017-07-26 09:17:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-26 09:17:15 --> Final output sent to browser
DEBUG - 2017-07-26 09:17:15 --> Total execution time: 0.8986
DEBUG - 2017-07-26 09:17:15 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 09:17:15 --> Database Forge Class Initialized
INFO - 2017-07-26 09:17:15 --> User Agent Class Initialized
DEBUG - 2017-07-26 09:17:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:24 --> Config Class Initialized
INFO - 2017-07-26 12:01:24 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:01:24 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:01:24 --> Utf8 Class Initialized
INFO - 2017-07-26 12:01:24 --> URI Class Initialized
INFO - 2017-07-26 12:01:24 --> Router Class Initialized
INFO - 2017-07-26 12:01:24 --> Output Class Initialized
INFO - 2017-07-26 12:01:24 --> Security Class Initialized
DEBUG - 2017-07-26 12:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:01:24 --> Input Class Initialized
INFO - 2017-07-26 12:01:24 --> Language Class Initialized
INFO - 2017-07-26 12:01:24 --> Loader Class Initialized
INFO - 2017-07-26 12:01:24 --> Helper loaded: url_helper
INFO - 2017-07-26 12:01:24 --> Helper loaded: form_helper
INFO - 2017-07-26 12:01:24 --> Helper loaded: security_helper
INFO - 2017-07-26 12:01:24 --> Helper loaded: path_helper
INFO - 2017-07-26 12:01:24 --> Helper loaded: common_helper
INFO - 2017-07-26 12:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:01:24 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:01:24 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:24 --> Email Class Initialized
INFO - 2017-07-26 12:01:24 --> Form Validation Class Initialized
INFO - 2017-07-26 12:01:24 --> Model Class Initialized
INFO - 2017-07-26 12:01:24 --> Model Class Initialized
INFO - 2017-07-26 12:01:24 --> Model Class Initialized
INFO - 2017-07-26 12:01:24 --> Model Class Initialized
INFO - 2017-07-26 12:01:24 --> Controller Class Initialized
INFO - 2017-07-26 12:01:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 12:01:24 --> Final output sent to browser
DEBUG - 2017-07-26 12:01:24 --> Total execution time: 0.0307
DEBUG - 2017-07-26 12:01:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:01:24 --> Database Forge Class Initialized
INFO - 2017-07-26 12:01:24 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:01:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:27 --> Config Class Initialized
INFO - 2017-07-26 12:01:27 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:01:27 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:01:27 --> Utf8 Class Initialized
INFO - 2017-07-26 12:01:27 --> URI Class Initialized
DEBUG - 2017-07-26 12:01:27 --> No URI present. Default controller set.
INFO - 2017-07-26 12:01:27 --> Router Class Initialized
INFO - 2017-07-26 12:01:27 --> Output Class Initialized
INFO - 2017-07-26 12:01:27 --> Security Class Initialized
DEBUG - 2017-07-26 12:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:01:27 --> Input Class Initialized
INFO - 2017-07-26 12:01:27 --> Language Class Initialized
INFO - 2017-07-26 12:01:27 --> Loader Class Initialized
INFO - 2017-07-26 12:01:27 --> Helper loaded: url_helper
INFO - 2017-07-26 12:01:27 --> Helper loaded: form_helper
INFO - 2017-07-26 12:01:27 --> Helper loaded: security_helper
INFO - 2017-07-26 12:01:27 --> Helper loaded: path_helper
INFO - 2017-07-26 12:01:27 --> Helper loaded: common_helper
INFO - 2017-07-26 12:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:01:27 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:01:27 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:27 --> Email Class Initialized
INFO - 2017-07-26 12:01:27 --> Form Validation Class Initialized
INFO - 2017-07-26 12:01:27 --> Model Class Initialized
INFO - 2017-07-26 12:01:27 --> Model Class Initialized
INFO - 2017-07-26 12:01:27 --> Model Class Initialized
INFO - 2017-07-26 12:01:27 --> Model Class Initialized
INFO - 2017-07-26 12:01:27 --> Controller Class Initialized
DEBUG - 2017-07-26 12:01:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 12:01:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 12:01:27 --> Final output sent to browser
DEBUG - 2017-07-26 12:01:27 --> Total execution time: 0.0274
DEBUG - 2017-07-26 12:01:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:01:27 --> Database Forge Class Initialized
INFO - 2017-07-26 12:01:27 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:38 --> Config Class Initialized
INFO - 2017-07-26 12:01:38 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:01:38 --> Utf8 Class Initialized
INFO - 2017-07-26 12:01:38 --> URI Class Initialized
INFO - 2017-07-26 12:01:38 --> Router Class Initialized
INFO - 2017-07-26 12:01:38 --> Output Class Initialized
INFO - 2017-07-26 12:01:38 --> Security Class Initialized
DEBUG - 2017-07-26 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:01:38 --> Input Class Initialized
INFO - 2017-07-26 12:01:38 --> Language Class Initialized
INFO - 2017-07-26 12:01:38 --> Loader Class Initialized
INFO - 2017-07-26 12:01:38 --> Helper loaded: url_helper
INFO - 2017-07-26 12:01:38 --> Helper loaded: form_helper
INFO - 2017-07-26 12:01:38 --> Helper loaded: security_helper
INFO - 2017-07-26 12:01:38 --> Helper loaded: path_helper
INFO - 2017-07-26 12:01:38 --> Helper loaded: common_helper
INFO - 2017-07-26 12:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:01:38 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:01:38 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:01:38 --> Email Class Initialized
INFO - 2017-07-26 12:01:38 --> Form Validation Class Initialized
INFO - 2017-07-26 12:01:38 --> Model Class Initialized
INFO - 2017-07-26 12:01:38 --> Model Class Initialized
INFO - 2017-07-26 12:01:38 --> Model Class Initialized
INFO - 2017-07-26 12:01:38 --> Model Class Initialized
INFO - 2017-07-26 12:01:38 --> Controller Class Initialized
INFO - 2017-07-26 12:01:38 --> Model Class Initialized
INFO - 2017-07-26 12:01:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:01:38 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:01:38 --> Final output sent to browser
DEBUG - 2017-07-26 12:01:38 --> Total execution time: 0.0278
DEBUG - 2017-07-26 12:01:38 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:01:38 --> Database Forge Class Initialized
INFO - 2017-07-26 12:01:38 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:21 --> Config Class Initialized
INFO - 2017-07-26 12:08:21 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:08:21 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:08:21 --> Utf8 Class Initialized
INFO - 2017-07-26 12:08:21 --> URI Class Initialized
INFO - 2017-07-26 12:08:21 --> Router Class Initialized
INFO - 2017-07-26 12:08:21 --> Output Class Initialized
INFO - 2017-07-26 12:08:21 --> Security Class Initialized
DEBUG - 2017-07-26 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:08:21 --> Input Class Initialized
INFO - 2017-07-26 12:08:21 --> Language Class Initialized
INFO - 2017-07-26 12:08:21 --> Loader Class Initialized
INFO - 2017-07-26 12:08:21 --> Helper loaded: url_helper
INFO - 2017-07-26 12:08:21 --> Helper loaded: form_helper
INFO - 2017-07-26 12:08:21 --> Helper loaded: security_helper
INFO - 2017-07-26 12:08:21 --> Helper loaded: path_helper
INFO - 2017-07-26 12:08:21 --> Helper loaded: common_helper
INFO - 2017-07-26 12:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:08:21 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:08:21 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:21 --> Email Class Initialized
INFO - 2017-07-26 12:08:21 --> Form Validation Class Initialized
INFO - 2017-07-26 12:08:21 --> Model Class Initialized
INFO - 2017-07-26 12:08:21 --> Model Class Initialized
INFO - 2017-07-26 12:08:21 --> Model Class Initialized
INFO - 2017-07-26 12:08:21 --> Model Class Initialized
INFO - 2017-07-26 12:08:21 --> Controller Class Initialized
INFO - 2017-07-26 12:08:21 --> Model Class Initialized
INFO - 2017-07-26 12:08:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:08:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:08:21 --> Final output sent to browser
DEBUG - 2017-07-26 12:08:21 --> Total execution time: 0.0300
DEBUG - 2017-07-26 12:08:21 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:08:21 --> Database Forge Class Initialized
INFO - 2017-07-26 12:08:21 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:08:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:25 --> Config Class Initialized
INFO - 2017-07-26 12:08:25 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:08:25 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:08:25 --> Utf8 Class Initialized
INFO - 2017-07-26 12:08:25 --> URI Class Initialized
DEBUG - 2017-07-26 12:08:25 --> No URI present. Default controller set.
INFO - 2017-07-26 12:08:25 --> Router Class Initialized
INFO - 2017-07-26 12:08:25 --> Output Class Initialized
INFO - 2017-07-26 12:08:25 --> Security Class Initialized
DEBUG - 2017-07-26 12:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:08:25 --> Input Class Initialized
INFO - 2017-07-26 12:08:25 --> Language Class Initialized
INFO - 2017-07-26 12:08:25 --> Loader Class Initialized
INFO - 2017-07-26 12:08:25 --> Helper loaded: url_helper
INFO - 2017-07-26 12:08:25 --> Helper loaded: form_helper
INFO - 2017-07-26 12:08:25 --> Helper loaded: security_helper
INFO - 2017-07-26 12:08:25 --> Helper loaded: path_helper
INFO - 2017-07-26 12:08:25 --> Helper loaded: common_helper
INFO - 2017-07-26 12:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:08:25 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:08:25 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:25 --> Email Class Initialized
INFO - 2017-07-26 12:08:25 --> Form Validation Class Initialized
INFO - 2017-07-26 12:08:25 --> Model Class Initialized
INFO - 2017-07-26 12:08:25 --> Model Class Initialized
INFO - 2017-07-26 12:08:25 --> Model Class Initialized
INFO - 2017-07-26 12:08:25 --> Model Class Initialized
INFO - 2017-07-26 12:08:25 --> Controller Class Initialized
DEBUG - 2017-07-26 12:08:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 12:08:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 12:08:25 --> Final output sent to browser
DEBUG - 2017-07-26 12:08:25 --> Total execution time: 0.0372
DEBUG - 2017-07-26 12:08:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:08:25 --> Database Forge Class Initialized
INFO - 2017-07-26 12:08:25 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:08:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:33 --> Config Class Initialized
INFO - 2017-07-26 12:08:33 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:08:33 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:08:33 --> Utf8 Class Initialized
INFO - 2017-07-26 12:08:33 --> URI Class Initialized
INFO - 2017-07-26 12:08:33 --> Router Class Initialized
INFO - 2017-07-26 12:08:33 --> Output Class Initialized
INFO - 2017-07-26 12:08:33 --> Security Class Initialized
DEBUG - 2017-07-26 12:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:08:33 --> Input Class Initialized
INFO - 2017-07-26 12:08:33 --> Language Class Initialized
INFO - 2017-07-26 12:08:33 --> Loader Class Initialized
INFO - 2017-07-26 12:08:33 --> Helper loaded: url_helper
INFO - 2017-07-26 12:08:33 --> Helper loaded: form_helper
INFO - 2017-07-26 12:08:33 --> Helper loaded: security_helper
INFO - 2017-07-26 12:08:33 --> Helper loaded: path_helper
INFO - 2017-07-26 12:08:33 --> Helper loaded: common_helper
INFO - 2017-07-26 12:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:08:33 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:08:33 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:08:33 --> Email Class Initialized
INFO - 2017-07-26 12:08:33 --> Form Validation Class Initialized
INFO - 2017-07-26 12:08:33 --> Model Class Initialized
INFO - 2017-07-26 12:08:33 --> Model Class Initialized
INFO - 2017-07-26 12:08:33 --> Model Class Initialized
INFO - 2017-07-26 12:08:33 --> Model Class Initialized
INFO - 2017-07-26 12:08:33 --> Controller Class Initialized
INFO - 2017-07-26 12:08:33 --> Model Class Initialized
INFO - 2017-07-26 12:08:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:08:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:08:33 --> Final output sent to browser
DEBUG - 2017-07-26 12:08:33 --> Total execution time: 0.0318
DEBUG - 2017-07-26 12:08:33 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:08:33 --> Database Forge Class Initialized
INFO - 2017-07-26 12:08:33 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:06 --> Config Class Initialized
INFO - 2017-07-26 12:39:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:39:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:39:06 --> Utf8 Class Initialized
INFO - 2017-07-26 12:39:06 --> URI Class Initialized
INFO - 2017-07-26 12:39:06 --> Router Class Initialized
INFO - 2017-07-26 12:39:06 --> Output Class Initialized
INFO - 2017-07-26 12:39:06 --> Security Class Initialized
DEBUG - 2017-07-26 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:39:06 --> Input Class Initialized
INFO - 2017-07-26 12:39:06 --> Language Class Initialized
INFO - 2017-07-26 12:39:06 --> Loader Class Initialized
INFO - 2017-07-26 12:39:06 --> Helper loaded: url_helper
INFO - 2017-07-26 12:39:06 --> Helper loaded: form_helper
INFO - 2017-07-26 12:39:06 --> Helper loaded: security_helper
INFO - 2017-07-26 12:39:06 --> Helper loaded: path_helper
INFO - 2017-07-26 12:39:06 --> Helper loaded: common_helper
INFO - 2017-07-26 12:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:39:06 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:39:06 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:06 --> Email Class Initialized
INFO - 2017-07-26 12:39:06 --> Form Validation Class Initialized
INFO - 2017-07-26 12:39:06 --> Model Class Initialized
INFO - 2017-07-26 12:39:06 --> Model Class Initialized
INFO - 2017-07-26 12:39:06 --> Model Class Initialized
INFO - 2017-07-26 12:39:06 --> Model Class Initialized
INFO - 2017-07-26 12:39:06 --> Controller Class Initialized
INFO - 2017-07-26 12:39:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-26 12:39:06 --> Final output sent to browser
DEBUG - 2017-07-26 12:39:06 --> Total execution time: 0.0274
DEBUG - 2017-07-26 12:39:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:39:06 --> Database Forge Class Initialized
INFO - 2017-07-26 12:39:06 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:39:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:06 --> Config Class Initialized
INFO - 2017-07-26 12:39:06 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:39:06 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:39:06 --> Utf8 Class Initialized
INFO - 2017-07-26 12:39:06 --> URI Class Initialized
INFO - 2017-07-26 12:39:06 --> Router Class Initialized
INFO - 2017-07-26 12:39:06 --> Output Class Initialized
INFO - 2017-07-26 12:39:06 --> Security Class Initialized
DEBUG - 2017-07-26 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:39:06 --> Input Class Initialized
INFO - 2017-07-26 12:39:06 --> Language Class Initialized
ERROR - 2017-07-26 12:39:06 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-26 12:39:13 --> Config Class Initialized
INFO - 2017-07-26 12:39:13 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:39:13 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:39:13 --> Utf8 Class Initialized
INFO - 2017-07-26 12:39:13 --> URI Class Initialized
DEBUG - 2017-07-26 12:39:13 --> No URI present. Default controller set.
INFO - 2017-07-26 12:39:13 --> Router Class Initialized
INFO - 2017-07-26 12:39:13 --> Output Class Initialized
INFO - 2017-07-26 12:39:13 --> Security Class Initialized
DEBUG - 2017-07-26 12:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:39:13 --> Input Class Initialized
INFO - 2017-07-26 12:39:13 --> Language Class Initialized
INFO - 2017-07-26 12:39:13 --> Loader Class Initialized
INFO - 2017-07-26 12:39:13 --> Helper loaded: url_helper
INFO - 2017-07-26 12:39:13 --> Helper loaded: form_helper
INFO - 2017-07-26 12:39:13 --> Helper loaded: security_helper
INFO - 2017-07-26 12:39:13 --> Helper loaded: path_helper
INFO - 2017-07-26 12:39:13 --> Helper loaded: common_helper
INFO - 2017-07-26 12:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:39:13 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:39:13 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:13 --> Email Class Initialized
INFO - 2017-07-26 12:39:13 --> Form Validation Class Initialized
INFO - 2017-07-26 12:39:13 --> Model Class Initialized
INFO - 2017-07-26 12:39:13 --> Model Class Initialized
INFO - 2017-07-26 12:39:13 --> Model Class Initialized
INFO - 2017-07-26 12:39:13 --> Model Class Initialized
INFO - 2017-07-26 12:39:13 --> Controller Class Initialized
DEBUG - 2017-07-26 12:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 12:39:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 12:39:13 --> Final output sent to browser
DEBUG - 2017-07-26 12:39:13 --> Total execution time: 0.0262
DEBUG - 2017-07-26 12:39:13 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:39:13 --> Database Forge Class Initialized
INFO - 2017-07-26 12:39:13 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:19 --> Config Class Initialized
INFO - 2017-07-26 12:39:19 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:39:19 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:39:19 --> Utf8 Class Initialized
INFO - 2017-07-26 12:39:19 --> URI Class Initialized
INFO - 2017-07-26 12:39:19 --> Router Class Initialized
INFO - 2017-07-26 12:39:19 --> Output Class Initialized
INFO - 2017-07-26 12:39:19 --> Security Class Initialized
DEBUG - 2017-07-26 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:39:19 --> Input Class Initialized
INFO - 2017-07-26 12:39:19 --> Language Class Initialized
INFO - 2017-07-26 12:39:19 --> Loader Class Initialized
INFO - 2017-07-26 12:39:19 --> Helper loaded: url_helper
INFO - 2017-07-26 12:39:19 --> Helper loaded: form_helper
INFO - 2017-07-26 12:39:19 --> Helper loaded: security_helper
INFO - 2017-07-26 12:39:19 --> Helper loaded: path_helper
INFO - 2017-07-26 12:39:19 --> Helper loaded: common_helper
INFO - 2017-07-26 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:39:19 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:39:19 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:19 --> Email Class Initialized
INFO - 2017-07-26 12:39:19 --> Form Validation Class Initialized
INFO - 2017-07-26 12:39:19 --> Model Class Initialized
INFO - 2017-07-26 12:39:19 --> Model Class Initialized
INFO - 2017-07-26 12:39:19 --> Model Class Initialized
INFO - 2017-07-26 12:39:19 --> Model Class Initialized
INFO - 2017-07-26 12:39:19 --> Controller Class Initialized
INFO - 2017-07-26 12:39:19 --> Model Class Initialized
INFO - 2017-07-26 12:39:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:39:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:39:19 --> Final output sent to browser
DEBUG - 2017-07-26 12:39:19 --> Total execution time: 0.0277
DEBUG - 2017-07-26 12:39:19 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:39:19 --> Database Forge Class Initialized
INFO - 2017-07-26 12:39:19 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:39:19 --> Config Class Initialized
INFO - 2017-07-26 12:39:19 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:39:19 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:39:19 --> Utf8 Class Initialized
INFO - 2017-07-26 12:39:19 --> URI Class Initialized
INFO - 2017-07-26 12:39:19 --> Router Class Initialized
INFO - 2017-07-26 12:39:19 --> Output Class Initialized
INFO - 2017-07-26 12:39:19 --> Security Class Initialized
DEBUG - 2017-07-26 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:39:19 --> Input Class Initialized
INFO - 2017-07-26 12:39:19 --> Language Class Initialized
ERROR - 2017-07-26 12:39:19 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 12:40:17 --> Config Class Initialized
INFO - 2017-07-26 12:40:17 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:40:17 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:40:17 --> Utf8 Class Initialized
INFO - 2017-07-26 12:40:17 --> URI Class Initialized
INFO - 2017-07-26 12:40:17 --> Router Class Initialized
INFO - 2017-07-26 12:40:17 --> Output Class Initialized
INFO - 2017-07-26 12:40:17 --> Security Class Initialized
DEBUG - 2017-07-26 12:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:40:17 --> Input Class Initialized
INFO - 2017-07-26 12:40:17 --> Language Class Initialized
INFO - 2017-07-26 12:40:17 --> Loader Class Initialized
INFO - 2017-07-26 12:40:17 --> Helper loaded: url_helper
INFO - 2017-07-26 12:40:17 --> Helper loaded: form_helper
INFO - 2017-07-26 12:40:17 --> Helper loaded: security_helper
INFO - 2017-07-26 12:40:17 --> Helper loaded: path_helper
INFO - 2017-07-26 12:40:17 --> Helper loaded: common_helper
INFO - 2017-07-26 12:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:40:17 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:40:17 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:40:17 --> Email Class Initialized
INFO - 2017-07-26 12:40:17 --> Form Validation Class Initialized
INFO - 2017-07-26 12:40:17 --> Model Class Initialized
INFO - 2017-07-26 12:40:17 --> Model Class Initialized
INFO - 2017-07-26 12:40:17 --> Model Class Initialized
INFO - 2017-07-26 12:40:17 --> Model Class Initialized
INFO - 2017-07-26 12:40:17 --> Controller Class Initialized
INFO - 2017-07-26 12:40:17 --> Model Class Initialized
INFO - 2017-07-26 12:40:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:40:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:40:17 --> Final output sent to browser
DEBUG - 2017-07-26 12:40:17 --> Total execution time: 0.0280
DEBUG - 2017-07-26 12:40:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:40:17 --> Database Forge Class Initialized
INFO - 2017-07-26 12:40:17 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:40:22 --> Config Class Initialized
INFO - 2017-07-26 12:40:22 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:40:22 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:40:22 --> Utf8 Class Initialized
INFO - 2017-07-26 12:40:22 --> URI Class Initialized
INFO - 2017-07-26 12:40:22 --> Router Class Initialized
INFO - 2017-07-26 12:40:22 --> Output Class Initialized
INFO - 2017-07-26 12:40:22 --> Security Class Initialized
DEBUG - 2017-07-26 12:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:40:22 --> Input Class Initialized
INFO - 2017-07-26 12:40:22 --> Language Class Initialized
ERROR - 2017-07-26 12:40:22 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 12:40:55 --> Config Class Initialized
INFO - 2017-07-26 12:40:55 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:40:55 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:40:55 --> Utf8 Class Initialized
INFO - 2017-07-26 12:40:55 --> URI Class Initialized
INFO - 2017-07-26 12:40:55 --> Router Class Initialized
INFO - 2017-07-26 12:40:55 --> Output Class Initialized
INFO - 2017-07-26 12:40:55 --> Security Class Initialized
DEBUG - 2017-07-26 12:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:40:55 --> Input Class Initialized
INFO - 2017-07-26 12:40:55 --> Language Class Initialized
INFO - 2017-07-26 12:40:55 --> Loader Class Initialized
INFO - 2017-07-26 12:40:55 --> Helper loaded: url_helper
INFO - 2017-07-26 12:40:55 --> Helper loaded: form_helper
INFO - 2017-07-26 12:40:55 --> Helper loaded: security_helper
INFO - 2017-07-26 12:40:55 --> Helper loaded: path_helper
INFO - 2017-07-26 12:40:55 --> Helper loaded: common_helper
INFO - 2017-07-26 12:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 12:40:55 --> Helper loaded: check_session_helper
INFO - 2017-07-26 12:40:55 --> Database Driver Class Initialized
DEBUG - 2017-07-26 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:40:55 --> Email Class Initialized
INFO - 2017-07-26 12:40:55 --> Form Validation Class Initialized
INFO - 2017-07-26 12:40:55 --> Model Class Initialized
INFO - 2017-07-26 12:40:55 --> Model Class Initialized
INFO - 2017-07-26 12:40:55 --> Model Class Initialized
INFO - 2017-07-26 12:40:55 --> Model Class Initialized
INFO - 2017-07-26 12:40:55 --> Controller Class Initialized
INFO - 2017-07-26 12:40:55 --> Model Class Initialized
INFO - 2017-07-26 12:40:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 12:40:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 12:40:55 --> Final output sent to browser
DEBUG - 2017-07-26 12:40:55 --> Total execution time: 0.0275
DEBUG - 2017-07-26 12:40:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 12:40:55 --> Database Forge Class Initialized
INFO - 2017-07-26 12:40:55 --> User Agent Class Initialized
DEBUG - 2017-07-26 12:40:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 12:40:57 --> Config Class Initialized
INFO - 2017-07-26 12:40:57 --> Hooks Class Initialized
DEBUG - 2017-07-26 12:40:57 --> UTF-8 Support Enabled
INFO - 2017-07-26 12:40:57 --> Utf8 Class Initialized
INFO - 2017-07-26 12:40:57 --> URI Class Initialized
INFO - 2017-07-26 12:40:57 --> Router Class Initialized
INFO - 2017-07-26 12:40:57 --> Output Class Initialized
INFO - 2017-07-26 12:40:57 --> Security Class Initialized
DEBUG - 2017-07-26 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 12:40:57 --> Input Class Initialized
INFO - 2017-07-26 12:40:57 --> Language Class Initialized
ERROR - 2017-07-26 12:40:57 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 15:24:28 --> Config Class Initialized
INFO - 2017-07-26 15:24:28 --> Hooks Class Initialized
DEBUG - 2017-07-26 15:24:28 --> UTF-8 Support Enabled
INFO - 2017-07-26 15:24:28 --> Utf8 Class Initialized
INFO - 2017-07-26 15:24:28 --> URI Class Initialized
DEBUG - 2017-07-26 15:24:28 --> No URI present. Default controller set.
INFO - 2017-07-26 15:24:28 --> Router Class Initialized
INFO - 2017-07-26 15:24:28 --> Output Class Initialized
INFO - 2017-07-26 15:24:28 --> Security Class Initialized
DEBUG - 2017-07-26 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 15:24:28 --> Input Class Initialized
INFO - 2017-07-26 15:24:28 --> Language Class Initialized
INFO - 2017-07-26 15:24:28 --> Loader Class Initialized
INFO - 2017-07-26 15:24:28 --> Helper loaded: url_helper
INFO - 2017-07-26 15:24:28 --> Helper loaded: form_helper
INFO - 2017-07-26 15:24:28 --> Helper loaded: security_helper
INFO - 2017-07-26 15:24:28 --> Helper loaded: path_helper
INFO - 2017-07-26 15:24:28 --> Helper loaded: common_helper
INFO - 2017-07-26 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 15:24:28 --> Helper loaded: check_session_helper
INFO - 2017-07-26 15:24:28 --> Database Driver Class Initialized
DEBUG - 2017-07-26 15:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 15:24:28 --> Email Class Initialized
INFO - 2017-07-26 15:24:28 --> Form Validation Class Initialized
INFO - 2017-07-26 15:24:28 --> Model Class Initialized
INFO - 2017-07-26 15:24:28 --> Model Class Initialized
INFO - 2017-07-26 15:24:28 --> Model Class Initialized
INFO - 2017-07-26 15:24:28 --> Model Class Initialized
INFO - 2017-07-26 15:24:28 --> Controller Class Initialized
DEBUG - 2017-07-26 15:24:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 15:24:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 15:24:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 15:24:28 --> Final output sent to browser
DEBUG - 2017-07-26 15:24:28 --> Total execution time: 0.1277
DEBUG - 2017-07-26 15:24:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 15:24:28 --> Database Forge Class Initialized
INFO - 2017-07-26 15:24:28 --> User Agent Class Initialized
DEBUG - 2017-07-26 15:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 16:52:05 --> Config Class Initialized
INFO - 2017-07-26 16:52:05 --> Hooks Class Initialized
DEBUG - 2017-07-26 16:52:05 --> UTF-8 Support Enabled
INFO - 2017-07-26 16:52:05 --> Utf8 Class Initialized
INFO - 2017-07-26 16:52:05 --> URI Class Initialized
DEBUG - 2017-07-26 16:52:05 --> No URI present. Default controller set.
INFO - 2017-07-26 16:52:05 --> Router Class Initialized
INFO - 2017-07-26 16:52:05 --> Output Class Initialized
INFO - 2017-07-26 16:52:05 --> Security Class Initialized
DEBUG - 2017-07-26 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 16:52:05 --> Input Class Initialized
INFO - 2017-07-26 16:52:05 --> Language Class Initialized
INFO - 2017-07-26 16:52:05 --> Loader Class Initialized
INFO - 2017-07-26 16:52:05 --> Helper loaded: url_helper
INFO - 2017-07-26 16:52:05 --> Helper loaded: form_helper
INFO - 2017-07-26 16:52:05 --> Helper loaded: security_helper
INFO - 2017-07-26 16:52:05 --> Helper loaded: path_helper
INFO - 2017-07-26 16:52:05 --> Helper loaded: common_helper
INFO - 2017-07-26 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 16:52:05 --> Helper loaded: check_session_helper
INFO - 2017-07-26 16:52:05 --> Database Driver Class Initialized
DEBUG - 2017-07-26 16:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 16:52:05 --> Email Class Initialized
INFO - 2017-07-26 16:52:05 --> Form Validation Class Initialized
INFO - 2017-07-26 16:52:05 --> Model Class Initialized
INFO - 2017-07-26 16:52:05 --> Model Class Initialized
INFO - 2017-07-26 16:52:05 --> Model Class Initialized
INFO - 2017-07-26 16:52:05 --> Model Class Initialized
INFO - 2017-07-26 16:52:05 --> Controller Class Initialized
DEBUG - 2017-07-26 16:52:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-26 16:52:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-26 16:52:05 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-26 16:52:05 --> Final output sent to browser
DEBUG - 2017-07-26 16:52:05 --> Total execution time: 0.0312
DEBUG - 2017-07-26 16:52:05 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 16:52:05 --> Database Forge Class Initialized
INFO - 2017-07-26 16:52:05 --> User Agent Class Initialized
DEBUG - 2017-07-26 16:52:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 18:49:28 --> Config Class Initialized
INFO - 2017-07-26 18:49:28 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:49:28 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:49:28 --> Utf8 Class Initialized
INFO - 2017-07-26 18:49:28 --> URI Class Initialized
INFO - 2017-07-26 18:49:29 --> Router Class Initialized
INFO - 2017-07-26 18:49:29 --> Output Class Initialized
INFO - 2017-07-26 18:49:29 --> Security Class Initialized
DEBUG - 2017-07-26 18:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:49:29 --> Input Class Initialized
INFO - 2017-07-26 18:49:29 --> Language Class Initialized
INFO - 2017-07-26 18:49:29 --> Loader Class Initialized
INFO - 2017-07-26 18:49:29 --> Helper loaded: url_helper
INFO - 2017-07-26 18:49:29 --> Helper loaded: form_helper
INFO - 2017-07-26 18:49:29 --> Helper loaded: security_helper
INFO - 2017-07-26 18:49:29 --> Helper loaded: path_helper
INFO - 2017-07-26 18:49:29 --> Helper loaded: common_helper
INFO - 2017-07-26 18:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 18:49:29 --> Helper loaded: check_session_helper
INFO - 2017-07-26 18:49:29 --> Database Driver Class Initialized
DEBUG - 2017-07-26 18:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 18:49:29 --> Email Class Initialized
INFO - 2017-07-26 18:49:29 --> Form Validation Class Initialized
INFO - 2017-07-26 18:49:29 --> Model Class Initialized
INFO - 2017-07-26 18:49:29 --> Model Class Initialized
INFO - 2017-07-26 18:49:29 --> Model Class Initialized
INFO - 2017-07-26 18:49:29 --> Model Class Initialized
INFO - 2017-07-26 18:49:29 --> Controller Class Initialized
INFO - 2017-07-26 18:49:29 --> Model Class Initialized
INFO - 2017-07-26 18:49:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 18:49:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 18:49:29 --> Final output sent to browser
DEBUG - 2017-07-26 18:49:29 --> Total execution time: 1.9233
DEBUG - 2017-07-26 18:49:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 18:49:29 --> Database Forge Class Initialized
INFO - 2017-07-26 18:49:29 --> User Agent Class Initialized
DEBUG - 2017-07-26 18:49:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 18:49:40 --> Config Class Initialized
INFO - 2017-07-26 18:49:40 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:49:40 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:49:40 --> Utf8 Class Initialized
INFO - 2017-07-26 18:49:40 --> URI Class Initialized
INFO - 2017-07-26 18:49:40 --> Router Class Initialized
INFO - 2017-07-26 18:49:40 --> Output Class Initialized
INFO - 2017-07-26 18:49:40 --> Security Class Initialized
DEBUG - 2017-07-26 18:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:49:40 --> Input Class Initialized
INFO - 2017-07-26 18:49:40 --> Language Class Initialized
ERROR - 2017-07-26 18:49:40 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 18:51:03 --> Config Class Initialized
INFO - 2017-07-26 18:51:03 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:51:03 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:51:03 --> Utf8 Class Initialized
INFO - 2017-07-26 18:51:03 --> URI Class Initialized
INFO - 2017-07-26 18:51:03 --> Router Class Initialized
INFO - 2017-07-26 18:51:03 --> Output Class Initialized
INFO - 2017-07-26 18:51:03 --> Security Class Initialized
DEBUG - 2017-07-26 18:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:51:03 --> Input Class Initialized
INFO - 2017-07-26 18:51:03 --> Language Class Initialized
INFO - 2017-07-26 18:51:03 --> Loader Class Initialized
INFO - 2017-07-26 18:51:03 --> Helper loaded: url_helper
INFO - 2017-07-26 18:51:03 --> Helper loaded: form_helper
INFO - 2017-07-26 18:51:03 --> Helper loaded: security_helper
INFO - 2017-07-26 18:51:03 --> Helper loaded: path_helper
INFO - 2017-07-26 18:51:03 --> Helper loaded: common_helper
INFO - 2017-07-26 18:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 18:51:03 --> Helper loaded: check_session_helper
INFO - 2017-07-26 18:51:03 --> Database Driver Class Initialized
DEBUG - 2017-07-26 18:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 18:51:03 --> Email Class Initialized
INFO - 2017-07-26 18:51:03 --> Form Validation Class Initialized
INFO - 2017-07-26 18:51:03 --> Model Class Initialized
INFO - 2017-07-26 18:51:03 --> Model Class Initialized
INFO - 2017-07-26 18:51:03 --> Model Class Initialized
INFO - 2017-07-26 18:51:03 --> Model Class Initialized
INFO - 2017-07-26 18:51:03 --> Controller Class Initialized
INFO - 2017-07-26 18:51:03 --> Model Class Initialized
INFO - 2017-07-26 18:51:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 18:51:03 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 18:51:03 --> Final output sent to browser
DEBUG - 2017-07-26 18:51:03 --> Total execution time: 0.0282
DEBUG - 2017-07-26 18:51:03 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 18:51:03 --> Database Forge Class Initialized
INFO - 2017-07-26 18:51:03 --> User Agent Class Initialized
DEBUG - 2017-07-26 18:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 18:51:04 --> Config Class Initialized
INFO - 2017-07-26 18:51:04 --> Hooks Class Initialized
DEBUG - 2017-07-26 18:51:04 --> UTF-8 Support Enabled
INFO - 2017-07-26 18:51:04 --> Utf8 Class Initialized
INFO - 2017-07-26 18:51:04 --> URI Class Initialized
INFO - 2017-07-26 18:51:04 --> Router Class Initialized
INFO - 2017-07-26 18:51:04 --> Output Class Initialized
INFO - 2017-07-26 18:51:04 --> Security Class Initialized
DEBUG - 2017-07-26 18:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 18:51:04 --> Input Class Initialized
INFO - 2017-07-26 18:51:04 --> Language Class Initialized
ERROR - 2017-07-26 18:51:04 --> 404 Page Not Found: Page/assets
INFO - 2017-07-26 19:02:17 --> Config Class Initialized
INFO - 2017-07-26 19:02:17 --> Hooks Class Initialized
DEBUG - 2017-07-26 19:02:17 --> UTF-8 Support Enabled
INFO - 2017-07-26 19:02:17 --> Utf8 Class Initialized
INFO - 2017-07-26 19:02:17 --> URI Class Initialized
INFO - 2017-07-26 19:02:17 --> Router Class Initialized
INFO - 2017-07-26 19:02:17 --> Output Class Initialized
INFO - 2017-07-26 19:02:17 --> Security Class Initialized
DEBUG - 2017-07-26 19:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 19:02:17 --> Input Class Initialized
INFO - 2017-07-26 19:02:17 --> Language Class Initialized
INFO - 2017-07-26 19:02:17 --> Loader Class Initialized
INFO - 2017-07-26 19:02:17 --> Helper loaded: url_helper
INFO - 2017-07-26 19:02:17 --> Helper loaded: form_helper
INFO - 2017-07-26 19:02:17 --> Helper loaded: security_helper
INFO - 2017-07-26 19:02:17 --> Helper loaded: path_helper
INFO - 2017-07-26 19:02:17 --> Helper loaded: common_helper
INFO - 2017-07-26 19:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 19:02:17 --> Helper loaded: check_session_helper
INFO - 2017-07-26 19:02:17 --> Database Driver Class Initialized
DEBUG - 2017-07-26 19:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 19:02:17 --> Email Class Initialized
INFO - 2017-07-26 19:02:17 --> Form Validation Class Initialized
INFO - 2017-07-26 19:02:17 --> Model Class Initialized
INFO - 2017-07-26 19:02:17 --> Model Class Initialized
INFO - 2017-07-26 19:02:17 --> Model Class Initialized
INFO - 2017-07-26 19:02:17 --> Model Class Initialized
INFO - 2017-07-26 19:02:17 --> Controller Class Initialized
INFO - 2017-07-26 19:02:17 --> Model Class Initialized
INFO - 2017-07-26 19:02:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-26 19:02:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 19:02:17 --> Final output sent to browser
DEBUG - 2017-07-26 19:02:17 --> Total execution time: 0.0283
DEBUG - 2017-07-26 19:02:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 19:02:17 --> Database Forge Class Initialized
INFO - 2017-07-26 19:02:17 --> User Agent Class Initialized
DEBUG - 2017-07-26 19:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 19:02:23 --> Config Class Initialized
INFO - 2017-07-26 19:02:23 --> Hooks Class Initialized
DEBUG - 2017-07-26 19:02:23 --> UTF-8 Support Enabled
INFO - 2017-07-26 19:02:23 --> Utf8 Class Initialized
INFO - 2017-07-26 19:02:23 --> URI Class Initialized
INFO - 2017-07-26 19:02:23 --> Router Class Initialized
INFO - 2017-07-26 19:02:23 --> Output Class Initialized
INFO - 2017-07-26 19:02:23 --> Security Class Initialized
DEBUG - 2017-07-26 19:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-26 19:02:23 --> Input Class Initialized
INFO - 2017-07-26 19:02:23 --> Language Class Initialized
INFO - 2017-07-26 19:02:23 --> Loader Class Initialized
INFO - 2017-07-26 19:02:23 --> Helper loaded: url_helper
INFO - 2017-07-26 19:02:23 --> Helper loaded: form_helper
INFO - 2017-07-26 19:02:23 --> Helper loaded: security_helper
INFO - 2017-07-26 19:02:23 --> Helper loaded: path_helper
INFO - 2017-07-26 19:02:23 --> Helper loaded: common_helper
INFO - 2017-07-26 19:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-26 19:02:23 --> Helper loaded: check_session_helper
INFO - 2017-07-26 19:02:23 --> Database Driver Class Initialized
DEBUG - 2017-07-26 19:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-26 19:02:23 --> Email Class Initialized
INFO - 2017-07-26 19:02:23 --> Form Validation Class Initialized
INFO - 2017-07-26 19:02:23 --> Model Class Initialized
INFO - 2017-07-26 19:02:23 --> Model Class Initialized
INFO - 2017-07-26 19:02:23 --> Model Class Initialized
INFO - 2017-07-26 19:02:23 --> Model Class Initialized
INFO - 2017-07-26 19:02:23 --> Controller Class Initialized
INFO - 2017-07-26 19:02:23 --> Helper loaded: captcha_helper
INFO - 2017-07-26 19:02:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/contact_us.php
INFO - 2017-07-26 19:02:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-26 19:02:23 --> Final output sent to browser
DEBUG - 2017-07-26 19:02:23 --> Total execution time: 0.0741
DEBUG - 2017-07-26 19:02:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-26 19:02:23 --> Database Forge Class Initialized
INFO - 2017-07-26 19:02:23 --> User Agent Class Initialized
DEBUG - 2017-07-26 19:02:23 --> Session class already loaded. Second attempt ignored.
