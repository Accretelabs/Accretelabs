<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-07 04:55:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 04:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 04:55:13 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 04:55:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 04:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 04:58:38 --> 404 Page Not Found: Assets/images
ERROR - 2016-12-07 06:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 06:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 06:35:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 06:35:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 06:43:34 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 06:43:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-07 06:43:52 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 06:44:19 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 06:44:46 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 07:11:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:13:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:27:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:27:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:27:48 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:27:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:28:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:28:16 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:28:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:41:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:41:12 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:41:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:41:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:44:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'X.doc_name like '%jayanthi srinivasiah%' ) and X.case_status = '0' group by X.id' at line 1 - Invalid query: SELECT * FROM (select ch.id as case_id, AES_DECRYPT(ch.name,'Oncolens') as pname, ch.mark_as_discussed_live, (select CONCAT_WS(' ', fname, lname) from users where id=case_entered_by) as doc_name, u.fname, datediff(CURDATE(),  AES_DECRYPT(ch.dob,'Oncolens') ) as dob_days,ch.cancer_id,ch.case_status,ca.is_tumor,AES_DECRYPT(ch.case_description, 'Oncolens') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type,  AES_DECRYPT(ch.dob,'Oncolens') as dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count FROM case_doc_email_status ce INNER JOIN case_history ch  ON ch.id = case_id left join case_assignments ca on ch.id=ca.case_id left join users u on u.id = ch.id left join cancercategories c on c.cancer_id=ch.cancer_id left join hospital_doctor hd on hd.doctor_id=ce.doctor_id  where ch.assigned_hospital = '7' and ch.is_deleted = '0')X where 1   and  (  X.pname  like '%%' X.doc_name like '%jayanthi srinivasiah%' ) and X.case_status = '0' group by X.id order by X.id desc limit 0, 10
ERROR - 2016-12-07 07:44:35 --> Severity: Error --> Call to a member function result_object() on boolean /var/www/html/application/models/Mtumorboard.php 757
ERROR - 2016-12-07 07:45:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:45:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:46:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:49:15 --> Query error: Unknown column 'ch.staging_discussed' in 'field list' - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id WHERE cma.case_id=331
ERROR - 2016-12-07 07:49:15 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Mcase.php 4581
ERROR - 2016-12-07 07:49:24 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:50:06 --> Query error: Unknown column 'ch.prospective_discussion' in 'field list' - Invalid query: SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed'  FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id WHERE cma.case_id=331
ERROR - 2016-12-07 07:50:06 --> Severity: Error --> Call to a member function result_array() on boolean /var/www/html/application/models/Mcase.php 4581
ERROR - 2016-12-07 07:59:00 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 07:59:00 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 07:59:00 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 07:59:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:59:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 07:59:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 07:59:36 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:18:18 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 08:18:18 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 08:18:18 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 08:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 08:27:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:44:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:44:09 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:44:09 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:45:58 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:50:15 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2016-12-07 08:52:31 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:52:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:52:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 08:52:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 08:55:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
               ' at line 1 - Invalid query: select FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
                    case_history 
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
               ON c.cancer_id = ch.cancer_id  LEFT JOIN hospital_doctor hd ON hd.doctor_id = ch.case_entered_by   
                    WHERE ch.is_deleted = '0'  and   ch.assigned_hospital='7'
                     GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch
ERROR - 2016-12-07 08:55:54 --> Severity: Error --> Call to a member function num_rows() on boolean /var/www/html/application/models/Mcustom.php 200
ERROR - 2016-12-07 08:56:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
               ' at line 1 - Invalid query: select FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
                    case_history 
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
               ON c.cancer_id = ch.cancer_id  LEFT JOIN hospital_doctor hd ON hd.doctor_id = ch.case_entered_by   
                    WHERE ch.is_deleted = '0'  and   ch.assigned_hospital='7'
                     GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch
ERROR - 2016-12-07 08:56:03 --> Severity: Error --> Call to a member function num_rows() on boolean /var/www/html/application/models/Mcustom.php 200
ERROR - 2016-12-07 08:56:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
               ' at line 1 - Invalid query: select FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
                    case_history 
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
               ON c.cancer_id = ch.cancer_id  LEFT JOIN hospital_doctor hd ON hd.doctor_id = ch.case_entered_by   
                    WHERE ch.is_deleted = '0'  and   ch.assigned_hospital='7'
                     GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch
ERROR - 2016-12-07 08:56:08 --> Severity: Error --> Call to a member function num_rows() on boolean /var/www/html/application/models/Mcustom.php 200
ERROR - 2016-12-07 08:56:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
               ' at line 1 - Invalid query: select FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
                    case_history 
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
               ON c.cancer_id = ch.cancer_id  LEFT JOIN hospital_doctor hd ON hd.doctor_id = ch.case_entered_by   
                    WHERE ch.is_deleted = '0'  and   ch.assigned_hospital='7'
                    and (  DATE(ch.`case_submit_date`) BETWEEN DATE('2016-09-01') AND DATE('2016-12-01') ) GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch
ERROR - 2016-12-07 08:56:24 --> Severity: Error --> Call to a member function num_rows() on boolean /var/www/html/application/models/Mcustom.php 200
ERROR - 2016-12-07 08:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 09:35:32 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 09:35:32 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 09:35:32 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 09:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 09:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 09:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 10:16:24 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2016-12-07 10:25:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:25:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 10:36:38 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:36:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:36:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:36:40 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:36:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:36:41 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:39:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:39:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:39:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:41:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:41:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:41:58 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 10:42:14 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:42:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:42:16 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:42:16 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:42:22 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 10:44:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:45:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 10:46:42 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 10:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 11:02:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-07 11:02:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 11:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 11:08:23 --> Severity: Warning --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094438:SSL routines:SSL3_READ_BYTES:tlsv1 alert internal error /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 11:08:23 --> Severity: Warning --> stream_socket_client(): Failed to enable crypto /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 11:08:23 --> Severity: Warning --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /var/www/html/application/models/Mcase.php 1180
ERROR - 2016-12-07 11:11:07 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 11:11:07 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 11:11:14 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-07 11:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-07 11:11:29 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 11:11:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-07 11:12:36 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-07 12:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 14:11:39 --> 404 Page Not Found: Users/upcoming-in-person-tumor-boards.html
ERROR - 2016-12-07 17:01:27 --> 404 Page Not Found: M/page
ERROR - 2016-12-07 19:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 19:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-07 20:32:18 --> 404 Page Not Found: Robotstxt/index
