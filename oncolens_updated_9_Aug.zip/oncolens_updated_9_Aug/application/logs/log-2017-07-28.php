<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-28 09:36:12 --> Config Class Initialized
INFO - 2017-07-28 09:36:12 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:36:12 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:36:12 --> Utf8 Class Initialized
INFO - 2017-07-28 09:36:12 --> URI Class Initialized
DEBUG - 2017-07-28 09:36:12 --> No URI present. Default controller set.
INFO - 2017-07-28 09:36:12 --> Router Class Initialized
INFO - 2017-07-28 09:36:12 --> Output Class Initialized
INFO - 2017-07-28 09:36:12 --> Security Class Initialized
DEBUG - 2017-07-28 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:36:12 --> Input Class Initialized
INFO - 2017-07-28 09:36:12 --> Language Class Initialized
INFO - 2017-07-28 09:36:13 --> Loader Class Initialized
INFO - 2017-07-28 09:36:13 --> Helper loaded: url_helper
INFO - 2017-07-28 09:36:13 --> Helper loaded: form_helper
INFO - 2017-07-28 09:36:13 --> Helper loaded: security_helper
INFO - 2017-07-28 09:36:13 --> Helper loaded: path_helper
INFO - 2017-07-28 09:36:13 --> Helper loaded: common_helper
INFO - 2017-07-28 09:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:36:13 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:36:13 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:36:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:36:13 --> Email Class Initialized
INFO - 2017-07-28 09:36:13 --> Form Validation Class Initialized
INFO - 2017-07-28 09:36:13 --> Model Class Initialized
INFO - 2017-07-28 09:36:13 --> Model Class Initialized
INFO - 2017-07-28 09:36:13 --> Model Class Initialized
INFO - 2017-07-28 09:36:13 --> Model Class Initialized
INFO - 2017-07-28 09:36:13 --> Controller Class Initialized
DEBUG - 2017-07-28 09:36:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:36:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 09:36:13 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 09:36:13 --> Final output sent to browser
DEBUG - 2017-07-28 09:36:13 --> Total execution time: 1.1940
DEBUG - 2017-07-28 09:36:13 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:36:14 --> Database Forge Class Initialized
INFO - 2017-07-28 09:36:15 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:43 --> Config Class Initialized
INFO - 2017-07-28 09:50:43 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:50:43 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:50:43 --> Utf8 Class Initialized
INFO - 2017-07-28 09:50:43 --> URI Class Initialized
DEBUG - 2017-07-28 09:50:43 --> No URI present. Default controller set.
INFO - 2017-07-28 09:50:43 --> Router Class Initialized
INFO - 2017-07-28 09:50:43 --> Output Class Initialized
INFO - 2017-07-28 09:50:43 --> Security Class Initialized
DEBUG - 2017-07-28 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:50:43 --> Input Class Initialized
INFO - 2017-07-28 09:50:43 --> Language Class Initialized
INFO - 2017-07-28 09:50:43 --> Loader Class Initialized
INFO - 2017-07-28 09:50:43 --> Helper loaded: url_helper
INFO - 2017-07-28 09:50:43 --> Helper loaded: form_helper
INFO - 2017-07-28 09:50:43 --> Helper loaded: security_helper
INFO - 2017-07-28 09:50:43 --> Helper loaded: path_helper
INFO - 2017-07-28 09:50:43 --> Helper loaded: common_helper
INFO - 2017-07-28 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:50:43 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:50:43 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:50:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:43 --> Email Class Initialized
INFO - 2017-07-28 09:50:43 --> Form Validation Class Initialized
INFO - 2017-07-28 09:50:43 --> Model Class Initialized
INFO - 2017-07-28 09:50:44 --> Model Class Initialized
INFO - 2017-07-28 09:50:44 --> Model Class Initialized
INFO - 2017-07-28 09:50:44 --> Model Class Initialized
INFO - 2017-07-28 09:50:44 --> Controller Class Initialized
DEBUG - 2017-07-28 09:50:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 09:50:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 09:50:44 --> Final output sent to browser
DEBUG - 2017-07-28 09:50:44 --> Total execution time: 0.0278
DEBUG - 2017-07-28 09:50:44 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:50:44 --> Database Forge Class Initialized
INFO - 2017-07-28 09:50:44 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:50:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:58 --> Config Class Initialized
INFO - 2017-07-28 09:50:58 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:50:58 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:50:58 --> Utf8 Class Initialized
INFO - 2017-07-28 09:50:58 --> URI Class Initialized
INFO - 2017-07-28 09:50:58 --> Router Class Initialized
INFO - 2017-07-28 09:50:58 --> Output Class Initialized
INFO - 2017-07-28 09:50:58 --> Security Class Initialized
DEBUG - 2017-07-28 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:50:58 --> Input Class Initialized
INFO - 2017-07-28 09:50:58 --> Language Class Initialized
INFO - 2017-07-28 09:50:58 --> Loader Class Initialized
INFO - 2017-07-28 09:50:58 --> Helper loaded: url_helper
INFO - 2017-07-28 09:50:58 --> Helper loaded: form_helper
INFO - 2017-07-28 09:50:58 --> Helper loaded: security_helper
INFO - 2017-07-28 09:50:58 --> Helper loaded: path_helper
INFO - 2017-07-28 09:50:58 --> Helper loaded: common_helper
INFO - 2017-07-28 09:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:50:58 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:50:58 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:58 --> Email Class Initialized
INFO - 2017-07-28 09:50:58 --> Form Validation Class Initialized
INFO - 2017-07-28 09:50:58 --> Model Class Initialized
INFO - 2017-07-28 09:50:58 --> Model Class Initialized
INFO - 2017-07-28 09:50:58 --> Model Class Initialized
INFO - 2017-07-28 09:50:58 --> Model Class Initialized
INFO - 2017-07-28 09:50:58 --> Controller Class Initialized
INFO - 2017-07-28 09:50:58 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/login.php
INFO - 2017-07-28 09:50:58 --> Final output sent to browser
DEBUG - 2017-07-28 09:50:58 --> Total execution time: 0.0396
DEBUG - 2017-07-28 09:50:58 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:50:58 --> Database Forge Class Initialized
INFO - 2017-07-28 09:50:58 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:50:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:50:59 --> Config Class Initialized
INFO - 2017-07-28 09:50:59 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:50:59 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:50:59 --> Utf8 Class Initialized
INFO - 2017-07-28 09:50:59 --> URI Class Initialized
INFO - 2017-07-28 09:50:59 --> Router Class Initialized
INFO - 2017-07-28 09:50:59 --> Output Class Initialized
INFO - 2017-07-28 09:50:59 --> Security Class Initialized
DEBUG - 2017-07-28 09:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:50:59 --> Input Class Initialized
INFO - 2017-07-28 09:50:59 --> Language Class Initialized
ERROR - 2017-07-28 09:50:59 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 09:51:01 --> Config Class Initialized
INFO - 2017-07-28 09:51:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:51:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:51:01 --> Utf8 Class Initialized
INFO - 2017-07-28 09:51:01 --> URI Class Initialized
INFO - 2017-07-28 09:51:01 --> Router Class Initialized
INFO - 2017-07-28 09:51:01 --> Output Class Initialized
INFO - 2017-07-28 09:51:01 --> Security Class Initialized
DEBUG - 2017-07-28 09:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:51:01 --> Input Class Initialized
INFO - 2017-07-28 09:51:01 --> Language Class Initialized
INFO - 2017-07-28 09:51:01 --> Loader Class Initialized
INFO - 2017-07-28 09:51:01 --> Helper loaded: url_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: form_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: security_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: path_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: common_helper
INFO - 2017-07-28 09:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:51:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:51:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:01 --> Email Class Initialized
INFO - 2017-07-28 09:51:01 --> Form Validation Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Controller Class Initialized
INFO - 2017-07-28 09:51:01 --> Config Class Initialized
INFO - 2017-07-28 09:51:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:51:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:51:01 --> Utf8 Class Initialized
INFO - 2017-07-28 09:51:01 --> URI Class Initialized
INFO - 2017-07-28 09:51:01 --> Router Class Initialized
INFO - 2017-07-28 09:51:01 --> Output Class Initialized
INFO - 2017-07-28 09:51:01 --> Security Class Initialized
DEBUG - 2017-07-28 09:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:51:01 --> Input Class Initialized
INFO - 2017-07-28 09:51:01 --> Language Class Initialized
INFO - 2017-07-28 09:51:01 --> Loader Class Initialized
INFO - 2017-07-28 09:51:01 --> Helper loaded: url_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: form_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: security_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: path_helper
INFO - 2017-07-28 09:51:01 --> Helper loaded: common_helper
INFO - 2017-07-28 09:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:51:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:51:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:51:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:01 --> Email Class Initialized
INFO - 2017-07-28 09:51:01 --> Form Validation Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Model Class Initialized
INFO - 2017-07-28 09:51:01 --> Controller Class Initialized
INFO - 2017-07-28 09:51:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-28 09:51:01 --> Pagination Class Initialized
INFO - 2017-07-28 09:51:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 09:51:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-07-28 09:51:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 09:51:02 --> Final output sent to browser
DEBUG - 2017-07-28 09:51:02 --> Total execution time: 1.0328
DEBUG - 2017-07-28 09:51:02 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:51:02 --> Database Forge Class Initialized
INFO - 2017-07-28 09:51:02 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:25 --> Config Class Initialized
INFO - 2017-07-28 09:51:25 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:51:25 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:51:25 --> Utf8 Class Initialized
INFO - 2017-07-28 09:51:25 --> URI Class Initialized
INFO - 2017-07-28 09:51:25 --> Router Class Initialized
INFO - 2017-07-28 09:51:25 --> Output Class Initialized
INFO - 2017-07-28 09:51:25 --> Security Class Initialized
DEBUG - 2017-07-28 09:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:51:25 --> Input Class Initialized
INFO - 2017-07-28 09:51:25 --> Language Class Initialized
INFO - 2017-07-28 09:51:25 --> Loader Class Initialized
INFO - 2017-07-28 09:51:25 --> Helper loaded: url_helper
INFO - 2017-07-28 09:51:25 --> Helper loaded: form_helper
INFO - 2017-07-28 09:51:25 --> Helper loaded: security_helper
INFO - 2017-07-28 09:51:25 --> Helper loaded: path_helper
INFO - 2017-07-28 09:51:25 --> Helper loaded: common_helper
INFO - 2017-07-28 09:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:51:25 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:51:25 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:25 --> Email Class Initialized
INFO - 2017-07-28 09:51:25 --> Form Validation Class Initialized
INFO - 2017-07-28 09:51:25 --> Model Class Initialized
INFO - 2017-07-28 09:51:25 --> Model Class Initialized
INFO - 2017-07-28 09:51:25 --> Model Class Initialized
INFO - 2017-07-28 09:51:25 --> Model Class Initialized
INFO - 2017-07-28 09:51:25 --> Controller Class Initialized
INFO - 2017-07-28 09:51:25 --> Model Class Initialized
INFO - 2017-07-28 09:51:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 09:51:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/email_templates.php
INFO - 2017-07-28 09:51:25 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 09:51:25 --> Final output sent to browser
DEBUG - 2017-07-28 09:51:25 --> Total execution time: 0.1328
DEBUG - 2017-07-28 09:51:25 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:51:25 --> Database Forge Class Initialized
INFO - 2017-07-28 09:51:25 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:29 --> Config Class Initialized
INFO - 2017-07-28 09:51:29 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:51:29 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:51:29 --> Utf8 Class Initialized
INFO - 2017-07-28 09:51:29 --> URI Class Initialized
INFO - 2017-07-28 09:51:29 --> Router Class Initialized
INFO - 2017-07-28 09:51:29 --> Output Class Initialized
INFO - 2017-07-28 09:51:29 --> Security Class Initialized
DEBUG - 2017-07-28 09:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:51:29 --> Input Class Initialized
INFO - 2017-07-28 09:51:29 --> Language Class Initialized
INFO - 2017-07-28 09:51:29 --> Loader Class Initialized
INFO - 2017-07-28 09:51:29 --> Helper loaded: url_helper
INFO - 2017-07-28 09:51:29 --> Helper loaded: form_helper
INFO - 2017-07-28 09:51:29 --> Helper loaded: security_helper
INFO - 2017-07-28 09:51:29 --> Helper loaded: path_helper
INFO - 2017-07-28 09:51:29 --> Helper loaded: common_helper
INFO - 2017-07-28 09:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:51:29 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:51:29 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:51:29 --> Email Class Initialized
INFO - 2017-07-28 09:51:29 --> Form Validation Class Initialized
INFO - 2017-07-28 09:51:29 --> Model Class Initialized
INFO - 2017-07-28 09:51:29 --> Model Class Initialized
INFO - 2017-07-28 09:51:29 --> Model Class Initialized
INFO - 2017-07-28 09:51:29 --> Model Class Initialized
INFO - 2017-07-28 09:51:29 --> Controller Class Initialized
INFO - 2017-07-28 09:51:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 09:51:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-28 09:51:29 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 09:51:29 --> Final output sent to browser
DEBUG - 2017-07-28 09:51:29 --> Total execution time: 0.2661
DEBUG - 2017-07-28 09:51:29 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:51:29 --> Database Forge Class Initialized
INFO - 2017-07-28 09:51:29 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:01 --> Config Class Initialized
INFO - 2017-07-28 09:53:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:53:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:53:01 --> Utf8 Class Initialized
INFO - 2017-07-28 09:53:01 --> URI Class Initialized
DEBUG - 2017-07-28 09:53:01 --> No URI present. Default controller set.
INFO - 2017-07-28 09:53:01 --> Router Class Initialized
INFO - 2017-07-28 09:53:01 --> Output Class Initialized
INFO - 2017-07-28 09:53:01 --> Security Class Initialized
DEBUG - 2017-07-28 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:53:01 --> Input Class Initialized
INFO - 2017-07-28 09:53:01 --> Language Class Initialized
INFO - 2017-07-28 09:53:01 --> Loader Class Initialized
INFO - 2017-07-28 09:53:01 --> Helper loaded: url_helper
INFO - 2017-07-28 09:53:01 --> Helper loaded: form_helper
INFO - 2017-07-28 09:53:01 --> Helper loaded: security_helper
INFO - 2017-07-28 09:53:01 --> Helper loaded: path_helper
INFO - 2017-07-28 09:53:01 --> Helper loaded: common_helper
INFO - 2017-07-28 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:53:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:53:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:53:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:01 --> Email Class Initialized
INFO - 2017-07-28 09:53:01 --> Form Validation Class Initialized
INFO - 2017-07-28 09:53:01 --> Model Class Initialized
INFO - 2017-07-28 09:53:01 --> Model Class Initialized
INFO - 2017-07-28 09:53:01 --> Model Class Initialized
INFO - 2017-07-28 09:53:01 --> Model Class Initialized
INFO - 2017-07-28 09:53:01 --> Controller Class Initialized
DEBUG - 2017-07-28 09:53:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 09:53:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 09:53:01 --> Final output sent to browser
DEBUG - 2017-07-28 09:53:01 --> Total execution time: 0.0313
DEBUG - 2017-07-28 09:53:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:53:02 --> Database Forge Class Initialized
INFO - 2017-07-28 09:53:02 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:09 --> Config Class Initialized
INFO - 2017-07-28 09:53:09 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:53:09 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:53:09 --> Utf8 Class Initialized
INFO - 2017-07-28 09:53:09 --> URI Class Initialized
INFO - 2017-07-28 09:53:09 --> Router Class Initialized
INFO - 2017-07-28 09:53:09 --> Output Class Initialized
INFO - 2017-07-28 09:53:09 --> Security Class Initialized
DEBUG - 2017-07-28 09:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:53:09 --> Input Class Initialized
INFO - 2017-07-28 09:53:09 --> Language Class Initialized
INFO - 2017-07-28 09:53:09 --> Loader Class Initialized
INFO - 2017-07-28 09:53:09 --> Helper loaded: url_helper
INFO - 2017-07-28 09:53:09 --> Helper loaded: form_helper
INFO - 2017-07-28 09:53:09 --> Helper loaded: security_helper
INFO - 2017-07-28 09:53:09 --> Helper loaded: path_helper
INFO - 2017-07-28 09:53:09 --> Helper loaded: common_helper
INFO - 2017-07-28 09:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:53:09 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:53:09 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:09 --> Email Class Initialized
INFO - 2017-07-28 09:53:09 --> Form Validation Class Initialized
INFO - 2017-07-28 09:53:09 --> Model Class Initialized
INFO - 2017-07-28 09:53:09 --> Model Class Initialized
INFO - 2017-07-28 09:53:09 --> Model Class Initialized
INFO - 2017-07-28 09:53:09 --> Model Class Initialized
INFO - 2017-07-28 09:53:09 --> Controller Class Initialized
INFO - 2017-07-28 09:53:10 --> Model Class Initialized
INFO - 2017-07-28 09:53:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 09:53:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 09:53:10 --> Final output sent to browser
DEBUG - 2017-07-28 09:53:10 --> Total execution time: 0.9691
DEBUG - 2017-07-28 09:53:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:53:10 --> Database Forge Class Initialized
INFO - 2017-07-28 09:53:10 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:53:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:53:17 --> Config Class Initialized
INFO - 2017-07-28 09:53:17 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:53:17 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:53:17 --> Utf8 Class Initialized
INFO - 2017-07-28 09:53:17 --> URI Class Initialized
INFO - 2017-07-28 09:53:17 --> Router Class Initialized
INFO - 2017-07-28 09:53:17 --> Output Class Initialized
INFO - 2017-07-28 09:53:17 --> Security Class Initialized
DEBUG - 2017-07-28 09:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:53:17 --> Input Class Initialized
INFO - 2017-07-28 09:53:17 --> Language Class Initialized
ERROR - 2017-07-28 09:53:17 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 09:55:00 --> Config Class Initialized
INFO - 2017-07-28 09:55:00 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:55:00 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:55:00 --> Utf8 Class Initialized
INFO - 2017-07-28 09:55:00 --> URI Class Initialized
DEBUG - 2017-07-28 09:55:00 --> No URI present. Default controller set.
INFO - 2017-07-28 09:55:00 --> Router Class Initialized
INFO - 2017-07-28 09:55:00 --> Output Class Initialized
INFO - 2017-07-28 09:55:00 --> Security Class Initialized
DEBUG - 2017-07-28 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:55:00 --> Input Class Initialized
INFO - 2017-07-28 09:55:00 --> Language Class Initialized
INFO - 2017-07-28 09:55:00 --> Loader Class Initialized
INFO - 2017-07-28 09:55:00 --> Helper loaded: url_helper
INFO - 2017-07-28 09:55:00 --> Helper loaded: form_helper
INFO - 2017-07-28 09:55:00 --> Helper loaded: security_helper
INFO - 2017-07-28 09:55:00 --> Helper loaded: path_helper
INFO - 2017-07-28 09:55:00 --> Helper loaded: common_helper
INFO - 2017-07-28 09:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:55:00 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:55:00 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:55:00 --> Email Class Initialized
INFO - 2017-07-28 09:55:00 --> Form Validation Class Initialized
INFO - 2017-07-28 09:55:00 --> Model Class Initialized
INFO - 2017-07-28 09:55:00 --> Model Class Initialized
INFO - 2017-07-28 09:55:00 --> Model Class Initialized
INFO - 2017-07-28 09:55:00 --> Model Class Initialized
INFO - 2017-07-28 09:55:00 --> Controller Class Initialized
DEBUG - 2017-07-28 09:55:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:55:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 09:55:00 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 09:55:00 --> Final output sent to browser
DEBUG - 2017-07-28 09:55:00 --> Total execution time: 0.0286
DEBUG - 2017-07-28 09:55:00 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:55:00 --> Database Forge Class Initialized
INFO - 2017-07-28 09:55:00 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:55:17 --> Config Class Initialized
INFO - 2017-07-28 09:55:17 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:55:17 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:55:17 --> Utf8 Class Initialized
INFO - 2017-07-28 09:55:17 --> URI Class Initialized
INFO - 2017-07-28 09:55:17 --> Router Class Initialized
INFO - 2017-07-28 09:55:17 --> Output Class Initialized
INFO - 2017-07-28 09:55:17 --> Security Class Initialized
DEBUG - 2017-07-28 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:55:17 --> Input Class Initialized
INFO - 2017-07-28 09:55:17 --> Language Class Initialized
INFO - 2017-07-28 09:55:17 --> Loader Class Initialized
INFO - 2017-07-28 09:55:17 --> Helper loaded: url_helper
INFO - 2017-07-28 09:55:17 --> Helper loaded: form_helper
INFO - 2017-07-28 09:55:17 --> Helper loaded: security_helper
INFO - 2017-07-28 09:55:17 --> Helper loaded: path_helper
INFO - 2017-07-28 09:55:17 --> Helper loaded: common_helper
INFO - 2017-07-28 09:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:55:17 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:55:17 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:55:17 --> Email Class Initialized
INFO - 2017-07-28 09:55:17 --> Form Validation Class Initialized
INFO - 2017-07-28 09:55:17 --> Model Class Initialized
INFO - 2017-07-28 09:55:17 --> Model Class Initialized
INFO - 2017-07-28 09:55:17 --> Model Class Initialized
INFO - 2017-07-28 09:55:17 --> Model Class Initialized
INFO - 2017-07-28 09:55:17 --> Controller Class Initialized
INFO - 2017-07-28 09:55:17 --> Model Class Initialized
INFO - 2017-07-28 09:55:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 09:55:17 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 09:55:17 --> Final output sent to browser
DEBUG - 2017-07-28 09:55:17 --> Total execution time: 0.0283
DEBUG - 2017-07-28 09:55:17 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:55:17 --> Database Forge Class Initialized
INFO - 2017-07-28 09:55:17 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:55:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:55:28 --> Config Class Initialized
INFO - 2017-07-28 09:55:28 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:55:28 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:55:28 --> Utf8 Class Initialized
INFO - 2017-07-28 09:55:28 --> URI Class Initialized
INFO - 2017-07-28 09:55:28 --> Router Class Initialized
INFO - 2017-07-28 09:55:28 --> Output Class Initialized
INFO - 2017-07-28 09:55:28 --> Security Class Initialized
DEBUG - 2017-07-28 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:55:28 --> Input Class Initialized
INFO - 2017-07-28 09:55:28 --> Language Class Initialized
ERROR - 2017-07-28 09:55:28 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 09:59:01 --> Config Class Initialized
INFO - 2017-07-28 09:59:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:59:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:59:01 --> Utf8 Class Initialized
INFO - 2017-07-28 09:59:01 --> URI Class Initialized
INFO - 2017-07-28 09:59:01 --> Router Class Initialized
INFO - 2017-07-28 09:59:01 --> Output Class Initialized
INFO - 2017-07-28 09:59:01 --> Security Class Initialized
DEBUG - 2017-07-28 09:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:59:01 --> Input Class Initialized
INFO - 2017-07-28 09:59:01 --> Language Class Initialized
INFO - 2017-07-28 09:59:01 --> Loader Class Initialized
INFO - 2017-07-28 09:59:01 --> Helper loaded: url_helper
INFO - 2017-07-28 09:59:01 --> Helper loaded: form_helper
INFO - 2017-07-28 09:59:01 --> Helper loaded: security_helper
INFO - 2017-07-28 09:59:01 --> Helper loaded: path_helper
INFO - 2017-07-28 09:59:01 --> Helper loaded: common_helper
INFO - 2017-07-28 09:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:59:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:59:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:01 --> Email Class Initialized
INFO - 2017-07-28 09:59:01 --> Form Validation Class Initialized
INFO - 2017-07-28 09:59:01 --> Model Class Initialized
INFO - 2017-07-28 09:59:01 --> Model Class Initialized
INFO - 2017-07-28 09:59:01 --> Model Class Initialized
INFO - 2017-07-28 09:59:01 --> Model Class Initialized
INFO - 2017-07-28 09:59:01 --> Controller Class Initialized
INFO - 2017-07-28 09:59:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 09:59:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-28 09:59:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 09:59:01 --> Final output sent to browser
DEBUG - 2017-07-28 09:59:01 --> Total execution time: 0.0306
DEBUG - 2017-07-28 09:59:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:59:01 --> Database Forge Class Initialized
INFO - 2017-07-28 09:59:01 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:59:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:02 --> Config Class Initialized
INFO - 2017-07-28 09:59:02 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:59:02 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:59:02 --> Utf8 Class Initialized
INFO - 2017-07-28 09:59:02 --> URI Class Initialized
INFO - 2017-07-28 09:59:02 --> Router Class Initialized
INFO - 2017-07-28 09:59:02 --> Output Class Initialized
INFO - 2017-07-28 09:59:02 --> Security Class Initialized
DEBUG - 2017-07-28 09:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:59:02 --> Input Class Initialized
INFO - 2017-07-28 09:59:02 --> Language Class Initialized
INFO - 2017-07-28 09:59:02 --> Loader Class Initialized
INFO - 2017-07-28 09:59:02 --> Helper loaded: url_helper
INFO - 2017-07-28 09:59:02 --> Helper loaded: form_helper
INFO - 2017-07-28 09:59:02 --> Helper loaded: security_helper
INFO - 2017-07-28 09:59:02 --> Helper loaded: path_helper
INFO - 2017-07-28 09:59:02 --> Helper loaded: common_helper
INFO - 2017-07-28 09:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:59:02 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:59:02 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:02 --> Email Class Initialized
INFO - 2017-07-28 09:59:02 --> Form Validation Class Initialized
INFO - 2017-07-28 09:59:02 --> Model Class Initialized
INFO - 2017-07-28 09:59:02 --> Model Class Initialized
INFO - 2017-07-28 09:59:02 --> Model Class Initialized
INFO - 2017-07-28 09:59:02 --> Model Class Initialized
INFO - 2017-07-28 09:59:02 --> Controller Class Initialized
INFO - 2017-07-28 09:59:02 --> Model Class Initialized
INFO - 2017-07-28 09:59:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 09:59:02 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 09:59:02 --> Final output sent to browser
DEBUG - 2017-07-28 09:59:02 --> Total execution time: 0.0276
DEBUG - 2017-07-28 09:59:02 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:59:02 --> Database Forge Class Initialized
INFO - 2017-07-28 09:59:02 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:59:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:10 --> Config Class Initialized
INFO - 2017-07-28 09:59:10 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:59:10 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:59:10 --> Utf8 Class Initialized
INFO - 2017-07-28 09:59:10 --> URI Class Initialized
INFO - 2017-07-28 09:59:10 --> Router Class Initialized
INFO - 2017-07-28 09:59:10 --> Output Class Initialized
INFO - 2017-07-28 09:59:10 --> Security Class Initialized
DEBUG - 2017-07-28 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:59:10 --> Input Class Initialized
INFO - 2017-07-28 09:59:10 --> Language Class Initialized
ERROR - 2017-07-28 09:59:10 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 09:59:20 --> Config Class Initialized
INFO - 2017-07-28 09:59:20 --> Hooks Class Initialized
DEBUG - 2017-07-28 09:59:20 --> UTF-8 Support Enabled
INFO - 2017-07-28 09:59:20 --> Utf8 Class Initialized
INFO - 2017-07-28 09:59:20 --> URI Class Initialized
DEBUG - 2017-07-28 09:59:20 --> No URI present. Default controller set.
INFO - 2017-07-28 09:59:20 --> Router Class Initialized
INFO - 2017-07-28 09:59:20 --> Output Class Initialized
INFO - 2017-07-28 09:59:20 --> Security Class Initialized
DEBUG - 2017-07-28 09:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 09:59:20 --> Input Class Initialized
INFO - 2017-07-28 09:59:20 --> Language Class Initialized
INFO - 2017-07-28 09:59:20 --> Loader Class Initialized
INFO - 2017-07-28 09:59:20 --> Helper loaded: url_helper
INFO - 2017-07-28 09:59:20 --> Helper loaded: form_helper
INFO - 2017-07-28 09:59:20 --> Helper loaded: security_helper
INFO - 2017-07-28 09:59:20 --> Helper loaded: path_helper
INFO - 2017-07-28 09:59:20 --> Helper loaded: common_helper
INFO - 2017-07-28 09:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 09:59:20 --> Helper loaded: check_session_helper
INFO - 2017-07-28 09:59:20 --> Database Driver Class Initialized
DEBUG - 2017-07-28 09:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:20 --> Email Class Initialized
INFO - 2017-07-28 09:59:20 --> Form Validation Class Initialized
INFO - 2017-07-28 09:59:20 --> Model Class Initialized
INFO - 2017-07-28 09:59:20 --> Model Class Initialized
INFO - 2017-07-28 09:59:20 --> Model Class Initialized
INFO - 2017-07-28 09:59:20 --> Model Class Initialized
INFO - 2017-07-28 09:59:20 --> Controller Class Initialized
DEBUG - 2017-07-28 09:59:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 09:59:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 09:59:20 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 09:59:20 --> Final output sent to browser
DEBUG - 2017-07-28 09:59:20 --> Total execution time: 0.0288
DEBUG - 2017-07-28 09:59:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 09:59:20 --> Database Forge Class Initialized
INFO - 2017-07-28 09:59:20 --> User Agent Class Initialized
DEBUG - 2017-07-28 09:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:00:23 --> Config Class Initialized
INFO - 2017-07-28 10:00:23 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:00:23 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:00:23 --> Utf8 Class Initialized
INFO - 2017-07-28 10:00:23 --> URI Class Initialized
INFO - 2017-07-28 10:00:23 --> Router Class Initialized
INFO - 2017-07-28 10:00:23 --> Output Class Initialized
INFO - 2017-07-28 10:00:23 --> Security Class Initialized
DEBUG - 2017-07-28 10:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:00:23 --> Input Class Initialized
INFO - 2017-07-28 10:00:23 --> Language Class Initialized
INFO - 2017-07-28 10:00:23 --> Loader Class Initialized
INFO - 2017-07-28 10:00:23 --> Helper loaded: url_helper
INFO - 2017-07-28 10:00:23 --> Helper loaded: form_helper
INFO - 2017-07-28 10:00:23 --> Helper loaded: security_helper
INFO - 2017-07-28 10:00:23 --> Helper loaded: path_helper
INFO - 2017-07-28 10:00:23 --> Helper loaded: common_helper
INFO - 2017-07-28 10:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:00:23 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:00:23 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:00:23 --> Email Class Initialized
INFO - 2017-07-28 10:00:23 --> Form Validation Class Initialized
INFO - 2017-07-28 10:00:23 --> Model Class Initialized
INFO - 2017-07-28 10:00:23 --> Model Class Initialized
INFO - 2017-07-28 10:00:23 --> Model Class Initialized
INFO - 2017-07-28 10:00:23 --> Model Class Initialized
INFO - 2017-07-28 10:00:23 --> Controller Class Initialized
INFO - 2017-07-28 10:00:23 --> Model Class Initialized
INFO - 2017-07-28 10:00:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:00:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:00:23 --> Final output sent to browser
DEBUG - 2017-07-28 10:00:23 --> Total execution time: 0.0310
DEBUG - 2017-07-28 10:00:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:00:23 --> Database Forge Class Initialized
INFO - 2017-07-28 10:00:23 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:01:08 --> Config Class Initialized
INFO - 2017-07-28 10:01:08 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:01:08 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:01:08 --> Utf8 Class Initialized
INFO - 2017-07-28 10:01:08 --> URI Class Initialized
INFO - 2017-07-28 10:01:08 --> Router Class Initialized
INFO - 2017-07-28 10:01:08 --> Output Class Initialized
INFO - 2017-07-28 10:01:08 --> Security Class Initialized
DEBUG - 2017-07-28 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:01:08 --> Input Class Initialized
INFO - 2017-07-28 10:01:08 --> Language Class Initialized
ERROR - 2017-07-28 10:01:08 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 10:01:18 --> Config Class Initialized
INFO - 2017-07-28 10:01:18 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:01:18 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:01:18 --> Utf8 Class Initialized
INFO - 2017-07-28 10:01:18 --> URI Class Initialized
INFO - 2017-07-28 10:01:18 --> Router Class Initialized
INFO - 2017-07-28 10:01:18 --> Output Class Initialized
INFO - 2017-07-28 10:01:18 --> Security Class Initialized
DEBUG - 2017-07-28 10:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:01:18 --> Input Class Initialized
INFO - 2017-07-28 10:01:18 --> Language Class Initialized
ERROR - 2017-07-28 10:01:18 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:01:26 --> Config Class Initialized
INFO - 2017-07-28 10:01:26 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:01:26 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:01:26 --> Utf8 Class Initialized
INFO - 2017-07-28 10:01:26 --> URI Class Initialized
INFO - 2017-07-28 10:01:26 --> Router Class Initialized
INFO - 2017-07-28 10:01:26 --> Output Class Initialized
INFO - 2017-07-28 10:01:26 --> Security Class Initialized
DEBUG - 2017-07-28 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:01:26 --> Input Class Initialized
INFO - 2017-07-28 10:01:26 --> Language Class Initialized
ERROR - 2017-07-28 10:01:26 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 10:04:14 --> Config Class Initialized
INFO - 2017-07-28 10:04:14 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:04:14 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:04:14 --> Utf8 Class Initialized
INFO - 2017-07-28 10:04:14 --> URI Class Initialized
DEBUG - 2017-07-28 10:04:14 --> No URI present. Default controller set.
INFO - 2017-07-28 10:04:14 --> Router Class Initialized
INFO - 2017-07-28 10:04:14 --> Output Class Initialized
INFO - 2017-07-28 10:04:14 --> Security Class Initialized
DEBUG - 2017-07-28 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:04:14 --> Input Class Initialized
INFO - 2017-07-28 10:04:14 --> Language Class Initialized
INFO - 2017-07-28 10:04:14 --> Loader Class Initialized
INFO - 2017-07-28 10:04:14 --> Helper loaded: url_helper
INFO - 2017-07-28 10:04:14 --> Helper loaded: form_helper
INFO - 2017-07-28 10:04:14 --> Helper loaded: security_helper
INFO - 2017-07-28 10:04:14 --> Helper loaded: path_helper
INFO - 2017-07-28 10:04:14 --> Helper loaded: common_helper
INFO - 2017-07-28 10:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:04:14 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:04:14 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:04:14 --> Email Class Initialized
INFO - 2017-07-28 10:04:14 --> Form Validation Class Initialized
INFO - 2017-07-28 10:04:14 --> Model Class Initialized
INFO - 2017-07-28 10:04:14 --> Model Class Initialized
INFO - 2017-07-28 10:04:14 --> Model Class Initialized
INFO - 2017-07-28 10:04:14 --> Model Class Initialized
INFO - 2017-07-28 10:04:14 --> Controller Class Initialized
DEBUG - 2017-07-28 10:04:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:04:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:04:14 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:04:14 --> Final output sent to browser
DEBUG - 2017-07-28 10:04:14 --> Total execution time: 0.0293
DEBUG - 2017-07-28 10:04:14 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:04:14 --> Database Forge Class Initialized
INFO - 2017-07-28 10:04:14 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:04:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:01 --> Config Class Initialized
INFO - 2017-07-28 10:08:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:08:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:08:01 --> Utf8 Class Initialized
INFO - 2017-07-28 10:08:01 --> URI Class Initialized
INFO - 2017-07-28 10:08:01 --> Router Class Initialized
INFO - 2017-07-28 10:08:01 --> Output Class Initialized
INFO - 2017-07-28 10:08:01 --> Security Class Initialized
DEBUG - 2017-07-28 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:08:01 --> Input Class Initialized
INFO - 2017-07-28 10:08:01 --> Language Class Initialized
INFO - 2017-07-28 10:08:01 --> Loader Class Initialized
INFO - 2017-07-28 10:08:01 --> Helper loaded: url_helper
INFO - 2017-07-28 10:08:01 --> Helper loaded: form_helper
INFO - 2017-07-28 10:08:01 --> Helper loaded: security_helper
INFO - 2017-07-28 10:08:01 --> Helper loaded: path_helper
INFO - 2017-07-28 10:08:01 --> Helper loaded: common_helper
INFO - 2017-07-28 10:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:08:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:08:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:01 --> Email Class Initialized
INFO - 2017-07-28 10:08:01 --> Form Validation Class Initialized
INFO - 2017-07-28 10:08:01 --> Model Class Initialized
INFO - 2017-07-28 10:08:01 --> Model Class Initialized
INFO - 2017-07-28 10:08:01 --> Model Class Initialized
INFO - 2017-07-28 10:08:01 --> Model Class Initialized
INFO - 2017-07-28 10:08:01 --> Controller Class Initialized
INFO - 2017-07-28 10:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-28 10:08:01 --> Pagination Class Initialized
INFO - 2017-07-28 10:08:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 10:08:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managetumorboards.php
INFO - 2017-07-28 10:08:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 10:08:01 --> Final output sent to browser
DEBUG - 2017-07-28 10:08:01 --> Total execution time: 0.1994
DEBUG - 2017-07-28 10:08:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:08:01 --> Database Forge Class Initialized
INFO - 2017-07-28 10:08:01 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:06 --> Config Class Initialized
INFO - 2017-07-28 10:08:06 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:08:06 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:08:06 --> Utf8 Class Initialized
INFO - 2017-07-28 10:08:06 --> URI Class Initialized
INFO - 2017-07-28 10:08:06 --> Router Class Initialized
INFO - 2017-07-28 10:08:06 --> Output Class Initialized
INFO - 2017-07-28 10:08:06 --> Security Class Initialized
DEBUG - 2017-07-28 10:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:08:06 --> Input Class Initialized
INFO - 2017-07-28 10:08:06 --> Language Class Initialized
INFO - 2017-07-28 10:08:06 --> Loader Class Initialized
INFO - 2017-07-28 10:08:06 --> Helper loaded: url_helper
INFO - 2017-07-28 10:08:06 --> Helper loaded: form_helper
INFO - 2017-07-28 10:08:06 --> Helper loaded: security_helper
INFO - 2017-07-28 10:08:06 --> Helper loaded: path_helper
INFO - 2017-07-28 10:08:06 --> Helper loaded: common_helper
INFO - 2017-07-28 10:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:08:06 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:08:06 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:06 --> Email Class Initialized
INFO - 2017-07-28 10:08:06 --> Form Validation Class Initialized
INFO - 2017-07-28 10:08:06 --> Model Class Initialized
INFO - 2017-07-28 10:08:06 --> Model Class Initialized
INFO - 2017-07-28 10:08:06 --> Model Class Initialized
INFO - 2017-07-28 10:08:06 --> Model Class Initialized
INFO - 2017-07-28 10:08:06 --> Controller Class Initialized
INFO - 2017-07-28 10:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-28 10:08:06 --> Pagination Class Initialized
INFO - 2017-07-28 10:08:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 10:08:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/users.php
INFO - 2017-07-28 10:08:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 10:08:06 --> Final output sent to browser
DEBUG - 2017-07-28 10:08:06 --> Total execution time: 0.0347
DEBUG - 2017-07-28 10:08:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:08:06 --> Database Forge Class Initialized
INFO - 2017-07-28 10:08:06 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:09 --> Config Class Initialized
INFO - 2017-07-28 10:08:09 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:08:09 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:08:09 --> Utf8 Class Initialized
INFO - 2017-07-28 10:08:09 --> URI Class Initialized
INFO - 2017-07-28 10:08:09 --> Router Class Initialized
INFO - 2017-07-28 10:08:09 --> Output Class Initialized
INFO - 2017-07-28 10:08:09 --> Security Class Initialized
DEBUG - 2017-07-28 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:08:09 --> Input Class Initialized
INFO - 2017-07-28 10:08:09 --> Language Class Initialized
INFO - 2017-07-28 10:08:09 --> Loader Class Initialized
INFO - 2017-07-28 10:08:09 --> Helper loaded: url_helper
INFO - 2017-07-28 10:08:09 --> Helper loaded: form_helper
INFO - 2017-07-28 10:08:09 --> Helper loaded: security_helper
INFO - 2017-07-28 10:08:09 --> Helper loaded: path_helper
INFO - 2017-07-28 10:08:09 --> Helper loaded: common_helper
INFO - 2017-07-28 10:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:08:09 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:08:09 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:08:09 --> Email Class Initialized
INFO - 2017-07-28 10:08:09 --> Form Validation Class Initialized
INFO - 2017-07-28 10:08:09 --> Model Class Initialized
INFO - 2017-07-28 10:08:09 --> Model Class Initialized
INFO - 2017-07-28 10:08:09 --> Model Class Initialized
INFO - 2017-07-28 10:08:09 --> Model Class Initialized
INFO - 2017-07-28 10:08:09 --> Controller Class Initialized
INFO - 2017-07-28 10:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-28 10:08:09 --> Pagination Class Initialized
INFO - 2017-07-28 10:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 10:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-07-28 10:08:09 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 10:08:09 --> Final output sent to browser
DEBUG - 2017-07-28 10:08:09 --> Total execution time: 0.2863
DEBUG - 2017-07-28 10:08:09 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:08:09 --> Database Forge Class Initialized
INFO - 2017-07-28 10:08:09 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:19:23 --> Config Class Initialized
INFO - 2017-07-28 10:19:23 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:19:23 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:19:23 --> Utf8 Class Initialized
INFO - 2017-07-28 10:19:23 --> URI Class Initialized
DEBUG - 2017-07-28 10:19:23 --> No URI present. Default controller set.
INFO - 2017-07-28 10:19:23 --> Router Class Initialized
INFO - 2017-07-28 10:19:23 --> Output Class Initialized
INFO - 2017-07-28 10:19:23 --> Security Class Initialized
DEBUG - 2017-07-28 10:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:19:23 --> Input Class Initialized
INFO - 2017-07-28 10:19:23 --> Language Class Initialized
INFO - 2017-07-28 10:19:23 --> Loader Class Initialized
INFO - 2017-07-28 10:19:23 --> Helper loaded: url_helper
INFO - 2017-07-28 10:19:23 --> Helper loaded: form_helper
INFO - 2017-07-28 10:19:23 --> Helper loaded: security_helper
INFO - 2017-07-28 10:19:23 --> Helper loaded: path_helper
INFO - 2017-07-28 10:19:23 --> Helper loaded: common_helper
INFO - 2017-07-28 10:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:19:23 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:19:23 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:19:23 --> Email Class Initialized
INFO - 2017-07-28 10:19:23 --> Form Validation Class Initialized
INFO - 2017-07-28 10:19:23 --> Model Class Initialized
INFO - 2017-07-28 10:19:23 --> Model Class Initialized
INFO - 2017-07-28 10:19:23 --> Model Class Initialized
INFO - 2017-07-28 10:19:23 --> Model Class Initialized
INFO - 2017-07-28 10:19:23 --> Controller Class Initialized
DEBUG - 2017-07-28 10:19:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:19:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:19:23 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:19:23 --> Final output sent to browser
DEBUG - 2017-07-28 10:19:23 --> Total execution time: 0.0281
DEBUG - 2017-07-28 10:19:23 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:19:23 --> Database Forge Class Initialized
INFO - 2017-07-28 10:19:23 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:21:11 --> Config Class Initialized
INFO - 2017-07-28 10:21:11 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:21:11 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:21:11 --> Utf8 Class Initialized
INFO - 2017-07-28 10:21:11 --> URI Class Initialized
DEBUG - 2017-07-28 10:21:11 --> No URI present. Default controller set.
INFO - 2017-07-28 10:21:11 --> Router Class Initialized
INFO - 2017-07-28 10:21:11 --> Output Class Initialized
INFO - 2017-07-28 10:21:11 --> Security Class Initialized
DEBUG - 2017-07-28 10:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:21:11 --> Input Class Initialized
INFO - 2017-07-28 10:21:11 --> Language Class Initialized
INFO - 2017-07-28 10:21:11 --> Loader Class Initialized
INFO - 2017-07-28 10:21:11 --> Helper loaded: url_helper
INFO - 2017-07-28 10:21:11 --> Helper loaded: form_helper
INFO - 2017-07-28 10:21:11 --> Helper loaded: security_helper
INFO - 2017-07-28 10:21:11 --> Helper loaded: path_helper
INFO - 2017-07-28 10:21:11 --> Helper loaded: common_helper
INFO - 2017-07-28 10:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:21:11 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:21:11 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:21:11 --> Email Class Initialized
INFO - 2017-07-28 10:21:11 --> Form Validation Class Initialized
INFO - 2017-07-28 10:21:11 --> Model Class Initialized
INFO - 2017-07-28 10:21:11 --> Model Class Initialized
INFO - 2017-07-28 10:21:11 --> Model Class Initialized
INFO - 2017-07-28 10:21:11 --> Model Class Initialized
INFO - 2017-07-28 10:21:11 --> Controller Class Initialized
DEBUG - 2017-07-28 10:21:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:21:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:21:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:21:11 --> Final output sent to browser
DEBUG - 2017-07-28 10:21:11 --> Total execution time: 0.0283
DEBUG - 2017-07-28 10:21:11 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:21:11 --> Database Forge Class Initialized
INFO - 2017-07-28 10:21:11 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:22:46 --> Config Class Initialized
INFO - 2017-07-28 10:22:46 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:22:46 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:22:46 --> Utf8 Class Initialized
INFO - 2017-07-28 10:22:46 --> URI Class Initialized
DEBUG - 2017-07-28 10:22:46 --> No URI present. Default controller set.
INFO - 2017-07-28 10:22:46 --> Router Class Initialized
INFO - 2017-07-28 10:22:46 --> Output Class Initialized
INFO - 2017-07-28 10:22:46 --> Security Class Initialized
DEBUG - 2017-07-28 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:22:46 --> Input Class Initialized
INFO - 2017-07-28 10:22:46 --> Language Class Initialized
INFO - 2017-07-28 10:22:46 --> Loader Class Initialized
INFO - 2017-07-28 10:22:46 --> Helper loaded: url_helper
INFO - 2017-07-28 10:22:46 --> Helper loaded: form_helper
INFO - 2017-07-28 10:22:46 --> Helper loaded: security_helper
INFO - 2017-07-28 10:22:46 --> Helper loaded: path_helper
INFO - 2017-07-28 10:22:46 --> Helper loaded: common_helper
INFO - 2017-07-28 10:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:22:46 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:22:46 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:22:46 --> Email Class Initialized
INFO - 2017-07-28 10:22:46 --> Form Validation Class Initialized
INFO - 2017-07-28 10:22:46 --> Model Class Initialized
INFO - 2017-07-28 10:22:46 --> Model Class Initialized
INFO - 2017-07-28 10:22:46 --> Model Class Initialized
INFO - 2017-07-28 10:22:46 --> Model Class Initialized
INFO - 2017-07-28 10:22:46 --> Controller Class Initialized
DEBUG - 2017-07-28 10:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:22:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:22:46 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:22:46 --> Final output sent to browser
DEBUG - 2017-07-28 10:22:46 --> Total execution time: 0.0297
DEBUG - 2017-07-28 10:22:46 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:22:46 --> Database Forge Class Initialized
INFO - 2017-07-28 10:22:46 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:22:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:27:24 --> Config Class Initialized
INFO - 2017-07-28 10:27:24 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:27:24 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:27:24 --> Utf8 Class Initialized
INFO - 2017-07-28 10:27:24 --> URI Class Initialized
DEBUG - 2017-07-28 10:27:24 --> No URI present. Default controller set.
INFO - 2017-07-28 10:27:24 --> Router Class Initialized
INFO - 2017-07-28 10:27:24 --> Output Class Initialized
INFO - 2017-07-28 10:27:24 --> Security Class Initialized
DEBUG - 2017-07-28 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:27:24 --> Input Class Initialized
INFO - 2017-07-28 10:27:24 --> Language Class Initialized
INFO - 2017-07-28 10:27:24 --> Loader Class Initialized
INFO - 2017-07-28 10:27:24 --> Helper loaded: url_helper
INFO - 2017-07-28 10:27:24 --> Helper loaded: form_helper
INFO - 2017-07-28 10:27:24 --> Helper loaded: security_helper
INFO - 2017-07-28 10:27:24 --> Helper loaded: path_helper
INFO - 2017-07-28 10:27:24 --> Helper loaded: common_helper
INFO - 2017-07-28 10:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:27:24 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:27:24 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:27:24 --> Email Class Initialized
INFO - 2017-07-28 10:27:24 --> Form Validation Class Initialized
INFO - 2017-07-28 10:27:24 --> Model Class Initialized
INFO - 2017-07-28 10:27:24 --> Model Class Initialized
INFO - 2017-07-28 10:27:24 --> Model Class Initialized
INFO - 2017-07-28 10:27:24 --> Model Class Initialized
INFO - 2017-07-28 10:27:24 --> Controller Class Initialized
DEBUG - 2017-07-28 10:27:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:27:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:27:24 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:27:24 --> Final output sent to browser
DEBUG - 2017-07-28 10:27:24 --> Total execution time: 0.0335
DEBUG - 2017-07-28 10:27:24 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:27:24 --> Database Forge Class Initialized
INFO - 2017-07-28 10:27:24 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:10 --> Config Class Initialized
INFO - 2017-07-28 10:29:10 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:29:10 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:29:10 --> Utf8 Class Initialized
INFO - 2017-07-28 10:29:10 --> URI Class Initialized
DEBUG - 2017-07-28 10:29:10 --> No URI present. Default controller set.
INFO - 2017-07-28 10:29:10 --> Router Class Initialized
INFO - 2017-07-28 10:29:10 --> Output Class Initialized
INFO - 2017-07-28 10:29:10 --> Security Class Initialized
DEBUG - 2017-07-28 10:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:29:10 --> Input Class Initialized
INFO - 2017-07-28 10:29:10 --> Language Class Initialized
INFO - 2017-07-28 10:29:10 --> Loader Class Initialized
INFO - 2017-07-28 10:29:10 --> Helper loaded: url_helper
INFO - 2017-07-28 10:29:10 --> Helper loaded: form_helper
INFO - 2017-07-28 10:29:10 --> Helper loaded: security_helper
INFO - 2017-07-28 10:29:10 --> Helper loaded: path_helper
INFO - 2017-07-28 10:29:10 --> Helper loaded: common_helper
INFO - 2017-07-28 10:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:29:10 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:29:10 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:10 --> Email Class Initialized
INFO - 2017-07-28 10:29:10 --> Form Validation Class Initialized
INFO - 2017-07-28 10:29:10 --> Model Class Initialized
INFO - 2017-07-28 10:29:10 --> Model Class Initialized
INFO - 2017-07-28 10:29:10 --> Model Class Initialized
INFO - 2017-07-28 10:29:10 --> Model Class Initialized
INFO - 2017-07-28 10:29:10 --> Controller Class Initialized
DEBUG - 2017-07-28 10:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:29:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:29:10 --> Final output sent to browser
DEBUG - 2017-07-28 10:29:10 --> Total execution time: 0.0330
DEBUG - 2017-07-28 10:29:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:29:10 --> Database Forge Class Initialized
INFO - 2017-07-28 10:29:10 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:29:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:18 --> Config Class Initialized
INFO - 2017-07-28 10:29:18 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:29:18 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:29:18 --> Utf8 Class Initialized
INFO - 2017-07-28 10:29:18 --> URI Class Initialized
INFO - 2017-07-28 10:29:18 --> Router Class Initialized
INFO - 2017-07-28 10:29:18 --> Output Class Initialized
INFO - 2017-07-28 10:29:18 --> Security Class Initialized
DEBUG - 2017-07-28 10:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:29:18 --> Input Class Initialized
INFO - 2017-07-28 10:29:18 --> Language Class Initialized
INFO - 2017-07-28 10:29:18 --> Loader Class Initialized
INFO - 2017-07-28 10:29:18 --> Helper loaded: url_helper
INFO - 2017-07-28 10:29:18 --> Helper loaded: form_helper
INFO - 2017-07-28 10:29:18 --> Helper loaded: security_helper
INFO - 2017-07-28 10:29:18 --> Helper loaded: path_helper
INFO - 2017-07-28 10:29:18 --> Helper loaded: common_helper
INFO - 2017-07-28 10:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:29:18 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:29:18 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:29:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:18 --> Email Class Initialized
INFO - 2017-07-28 10:29:18 --> Form Validation Class Initialized
INFO - 2017-07-28 10:29:18 --> Model Class Initialized
INFO - 2017-07-28 10:29:18 --> Model Class Initialized
INFO - 2017-07-28 10:29:18 --> Model Class Initialized
INFO - 2017-07-28 10:29:18 --> Model Class Initialized
INFO - 2017-07-28 10:29:18 --> Controller Class Initialized
INFO - 2017-07-28 10:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2017-07-28 10:29:18 --> Pagination Class Initialized
INFO - 2017-07-28 10:29:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 10:29:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/managehospitals.php
INFO - 2017-07-28 10:29:18 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 10:29:18 --> Final output sent to browser
DEBUG - 2017-07-28 10:29:18 --> Total execution time: 0.0325
DEBUG - 2017-07-28 10:29:18 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:29:18 --> Database Forge Class Initialized
INFO - 2017-07-28 10:29:18 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:29:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:29:24 --> Config Class Initialized
INFO - 2017-07-28 10:29:24 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:29:24 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:29:24 --> Utf8 Class Initialized
INFO - 2017-07-28 10:29:24 --> URI Class Initialized
INFO - 2017-07-28 10:29:24 --> Router Class Initialized
INFO - 2017-07-28 10:29:24 --> Output Class Initialized
INFO - 2017-07-28 10:29:24 --> Security Class Initialized
DEBUG - 2017-07-28 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:29:24 --> Input Class Initialized
INFO - 2017-07-28 10:29:24 --> Language Class Initialized
ERROR - 2017-07-28 10:29:24 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 10:35:21 --> Config Class Initialized
INFO - 2017-07-28 10:35:21 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:35:21 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:35:21 --> Utf8 Class Initialized
INFO - 2017-07-28 10:35:21 --> URI Class Initialized
INFO - 2017-07-28 10:35:21 --> Router Class Initialized
INFO - 2017-07-28 10:35:21 --> Output Class Initialized
INFO - 2017-07-28 10:35:21 --> Security Class Initialized
DEBUG - 2017-07-28 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:35:21 --> Input Class Initialized
INFO - 2017-07-28 10:35:21 --> Language Class Initialized
INFO - 2017-07-28 10:35:21 --> Loader Class Initialized
INFO - 2017-07-28 10:35:21 --> Helper loaded: url_helper
INFO - 2017-07-28 10:35:21 --> Helper loaded: form_helper
INFO - 2017-07-28 10:35:21 --> Helper loaded: security_helper
INFO - 2017-07-28 10:35:21 --> Helper loaded: path_helper
INFO - 2017-07-28 10:35:21 --> Helper loaded: common_helper
INFO - 2017-07-28 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:35:21 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:35:21 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:35:21 --> Email Class Initialized
INFO - 2017-07-28 10:35:21 --> Form Validation Class Initialized
INFO - 2017-07-28 10:35:21 --> Model Class Initialized
INFO - 2017-07-28 10:35:21 --> Model Class Initialized
INFO - 2017-07-28 10:35:21 --> Model Class Initialized
INFO - 2017-07-28 10:35:21 --> Model Class Initialized
INFO - 2017-07-28 10:35:21 --> Controller Class Initialized
INFO - 2017-07-28 10:35:21 --> Model Class Initialized
INFO - 2017-07-28 10:35:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:35:21 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:35:21 --> Final output sent to browser
DEBUG - 2017-07-28 10:35:21 --> Total execution time: 0.0309
DEBUG - 2017-07-28 10:35:21 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:35:21 --> Database Forge Class Initialized
INFO - 2017-07-28 10:35:21 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:37:29 --> Config Class Initialized
INFO - 2017-07-28 10:37:29 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:37:29 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:37:29 --> Utf8 Class Initialized
INFO - 2017-07-28 10:37:29 --> URI Class Initialized
INFO - 2017-07-28 10:37:29 --> Router Class Initialized
INFO - 2017-07-28 10:37:29 --> Output Class Initialized
INFO - 2017-07-28 10:37:29 --> Security Class Initialized
DEBUG - 2017-07-28 10:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:37:29 --> Input Class Initialized
INFO - 2017-07-28 10:37:29 --> Language Class Initialized
INFO - 2017-07-28 10:37:29 --> Loader Class Initialized
INFO - 2017-07-28 10:37:29 --> Helper loaded: url_helper
INFO - 2017-07-28 10:37:29 --> Helper loaded: form_helper
INFO - 2017-07-28 10:37:29 --> Helper loaded: security_helper
INFO - 2017-07-28 10:37:29 --> Helper loaded: path_helper
INFO - 2017-07-28 10:37:29 --> Helper loaded: common_helper
INFO - 2017-07-28 10:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:37:30 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:37:30 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:37:30 --> Email Class Initialized
INFO - 2017-07-28 10:37:30 --> Form Validation Class Initialized
INFO - 2017-07-28 10:37:30 --> Model Class Initialized
INFO - 2017-07-28 10:37:30 --> Model Class Initialized
INFO - 2017-07-28 10:37:30 --> Model Class Initialized
INFO - 2017-07-28 10:37:30 --> Model Class Initialized
INFO - 2017-07-28 10:37:30 --> Controller Class Initialized
INFO - 2017-07-28 10:37:30 --> Model Class Initialized
INFO - 2017-07-28 10:37:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:37:30 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:37:30 --> Final output sent to browser
DEBUG - 2017-07-28 10:37:30 --> Total execution time: 0.0318
DEBUG - 2017-07-28 10:37:30 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:37:30 --> Database Forge Class Initialized
INFO - 2017-07-28 10:37:30 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:37:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:37:33 --> Config Class Initialized
INFO - 2017-07-28 10:37:33 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:37:33 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:37:33 --> Utf8 Class Initialized
INFO - 2017-07-28 10:37:33 --> URI Class Initialized
INFO - 2017-07-28 10:37:33 --> Router Class Initialized
INFO - 2017-07-28 10:37:33 --> Output Class Initialized
INFO - 2017-07-28 10:37:33 --> Security Class Initialized
DEBUG - 2017-07-28 10:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:37:33 --> Input Class Initialized
INFO - 2017-07-28 10:37:33 --> Language Class Initialized
INFO - 2017-07-28 10:37:33 --> Loader Class Initialized
INFO - 2017-07-28 10:37:33 --> Helper loaded: url_helper
INFO - 2017-07-28 10:37:33 --> Helper loaded: form_helper
INFO - 2017-07-28 10:37:33 --> Helper loaded: security_helper
INFO - 2017-07-28 10:37:33 --> Helper loaded: path_helper
INFO - 2017-07-28 10:37:33 --> Helper loaded: common_helper
INFO - 2017-07-28 10:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:37:33 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:37:33 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:37:33 --> Email Class Initialized
INFO - 2017-07-28 10:37:33 --> Form Validation Class Initialized
INFO - 2017-07-28 10:37:33 --> Model Class Initialized
INFO - 2017-07-28 10:37:33 --> Model Class Initialized
INFO - 2017-07-28 10:37:33 --> Model Class Initialized
INFO - 2017-07-28 10:37:33 --> Model Class Initialized
INFO - 2017-07-28 10:37:33 --> Controller Class Initialized
INFO - 2017-07-28 10:37:33 --> Model Class Initialized
INFO - 2017-07-28 10:37:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:37:33 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:37:33 --> Final output sent to browser
DEBUG - 2017-07-28 10:37:33 --> Total execution time: 0.0295
DEBUG - 2017-07-28 10:37:33 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:37:33 --> Database Forge Class Initialized
INFO - 2017-07-28 10:37:33 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:37:42 --> Config Class Initialized
INFO - 2017-07-28 10:37:42 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:37:42 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:37:42 --> Utf8 Class Initialized
INFO - 2017-07-28 10:37:42 --> URI Class Initialized
INFO - 2017-07-28 10:37:42 --> Router Class Initialized
INFO - 2017-07-28 10:37:42 --> Output Class Initialized
INFO - 2017-07-28 10:37:42 --> Security Class Initialized
DEBUG - 2017-07-28 10:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:37:42 --> Input Class Initialized
INFO - 2017-07-28 10:37:42 --> Language Class Initialized
ERROR - 2017-07-28 10:37:42 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:41:37 --> Config Class Initialized
INFO - 2017-07-28 10:41:37 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:41:37 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:41:37 --> Utf8 Class Initialized
INFO - 2017-07-28 10:41:37 --> URI Class Initialized
INFO - 2017-07-28 10:41:37 --> Router Class Initialized
INFO - 2017-07-28 10:41:37 --> Output Class Initialized
INFO - 2017-07-28 10:41:37 --> Security Class Initialized
DEBUG - 2017-07-28 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:41:37 --> Input Class Initialized
INFO - 2017-07-28 10:41:37 --> Language Class Initialized
INFO - 2017-07-28 10:41:37 --> Loader Class Initialized
INFO - 2017-07-28 10:41:37 --> Helper loaded: url_helper
INFO - 2017-07-28 10:41:37 --> Helper loaded: form_helper
INFO - 2017-07-28 10:41:37 --> Helper loaded: security_helper
INFO - 2017-07-28 10:41:37 --> Helper loaded: path_helper
INFO - 2017-07-28 10:41:37 --> Helper loaded: common_helper
INFO - 2017-07-28 10:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:41:37 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:41:37 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:41:37 --> Email Class Initialized
INFO - 2017-07-28 10:41:37 --> Form Validation Class Initialized
INFO - 2017-07-28 10:41:37 --> Model Class Initialized
INFO - 2017-07-28 10:41:37 --> Model Class Initialized
INFO - 2017-07-28 10:41:37 --> Model Class Initialized
INFO - 2017-07-28 10:41:37 --> Model Class Initialized
INFO - 2017-07-28 10:41:37 --> Controller Class Initialized
INFO - 2017-07-28 10:41:37 --> Model Class Initialized
INFO - 2017-07-28 10:41:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:41:37 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:41:37 --> Final output sent to browser
DEBUG - 2017-07-28 10:41:37 --> Total execution time: 0.0306
DEBUG - 2017-07-28 10:41:37 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:41:37 --> Database Forge Class Initialized
INFO - 2017-07-28 10:41:37 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:42:32 --> Config Class Initialized
INFO - 2017-07-28 10:42:32 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:42:32 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:42:32 --> Utf8 Class Initialized
INFO - 2017-07-28 10:42:32 --> URI Class Initialized
INFO - 2017-07-28 10:42:32 --> Router Class Initialized
INFO - 2017-07-28 10:42:32 --> Output Class Initialized
INFO - 2017-07-28 10:42:32 --> Security Class Initialized
DEBUG - 2017-07-28 10:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:42:32 --> Input Class Initialized
INFO - 2017-07-28 10:42:32 --> Language Class Initialized
INFO - 2017-07-28 10:42:32 --> Loader Class Initialized
INFO - 2017-07-28 10:42:32 --> Helper loaded: url_helper
INFO - 2017-07-28 10:42:32 --> Helper loaded: form_helper
INFO - 2017-07-28 10:42:32 --> Helper loaded: security_helper
INFO - 2017-07-28 10:42:32 --> Helper loaded: path_helper
INFO - 2017-07-28 10:42:32 --> Helper loaded: common_helper
INFO - 2017-07-28 10:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:42:32 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:42:32 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:42:32 --> Email Class Initialized
INFO - 2017-07-28 10:42:32 --> Form Validation Class Initialized
INFO - 2017-07-28 10:42:32 --> Model Class Initialized
INFO - 2017-07-28 10:42:32 --> Model Class Initialized
INFO - 2017-07-28 10:42:32 --> Model Class Initialized
INFO - 2017-07-28 10:42:32 --> Model Class Initialized
INFO - 2017-07-28 10:42:32 --> Controller Class Initialized
INFO - 2017-07-28 10:42:32 --> Model Class Initialized
INFO - 2017-07-28 10:42:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:42:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:42:32 --> Final output sent to browser
DEBUG - 2017-07-28 10:42:32 --> Total execution time: 0.0282
DEBUG - 2017-07-28 10:42:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:42:32 --> Database Forge Class Initialized
INFO - 2017-07-28 10:42:32 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:42:40 --> Config Class Initialized
INFO - 2017-07-28 10:42:40 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:42:40 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:42:40 --> Utf8 Class Initialized
INFO - 2017-07-28 10:42:40 --> URI Class Initialized
INFO - 2017-07-28 10:42:40 --> Router Class Initialized
INFO - 2017-07-28 10:42:40 --> Output Class Initialized
INFO - 2017-07-28 10:42:40 --> Security Class Initialized
DEBUG - 2017-07-28 10:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:42:40 --> Input Class Initialized
INFO - 2017-07-28 10:42:40 --> Language Class Initialized
ERROR - 2017-07-28 10:42:40 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:44:06 --> Config Class Initialized
INFO - 2017-07-28 10:44:06 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:44:06 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:44:06 --> Utf8 Class Initialized
INFO - 2017-07-28 10:44:06 --> URI Class Initialized
INFO - 2017-07-28 10:44:06 --> Router Class Initialized
INFO - 2017-07-28 10:44:06 --> Output Class Initialized
INFO - 2017-07-28 10:44:06 --> Security Class Initialized
DEBUG - 2017-07-28 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:44:06 --> Input Class Initialized
INFO - 2017-07-28 10:44:06 --> Language Class Initialized
INFO - 2017-07-28 10:44:06 --> Loader Class Initialized
INFO - 2017-07-28 10:44:06 --> Helper loaded: url_helper
INFO - 2017-07-28 10:44:06 --> Helper loaded: form_helper
INFO - 2017-07-28 10:44:06 --> Helper loaded: security_helper
INFO - 2017-07-28 10:44:06 --> Helper loaded: path_helper
INFO - 2017-07-28 10:44:06 --> Helper loaded: common_helper
INFO - 2017-07-28 10:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:44:06 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:44:06 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:06 --> Email Class Initialized
INFO - 2017-07-28 10:44:06 --> Form Validation Class Initialized
INFO - 2017-07-28 10:44:06 --> Model Class Initialized
INFO - 2017-07-28 10:44:06 --> Model Class Initialized
INFO - 2017-07-28 10:44:06 --> Model Class Initialized
INFO - 2017-07-28 10:44:06 --> Model Class Initialized
INFO - 2017-07-28 10:44:06 --> Controller Class Initialized
INFO - 2017-07-28 10:44:06 --> Model Class Initialized
INFO - 2017-07-28 10:44:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:44:06 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:44:06 --> Final output sent to browser
DEBUG - 2017-07-28 10:44:06 --> Total execution time: 0.0306
DEBUG - 2017-07-28 10:44:06 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:44:06 --> Database Forge Class Initialized
INFO - 2017-07-28 10:44:06 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:44:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:08 --> Config Class Initialized
INFO - 2017-07-28 10:44:08 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:44:08 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:44:08 --> Utf8 Class Initialized
INFO - 2017-07-28 10:44:08 --> URI Class Initialized
INFO - 2017-07-28 10:44:08 --> Router Class Initialized
INFO - 2017-07-28 10:44:08 --> Output Class Initialized
INFO - 2017-07-28 10:44:08 --> Security Class Initialized
DEBUG - 2017-07-28 10:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:44:08 --> Input Class Initialized
INFO - 2017-07-28 10:44:08 --> Language Class Initialized
INFO - 2017-07-28 10:44:08 --> Loader Class Initialized
INFO - 2017-07-28 10:44:08 --> Helper loaded: url_helper
INFO - 2017-07-28 10:44:08 --> Helper loaded: form_helper
INFO - 2017-07-28 10:44:08 --> Helper loaded: security_helper
INFO - 2017-07-28 10:44:08 --> Helper loaded: path_helper
INFO - 2017-07-28 10:44:08 --> Helper loaded: common_helper
INFO - 2017-07-28 10:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:44:08 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:44:08 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:08 --> Email Class Initialized
INFO - 2017-07-28 10:44:08 --> Form Validation Class Initialized
INFO - 2017-07-28 10:44:08 --> Model Class Initialized
INFO - 2017-07-28 10:44:08 --> Model Class Initialized
INFO - 2017-07-28 10:44:08 --> Model Class Initialized
INFO - 2017-07-28 10:44:08 --> Model Class Initialized
INFO - 2017-07-28 10:44:08 --> Controller Class Initialized
INFO - 2017-07-28 10:44:08 --> Model Class Initialized
INFO - 2017-07-28 10:44:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:44:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:44:08 --> Final output sent to browser
DEBUG - 2017-07-28 10:44:08 --> Total execution time: 0.0282
DEBUG - 2017-07-28 10:44:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:44:08 --> Database Forge Class Initialized
INFO - 2017-07-28 10:44:08 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:44:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:15 --> Config Class Initialized
INFO - 2017-07-28 10:44:15 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:44:15 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:44:15 --> Utf8 Class Initialized
INFO - 2017-07-28 10:44:15 --> URI Class Initialized
INFO - 2017-07-28 10:44:15 --> Router Class Initialized
INFO - 2017-07-28 10:44:15 --> Output Class Initialized
INFO - 2017-07-28 10:44:15 --> Security Class Initialized
DEBUG - 2017-07-28 10:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:44:15 --> Input Class Initialized
INFO - 2017-07-28 10:44:15 --> Language Class Initialized
ERROR - 2017-07-28 10:44:15 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:44:27 --> Config Class Initialized
INFO - 2017-07-28 10:44:27 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:44:27 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:44:27 --> Utf8 Class Initialized
INFO - 2017-07-28 10:44:27 --> URI Class Initialized
INFO - 2017-07-28 10:44:27 --> Router Class Initialized
INFO - 2017-07-28 10:44:27 --> Output Class Initialized
INFO - 2017-07-28 10:44:27 --> Security Class Initialized
DEBUG - 2017-07-28 10:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:44:27 --> Input Class Initialized
INFO - 2017-07-28 10:44:27 --> Language Class Initialized
INFO - 2017-07-28 10:44:27 --> Loader Class Initialized
INFO - 2017-07-28 10:44:27 --> Helper loaded: url_helper
INFO - 2017-07-28 10:44:27 --> Helper loaded: form_helper
INFO - 2017-07-28 10:44:27 --> Helper loaded: security_helper
INFO - 2017-07-28 10:44:27 --> Helper loaded: path_helper
INFO - 2017-07-28 10:44:27 --> Helper loaded: common_helper
INFO - 2017-07-28 10:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:44:27 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:44:27 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:27 --> Email Class Initialized
INFO - 2017-07-28 10:44:27 --> Form Validation Class Initialized
INFO - 2017-07-28 10:44:27 --> Model Class Initialized
INFO - 2017-07-28 10:44:27 --> Model Class Initialized
INFO - 2017-07-28 10:44:27 --> Model Class Initialized
INFO - 2017-07-28 10:44:27 --> Model Class Initialized
INFO - 2017-07-28 10:44:27 --> Controller Class Initialized
INFO - 2017-07-28 10:44:27 --> Model Class Initialized
INFO - 2017-07-28 10:44:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:44:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:44:27 --> Final output sent to browser
DEBUG - 2017-07-28 10:44:27 --> Total execution time: 0.0298
DEBUG - 2017-07-28 10:44:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:44:27 --> Database Forge Class Initialized
INFO - 2017-07-28 10:44:27 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:44:38 --> Config Class Initialized
INFO - 2017-07-28 10:44:38 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:44:38 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:44:38 --> Utf8 Class Initialized
INFO - 2017-07-28 10:44:38 --> URI Class Initialized
INFO - 2017-07-28 10:44:38 --> Router Class Initialized
INFO - 2017-07-28 10:44:38 --> Output Class Initialized
INFO - 2017-07-28 10:44:38 --> Security Class Initialized
DEBUG - 2017-07-28 10:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:44:38 --> Input Class Initialized
INFO - 2017-07-28 10:44:38 --> Language Class Initialized
ERROR - 2017-07-28 10:44:38 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:49:32 --> Config Class Initialized
INFO - 2017-07-28 10:49:32 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:49:32 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:49:32 --> Utf8 Class Initialized
INFO - 2017-07-28 10:49:32 --> URI Class Initialized
DEBUG - 2017-07-28 10:49:32 --> No URI present. Default controller set.
INFO - 2017-07-28 10:49:32 --> Router Class Initialized
INFO - 2017-07-28 10:49:32 --> Output Class Initialized
INFO - 2017-07-28 10:49:32 --> Security Class Initialized
DEBUG - 2017-07-28 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:49:32 --> Input Class Initialized
INFO - 2017-07-28 10:49:32 --> Language Class Initialized
INFO - 2017-07-28 10:49:32 --> Loader Class Initialized
INFO - 2017-07-28 10:49:32 --> Helper loaded: url_helper
INFO - 2017-07-28 10:49:32 --> Helper loaded: form_helper
INFO - 2017-07-28 10:49:32 --> Helper loaded: security_helper
INFO - 2017-07-28 10:49:32 --> Helper loaded: path_helper
INFO - 2017-07-28 10:49:32 --> Helper loaded: common_helper
INFO - 2017-07-28 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:49:32 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:49:32 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:49:32 --> Email Class Initialized
INFO - 2017-07-28 10:49:32 --> Form Validation Class Initialized
INFO - 2017-07-28 10:49:32 --> Model Class Initialized
INFO - 2017-07-28 10:49:32 --> Model Class Initialized
INFO - 2017-07-28 10:49:32 --> Model Class Initialized
INFO - 2017-07-28 10:49:32 --> Model Class Initialized
INFO - 2017-07-28 10:49:32 --> Controller Class Initialized
DEBUG - 2017-07-28 10:49:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:49:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 10:49:32 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 10:49:32 --> Final output sent to browser
DEBUG - 2017-07-28 10:49:32 --> Total execution time: 0.0300
DEBUG - 2017-07-28 10:49:32 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:49:32 --> Database Forge Class Initialized
INFO - 2017-07-28 10:49:32 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:49:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:49:44 --> Config Class Initialized
INFO - 2017-07-28 10:49:44 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:49:44 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:49:44 --> Utf8 Class Initialized
INFO - 2017-07-28 10:49:44 --> URI Class Initialized
INFO - 2017-07-28 10:49:44 --> Router Class Initialized
INFO - 2017-07-28 10:49:44 --> Output Class Initialized
INFO - 2017-07-28 10:49:44 --> Security Class Initialized
DEBUG - 2017-07-28 10:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:49:44 --> Input Class Initialized
INFO - 2017-07-28 10:49:44 --> Language Class Initialized
INFO - 2017-07-28 10:49:44 --> Loader Class Initialized
INFO - 2017-07-28 10:49:44 --> Helper loaded: url_helper
INFO - 2017-07-28 10:49:44 --> Helper loaded: form_helper
INFO - 2017-07-28 10:49:44 --> Helper loaded: security_helper
INFO - 2017-07-28 10:49:44 --> Helper loaded: path_helper
INFO - 2017-07-28 10:49:44 --> Helper loaded: common_helper
INFO - 2017-07-28 10:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:49:44 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:49:44 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:49:44 --> Email Class Initialized
INFO - 2017-07-28 10:49:44 --> Form Validation Class Initialized
INFO - 2017-07-28 10:49:44 --> Model Class Initialized
INFO - 2017-07-28 10:49:44 --> Model Class Initialized
INFO - 2017-07-28 10:49:44 --> Model Class Initialized
INFO - 2017-07-28 10:49:44 --> Model Class Initialized
INFO - 2017-07-28 10:49:44 --> Controller Class Initialized
INFO - 2017-07-28 10:49:44 --> Model Class Initialized
INFO - 2017-07-28 10:49:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:49:44 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:49:44 --> Final output sent to browser
DEBUG - 2017-07-28 10:49:44 --> Total execution time: 0.0283
DEBUG - 2017-07-28 10:49:44 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:49:44 --> Database Forge Class Initialized
INFO - 2017-07-28 10:49:44 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:49:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:49:59 --> Config Class Initialized
INFO - 2017-07-28 10:49:59 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:49:59 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:49:59 --> Utf8 Class Initialized
INFO - 2017-07-28 10:49:59 --> URI Class Initialized
INFO - 2017-07-28 10:49:59 --> Router Class Initialized
INFO - 2017-07-28 10:49:59 --> Output Class Initialized
INFO - 2017-07-28 10:49:59 --> Security Class Initialized
DEBUG - 2017-07-28 10:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:49:59 --> Input Class Initialized
INFO - 2017-07-28 10:49:59 --> Language Class Initialized
ERROR - 2017-07-28 10:49:59 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:51:22 --> Config Class Initialized
INFO - 2017-07-28 10:51:22 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:51:22 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:51:22 --> Utf8 Class Initialized
INFO - 2017-07-28 10:51:22 --> URI Class Initialized
INFO - 2017-07-28 10:51:22 --> Router Class Initialized
INFO - 2017-07-28 10:51:22 --> Output Class Initialized
INFO - 2017-07-28 10:51:22 --> Security Class Initialized
DEBUG - 2017-07-28 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:51:22 --> Input Class Initialized
INFO - 2017-07-28 10:51:22 --> Language Class Initialized
INFO - 2017-07-28 10:51:22 --> Loader Class Initialized
INFO - 2017-07-28 10:51:22 --> Helper loaded: url_helper
INFO - 2017-07-28 10:51:22 --> Helper loaded: form_helper
INFO - 2017-07-28 10:51:22 --> Helper loaded: security_helper
INFO - 2017-07-28 10:51:22 --> Helper loaded: path_helper
INFO - 2017-07-28 10:51:22 --> Helper loaded: common_helper
INFO - 2017-07-28 10:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:51:22 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:51:22 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:51:22 --> Email Class Initialized
INFO - 2017-07-28 10:51:22 --> Form Validation Class Initialized
INFO - 2017-07-28 10:51:22 --> Model Class Initialized
INFO - 2017-07-28 10:51:22 --> Model Class Initialized
INFO - 2017-07-28 10:51:22 --> Model Class Initialized
INFO - 2017-07-28 10:51:22 --> Model Class Initialized
INFO - 2017-07-28 10:51:22 --> Controller Class Initialized
INFO - 2017-07-28 10:51:22 --> Model Class Initialized
INFO - 2017-07-28 10:51:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:51:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:51:22 --> Final output sent to browser
DEBUG - 2017-07-28 10:51:22 --> Total execution time: 0.0281
DEBUG - 2017-07-28 10:51:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:51:22 --> Database Forge Class Initialized
INFO - 2017-07-28 10:51:22 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:51:42 --> Config Class Initialized
INFO - 2017-07-28 10:51:42 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:51:42 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:51:42 --> Utf8 Class Initialized
INFO - 2017-07-28 10:51:42 --> URI Class Initialized
INFO - 2017-07-28 10:51:42 --> Router Class Initialized
INFO - 2017-07-28 10:51:42 --> Output Class Initialized
INFO - 2017-07-28 10:51:42 --> Security Class Initialized
DEBUG - 2017-07-28 10:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:51:42 --> Input Class Initialized
INFO - 2017-07-28 10:51:42 --> Language Class Initialized
INFO - 2017-07-28 10:51:42 --> Loader Class Initialized
INFO - 2017-07-28 10:51:42 --> Helper loaded: url_helper
INFO - 2017-07-28 10:51:42 --> Helper loaded: form_helper
INFO - 2017-07-28 10:51:42 --> Helper loaded: security_helper
INFO - 2017-07-28 10:51:42 --> Helper loaded: path_helper
INFO - 2017-07-28 10:51:42 --> Helper loaded: common_helper
INFO - 2017-07-28 10:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:51:42 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:51:42 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:51:42 --> Email Class Initialized
INFO - 2017-07-28 10:51:42 --> Form Validation Class Initialized
INFO - 2017-07-28 10:51:42 --> Model Class Initialized
INFO - 2017-07-28 10:51:42 --> Model Class Initialized
INFO - 2017-07-28 10:51:42 --> Model Class Initialized
INFO - 2017-07-28 10:51:42 --> Model Class Initialized
INFO - 2017-07-28 10:51:42 --> Controller Class Initialized
INFO - 2017-07-28 10:51:42 --> Model Class Initialized
INFO - 2017-07-28 10:51:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:51:42 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:51:42 --> Final output sent to browser
DEBUG - 2017-07-28 10:51:42 --> Total execution time: 0.0262
DEBUG - 2017-07-28 10:51:42 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:51:42 --> Database Forge Class Initialized
INFO - 2017-07-28 10:51:42 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:51:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:51:51 --> Config Class Initialized
INFO - 2017-07-28 10:51:51 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:51:51 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:51:51 --> Utf8 Class Initialized
INFO - 2017-07-28 10:51:51 --> URI Class Initialized
INFO - 2017-07-28 10:51:51 --> Router Class Initialized
INFO - 2017-07-28 10:51:51 --> Output Class Initialized
INFO - 2017-07-28 10:51:51 --> Security Class Initialized
DEBUG - 2017-07-28 10:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:51:51 --> Input Class Initialized
INFO - 2017-07-28 10:51:51 --> Language Class Initialized
ERROR - 2017-07-28 10:51:51 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:56:15 --> Config Class Initialized
INFO - 2017-07-28 10:56:15 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:56:15 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:56:15 --> Utf8 Class Initialized
INFO - 2017-07-28 10:56:15 --> URI Class Initialized
INFO - 2017-07-28 10:56:15 --> Router Class Initialized
INFO - 2017-07-28 10:56:15 --> Output Class Initialized
INFO - 2017-07-28 10:56:15 --> Security Class Initialized
DEBUG - 2017-07-28 10:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:56:15 --> Input Class Initialized
INFO - 2017-07-28 10:56:15 --> Language Class Initialized
INFO - 2017-07-28 10:56:15 --> Loader Class Initialized
INFO - 2017-07-28 10:56:15 --> Helper loaded: url_helper
INFO - 2017-07-28 10:56:15 --> Helper loaded: form_helper
INFO - 2017-07-28 10:56:15 --> Helper loaded: security_helper
INFO - 2017-07-28 10:56:15 --> Helper loaded: path_helper
INFO - 2017-07-28 10:56:15 --> Helper loaded: common_helper
INFO - 2017-07-28 10:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:56:15 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:56:15 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:56:15 --> Email Class Initialized
INFO - 2017-07-28 10:56:15 --> Form Validation Class Initialized
INFO - 2017-07-28 10:56:15 --> Model Class Initialized
INFO - 2017-07-28 10:56:15 --> Model Class Initialized
INFO - 2017-07-28 10:56:15 --> Model Class Initialized
INFO - 2017-07-28 10:56:15 --> Model Class Initialized
INFO - 2017-07-28 10:56:15 --> Controller Class Initialized
INFO - 2017-07-28 10:56:15 --> Model Class Initialized
INFO - 2017-07-28 10:56:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:56:15 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:56:15 --> Final output sent to browser
DEBUG - 2017-07-28 10:56:15 --> Total execution time: 0.0296
DEBUG - 2017-07-28 10:56:15 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:56:15 --> Database Forge Class Initialized
INFO - 2017-07-28 10:56:15 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:56:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:56:24 --> Config Class Initialized
INFO - 2017-07-28 10:56:24 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:56:24 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:56:24 --> Utf8 Class Initialized
INFO - 2017-07-28 10:56:24 --> URI Class Initialized
INFO - 2017-07-28 10:56:24 --> Router Class Initialized
INFO - 2017-07-28 10:56:24 --> Output Class Initialized
INFO - 2017-07-28 10:56:24 --> Security Class Initialized
DEBUG - 2017-07-28 10:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:56:24 --> Input Class Initialized
INFO - 2017-07-28 10:56:24 --> Language Class Initialized
ERROR - 2017-07-28 10:56:24 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:57:10 --> Config Class Initialized
INFO - 2017-07-28 10:57:10 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:57:10 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:57:10 --> Utf8 Class Initialized
INFO - 2017-07-28 10:57:10 --> URI Class Initialized
INFO - 2017-07-28 10:57:10 --> Router Class Initialized
INFO - 2017-07-28 10:57:10 --> Output Class Initialized
INFO - 2017-07-28 10:57:10 --> Security Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:57:10 --> Input Class Initialized
INFO - 2017-07-28 10:57:10 --> Language Class Initialized
INFO - 2017-07-28 10:57:10 --> Loader Class Initialized
INFO - 2017-07-28 10:57:10 --> Helper loaded: url_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: form_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: security_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: path_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: common_helper
INFO - 2017-07-28 10:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:57:10 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:57:10 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:57:10 --> Email Class Initialized
INFO - 2017-07-28 10:57:10 --> Form Validation Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Controller Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:57:10 --> Final output sent to browser
DEBUG - 2017-07-28 10:57:10 --> Total execution time: 0.0292
DEBUG - 2017-07-28 10:57:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:57:10 --> Database Forge Class Initialized
INFO - 2017-07-28 10:57:10 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:57:10 --> Config Class Initialized
INFO - 2017-07-28 10:57:10 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:57:10 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:57:10 --> Utf8 Class Initialized
INFO - 2017-07-28 10:57:10 --> URI Class Initialized
INFO - 2017-07-28 10:57:10 --> Router Class Initialized
INFO - 2017-07-28 10:57:10 --> Output Class Initialized
INFO - 2017-07-28 10:57:10 --> Security Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:57:10 --> Input Class Initialized
INFO - 2017-07-28 10:57:10 --> Language Class Initialized
INFO - 2017-07-28 10:57:10 --> Loader Class Initialized
INFO - 2017-07-28 10:57:10 --> Helper loaded: url_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: form_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: security_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: path_helper
INFO - 2017-07-28 10:57:10 --> Helper loaded: common_helper
INFO - 2017-07-28 10:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:57:10 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:57:10 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:57:10 --> Email Class Initialized
INFO - 2017-07-28 10:57:10 --> Form Validation Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> Controller Class Initialized
INFO - 2017-07-28 10:57:10 --> Model Class Initialized
INFO - 2017-07-28 10:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:57:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:57:10 --> Final output sent to browser
DEBUG - 2017-07-28 10:57:10 --> Total execution time: 0.0330
DEBUG - 2017-07-28 10:57:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:57:10 --> Database Forge Class Initialized
INFO - 2017-07-28 10:57:10 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:57:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:57:11 --> Config Class Initialized
INFO - 2017-07-28 10:57:11 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:57:11 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:57:11 --> Utf8 Class Initialized
INFO - 2017-07-28 10:57:11 --> URI Class Initialized
INFO - 2017-07-28 10:57:11 --> Router Class Initialized
INFO - 2017-07-28 10:57:11 --> Output Class Initialized
INFO - 2017-07-28 10:57:11 --> Security Class Initialized
DEBUG - 2017-07-28 10:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:57:11 --> Input Class Initialized
INFO - 2017-07-28 10:57:11 --> Language Class Initialized
INFO - 2017-07-28 10:57:11 --> Loader Class Initialized
INFO - 2017-07-28 10:57:11 --> Helper loaded: url_helper
INFO - 2017-07-28 10:57:11 --> Helper loaded: form_helper
INFO - 2017-07-28 10:57:11 --> Helper loaded: security_helper
INFO - 2017-07-28 10:57:11 --> Helper loaded: path_helper
INFO - 2017-07-28 10:57:11 --> Helper loaded: common_helper
INFO - 2017-07-28 10:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 10:57:11 --> Helper loaded: check_session_helper
INFO - 2017-07-28 10:57:11 --> Database Driver Class Initialized
DEBUG - 2017-07-28 10:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:57:11 --> Email Class Initialized
INFO - 2017-07-28 10:57:11 --> Form Validation Class Initialized
INFO - 2017-07-28 10:57:11 --> Model Class Initialized
INFO - 2017-07-28 10:57:11 --> Model Class Initialized
INFO - 2017-07-28 10:57:11 --> Model Class Initialized
INFO - 2017-07-28 10:57:11 --> Model Class Initialized
INFO - 2017-07-28 10:57:11 --> Controller Class Initialized
INFO - 2017-07-28 10:57:11 --> Model Class Initialized
INFO - 2017-07-28 10:57:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 10:57:11 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 10:57:11 --> Final output sent to browser
DEBUG - 2017-07-28 10:57:11 --> Total execution time: 0.0302
DEBUG - 2017-07-28 10:57:11 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 10:57:11 --> Database Forge Class Initialized
INFO - 2017-07-28 10:57:11 --> User Agent Class Initialized
DEBUG - 2017-07-28 10:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 10:58:15 --> Config Class Initialized
INFO - 2017-07-28 10:58:15 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:58:15 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:58:15 --> Utf8 Class Initialized
INFO - 2017-07-28 10:58:15 --> URI Class Initialized
INFO - 2017-07-28 10:58:15 --> Router Class Initialized
INFO - 2017-07-28 10:58:15 --> Output Class Initialized
INFO - 2017-07-28 10:58:15 --> Security Class Initialized
DEBUG - 2017-07-28 10:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:58:15 --> Input Class Initialized
INFO - 2017-07-28 10:58:15 --> Language Class Initialized
ERROR - 2017-07-28 10:58:15 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 10:58:52 --> Config Class Initialized
INFO - 2017-07-28 10:58:52 --> Hooks Class Initialized
DEBUG - 2017-07-28 10:58:52 --> UTF-8 Support Enabled
INFO - 2017-07-28 10:58:52 --> Utf8 Class Initialized
INFO - 2017-07-28 10:58:52 --> URI Class Initialized
INFO - 2017-07-28 10:58:52 --> Router Class Initialized
INFO - 2017-07-28 10:58:52 --> Output Class Initialized
INFO - 2017-07-28 10:58:52 --> Security Class Initialized
DEBUG - 2017-07-28 10:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 10:58:52 --> Input Class Initialized
INFO - 2017-07-28 10:58:52 --> Language Class Initialized
ERROR - 2017-07-28 10:58:52 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 11:00:31 --> Config Class Initialized
INFO - 2017-07-28 11:00:31 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:00:31 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:00:31 --> Utf8 Class Initialized
INFO - 2017-07-28 11:00:31 --> URI Class Initialized
INFO - 2017-07-28 11:00:31 --> Router Class Initialized
INFO - 2017-07-28 11:00:31 --> Output Class Initialized
INFO - 2017-07-28 11:00:31 --> Security Class Initialized
DEBUG - 2017-07-28 11:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:00:31 --> Input Class Initialized
INFO - 2017-07-28 11:00:31 --> Language Class Initialized
ERROR - 2017-07-28 11:00:31 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 11:00:40 --> Config Class Initialized
INFO - 2017-07-28 11:00:40 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:00:40 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:00:40 --> Utf8 Class Initialized
INFO - 2017-07-28 11:00:40 --> URI Class Initialized
INFO - 2017-07-28 11:00:40 --> Router Class Initialized
INFO - 2017-07-28 11:00:40 --> Output Class Initialized
INFO - 2017-07-28 11:00:40 --> Security Class Initialized
DEBUG - 2017-07-28 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:00:40 --> Input Class Initialized
INFO - 2017-07-28 11:00:40 --> Language Class Initialized
INFO - 2017-07-28 11:00:40 --> Loader Class Initialized
INFO - 2017-07-28 11:00:40 --> Helper loaded: url_helper
INFO - 2017-07-28 11:00:40 --> Helper loaded: form_helper
INFO - 2017-07-28 11:00:40 --> Helper loaded: security_helper
INFO - 2017-07-28 11:00:40 --> Helper loaded: path_helper
INFO - 2017-07-28 11:00:40 --> Helper loaded: common_helper
INFO - 2017-07-28 11:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:00:40 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:00:40 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:00:40 --> Email Class Initialized
INFO - 2017-07-28 11:00:40 --> Form Validation Class Initialized
INFO - 2017-07-28 11:00:40 --> Model Class Initialized
INFO - 2017-07-28 11:00:40 --> Model Class Initialized
INFO - 2017-07-28 11:00:40 --> Model Class Initialized
INFO - 2017-07-28 11:00:40 --> Model Class Initialized
INFO - 2017-07-28 11:00:40 --> Controller Class Initialized
INFO - 2017-07-28 11:00:40 --> Model Class Initialized
INFO - 2017-07-28 11:00:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:00:40 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:00:40 --> Final output sent to browser
DEBUG - 2017-07-28 11:00:40 --> Total execution time: 0.0280
DEBUG - 2017-07-28 11:00:40 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:00:40 --> Database Forge Class Initialized
INFO - 2017-07-28 11:00:40 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:00:52 --> Config Class Initialized
INFO - 2017-07-28 11:00:52 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:00:52 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:00:52 --> Utf8 Class Initialized
INFO - 2017-07-28 11:00:52 --> URI Class Initialized
INFO - 2017-07-28 11:00:52 --> Router Class Initialized
INFO - 2017-07-28 11:00:52 --> Output Class Initialized
INFO - 2017-07-28 11:00:52 --> Security Class Initialized
DEBUG - 2017-07-28 11:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:00:52 --> Input Class Initialized
INFO - 2017-07-28 11:00:52 --> Language Class Initialized
ERROR - 2017-07-28 11:00:52 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 11:01:01 --> Config Class Initialized
INFO - 2017-07-28 11:01:01 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:01:01 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:01:01 --> Utf8 Class Initialized
INFO - 2017-07-28 11:01:01 --> URI Class Initialized
INFO - 2017-07-28 11:01:01 --> Router Class Initialized
INFO - 2017-07-28 11:01:01 --> Output Class Initialized
INFO - 2017-07-28 11:01:01 --> Security Class Initialized
DEBUG - 2017-07-28 11:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:01:01 --> Input Class Initialized
INFO - 2017-07-28 11:01:01 --> Language Class Initialized
INFO - 2017-07-28 11:01:01 --> Loader Class Initialized
INFO - 2017-07-28 11:01:01 --> Helper loaded: url_helper
INFO - 2017-07-28 11:01:01 --> Helper loaded: form_helper
INFO - 2017-07-28 11:01:01 --> Helper loaded: security_helper
INFO - 2017-07-28 11:01:01 --> Helper loaded: path_helper
INFO - 2017-07-28 11:01:01 --> Helper loaded: common_helper
INFO - 2017-07-28 11:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:01:01 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:01:01 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:01:01 --> Email Class Initialized
INFO - 2017-07-28 11:01:01 --> Form Validation Class Initialized
INFO - 2017-07-28 11:01:01 --> Model Class Initialized
INFO - 2017-07-28 11:01:01 --> Model Class Initialized
INFO - 2017-07-28 11:01:01 --> Model Class Initialized
INFO - 2017-07-28 11:01:01 --> Model Class Initialized
INFO - 2017-07-28 11:01:01 --> Controller Class Initialized
INFO - 2017-07-28 11:01:01 --> Model Class Initialized
INFO - 2017-07-28 11:01:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:01:01 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:01:01 --> Final output sent to browser
DEBUG - 2017-07-28 11:01:01 --> Total execution time: 0.0251
DEBUG - 2017-07-28 11:01:01 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:01:01 --> Database Forge Class Initialized
INFO - 2017-07-28 11:01:01 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:01:17 --> Config Class Initialized
INFO - 2017-07-28 11:01:17 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:01:17 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:01:17 --> Utf8 Class Initialized
INFO - 2017-07-28 11:01:17 --> URI Class Initialized
INFO - 2017-07-28 11:01:17 --> Router Class Initialized
INFO - 2017-07-28 11:01:17 --> Output Class Initialized
INFO - 2017-07-28 11:01:17 --> Security Class Initialized
DEBUG - 2017-07-28 11:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:01:17 --> Input Class Initialized
INFO - 2017-07-28 11:01:17 --> Language Class Initialized
ERROR - 2017-07-28 11:01:17 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 11:02:22 --> Config Class Initialized
INFO - 2017-07-28 11:02:22 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:02:22 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:02:22 --> Utf8 Class Initialized
INFO - 2017-07-28 11:02:22 --> URI Class Initialized
INFO - 2017-07-28 11:02:22 --> Router Class Initialized
INFO - 2017-07-28 11:02:22 --> Output Class Initialized
INFO - 2017-07-28 11:02:22 --> Security Class Initialized
DEBUG - 2017-07-28 11:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:02:22 --> Input Class Initialized
INFO - 2017-07-28 11:02:22 --> Language Class Initialized
INFO - 2017-07-28 11:02:22 --> Loader Class Initialized
INFO - 2017-07-28 11:02:22 --> Helper loaded: url_helper
INFO - 2017-07-28 11:02:22 --> Helper loaded: form_helper
INFO - 2017-07-28 11:02:22 --> Helper loaded: security_helper
INFO - 2017-07-28 11:02:22 --> Helper loaded: path_helper
INFO - 2017-07-28 11:02:22 --> Helper loaded: common_helper
INFO - 2017-07-28 11:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:02:22 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:02:22 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:02:22 --> Email Class Initialized
INFO - 2017-07-28 11:02:22 --> Form Validation Class Initialized
INFO - 2017-07-28 11:02:22 --> Model Class Initialized
INFO - 2017-07-28 11:02:22 --> Model Class Initialized
INFO - 2017-07-28 11:02:22 --> Model Class Initialized
INFO - 2017-07-28 11:02:22 --> Model Class Initialized
INFO - 2017-07-28 11:02:22 --> Controller Class Initialized
INFO - 2017-07-28 11:02:22 --> Model Class Initialized
INFO - 2017-07-28 11:02:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:02:22 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:02:22 --> Final output sent to browser
DEBUG - 2017-07-28 11:02:22 --> Total execution time: 0.0279
DEBUG - 2017-07-28 11:02:22 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:02:22 --> Database Forge Class Initialized
INFO - 2017-07-28 11:02:22 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:02:43 --> Config Class Initialized
INFO - 2017-07-28 11:02:43 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:02:43 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:02:43 --> Utf8 Class Initialized
INFO - 2017-07-28 11:02:43 --> URI Class Initialized
INFO - 2017-07-28 11:02:43 --> Router Class Initialized
INFO - 2017-07-28 11:02:43 --> Output Class Initialized
INFO - 2017-07-28 11:02:43 --> Security Class Initialized
DEBUG - 2017-07-28 11:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:02:43 --> Input Class Initialized
INFO - 2017-07-28 11:02:43 --> Language Class Initialized
INFO - 2017-07-28 11:02:43 --> Loader Class Initialized
INFO - 2017-07-28 11:02:43 --> Helper loaded: url_helper
INFO - 2017-07-28 11:02:43 --> Helper loaded: form_helper
INFO - 2017-07-28 11:02:43 --> Helper loaded: security_helper
INFO - 2017-07-28 11:02:43 --> Helper loaded: path_helper
INFO - 2017-07-28 11:02:43 --> Helper loaded: common_helper
INFO - 2017-07-28 11:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:02:43 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:02:43 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:02:43 --> Email Class Initialized
INFO - 2017-07-28 11:02:43 --> Form Validation Class Initialized
INFO - 2017-07-28 11:02:43 --> Model Class Initialized
INFO - 2017-07-28 11:02:43 --> Model Class Initialized
INFO - 2017-07-28 11:02:43 --> Model Class Initialized
INFO - 2017-07-28 11:02:43 --> Model Class Initialized
INFO - 2017-07-28 11:02:43 --> Controller Class Initialized
INFO - 2017-07-28 11:02:43 --> Model Class Initialized
INFO - 2017-07-28 11:02:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:02:43 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:02:43 --> Final output sent to browser
DEBUG - 2017-07-28 11:02:43 --> Total execution time: 0.0322
DEBUG - 2017-07-28 11:02:43 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:02:43 --> Database Forge Class Initialized
INFO - 2017-07-28 11:02:43 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:02:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:06:55 --> Config Class Initialized
INFO - 2017-07-28 11:06:55 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:06:55 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:06:55 --> Utf8 Class Initialized
INFO - 2017-07-28 11:06:55 --> URI Class Initialized
INFO - 2017-07-28 11:06:55 --> Router Class Initialized
INFO - 2017-07-28 11:06:55 --> Output Class Initialized
INFO - 2017-07-28 11:06:55 --> Security Class Initialized
DEBUG - 2017-07-28 11:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:06:55 --> Input Class Initialized
INFO - 2017-07-28 11:06:55 --> Language Class Initialized
INFO - 2017-07-28 11:06:55 --> Loader Class Initialized
INFO - 2017-07-28 11:06:55 --> Helper loaded: url_helper
INFO - 2017-07-28 11:06:55 --> Helper loaded: form_helper
INFO - 2017-07-28 11:06:55 --> Helper loaded: security_helper
INFO - 2017-07-28 11:06:55 --> Helper loaded: path_helper
INFO - 2017-07-28 11:06:55 --> Helper loaded: common_helper
INFO - 2017-07-28 11:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:06:55 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:06:55 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:06:55 --> Email Class Initialized
INFO - 2017-07-28 11:06:55 --> Form Validation Class Initialized
INFO - 2017-07-28 11:06:55 --> Model Class Initialized
INFO - 2017-07-28 11:06:55 --> Model Class Initialized
INFO - 2017-07-28 11:06:55 --> Model Class Initialized
INFO - 2017-07-28 11:06:55 --> Model Class Initialized
INFO - 2017-07-28 11:06:55 --> Controller Class Initialized
INFO - 2017-07-28 11:06:55 --> Model Class Initialized
INFO - 2017-07-28 11:06:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:06:55 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:06:55 --> Final output sent to browser
DEBUG - 2017-07-28 11:06:55 --> Total execution time: 0.0279
DEBUG - 2017-07-28 11:06:55 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:06:55 --> Database Forge Class Initialized
INFO - 2017-07-28 11:06:55 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:06:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:07:47 --> Config Class Initialized
INFO - 2017-07-28 11:07:47 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:07:47 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:07:47 --> Utf8 Class Initialized
INFO - 2017-07-28 11:07:47 --> URI Class Initialized
INFO - 2017-07-28 11:07:47 --> Router Class Initialized
INFO - 2017-07-28 11:07:47 --> Output Class Initialized
INFO - 2017-07-28 11:07:47 --> Security Class Initialized
DEBUG - 2017-07-28 11:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:07:47 --> Input Class Initialized
INFO - 2017-07-28 11:07:47 --> Language Class Initialized
INFO - 2017-07-28 11:07:47 --> Loader Class Initialized
INFO - 2017-07-28 11:07:47 --> Helper loaded: url_helper
INFO - 2017-07-28 11:07:47 --> Helper loaded: form_helper
INFO - 2017-07-28 11:07:47 --> Helper loaded: security_helper
INFO - 2017-07-28 11:07:47 --> Helper loaded: path_helper
INFO - 2017-07-28 11:07:47 --> Helper loaded: common_helper
INFO - 2017-07-28 11:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:07:47 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:07:47 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:07:47 --> Email Class Initialized
INFO - 2017-07-28 11:07:47 --> Form Validation Class Initialized
INFO - 2017-07-28 11:07:47 --> Model Class Initialized
INFO - 2017-07-28 11:07:47 --> Model Class Initialized
INFO - 2017-07-28 11:07:47 --> Model Class Initialized
INFO - 2017-07-28 11:07:47 --> Model Class Initialized
INFO - 2017-07-28 11:07:47 --> Controller Class Initialized
INFO - 2017-07-28 11:07:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 11:07:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-28 11:07:47 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 11:07:47 --> Final output sent to browser
DEBUG - 2017-07-28 11:07:47 --> Total execution time: 0.1139
DEBUG - 2017-07-28 11:07:47 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:07:47 --> Database Forge Class Initialized
INFO - 2017-07-28 11:07:47 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:07:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:07:48 --> Config Class Initialized
INFO - 2017-07-28 11:07:48 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:07:48 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:07:48 --> Utf8 Class Initialized
INFO - 2017-07-28 11:07:48 --> URI Class Initialized
INFO - 2017-07-28 11:07:48 --> Router Class Initialized
INFO - 2017-07-28 11:07:48 --> Output Class Initialized
INFO - 2017-07-28 11:07:48 --> Security Class Initialized
DEBUG - 2017-07-28 11:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:07:48 --> Input Class Initialized
INFO - 2017-07-28 11:07:48 --> Language Class Initialized
ERROR - 2017-07-28 11:07:48 --> 404 Page Not Found: Faviconico/index
INFO - 2017-07-28 11:07:56 --> Config Class Initialized
INFO - 2017-07-28 11:07:56 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:07:56 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:07:56 --> Utf8 Class Initialized
INFO - 2017-07-28 11:07:56 --> URI Class Initialized
INFO - 2017-07-28 11:07:56 --> Router Class Initialized
INFO - 2017-07-28 11:07:56 --> Output Class Initialized
INFO - 2017-07-28 11:07:56 --> Security Class Initialized
DEBUG - 2017-07-28 11:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:07:56 --> Input Class Initialized
INFO - 2017-07-28 11:07:56 --> Language Class Initialized
INFO - 2017-07-28 11:07:56 --> Loader Class Initialized
INFO - 2017-07-28 11:07:56 --> Helper loaded: url_helper
INFO - 2017-07-28 11:07:56 --> Helper loaded: form_helper
INFO - 2017-07-28 11:07:56 --> Helper loaded: security_helper
INFO - 2017-07-28 11:07:56 --> Helper loaded: path_helper
INFO - 2017-07-28 11:07:56 --> Helper loaded: common_helper
INFO - 2017-07-28 11:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:07:56 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:07:56 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:07:56 --> Email Class Initialized
INFO - 2017-07-28 11:07:56 --> Form Validation Class Initialized
INFO - 2017-07-28 11:07:56 --> Model Class Initialized
INFO - 2017-07-28 11:07:56 --> Model Class Initialized
INFO - 2017-07-28 11:07:56 --> Model Class Initialized
INFO - 2017-07-28 11:07:56 --> Model Class Initialized
INFO - 2017-07-28 11:07:56 --> Controller Class Initialized
DEBUG - 2017-07-28 11:07:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:07:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 11:07:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-07-28 11:07:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 11:07:56 --> Final output sent to browser
DEBUG - 2017-07-28 11:07:56 --> Total execution time: 0.0273
DEBUG - 2017-07-28 11:07:56 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:07:56 --> Database Forge Class Initialized
INFO - 2017-07-28 11:07:56 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:08:49 --> Config Class Initialized
INFO - 2017-07-28 11:08:49 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:08:49 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:08:49 --> Utf8 Class Initialized
INFO - 2017-07-28 11:08:49 --> URI Class Initialized
INFO - 2017-07-28 11:08:49 --> Router Class Initialized
INFO - 2017-07-28 11:08:49 --> Output Class Initialized
INFO - 2017-07-28 11:08:49 --> Security Class Initialized
DEBUG - 2017-07-28 11:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:08:49 --> Input Class Initialized
INFO - 2017-07-28 11:08:49 --> Language Class Initialized
INFO - 2017-07-28 11:08:49 --> Loader Class Initialized
INFO - 2017-07-28 11:08:49 --> Helper loaded: url_helper
INFO - 2017-07-28 11:08:49 --> Helper loaded: form_helper
INFO - 2017-07-28 11:08:49 --> Helper loaded: security_helper
INFO - 2017-07-28 11:08:49 --> Helper loaded: path_helper
INFO - 2017-07-28 11:08:49 --> Helper loaded: common_helper
INFO - 2017-07-28 11:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:08:49 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:08:49 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:08:49 --> Email Class Initialized
INFO - 2017-07-28 11:08:49 --> Form Validation Class Initialized
INFO - 2017-07-28 11:08:49 --> Model Class Initialized
INFO - 2017-07-28 11:08:49 --> Model Class Initialized
INFO - 2017-07-28 11:08:49 --> Model Class Initialized
INFO - 2017-07-28 11:08:49 --> Model Class Initialized
INFO - 2017-07-28 11:08:49 --> Controller Class Initialized
DEBUG - 2017-07-28 11:08:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:08:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 11:08:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page_details.php
INFO - 2017-07-28 11:08:49 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 11:08:49 --> Final output sent to browser
DEBUG - 2017-07-28 11:08:49 --> Total execution time: 0.0364
DEBUG - 2017-07-28 11:08:49 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:08:49 --> Database Forge Class Initialized
INFO - 2017-07-28 11:08:49 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:08:56 --> Config Class Initialized
INFO - 2017-07-28 11:08:56 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:08:56 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:08:56 --> Utf8 Class Initialized
INFO - 2017-07-28 11:08:56 --> URI Class Initialized
INFO - 2017-07-28 11:08:56 --> Router Class Initialized
INFO - 2017-07-28 11:08:56 --> Output Class Initialized
INFO - 2017-07-28 11:08:56 --> Security Class Initialized
DEBUG - 2017-07-28 11:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:08:56 --> Input Class Initialized
INFO - 2017-07-28 11:08:56 --> Language Class Initialized
INFO - 2017-07-28 11:08:56 --> Loader Class Initialized
INFO - 2017-07-28 11:08:56 --> Helper loaded: url_helper
INFO - 2017-07-28 11:08:56 --> Helper loaded: form_helper
INFO - 2017-07-28 11:08:56 --> Helper loaded: security_helper
INFO - 2017-07-28 11:08:56 --> Helper loaded: path_helper
INFO - 2017-07-28 11:08:56 --> Helper loaded: common_helper
INFO - 2017-07-28 11:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:08:56 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:08:56 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:08:56 --> Email Class Initialized
INFO - 2017-07-28 11:08:56 --> Form Validation Class Initialized
INFO - 2017-07-28 11:08:56 --> Model Class Initialized
INFO - 2017-07-28 11:08:56 --> Model Class Initialized
INFO - 2017-07-28 11:08:56 --> Model Class Initialized
INFO - 2017-07-28 11:08:56 --> Model Class Initialized
INFO - 2017-07-28 11:08:56 --> Controller Class Initialized
INFO - 2017-07-28 11:08:56 --> Model Class Initialized
INFO - 2017-07-28 11:08:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:08:56 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:08:56 --> Final output sent to browser
DEBUG - 2017-07-28 11:08:56 --> Total execution time: 0.0297
DEBUG - 2017-07-28 11:08:56 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:08:56 --> Database Forge Class Initialized
INFO - 2017-07-28 11:08:56 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:08:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:09:10 --> Config Class Initialized
INFO - 2017-07-28 11:09:10 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:09:10 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:09:10 --> Utf8 Class Initialized
INFO - 2017-07-28 11:09:10 --> URI Class Initialized
INFO - 2017-07-28 11:09:10 --> Router Class Initialized
INFO - 2017-07-28 11:09:10 --> Output Class Initialized
INFO - 2017-07-28 11:09:10 --> Security Class Initialized
DEBUG - 2017-07-28 11:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:09:10 --> Input Class Initialized
INFO - 2017-07-28 11:09:10 --> Language Class Initialized
INFO - 2017-07-28 11:09:10 --> Loader Class Initialized
INFO - 2017-07-28 11:09:10 --> Helper loaded: url_helper
INFO - 2017-07-28 11:09:10 --> Helper loaded: form_helper
INFO - 2017-07-28 11:09:10 --> Helper loaded: security_helper
INFO - 2017-07-28 11:09:10 --> Helper loaded: path_helper
INFO - 2017-07-28 11:09:10 --> Helper loaded: common_helper
INFO - 2017-07-28 11:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:09:10 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:09:10 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:09:10 --> Email Class Initialized
INFO - 2017-07-28 11:09:10 --> Form Validation Class Initialized
INFO - 2017-07-28 11:09:10 --> Model Class Initialized
INFO - 2017-07-28 11:09:10 --> Model Class Initialized
INFO - 2017-07-28 11:09:10 --> Model Class Initialized
INFO - 2017-07-28 11:09:10 --> Model Class Initialized
INFO - 2017-07-28 11:09:10 --> Controller Class Initialized
INFO - 2017-07-28 11:09:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/header.php
INFO - 2017-07-28 11:09:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/page.php
INFO - 2017-07-28 11:09:10 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/admin/template.php
INFO - 2017-07-28 11:09:10 --> Final output sent to browser
DEBUG - 2017-07-28 11:09:10 --> Total execution time: 0.0262
DEBUG - 2017-07-28 11:09:10 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:09:10 --> Database Forge Class Initialized
INFO - 2017-07-28 11:09:10 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:21:52 --> Config Class Initialized
INFO - 2017-07-28 11:21:52 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:21:52 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:21:52 --> Utf8 Class Initialized
INFO - 2017-07-28 11:21:52 --> URI Class Initialized
INFO - 2017-07-28 11:21:52 --> Router Class Initialized
INFO - 2017-07-28 11:21:52 --> Output Class Initialized
INFO - 2017-07-28 11:21:52 --> Security Class Initialized
DEBUG - 2017-07-28 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:21:52 --> Input Class Initialized
INFO - 2017-07-28 11:21:52 --> Language Class Initialized
INFO - 2017-07-28 11:21:52 --> Loader Class Initialized
INFO - 2017-07-28 11:21:52 --> Helper loaded: url_helper
INFO - 2017-07-28 11:21:52 --> Helper loaded: form_helper
INFO - 2017-07-28 11:21:52 --> Helper loaded: security_helper
INFO - 2017-07-28 11:21:52 --> Helper loaded: path_helper
INFO - 2017-07-28 11:21:52 --> Helper loaded: common_helper
INFO - 2017-07-28 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:21:52 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:21:52 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:21:52 --> Email Class Initialized
INFO - 2017-07-28 11:21:52 --> Form Validation Class Initialized
INFO - 2017-07-28 11:21:52 --> Model Class Initialized
INFO - 2017-07-28 11:21:52 --> Model Class Initialized
INFO - 2017-07-28 11:21:52 --> Model Class Initialized
INFO - 2017-07-28 11:21:52 --> Model Class Initialized
INFO - 2017-07-28 11:21:52 --> Controller Class Initialized
INFO - 2017-07-28 11:21:52 --> Model Class Initialized
INFO - 2017-07-28 11:21:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:21:52 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:21:52 --> Final output sent to browser
DEBUG - 2017-07-28 11:21:52 --> Total execution time: 0.0278
DEBUG - 2017-07-28 11:21:52 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:21:52 --> Database Forge Class Initialized
INFO - 2017-07-28 11:21:52 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:21:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:22:06 --> Config Class Initialized
INFO - 2017-07-28 11:22:06 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:22:06 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:22:06 --> Utf8 Class Initialized
INFO - 2017-07-28 11:22:06 --> URI Class Initialized
INFO - 2017-07-28 11:22:06 --> Router Class Initialized
INFO - 2017-07-28 11:22:06 --> Output Class Initialized
INFO - 2017-07-28 11:22:06 --> Security Class Initialized
DEBUG - 2017-07-28 11:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:22:06 --> Input Class Initialized
INFO - 2017-07-28 11:22:06 --> Language Class Initialized
ERROR - 2017-07-28 11:22:06 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 11:22:28 --> Config Class Initialized
INFO - 2017-07-28 11:22:28 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:22:28 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:22:28 --> Utf8 Class Initialized
INFO - 2017-07-28 11:22:28 --> URI Class Initialized
INFO - 2017-07-28 11:22:28 --> Router Class Initialized
INFO - 2017-07-28 11:22:28 --> Output Class Initialized
INFO - 2017-07-28 11:22:28 --> Security Class Initialized
DEBUG - 2017-07-28 11:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:22:28 --> Input Class Initialized
INFO - 2017-07-28 11:22:28 --> Language Class Initialized
INFO - 2017-07-28 11:22:28 --> Loader Class Initialized
INFO - 2017-07-28 11:22:28 --> Helper loaded: url_helper
INFO - 2017-07-28 11:22:28 --> Helper loaded: form_helper
INFO - 2017-07-28 11:22:28 --> Helper loaded: security_helper
INFO - 2017-07-28 11:22:28 --> Helper loaded: path_helper
INFO - 2017-07-28 11:22:28 --> Helper loaded: common_helper
INFO - 2017-07-28 11:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:22:28 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:22:28 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:22:28 --> Email Class Initialized
INFO - 2017-07-28 11:22:28 --> Form Validation Class Initialized
INFO - 2017-07-28 11:22:28 --> Model Class Initialized
INFO - 2017-07-28 11:22:28 --> Model Class Initialized
INFO - 2017-07-28 11:22:28 --> Model Class Initialized
INFO - 2017-07-28 11:22:28 --> Model Class Initialized
INFO - 2017-07-28 11:22:28 --> Controller Class Initialized
INFO - 2017-07-28 11:22:28 --> Model Class Initialized
INFO - 2017-07-28 11:22:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:22:28 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:22:28 --> Final output sent to browser
DEBUG - 2017-07-28 11:22:28 --> Total execution time: 0.0280
DEBUG - 2017-07-28 11:22:28 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:22:28 --> Database Forge Class Initialized
INFO - 2017-07-28 11:22:28 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:22:42 --> Config Class Initialized
INFO - 2017-07-28 11:22:42 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:22:42 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:22:42 --> Utf8 Class Initialized
INFO - 2017-07-28 11:22:42 --> URI Class Initialized
INFO - 2017-07-28 11:22:42 --> Router Class Initialized
INFO - 2017-07-28 11:22:42 --> Output Class Initialized
INFO - 2017-07-28 11:22:42 --> Security Class Initialized
DEBUG - 2017-07-28 11:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:22:42 --> Input Class Initialized
INFO - 2017-07-28 11:22:42 --> Language Class Initialized
ERROR - 2017-07-28 11:22:42 --> 404 Page Not Found: Page/assets
INFO - 2017-07-28 11:32:27 --> Config Class Initialized
INFO - 2017-07-28 11:32:27 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:32:27 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:32:27 --> Utf8 Class Initialized
INFO - 2017-07-28 11:32:27 --> URI Class Initialized
DEBUG - 2017-07-28 11:32:27 --> No URI present. Default controller set.
INFO - 2017-07-28 11:32:27 --> Router Class Initialized
INFO - 2017-07-28 11:32:27 --> Output Class Initialized
INFO - 2017-07-28 11:32:27 --> Security Class Initialized
DEBUG - 2017-07-28 11:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:32:27 --> Input Class Initialized
INFO - 2017-07-28 11:32:27 --> Language Class Initialized
INFO - 2017-07-28 11:32:27 --> Loader Class Initialized
INFO - 2017-07-28 11:32:27 --> Helper loaded: url_helper
INFO - 2017-07-28 11:32:27 --> Helper loaded: form_helper
INFO - 2017-07-28 11:32:27 --> Helper loaded: security_helper
INFO - 2017-07-28 11:32:27 --> Helper loaded: path_helper
INFO - 2017-07-28 11:32:27 --> Helper loaded: common_helper
INFO - 2017-07-28 11:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:32:27 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:32:27 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:32:27 --> Email Class Initialized
INFO - 2017-07-28 11:32:27 --> Form Validation Class Initialized
INFO - 2017-07-28 11:32:27 --> Model Class Initialized
INFO - 2017-07-28 11:32:27 --> Model Class Initialized
INFO - 2017-07-28 11:32:27 --> Model Class Initialized
INFO - 2017-07-28 11:32:27 --> Model Class Initialized
INFO - 2017-07-28 11:32:27 --> Controller Class Initialized
DEBUG - 2017-07-28 11:32:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:32:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/user_login.php
INFO - 2017-07-28 11:32:27 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/login_template.php
INFO - 2017-07-28 11:32:27 --> Final output sent to browser
DEBUG - 2017-07-28 11:32:27 --> Total execution time: 0.2557
DEBUG - 2017-07-28 11:32:27 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:32:27 --> Database Forge Class Initialized
INFO - 2017-07-28 11:32:27 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:32:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:56:08 --> Config Class Initialized
INFO - 2017-07-28 11:56:08 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:56:08 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:56:08 --> Utf8 Class Initialized
INFO - 2017-07-28 11:56:08 --> URI Class Initialized
INFO - 2017-07-28 11:56:08 --> Router Class Initialized
INFO - 2017-07-28 11:56:08 --> Output Class Initialized
INFO - 2017-07-28 11:56:08 --> Security Class Initialized
DEBUG - 2017-07-28 11:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:56:08 --> Input Class Initialized
INFO - 2017-07-28 11:56:08 --> Language Class Initialized
INFO - 2017-07-28 11:56:08 --> Loader Class Initialized
INFO - 2017-07-28 11:56:08 --> Helper loaded: url_helper
INFO - 2017-07-28 11:56:08 --> Helper loaded: form_helper
INFO - 2017-07-28 11:56:08 --> Helper loaded: security_helper
INFO - 2017-07-28 11:56:08 --> Helper loaded: path_helper
INFO - 2017-07-28 11:56:08 --> Helper loaded: common_helper
INFO - 2017-07-28 11:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:56:08 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:56:08 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:56:08 --> Email Class Initialized
INFO - 2017-07-28 11:56:08 --> Form Validation Class Initialized
INFO - 2017-07-28 11:56:08 --> Model Class Initialized
INFO - 2017-07-28 11:56:08 --> Model Class Initialized
INFO - 2017-07-28 11:56:08 --> Model Class Initialized
INFO - 2017-07-28 11:56:08 --> Model Class Initialized
INFO - 2017-07-28 11:56:08 --> Controller Class Initialized
INFO - 2017-07-28 11:56:08 --> Model Class Initialized
INFO - 2017-07-28 11:56:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:56:08 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:56:08 --> Final output sent to browser
DEBUG - 2017-07-28 11:56:08 --> Total execution time: 0.0322
DEBUG - 2017-07-28 11:56:08 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:56:08 --> Database Forge Class Initialized
INFO - 2017-07-28 11:56:08 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:56:36 --> Config Class Initialized
INFO - 2017-07-28 11:56:36 --> Hooks Class Initialized
DEBUG - 2017-07-28 11:56:36 --> UTF-8 Support Enabled
INFO - 2017-07-28 11:56:36 --> Utf8 Class Initialized
INFO - 2017-07-28 11:56:36 --> URI Class Initialized
INFO - 2017-07-28 11:56:36 --> Router Class Initialized
INFO - 2017-07-28 11:56:36 --> Output Class Initialized
INFO - 2017-07-28 11:56:36 --> Security Class Initialized
DEBUG - 2017-07-28 11:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 11:56:36 --> Input Class Initialized
INFO - 2017-07-28 11:56:36 --> Language Class Initialized
INFO - 2017-07-28 11:56:36 --> Loader Class Initialized
INFO - 2017-07-28 11:56:36 --> Helper loaded: url_helper
INFO - 2017-07-28 11:56:36 --> Helper loaded: form_helper
INFO - 2017-07-28 11:56:36 --> Helper loaded: security_helper
INFO - 2017-07-28 11:56:36 --> Helper loaded: path_helper
INFO - 2017-07-28 11:56:36 --> Helper loaded: common_helper
INFO - 2017-07-28 11:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 11:56:36 --> Helper loaded: check_session_helper
INFO - 2017-07-28 11:56:36 --> Database Driver Class Initialized
DEBUG - 2017-07-28 11:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 11:56:36 --> Email Class Initialized
INFO - 2017-07-28 11:56:36 --> Form Validation Class Initialized
INFO - 2017-07-28 11:56:36 --> Model Class Initialized
INFO - 2017-07-28 11:56:36 --> Model Class Initialized
INFO - 2017-07-28 11:56:36 --> Model Class Initialized
INFO - 2017-07-28 11:56:36 --> Model Class Initialized
INFO - 2017-07-28 11:56:36 --> Controller Class Initialized
INFO - 2017-07-28 11:56:36 --> Model Class Initialized
INFO - 2017-07-28 11:56:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 11:56:36 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 11:56:36 --> Final output sent to browser
DEBUG - 2017-07-28 11:56:36 --> Total execution time: 0.0295
DEBUG - 2017-07-28 11:56:36 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 11:56:36 --> Database Forge Class Initialized
INFO - 2017-07-28 11:56:36 --> User Agent Class Initialized
DEBUG - 2017-07-28 11:56:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 17:10:15 --> Config Class Initialized
INFO - 2017-07-28 17:10:15 --> Hooks Class Initialized
DEBUG - 2017-07-28 17:10:15 --> UTF-8 Support Enabled
INFO - 2017-07-28 17:10:15 --> Utf8 Class Initialized
INFO - 2017-07-28 17:10:15 --> URI Class Initialized
INFO - 2017-07-28 17:10:15 --> Router Class Initialized
INFO - 2017-07-28 17:10:16 --> Output Class Initialized
INFO - 2017-07-28 17:10:16 --> Security Class Initialized
DEBUG - 2017-07-28 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-28 17:10:16 --> Input Class Initialized
INFO - 2017-07-28 17:10:16 --> Language Class Initialized
INFO - 2017-07-28 17:10:16 --> Loader Class Initialized
INFO - 2017-07-28 17:10:16 --> Helper loaded: url_helper
INFO - 2017-07-28 17:10:16 --> Helper loaded: form_helper
INFO - 2017-07-28 17:10:16 --> Helper loaded: security_helper
INFO - 2017-07-28 17:10:16 --> Helper loaded: path_helper
INFO - 2017-07-28 17:10:16 --> Helper loaded: common_helper
INFO - 2017-07-28 17:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-28 17:10:18 --> Helper loaded: check_session_helper
INFO - 2017-07-28 17:10:18 --> Database Driver Class Initialized
DEBUG - 2017-07-28 17:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-28 17:10:18 --> Email Class Initialized
INFO - 2017-07-28 17:10:18 --> Form Validation Class Initialized
INFO - 2017-07-28 17:10:18 --> Model Class Initialized
INFO - 2017-07-28 17:10:18 --> Model Class Initialized
INFO - 2017-07-28 17:10:18 --> Model Class Initialized
INFO - 2017-07-28 17:10:18 --> Model Class Initialized
INFO - 2017-07-28 17:10:18 --> Controller Class Initialized
INFO - 2017-07-28 17:10:19 --> Model Class Initialized
INFO - 2017-07-28 17:10:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/page.php
INFO - 2017-07-28 17:10:19 --> File loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/views/template/cms_template.php
INFO - 2017-07-28 17:10:19 --> Final output sent to browser
DEBUG - 2017-07-28 17:10:19 --> Total execution time: 4.6482
DEBUG - 2017-07-28 17:10:20 --> Config file loaded: /var/www/vhosts/codunite.com/oncolens.accretelabs.com/application/config/usertracking_config.php
INFO - 2017-07-28 17:10:21 --> Database Forge Class Initialized
INFO - 2017-07-28 17:10:21 --> User Agent Class Initialized
DEBUG - 2017-07-28 17:10:21 --> Session class already loaded. Second attempt ignored.
