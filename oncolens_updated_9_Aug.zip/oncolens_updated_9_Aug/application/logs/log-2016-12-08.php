<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-08 01:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 05:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 05:16:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-08 05:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-08 05:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 06:26:03 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:26:03 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 06:26:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:27:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:27:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:27:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:28:13 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:28:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:28:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:34:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:34:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:34:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:34:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:38:45 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'e293ab67430ab34651863f834339a248519ddc8c', '/', 1481207925, '198.20.69.74', NULL, '')
ERROR - 2016-12-08 06:39:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:39:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:39:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:40:17 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:41:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:41:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:41:10 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:41:14 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:42:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:42:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:42:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:42:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:11 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:16 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:19 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 06:48:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 06:56:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-08 07:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:05:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:05:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:05:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:05:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:16:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:18:47 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:19:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:19:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:20:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 07:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:31:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-08 07:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:45:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-08 07:46:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-08 07:47:44 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 07:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 07:47:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 07:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 07:49:58 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:50:22 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 07:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 08:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 08:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-08 10:00:37 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 10:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 10:00:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 10:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 10:03:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 10:03:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 10:16:20 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-08 10:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image3.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164026_8_101_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164026_8_101_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164026_8_101_image3.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164026_8_101_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164026_8_101_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164031_8_101_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164031_8_101_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164031_8_101_image3.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164031_8_101_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:52:17 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164031_8_101_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:04 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image1.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:04 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:04 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image3.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:04 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164016_8_101_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164036_8_101_image2.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164036_8_101_image3.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164036_8_101_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 15:54:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1481164036_8_101_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-08 16:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 18:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 19:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 21:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-08 21:08:29 --> 404 Page Not Found: M/page
