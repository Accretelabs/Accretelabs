<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-20 02:20:07 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'd6e6cef33c7bbd786a72109427fbac09dd7d5664', '/', 1482229207, '66.240.219.146', NULL, '')
ERROR - 2016-12-20 05:57:45 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 05:57:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 06:15:54 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 07:03:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 07:30:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-20 07:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-20 07:33:47 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 07:33:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 07:33:57 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 07:34:36 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 07:34:44 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-20 07:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-20 07:37:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-20 07:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 07:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 07:39:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-20 07:40:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-20 07:40:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2016-12-20 07:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 07:46:37 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1482169330_8_220_image4.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-20 07:46:37 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1482169330_8_220_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-20 07:47:13 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1482169330_8_220_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-20 07:50:14 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-20 07:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-20 07:50:21 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/application/models/Mtumorboard.php 301
ERROR - 2016-12-20 07:50:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/application/models/Mtumorboard.php 304
ERROR - 2016-12-20 07:55:41 --> Severity: Warning --> unlink(/var/www/html/oncolensphp/upload/1482169330_8_220_image5.png): No such file or directory /var/www/html/application/models/Mcase.php 4899
ERROR - 2016-12-20 08:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 08:04:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 08:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 08:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-12-20 08:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 08:08:50 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 08:09:36 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2016-12-20 08:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 08:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 09:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 09:38:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2016-12-20 12:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 12:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2016-12-20 13:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 13:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 13:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 16:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-12-20 23:29:52 --> 404 Page Not Found: Robotstxt/index
