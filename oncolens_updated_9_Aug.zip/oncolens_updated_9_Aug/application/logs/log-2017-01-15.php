<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-15 03:21:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:21:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:22:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:23:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:24:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:25:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:26:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 03:27:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 04:24:46 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, '185270fe1b20869a338ff3356a9f93921dd38289', '/', 1484483086, '198.20.69.98', NULL, '')
ERROR - 2017-01-15 06:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-15 09:13:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 11:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-15 11:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-15 11:08:22 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2017-01-15 14:54:03 --> 404 Page Not Found: BingSiteAuthxml/index
ERROR - 2017-01-15 14:54:03 --> 404 Page Not Found: Bingsiteauthxml/index
ERROR - 2017-01-15 14:54:03 --> 404 Page Not Found: LiveSearchSiteAuthxml/index
ERROR - 2017-01-15 14:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-15 16:28:39 --> 404 Page Not Found: Apple-app-site-association/index
ERROR - 2017-01-15 17:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-15 17:53:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-15 17:55:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-15 17:59:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 18:01:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 18:01:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 18:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 18:11:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-15 19:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-15 20:26:56 --> 404 Page Not Found: Robotstxt/index
