<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-17 01:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-17 02:26:59 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2017-01-17 04:00:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-17 04:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2017-01-17 06:21:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib64/php/modules/suhosin.so' - /usr/lib64/php/modules/suhosin.so: undefined symbol: php_register_info_logo Unknown 0
ERROR - 2017-01-17 06:36:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-17 06:36:22 --> 404 Page Not Found: Assets/css
ERROR - 2017-01-17 06:36:54 --> 404 Page Not Found: Assets/fonts
ERROR - 2017-01-17 06:44:32 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-17 06:44:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-01-17 06:46:30 --> Severity: Warning --> opendir(/var/www/html/application/helpers/mpdf/tmp): failed to open dir: No such file or directory /var/www/html/application/helpers/mpdf/mpdf_helper.php 7502
ERROR - 2017-01-17 06:47:16 --> 404 Page Not Found: Faviconico/index
