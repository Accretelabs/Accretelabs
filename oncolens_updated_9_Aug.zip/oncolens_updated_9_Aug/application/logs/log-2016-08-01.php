<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-01 04:48:36 --> 404 Page Not Found: Page/assets
ERROR - 2016-08-01 05:15:38 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'bf4dea2e88b68797811dddca0b8cb6297b98efe1', '/', 1470053738, '184.105.247.195', NULL, '')
ERROR - 2016-08-01 12:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2016-08-01 13:45:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-01 23:00:12 --> Query error: Column 'client_user_agent' cannot be null - Invalid query: INSERT INTO `usertracking` (`user_type`, `user_identifier`, `session_id`, `request_uri`, `timestamp`, `client_ip`, `client_user_agent`, `referer_page`) VALUES ('isUser', NULL, 'bddc82826bd95d8de643858646d975e05843074f', '/', 1470117612, '184.105.247.196', NULL, '')
