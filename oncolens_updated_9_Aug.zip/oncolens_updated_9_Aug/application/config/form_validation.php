<?php

$config = array(
    'user_add' => array(
        array(
            'field' => 'fname',
            'label' => 'First Name',
            'rules' => 'required'
        //'rules' => 'required|is_unique[categories.name]'
        ),
        array(
            'field' => 'lname',
            'label' => 'Last Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'speciality_id',
            'label' => 'Speciality',
            'rules' => 'required'
        ),
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
            //'rules' => 'required|valid_email|is_unique[users.email]'
        ),
        array(
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required|matches[cpassword]'
        ),
        array(
            'field' => 'cpassword',
            'label' => 'Confirm Password',
            'rules' => 'required'
        ),
    ),
    
    'page_update' => array(
        array(
            'field' => 'page_name',
            'label' => 'Page Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'keyword',
            'label' => 'Keyword',
            'rules' => 'required'
        ),
        array(
            'field' => 'description',
            'label' => 'Description',
            'rules' => 'required'
        ),

    ),
    'user_update' => array(
        array(
            'field' => 'fname',
            'label' => 'First Name',
            'rules' => 'required'
        //'rules' => 'required|is_unique[categories.name]'
        ),
        array(
            'field' => 'lname',
            'label' => 'Last Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'speciality_id',
            'label' => 'Speciality',
            'rules' => 'required'
        ),
    ),
    'adminprofile' => array(
        array(
            'field' => 'firstname',
            'label' => 'First Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'lastname',
            'label' => 'Last Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
        ),
    ),
    'adminpassword' => array(
        array(
            'field' => 'oldpassword',
            'label' => 'Old password',
            'rules' => 'required'
        ),
        array(
            'field' => 'newpassword',
            'label' => 'New password',
            'rules' => 'required|matches[cpassword]'
        ),
        array(
            'field' => 'cpassword',
            'label' => 'Confirm password',
            'rules' => 'required'
        ),
    ),
    'forgotpassword' => array(
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
        ),
    ),
    'hosp_add' => array(
        array(
            'field' => 'hospital_admin_email',
            'label' => 'Email',
            //'rules' => 'required|valid_email'
            'rules' => 'required|valid_email|is_unique[hospital_network.hospital_admin_email]'
        ),
        array(
            'field' => 'hospital_network',
            'label' => 'Hospital Name',
            'rules' => 'required'
        )
//        array(
//            'field' => 'hospital_admin_username',
//            'label' => 'Hospital Username',
//            'rules' => 'required|min_length[3]|max_length[30]|is_unique[hospital_network.hospital_admin_username]'
//        ),
//        array(
//            'field' => 'hospital_admin_password',
//            'label' => 'Password',
//            'rules' => 'required'
//        ),
//        array(
//            'field' => 'cpassword',
//            'label' => 'Confirm Password',
//            'rules' => 'required'
//        ),
    ),
    'hosp_update' => array(
        array(
            'field' => 'hospital_network',
            'label' => 'Hospital Name',
            'rules' => 'required'
        )
//        array(
//            'field' => 'hospital_admin_username',
//            'label' => 'Hospital Admin Username',
//            'rules' => 'required'
//        ),
    ),
    'tumor_add' => array(
        array(
            'field' => 'tumor_board_name',
            'label' => 'Tumor Board Name',
            'rules' => 'required'
        ),
//                                                        array(
//									'field' => 'cancer',
//									'label' => 'Cancer Category',
//									'rules' => 'required'
//							),
        array(
            'field' => 'hospital',
            'label' => 'Related Hospital',
            'rules' => 'required'
        ),
    ),
    'tumor_update' => array(
        array(
            'field' => 'tumor_board_name',
            'label' => 'Tumor Board Name',
            'rules' => 'required'
        ),
//                                                        array(
//									'field' => 'cancer',
//									'label' => 'Cancer Category',
//									'rules' => 'required'
//							),
        array(
            'field' => 'hospital',
            'label' => 'Related Hospital',
            'rules' => 'required'
        ),
    ),
    'hospital_user_add' => array(
        array(
            'field' => 'fname',
            'label' => 'First Name',
            'rules' => 'required'
        //'rules' => 'required|is_unique[categories.name]'
        ),
        array(
            'field' => 'lname',
            'label' => 'Last Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'speciality_id',
            'label' => 'Speciality',
            'rules' => 'required'
        ),
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
        //'rules' => 'required|valid_email|is_unique[users.email]'
        //'rules' => 'required|is_unique[categories.name]'
        ),
    ),
    'hospital_user_update' => array(
        array(
            'field' => 'fname',
            'label' => 'First Name',
            'rules' => 'required'
        //'rules' => 'required|is_unique[categories.name]'
        ),
        array(
            'field' => 'lname',
            'label' => 'Last Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'speciality_id',
            'label' => 'Speciality',
            'rules' => 'required'
        ),
    ),
    'hosptumor_add' => array(
        array(
            'field' => 'tumor_board_name',
            'label' => 'Tumor Board Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'cancer',
            'label' => 'Cancer Category',
            'rules' => 'required'
        ),
    ),
    'hosptumor_update' => array(
        array(
            'field' => 'tumor_board_name',
            'label' => 'Tumor Board Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'cancer',
            'label' => 'Cancer Category',
            'rules' => 'required'
        ),
    ),
    'login_form' => array(
        array(
            'field' => 'username',
            'label' => 'Username',
            'rules' => 'required|valid_email'
        ),
        array(
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required'
        ),
    ),
    'forgot_form' => array(
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
        ),
    ),
    'reset_form' => array(
        array(
            'field' => 'pass',
            'label' => 'Old Password',
            'rules' => 'required|min_length[8]'
        ),
        array(
            'field' => 'cnfpassword',
            'label' => 'New Password',
            'rules' => 'required|min_length[8]|matches[pass]'
        ),
    ),
    'chnagepass_form' => array(
        array(
            'field' => 'oldpassword',
            'label' => 'Old Password',
            'rules' => 'required'
        ),
        array(
            'field' => 'newpassword',
            'label' => 'New Password',
            'rules' => 'required|min_length[8]'
        ),
        array(
            'field' => 'confirmpassword',
            'label' => 'Confirm Password',
            'rules' => 'required|matches[newpassword]'
        ),
    ),
    'force_change_form' => array(
        array(
            'field' => 'password',
            'label' => 'New Password',
            'rules' => 'required|min_length[8]'
        ),
        array(
            'field' => 'confirmpassword',
            'label' => 'Confirm Password',
            'rules' => 'required|matches[password]'
        ),
    ),
   
    'create_schedule' => array(
        array(
            'field' => 'tumor_id',
            'label' => 'Tumor Board',
            'rules' => 'required'
        ),
        array(
            'field' => 'recurrence_type',
            'label' => 'Recurrence',
            'rules' => 'required'
        ),
        array(
            'field' => 'week_days',
            'label' => 'Day of Week',
            'rules' => 'required'
        ),
        array(
            'field' => 'time_of_day',
            'label' => 'Time of Day',
            'rules' => 'required'
        ),
        array(
            'field' => 'first_date',
            'label' => 'Date of first tumor board',
            'rules' => 'required'
        ),
        array(
            'field' => 'last_date',
            'label' => 'Date of first tumor board',
            'rules' => 'required'
        )
    ),
     'request_data' => array(
        array(
            'field' => 'rImageFile0',
            'label' => 'Tumor Board',
            'rules' => 'required'
        )
       
    ),
    'contact_form' => array(
        array(
            'field' => 'name',
            'label' => 'Name',
            'rules' => 'required'
        ),
        array(
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email'
        ),
        array(
            'field' => 'comments',
            'label' => 'Comments',
            'rules' => 'required|max_length[250]'
        ),
         array(
            'field' => 'captcha',
            'label' => 'Comments',
            'rules' => 'required'
        ),
    ),
);
?>
