<?php
class Musers extends CI_Model {

    public function verifyAdmin($u, $pw, $lt) {
            $this->db->select('id,email,inactivity,inactivity_on,password');
            $this->db->where('email', db_clean($u));
            $this->db->where('is_active', '1');
            $this->db->limit(1);
            $Q = $this->db->get('users');
            if ($Q->num_rows() > 0) {
                
                $row = $Q->row();
                $inactivity = $row->inactivity_on;
                $current = date('Y-m-d H:i:s');
                
//                if ((!isset($_SESSION['count1']) || $_SESSION['count1']=="")  && $row->inactivity_on==0 )
//                    { $_SESSION['count1'] = 1; }
                
                $inactivity = strtotime($inactivity);
                $current = strtotime($current);
                $hour = round(($current - $inactivity) / (60 * 60), 2);
                
                if ($row->inactivity >= 3 && $row->inactivity_on != "0000-00-00 00:00:00" && $hour < 2) {
                    $this->session->set_flashdata('error', 'Your account is disabled, it will be activated after 2 hours. ');
                    //unset($_SESSION['count1']);
                } else {
                    if ($hour >= 2 && $row->inactivity_on != "0000-00-00 00:00:00") {
                        $data = array('inactivity' => '0', 'inactivity_on' => "0000-00-00 00:00:00");
                        $this->db->where('email', $u);
                        $this->db->where('is_active', '1');
                        $this->db->update('users', $data);
                    }
                            
                    if (($row->email == db_clean($u)) and ($this->bcrypt->check_password($pw, $row->password)) ) {
                        
                        $this->db->select('id,fname,lname,email,speciality_id,hospital_id,last_password_change_date');
                        $this->db->where('email', db_clean($u));
                        $this->db->where('is_active', '1');
                        $this->db->limit(1);
                        $Q = $this->db->get('users');
                        if ($Q->num_rows() > 0 && ($this->bcrypt->check_password($pw, $row->password))) {
                            
                            // check for forse password change (3 months old password check)
                            $result = $this->mcustom->force_pass_change($u,$pw);
                                
                            if($result == ""){
                                $row = $Q->row();
                                
                                if ($row->last_password_change_date == '0000-00-00 00:00:00') {
                                    $current_date_time = date("Y-m-d h:i:s");
                                    $data = array('last_password_change_date' => $current_date_time);
                                }
                                $data['inactivity'] = 0;
                                $data['inactivity_on'] = "0000-00-00 00:00:00";
                                $this->db->where('email', $u);
                                $this->db->where('is_active', '1');
                                $this->db->update('users', $data);

                                if(in_array($row->speciality_id,$this->config->item('speciality'))) {
                                    if($row->speciality_id == 2){
                                      $tab = 'hna';  
                                    }else{
                                      $tab = 'other'; 
                                    }

                                } else { $tab = 'default'; }

                                $session_data = array(
                                    'u_userid' => $row->id,
                                    'u_username' => $row->email,
                                    'u_name' => $row->fname,
                                    'u_fullname' => $row->fname.' '.$row->lname,
                                    'validated' => true,
                                    'tab' => $tab,
                                    'speciality_id' => $row->speciality_id,
                                    'hospital_id' => $this->get_user_hospitals($row->id),//$row->hospital_id
                                    'isLoggedIn' =>true,
                                    'timeOut' => 180,
                                    'loggedAt' => time()
                                );
                                
                                
                                $this->session->set_userdata($session_data);
                            }else{
                                $this->session->set_userdata(array('email'=> $u));
                                $this->session->set_flashdata('error','Your password is 3 months old, Please set your new password.');
                                redirect(site_url('/users/force_changepassword'));
                            }    
                        }
                    } else {
                        $this->db->select('id,email,inactivity,inactivity_on,password');
                        $this->db->where('email', db_clean($u));
                        $this->db->where('is_active', '1');
                        $this->db->limit(1);
                        $Q = $this->db->get('users');
                        $row = $Q->row();
                        $this->db->where('email', $u);
                        $this->db->where('is_active', '1');
                        $this->db->set('inactivity', 'inactivity+1', FALSE);
                        if ($row->inactivity >= 2) {
                            $this->db->set('inactivity_on', date('Y-m-d H:i:s'));
                        }
                        $this->db->update('users');
                        
                        $options = array('email' => db_clean($u),'is_active' => '1');
                        $Q = $this->db->get_where('users',$options,1);
                        $data = $Q->row();
                        
                        if($data->inactivity >= 3){       
                            $this->session->set_flashdata('error', 'Your account is disabled, it will be activated after 2 hours. ');
                             //unset($_SESSION['count1']);
                        }else{
                            $this->session->set_flashdata('error', 'You have made '.$data->inactivity.' unsuccessful attempts. The maximum retry attempts allowed for login are 3');
                        }
                    }
                }
            }
            else {
                $this->session->set_flashdata('error', 'Invalid email id and password');
            }
       
    }

    public function forgotpassword() {

        $data_user = array('email' => db_clean($this->input->post('email')));
        $Q = $this->db->get_where('users', $data_user);
        $column = "email";
        $table = "users";
      
        if ($Q->num_rows() > 0) {
            $token = md5(time());
            $logtype = $this->input->post('logtype');
            $data = array('password_token' => $token,'password_token_expire' => date('Y-m-d H:i:s'));
            $this->db->where($column, db_clean($this->input->post('email')));
            $this->db->update($table, $data);
            $logtype = $this->input->post('logtype');
            $link = '<a href="'.base_url()."users/resetpassword/" . $logtype . "/" . $token.'">'.base_url()."users/resetpassword/" . $logtype . "/" . $token.'</a>';
            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('forgotpassword');
            if($template){
                $mail_data = array(
                    'LOGO' => base_url()."images/oncolence-logo.png",
                    'LINK' => $link
                );
                $subject =  $template['subject'];
                $mailmessage =  $template['body'];
                foreach ($mail_data as $key=>$val){
                    $mailmessage = str_replace("{{".$key."}}", $val, $mailmessage);
                }
//            $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png' style='width:12%' ></p><br/>";
//            $mailmessage .= "<p>Thanks. Your reset password link below.</p>";
//            $mailmessage .= "<p><b>Password Reset link</b> " . $link . "</p>";
//            $mailmessage .= "<p>This link will expire after 2 hours</p>";
//            $mailmessage .= "<p><br /></p>";
//            $mailmessage .= "<p>Best Regards</p>";
//            $mailmessage .= "<p><b>Oncolens</b></p>";

//			$config['protocol'] = 'sendmail';
//			$config['mailpath'] = '/usr/sbin/sendmail';
//			$config['charset'] = 'iso-8859-1';
//			$config['wordwrap'] = TRUE;
            //echo $mailmessage;
            //exit;
            $this->email->set_mailtype("html");
            $this->email->from('support@oncolens.com', 'Oncolens');
            $this->email->to($this->input->post('email'));
            $this->email->subject($subject);
            $this->email->message($mailmessage);
            $result = $this->email->send();
            }
            $this->session->set_flashdata('success', 'A link to reset your password has been sent. Please check your email.');
        } else {
            $this->session->set_flashdata('error', 'Email doesn\'t match, Please try again later!');
        }
    }

    public function check_reset_url($data){
        if(!$this->session->flashdata('success')){
             // check passowrd token exist or not
            $token = $data['token'];
            $data_user = array('password_token' => db_clean($token));
            $Q = $this->db->get_where('users', $data_user);
            if ($Q->num_rows()== 0) {
                $this->session->set_flashdata('action','true');
                $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
                return true; 
            }else{
                // 2 hours link expire check
                $row = $Q->row();
                $date1 = $row->password_token_expire;
                $date2 = date('Y-m-d H:i:s'); 

                $timestamp1 = strtotime($date1);
                $timestamp2 = strtotime($date2);
                $hour = round(($timestamp2 - $timestamp1) / (60 * 60), 1);
                if($hour > 2){
                    $this->session->set_flashdata('action','true');
                    $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
                    return true; 
                }
            }
        }   
        
    }
    
    public function resetpassword() {
        $this->load->library('bcrypt');
        
        $logtype = $this->input->post('logtype');
        $data_user = array('password_token' => db_clean($this->input->post('token')));
            $column = "email";
            $table = "users";
            $pass = "password";
            
        $Q = $this->db->get_where('users', $data_user);
        
        if ($Q->num_rows() > 0) {
            $row = $Q->row();
            $pass_hash = $this->bcrypt->hash_password($this->input->post('pass'));
            $data = array($pass => $pass_hash, 'password_token' => '');
            $this->db->where('password_token', db_clean($this->input->post('token')));
            $this->db->update($table, $data);
            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('password_changed_successfully');
            if($template){
                $mail_data = array(
                    'LOGO' => base_url()."images/oncolence-logo.png"
                );
                $subject =  $template['subject'];
                $mailmessage =  $template['body'];
                foreach ($mail_data as $key=>$val){
                    $mailmessage = str_replace("{{".$key."}}", $val, $mailmessage);
                }
//            $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png' style='width:12%'></p><br/>";
//            $mailmessage .= "<p>Thank you admin. Your password have been changed.</p>";
//            $mailmessage .= "<p><br /></p>";
//            $mailmessage .= "<p>Best Regards</p>";
//            $mailmessage .= "<p><b>Oncolens</b></p>";

//			$config['protocol'] = 'sendmail';
//			$config['mailpath'] = '/usr/sbin/sendmail';
//			$config['charset'] = 'iso-8859-1';
//			$config['wordwrap'] = TRUE;
                $this->email->set_mailtype("html");
                $this->email->from('support@oncolens.com', 'Oncolens');
                $this->email->to($row->email);
                $this->email->subject($subject);
                $this->email->message($mailmessage);
                $this->email->send();
            }
            $this->session->set_flashdata('success', 'Password changed successfully. <a href="'.base_url().'users/">Please Login</a>');  
        } else {
            $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
        }
    }
    
    
    
    public function changepassword() {
        $data_user = array('email' =>$this->session->userdata('u_username'));
        $Q = $this->db->get_where('users',$data_user);
        $row = $Q->row();
        if($Q->num_rows()>0 && ($this->bcrypt->check_password($this->input->post('oldpassword'), $row->password))){
            if($this->input->post('oldpassword') != $this->input->post('newpassword')){
                $pass_hash = $this->bcrypt->hash_password($this->input->post('newpassword'));
                $data = array('password' => $pass_hash,'last_password_change_date'=> date("Y-m-d h:i:s"));
                $this->db->where('email',$this->session->userdata('u_username'));
                $this->db->update('users',$data);
                $this->session->set_flashdata('success', 'Password updated successfully!');
            }else{
                 $this->session->set_flashdata('error', 'Old password and new password must be different!');
            }
        } else {
            $this->session->set_flashdata('error', 'Old password doesn\'t match!');
        }
        
    }
    
    public function forcechangepassword() {
        if($this->session->userdata('email')!=""){
            $pass_hash = $this->bcrypt->hash_password($this->input->post('password'));
            
            $data_user = array('email' => $this->session->userdata('email'));
            $Q = $this->db->get_where('users',$data_user);
            $row = $Q->row();
            if($Q->num_rows()>0 ){
                if(($this->bcrypt->check_password($this->input->post('password'), $row->password))){
                    $this->session->set_flashdata('error', 'New password should not be same as old password!');
                    return false;
                } else {
                    $data = array('password' => $pass_hash,'last_password_change_date'=> date("Y-m-d h:i:s"));
                    $this->db->where('email',$this->session->userdata('email'));
                    $this->db->update('users',$data);
                    $this->session->set_flashdata('success', 'Password updated successfully!, Please login');
                    return true;
                }
            } else {
                $this->session->set_flashdata('error', 'Please try again later!');
                return false;
            }
        } else {
            $this->session->set_flashdata('error', 'Please try again later!');
            return false;
        }
        
    }
    
    public function profile($filter){
        $doctor_id = isset($filter['doctor_id']) ? $filter['doctor_id'] : $this->session->userdata('u_userid');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
         
        $this->db->select("c.id , c.hospital_network , b.id  as htumorid,d.tumor_id ,d.tumor_board_name");
        $this->db->from("hospital_doctor a");
        $this->db->join("hospital_doctor_tumor_board b", "a.hospital_doctor_id = b.hospital_doctor_id", "inner");
        $this->db->join("hospital_network c", "c.id = a.hospital_id", "inner");
        $this->db->join("tumor_board d", "d.tumor_id = b.tumor_id", "inner");
        $this->db->where("a.doctor_id = '$doctor_id'");
        $this->db->where("b.is_active = '1'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("c.hospital_network,d.tumor_board_name", "asc");
        $query = $this->db->get();
        return $count ? $query->num_rows() : $query->result();
        
     }
     
    public function hospitalTumorboard_edit($hospital_doctor_tumor_board_id,$hospital_id,$doctor_id,$tumor_id){
          
        $this->db->select("c.hospital_network");
        $this->db->from("hospital_doctor_tumor_board a");
        $this->db->join("hospital_doctor b", "a.hospital_doctor_id = b.hospital_doctor_id", "left");
        $this->db->join("hospital_network c", "c.id = b.hospital_id", "left");
        $this->db->where("a.id = $hospital_doctor_tumor_board_id");
        $query = $this->db->get();
        $data = $query->row();
        
        $data1 = array();
        $data1['hospital_network'] = $data->hospital_network;
        $data1['tumor_id'] = $tumor_id;
        $data1['hospital_doctor_tumor_board_id'] = $hospital_doctor_tumor_board_id;
        $data1['hospital_id'] = $hospital_id;
        $data1['doctor_id'] = $doctor_id;
        
        return $data1;
      }
      
    public function gettumor($hospital_id){
        $this->db->select("b.tumor_id,b.tumor_board_name");
        $this->db->from("hospital_tumor_board a");
        $this->db->join("tumor_board b", "a.tumor_id = b.tumor_id", "left");
        $this->db->where("a.hospital_id = $hospital_id");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
     }
     
    public function changeTumorboard($id) {
        $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
        $hospital_id = db_clean($this->input->post('hospital_id'));
        $tumor_id = $this->input->post('arr');
        $doctor_id = $this->input->post('doctor_id');

        $data = "";
        
        $this->db->select("hospital_doctor_id");
        $this->db->from("hospital_doctor");
        $this->db->where("hospital_id = $hospital_id")->where("doctor_id = $doctor_id");
        $query = $this->db->get();
        if ($query->num_rows()>0){
            $data = $query->row();
        }
        
        
        $this->db->select("hospital_doctor_id");
        $this->db->from("hospital_doctor_tumor_board");
        $this->db->where("tumor_id = $tumor_id")->where("hospital_doctor_id = $data->hospital_doctor_id");
        $query = $this->db->get();
        if ($query->num_rows()==0){
            $data = $query->row();
            
            $data_hospital_doctor_tumor_board = array('tumor_id' => $tumor_id);
            $this->db->where('id',$hospital_doctor_tumor_board_id);
            $this->db->update('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
             $this->session->set_flashdata('success', 'Tumor board has been updated successfully.');
            $data=true;
        }else{
             $this->session->set_flashdata('error', 'Tumor Board already added.');
             $data=false;
        }
        return $data;

    }

    public function tumorboard_list($id,$tumorid){	
//        $this->db->select("a.tumor_board_name,a.tumor_id");
//        $this->db->from("tumor_board as a");
//        $this->db->join("(SELECT  * FROM hospital_tumor_board AS b WHERE hospital_id = '".$id."') AS c ", "a.tumor_id = c.tumor_id", "inner join");
        
        $query = $this->db->query(
                "SELECT 
                    a.tumor_board_name,
                    a.tumor_id 
                  FROM
                    tumor_board AS a 
                    INNER JOIN 
                      (SELECT 
                        * 
                      FROM
                        hospital_tumor_board AS b 
                      WHERE hospital_id = '".$id."') AS c 
                      ON c.tumor_id = a.tumor_id 
                 WHERE a.tumor_id NOT IN (
                        SELECT 
                      hdtb.tumor_id 
                      FROM hospital_doctor AS hd 
                      INNER JOIN hospital_doctor_tumor_board AS hdtb 
                        ON hd.hospital_doctor_id = hdtb.hospital_doctor_id 
                        WHERE hd.hospital_id = '".$id."' 
                        AND hd.doctor_id = '".$this->session->userdata('u_userid')."' 
                        AND hdtb.is_active='1'
                      ) ");   
        
        if ($query->num_rows()>0){
            $data ="";
            foreach ($query->result() as $row){
                $selected= ($tumorid == $row->tumor_id)?'selected':'';
                $data  = $data.'<option value="'.$row->tumor_id.'" id="'.$row->tumor_id.'"  '.$selected.' >'.$row->tumor_board_name.'</option>';				
            }

            $query->free_result();
        } else {
            $data=false;
        }
        return $data;
        exit;
    }
    
    public function tumor_board_add(){

        $tumor_id = $this->input->post('arr');
        $is_tumor_board = isset($tumor_id)?'1':'0';

        $data = array();
        $options = array(
            'hospital_id' => $this->input->post('hospital_id'),           
            'doctor_id' => $this->session->userdata('u_userid'),    
            );
        $Q = $this->db->get_where('hospital_doctor',$options,1);
        if ($Q->num_rows() > 0){
            $data = $Q->row();
            $hospital_doctor_id = $data->hospital_doctor_id;
        }else{
            // hospital_doctor table insert query
            $data_host_doctor = array(
                'hospital_id' => $this->input->post('hospital_id'),                  
                'doctor_id' => $this->session->userdata('u_userid'),                 
                'is_tumor_board' => $is_tumor_board,              
                );

            $this->db->insert('hospital_doctor',$data_host_doctor);
            $hospital_doctor_id = $this->db->insert_id();
            // End hospital_doctor table insert query
        }

        //hospital_doctor_tumor_board
        foreach($tumor_id as $tumor){                   
             $data_hospital_doctor_tumor_board = array(
                 'tumor_id' => $tumor,                          
                 'hospital_doctor_id' => $hospital_doctor_id,                                   
                 );

            $Q = $this->db->get_where('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board,1);
            if ($Q->num_rows() == 0){ 
                $this->db->insert('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
            }else{
                $data = $Q->row();
                $update = array('is_active' => '1');
                $this->db->where('id', $data->id);
                $this->db->update('hospital_doctor_tumor_board',$update);
            }
        }

        $this->session->set_flashdata('success', 'Tumor board has been added successfully');
      
      
    }
    
    public function tumor_board_delete($id){
          $data = array();
          $options = array('id' => $id);
          $Q = $this->db->get_where('hospital_doctor_tumor_board',$options,1);
          if ($Q->num_rows()>0){
                $data = $Q->row();
                $data_hospital_doctor_tumor_board = array('is_active' => '0');
                $this->db->where('id', $id);
                $this->db->update('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
                $Q->free_result();
          }
          return true;
         
    }
    
    private function get_user_hospitals($id){
        $this->db->select('group_concat(hospital_id) hospitals', false);
        $this->db->from('hospital_doctor');
        $this->db->where("doctor_id = '$id'");
        $this->db->where("is_active = '1'");
        $q = $this->db->get()->row_array();
        return $q['hospitals'];
    }
    
    public function getReport() {
        $salt =$this->config->item('salt');
        $dFrom = $this->input->post('dFrom');
        $dTo = $this->input->post('dTo');
        $selectedData = $this->input->post('my_multi_select1');

        $query = "select ";
        $select = "";
        $condition = "";
        if (count($selectedData) > 0) {
            if (in_array('case_id', $selectedData)) {
                $select .="vir.id AS 'CaseId' ,";
            }
            if (in_array('name', $selectedData)) {
                $select .="AES_DECRYPT(ch.name,'$salt') as 'Patient Name' ,";
            }
            if (in_array('dob', $selectedData)) {
                $select .="AES_DECRYPT(ch.dob, '$salt') as 'Patient DOB' ,";
            }
            if (in_array('case_description', $selectedData)) {
                $select .=" AES_DECRYPT(ch.case_description, '$salt') as  'Case Description' ,";
            }
            if (in_array('cancer_type', $selectedData)) {
                $select .="cancer_type as 'Cancer Type' ,";
            }
            if (in_array('submitted_by', $selectedData)) {
                $select .="CONCAT_WS(' ', fname, lname) as 'Submitted by' ,";
            }
            if (in_array('tumor_name', $selectedData)) {
                $select .="tb.tumor_board_name AS 'Tumor Borad Name' ,";
            }
            if (in_array('case_status', $selectedData)) {
                $select .="if(case_status = '1', 'Open', 'Close')  as 'Case Status  ',";
            }
            if (in_array('meeting', $selectedData)) {
                $select .="(SELECT COUNT(case_id) FROM `case_meeting_assignments` WHERE `case_id`=ch.id) AS 'Number of Meetings' ,";
            }
            if (isset($dFrom) && $dFrom != "" && isset($dTo) && $dTo != "") {
                $condition .="and (  DATE(ch.`case_submit_date`) BETWEEN DATE('$dFrom') AND DATE('$dTo') )";
            }
        }
        $select = rtrim($select, ',');
        $query =$query . $select ."FROM (SELECT id, case_entered_by AS docid FROM case_history UNION ALL SELECT case_id AS id, doctor_id AS docid FROM case_doc_email_status ) AS vir LEFT JOIN case_assignments ca ON vir.id = vir.id LEFT JOIN users u ON u.id = vir.docid LEFT JOIN case_history ch ON ch.id = vir.id LEFT JOIN cancercategories c ON c.cancer_id = ch.cancer_id LEFT JOIN hospital_doctor hd ON hd.doctor_id = vir.docid LEFT JOIN case_assignment_tumor_board cat ON cat.case_id=vir.id LEFT JOIN tumor_board tb ON tb.tumor_id=cat.tumor_board_id WHERE ch.is_deleted = '0' $condition GROUP BY vir.id ORDER BY vir.id DESC ";
        $mydata=array();
        $data = $this->mcustom->getselectedata($query);
        if (in_array('meeting', $selectedData) || in_array('nccn', $selectedData) || in_array('staging', $selectedData) || in_array('prospective', $selectedData) || in_array('clinical', $selectedData) || in_array('palliative', $selectedData)){
        foreach($data as $key=>$value){
            $select1 ="";
            $select1="SELECT cmd.meeting_date as 'Meeting Date' ,";
            if (in_array('nccn', $selectedData)) {
                $select1 .="if(nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed' ,";
            }
            if (in_array('staging', $selectedData)) {
                $select1 .="if(staging_discussed, 'Yes', 'No') as 'Staging Disccussed' ,";
            }
            if (in_array('prospective', $selectedData)) {
                $select1 .="if(prospective_discussion, 'Yes', 'No') as 'Prospective Disccussed' ,";
            }

            if (in_array('clinical', $selectedData)) {
                $select1 .="if(clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,";
            }
            if (in_array('palliative', $selectedData)) {
                $select1 .="if(palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,";
            }
             if (in_array('attendees', $selectedData)) {
                $select1 .="(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')'),'No Attendees') from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'Attendees (Speciality)' ,";
            }
            $select1 = rtrim($select1, ',');
            $query1 =  $select1 ." FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id WHERE cma.case_id=".$value->CaseId;
            $Q= $this->db->query($query1);
            $data[$key]->submeetings = $Q->result_array();
        }
        }
     //prd($data);

        if ($data) {
            $lines = $data;
            $langs = array();
            $hidden_fields = !empty($hidden_fields) ? $hidden_fields : array();
            if ($lines && is_array($lines) && count($lines) > 0) {
                foreach ($lines as $row) {
                    foreach ($row as $field => $value) {
                        if (!in_array($field, $langs) && !in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                            array_push($langs, $field);
                        }
                    }
                }
            }
 
            // Starting the PHPExcel library
            $this->load->library('excel');
            // activate worksheet number 1
            $this->excel->setActiveSheetIndex(0);

            $this->excel->getProperties()->setTitle("Report")->setDescription("none");

            // name the worksheet
            $this->excel->getActiveSheet()->setTitle('Report');

            // Field names
            $col = 0;
            foreach ($langs as $field) {
                // set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);

                // change the font size
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setSize(14);

                // make the font become bold
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setBold(true);

                // set aligment to center for that cell
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getAlignment()
                        ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)
                        ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                // ->setWrapText(true);

                $col++;
            }
            $sheet = $this->excel->getActiveSheet();
            $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }

            $row = 2;
            foreach ($lines as $key => $line) {
                $col = 0;
                foreach ($langs as $field) {
                    $value = isset($line->$field) ? $line->$field : '';
                    if (!in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                        if (is_array($value)) {
                            if (count($value) > 0) {
                                $c=0;
                                foreach($value as $k=>$v){
                                    $c=$col;
                                   
                                  foreach($v as $field=>$val){
                                       $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, 1, $field);
                                       $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setSize(14);

                                        // make the font become bold
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setBold(true);

                                        // set aligment to center for that cell
                                       
                                        $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, $row, $val);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getFont()->setSize(12);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()
                                         ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()->setWrapText(true);
                                        $c++;
                                  }
                                $row++;
                                }
                            } else {
                                // set cell A1 content with some text
                               $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, 'NONE');
                            }
                        } else {
                            // set cell A1 content with some text
                            $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, ucfirst(strip_tags($value)));
                             $this->excel->getActiveSheet()->getStyleByColumnAndRow($col,$row)->getAlignment()->setWrapText(true);
                        }
                    }

//                    // change the font size
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getFont()->setSize(12);
                    // set aligment to vertical center for that cell
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getAlignment()
                            ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

                    $col++;
                }

                $row++;
            }
            
            $this->excel->setActiveSheetIndex(0);
            // mime type
            $filename = time() . "Report";
            header('Content-Type: application/vnd.ms-excel;charset=utf-8');
            // tell browser what's the file name
            header('Content-Disposition: attachment;filename=' . $filename.".xls");
            // no cache
            header('Cache-Control: max-age=0');
            // save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
            // if you want to save it as .XLSX Excel 2007 format
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
            ob_end_clean();
            // force user to download the Excel file without writing it to server's HD
            $objWriter->save('php://output');
        }
        else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }
     public function getnotification() {
        $this->db->select("*");
        $this->db->from("mst_notification");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }
     
     public function update_notification() {
        $data = array(
             'day' => $this->input->post('day'),
             'added_on' => date('Y-m-d H:i:s')
             );
        if ($this->input->post('id')) {
            //update
            $id = $this->input->post('id');
            $this->db->where("id = '$id'");
            $this->db->update('mst_notification', $data);
        } 
    }
    public function unsubsribes($id,$notification=false){
        if($notification)
            $n = $notification;
        else
            $n='0';
        $data = array(
            'notification' => $n
        );
        if($id){
            $this->db->where("id = '$id'");
            $this->db->update('users', $data);
            return true;
        }
        else {
            return false;
        }
    }


}
