<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cronjobdemo extends CI_Controller {

	// to send email notification weekly
	public function index()
	{
           	//	echo "de"; die;
              $this->load->model('mcrondemo');
              $data=  $this->mcrondemo->getusers();
              die;
	}
}
