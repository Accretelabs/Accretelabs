<?php 
class Managehospitals extends CI_Controller{
    
    public function __construct(){   
		parent::__construct();
		if(!isset($_SESSION['userid'])){
		 redirect(site_url('admin','refresh'));
		}
	}
        
        // view all list of hospitial
        public function index($page_num=1,$sortfield='id',$order='asc') {
         $this->load->library('pagination');
		$data['title'] = "Hospital list";
		$data['main'] = 'managehospitals';
		$data['page_name'] = 'manage_hospitals';
		
		//pagination
		/* Get the page number from the URI (/index.php/pagination/index/{pageid}) */
		$page_number = $this->uri->segment(3);	// it returns the 3rd segement from the url.In my requirement http://localhost:8080/ci/admin/users/2 is the url,  user 2 is page number(3rd segment)
		$config['base_url'] = base_url().'admin/managehospitals/'; // page url, where we can display all users
		$config['uri_segment'] = 3;
                $config['per_page'] = $this->config->item('per_page'); // set this value how many users per page.
		//$config['num_links'] = 5; // this allow the pagination with 5 links,like 1,2,3,4,5
		if(empty($page_number)) $page_number = 1;
		$offset = ($page_number-1) * $this->config->item('per_page');
		$config['use_page_numbers'] = TRUE; // set this value true,so that page number value will be like users/1 , users/2 , users/3 etc, otherwise it will be like users/10 , users/20 , users/30 etc
		
		$data['admins'] = $this->madmins->getAllHospitals($this->config->item('per_page'),$offset,$sortfield,$order);
		$config['total_rows'] = $this->db->count_all('hospital_network'); // it returns total count of records of tbl_users table.
		$config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
                $config['full_tag_close'] = '</ul></nav>';
                $data['page_start'] = (($page_number * $config['per_page']) - $config['per_page']) + 1;
                $data['page_end'] = $data['page_start'] + count($data['admins']) - 1;
                $data['page_total'] = $config['total_rows'];
                
                if($page_number>1 && $data['page_end']>$data['page_total'])
                {
                    $tmp_page_naumber=$page_number-1;
                    redirect('/admin/managehospitals/'.$tmp_page_number);
                
                }
                $config['first_link'] = 'First';
                $config['first_tag_open'] = '<li>';
                $config['first_tag_close'] = '</li>';

                $config['last_link'] = 'Last';
                $config['last_tag_open'] = '<li>';
                $config['last_tag_close'] = '</li>';

                $config['next_link'] = '&gt;';
                $config['next_tag_open'] = '<li>';
                $config['next_tag_close'] = '</li>';

                $config['prev_link'] = '&lt;';
                $config['prev_tag_open'] = '<li>';
                $config['prev_tag_close'] = '</li>';

                $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
                $config['cur_tag_close'] = '</a></li>';

                $config['num_tag_open'] = '<li>';
                $config['num_tag_close'] = '</li>';
                
		$this->pagination->cur_page = $offset;
		$this->pagination->initialize($config);
		$data['page_links'] = $this->pagination->create_links(); // It will returns the pagination links
		//var_dump(var_dump($config));
		
		
		$this->load->vars($data);
		$this->load->view('admin/template',$data); 	
        }
        
       // add hospitial 
        public function add($id=null){
            	$this->load->library('form_validation');	
		if ($this->input->post('action')){
			if($this->input->post('action') == 'add'){
		           $result=$this->madmins->addHospital();	             
                            if($result=='success')
                            $this->session->set_flashdata('success', 'Hospital added successfully');
                            else
                     $this->session->set_flashdata('error', 'Hospital with same name already existed.');
                                
			}else{
				$result=$this->madmins->updateHospital($id);
                                 if($result=='success')                                     
				$this->session->set_flashdata('success','Hospital updated successfully');
                                 else
                      $this->session->set_flashdata('error', 'Cannot Updated as Hospital with same name already existed.');     
			}
			 redirect(site_url('admin/managehospitals'));
		} else {
			if($id!=""){
		         $data['hospitaldetail'] = $this->madmins->getHospitaldetail($id);
			 }
                        
			$data['title'] = "Create Hospital";
			$data['main'] = 'hospital_add';
                        $data['page_name'] = 'manage_hospitals';
			$this->load->vars($data);
			$this->load->view('admin/template');
		}
	}
        
        //delete hospitial 
        public function delete(){
		$return = $this->madmins->delete_hospital($this->input->post('id'),$this->input->post('table_name'));
		if($return)
                    $this->session->set_flashdata('success', 'Hospital deleted Successfully.');
                else
                    $this->session->set_flashdata('error', 'Unable to delete hospital! Because there are users or tumor board associate with it.');
	}
        
        
        public function active(){
		$this->madmins->status_hospital($this->input->post('id'),$this->input->post('table_name'),'1');
		$this->session->set_flashdata('success', 'Hospital Active Successfully.');
                echo 'success';
	}
        
        public function inactive(){
		$return = $this->madmins->status_hospital($this->input->post('id'),$this->input->post('table_name'),'0');
		if($return)
                    $this->session->set_flashdata('success', 'Hospital Inactive Successfully.');
                else
                    $this->session->set_flashdata('error', 'Unable to inactive hospital! Because there are users or tumor board associate with it.');
	}
}

?>