<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

        // to validate the credentials for login
	public function index()
	{
		
            if($this->input->post('username')){
                $u = $this->input->post('username');
                $pw = $this->input->post('password');
                $this->madmins->verifyAdmin($u,$pw);
                    if (isset($_SESSION['userid']) && $_SESSION['userid'] > 0 && $_SESSION['is_superadmin'] == 1 ){
//				redirect('admin/dashboard','refresh');
                         redirect(site_url('admin/user'));
                    }
            }

            $data['title'] = "Admin Login";
            $this->load->vars($data);
            $this->load->view('login',$data);
	}
	
	public function forgotpassword(){
		$this->load->library('form_validation');
		$this->load->helper('string'); 
		
		if($this->input->post('action') && $this->form_validation->run('forgotpassword') == TRUE ){
			$data=$this->madmins->forgotpassword();
			redirect(site_url('admin/admin/forgotpassword'));
		}else{
			$data['title'] = "Forgot Password";
			$this->load->vars($data);
			$this->load->view('admin/forgot_password',$data);
		}
		
	}
	
	
	public function logout(){
		session_destroy();
		unset($_SESSION['userid']);
		unset($_SESSION['username']);
		$this->session->set_flashdata('error',"You have been logged out!");
//		redirect('admin/','refresh');
                redirect(site_url('admin/'));
	}
	
	
}
