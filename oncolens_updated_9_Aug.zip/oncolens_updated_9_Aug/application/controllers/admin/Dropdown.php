<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dropdown extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if(!isset($_SESSION['userid'])){
            redirect(site_url('admin','refresh'));
	}
        $this->load->model('mdropdown', 'drop');
    }
    
    //to manage treatments (post case 2 page select box)
    public function index($id=false) {
        $data =array();
        
        $cancer = $this->drop->getCancertypeadmin();
    
        $data['cancercategory'] = $cancer;
        $data['result'] = array();
        $data['errors'] = '';
        $cancer_type = '';
        $cancer_mode = '';
        if($this->input->post()){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('cancer','Cancer Type','required');
            //$this->form_validation->set_rules('cancer_mode','Cancer Mode','required');
            $cancer_type = $this->input->post('cancer');
            $cancer_mode = $this->input->post('cancer_mode');
            
            if($cancer_type=="11")
               $cancer_mode=0;
                
            if($this->form_validation->run()){
                $data['result'] = $this->drop->get_regimensDropdown(false,$cancer_type,false, false, false, array(),$cancer_mode);
            }else{
                $data['errors'] = validation_errors();
            }
        }
        $data['title'] = "Manage Treatments";
        $data['cancer_type'] = $cancer_type;
        $data['cancer_mode'] = $cancer_mode;
        $data['main'] = 'regimens';
        $data['page_name'] = 'treatments';
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    
     //to update treatments (post case 2 page select box)
    public function edit($id = 0, $cancer_filter = 0, $cancer_mode = '', $pageno = 1) {
        $data =array();
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        
        $data['cancercategory'] = $this->drop->getCancertype();
        $result = $this->drop->get_regimensDropdown($id,false, false, $cancer_filter, false, $filter, $cancer_mode);
        $data['result'] = $result[0];
        $data['cancer_filter'] = $cancer_filter;
        $data['cancer_mode'] = $cancer_mode;
        $data['title'] = "Manage Treatments";
        $data['main'] = 'edit_regimens';
        $data['page_name'] = 'treatments';
        
        
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . "admin/dropdown/edit/$id/$cancer_filter/$cancer_mode/";
        $config['total_rows'] = $this->drop->get_regimensDropdown($id,false, false, $cancer_filter, true, array(), $cancer_mode);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($result[0]->drop_down_data) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 7;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    //to update treatments (post case 2 page select box)
    public function editForm($mstid = 0,$id = 0,$cancer_type=0,$cancer_mode='') {
        $data =array();
        $result = $this->drop->get_regimensDropdown($mstid,false, $id);
       // prd($result);
        $table_name = $result['0']->table_name;
        //$cancer_type =        
        $data['metaStatus'] = $this->drop->getModeStatus($table_name,$cancer_type,0);
        $data['recStatus'] = $this->drop->getModeStatus($table_name,$cancer_type,1);
        $data['denevoStatus'] = $this->drop->getModeStatus($table_name,$cancer_type,2);
        $data['cancer_mode'] = $cancer_mode;
        
        //prd($result);
        if($this->input->post()){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name','Name','required');
            $this->form_validation->set_rules('cancer','Cancer Type','required');
            $this->form_validation->set_rules('cancer_mode','Cancer Mode','required');
            if(!$this->form_validation->run()){
                $this->session->set_flashdata('error', validation_errors());
            }else{
                $return = $this->drop->update_regimens($result[0]);
                if($return){
                if($this->input->post('id')){
                    $this->session->set_flashdata('success', 'Record Updated Successfully');
                }else{
                   $this->session->set_flashdata('success', 'Record Added Successfully');
                }
            }
            else{
                $this->session->set_flashdata('error', 'Record Already Exist.');
                redirect(base_url('admin/dropdown/editForm/'.$mstid.'/'.$id.'/'.$cancer_type.'/'.$cancer_mode));
                exit;
            }
                redirect(base_url('admin/dropdown/edit/'.$mstid.'/'.$cancer_type.'/'.$cancer_mode));
                exit;
            }
        }
        $data['result'] = $result[0];
        $data['cancer_type'] = $cancer_type;
         $cancer= $this->drop->getCancertype();        
        array_pop($cancer);
        array_pop($cancer);
        $data['cancercategory']=$cancer;
        $data['title'] = "Manage Treatments";
        $data['main'] = 'regimens_form';
        $data['page_name'] = 'treatments';
        $data['table_id'] = $id;
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    // manage sub cancercategories of cancer type
    public function managePathlogy($cancer_filter = 0, $pageno = 1) {
        $data =array();
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['cancercategory'] = $this->drop->getCancertype();
        $result = $this->drop->get_pathlogyDropdown(false,$cancer_filter, false, $filter);
        $data['result'] = $result;
        $data['cancer_filter'] = $cancer_filter;
        $data['title'] = "Manage Pathology";
        $data['main'] = 'pathlogy';
        $data['page_name'] = 'manage_pathlogy';
        
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . "admin/dropdown/managePathlogy/$cancer_filter/";
        $config['total_rows'] =$this->drop->get_pathlogyDropdown(false,$cancer_filter, true);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($result) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 5;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
      // manage sub cancercategories of cancer type
    public function editPathlogy($id = 0,$cancer_type=0) {
        $data =array();
        if(isset($id) && $id!=""){
            $result = $this->drop->get_pathlogyDropdown($id);
            $data['result'] = $result[0];
        }
        if($this->input->post()){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name','Name','required');
            $this->form_validation->set_rules('cancer','Cancer Type','required');
            if(!$this->form_validation->run()){
                $this->session->set_flashdata('error', validation_errors());
            }else{
                $return = $this->drop->update_pathlogy();
		if($return){
                    if($this->input->post('id')){
                        $this->session->set_flashdata('success', 'Record Updated Successfully');
                    }else{
                       $this->session->set_flashdata('success', 'Record Added Successfully');
                    }
                }else{
                   $this->session->set_flashdata('error', 'Record Already Exist.');
                }
                redirect(base_url('admin/dropdown/managePathlogy/'));
            }
        }
        
        $data['cancercategory'] = $this->drop->getCancertype();
        $data['cancer_type'] = $cancer_type;
        $data['title'] = "Edit Pathology";
        $data['main'] = 'pathlogy_form';
        $data['page_name'] = 'manage_pathlogy';
        $data['id'] = $id;
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    
     //to manage specific answers
     public function manageCaseanswer($cancer_filter = 0, $speciality_filter = 0, $pageno = 1) {
        $data =array();
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['cancercategory'] = $this->drop->getCancertypeadmin();
        $data['speciality'] = $this->madmins->getspeciality_according_ans();
        $result = $this->drop->get_specificAnswer(false,$cancer_filter,$speciality_filter, false, $filter);
        $data['result'] = $result;
        $data['cancer_filter'] = $cancer_filter;
        $data['speciality_filter'] = $speciality_filter;
        $data['title'] = "Manage Case Answer";
        $data['main'] = 'case_answer';
        $data['page_name'] = 'case_answer';
        
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . "admin/dropdown/manageCaseanswer/$cancer_filter/$speciality_filter";
        $config['total_rows'] =$this->drop->get_specificAnswer(false,$cancer_filter,$speciality_filter, true);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($result) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 6;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    //to update specific answers
    public function editspecificAnswer($id = 0) {
        $data =array();
        if(isset($id) && $id!=""){
        $result = $this->drop->get_specificAnswer($id);
        $data['result'] = $result[0];
        }
        if($this->input->post()){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name','Name','required');
            $this->form_validation->set_rules('cancer','Cancer Type','required');
            $this->form_validation->set_rules('speciality','Speciality','required');
            $this->form_validation->set_rules('cancer_mode','Cancer Mode','required');
            if(!$this->form_validation->run()){
                $this->session->set_flashdata('error', validation_errors());
            }else{
                $return = $this->drop->update_specific_answer();
                if($return){
                    if($this->input->post('id')){
                        $this->session->set_flashdata('success', 'Record Updated Successfully');
                    }else{
                       $this->session->set_flashdata('success', 'Record Added Successfully');
                    }
                }else{
                   $this->session->set_flashdata('error', 'Record Already Exist.');
                }
                redirect(base_url('admin/dropdown/manageCaseanswer/'));
            }
        }
        
        $data['cancercategory'] = $this->drop->getCancertypeadmin();
        $data['speciality'] = $this->madmins->getspecialityadmin();
        $data['title'] = "Manage Specific Answer";
        $data['main'] = 'specific_answer_form';
        $data['page_name'] = 'case_answer';
        $data['id'] = $id;
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
}    
?>