<?php
class Hospitaluser extends CI_Controller {

	public function __construct(){ 
		parent::__construct();
		if(!isset($_SESSION['userid'])){
		 redirect(site_url('admin'));
		}
	}

	public function index($page_num=1,$sortfield='id',$order='asc'){
		$this->load->library('pagination');
		$data['title'] = "Users Home";
		$data['main'] = 'hospitaluser';
		//pagination
		/* Get the page number from the URI (/index.php/pagination/index/{pageid}) */
		$page_number = $this->uri->segment(3);	// it returns the 3rd segement from the url.In my requirement http://localhost:8080/ci/admin/users/2 is the url,  user 2 is page number(3rd segment)
		$config['base_url'] = base_url().'admin/hospitaluser/'; // page url, where we can display all users
		$config['uri_segment'] = 3;
		$config['per_page'] = $this->config->item('per_page'); 
		if(empty($page_number)) $page_number = 1;
		$offset = ($page_number-1) * $config['per_page'];
		$config['use_page_numbers'] = TRUE; // set this value true,so that page number value will be like users/1 , users/2 , users/3 etc, otherwise it will be like users/10 , users/20 , users/30 etc
		
		$data['admins'] = $this->madmins->getMyUsers($config['per_page'],$offset,$sortfield,$order);
		$data['istumorboard'] = $this->madmins->tumorboardexits();
                
		//$config['total_rows'] = $this->db->count_all('users'); // it returns total count of records of tbl_users table.
                $config['total_rows'] = $this->madmins->getHospitalUser();
		$config['full_tag_open'] = '<div class="pagination">';
		$config['full_tag_close'] = '</div>';
		$this->pagination->cur_page = $offset;
		$this->pagination->initialize($config);
		$data['page_links'] = $this->pagination->create_links(); // It will returns the pagination links
		//var_dump(var_dump($config));
		
		
		$this->load->vars($data);
		$this->load->view('admin/template',$data);
	}
        
        public function add($id=null){
		$this->load->library('form_validation');	
		if ($this->input->post('action') && $this->form_validation->run('hospital_user_'.$this->input->post('action')) == TRUE){		
			if($this->input->post('action') == 'add'){
				$this->madmins->addUser();
				$this->session->set_flashdata('message','User added successfully');
			}else{
				$this->madmins->updateUser($id);
				$this->session->set_flashdata('message','User updated successfully');
			}
			 redirect(site_url('admin/hospitaluser'));
		} else {
			if($id!=""){
				$data['userdetail'] = $this->madmins->getUser($id);
                                $data['selectedtumorboard'] = $this->madmins->selectedtumorboard($id);
                                $data['selectedhospitals'] = $this->madmins->getselectedhospitals($id); 
			}
			$data['istumorboard'] = $this->madmins->tumorboardexits();
                        $data['speciality'] = $this->madmins->getspeciality();
			$data['hospitals'] = $this->madmins->gethospitalid($_SESSION['username']);
			
			$data['title'] = "Create User";
			$data['main'] = 'hospitaluser_add';
			$this->load->vars($data);
			$this->load->view('admin/template');
		}
	}
	
	
	public function delete(){
		$this->madmins->delete_user($this->input->post('id'),$this->input->post('table_name'));
		echo 'success';
	}
	
	public function active(){
		$this->madmins->status_user($this->input->post('id'),$this->input->post('table_name'),'1');
		echo 'success';
	}
	
	public function inactive(){
		$this->madmins->status_user($this->input->post('id'),$this->input->post('table_name'),'0');
		echo 'success';
	}
        
        public function tumorboardlist(){
		$list = $this->madmins->tumorboard_list($this->input->post('id'),$this->input->post('tumorid'));
		print_r($list);
	}
        public function hostipal_add(){ 
            $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
            $hospital_id = $this->input->post('hospital_id');
            $doctor_id = $this->input->post('doctor_id');
            $data = array();
            $data['value'] = $this->madmins->hospitalTumorboard_edit($hospital_doctor_tumor_board_id, $hospital_id, $doctor_id);
            $data['tumor'] = $this->madmins->gettumor($data['value']['tumor_id'],$hospital_id);
           
            
            $this->load->vars($data);
            $this->load->view('admin/hospital_edit_model');           
        }
	
        public function doctor_check(){
		$data= $this->madmins->doctor_check($this->input->post('email'));
		echo $data;
	}
        
        
        public function user_tumor_data(){
		$data = $this->madmins->user_tumor_data_add($this->input->post('id'),$this->input->post('tumor_id'),$this->input->post('hospital_id'));
		return $data ;
	}
	

}
?>