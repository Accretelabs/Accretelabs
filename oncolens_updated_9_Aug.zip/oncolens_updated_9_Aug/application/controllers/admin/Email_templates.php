<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email_templates extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if(!isset($_SESSION['userid'])){
            redirect(site_url('admin','refresh'));
	}
        $this->load->model('memail_templates', 'memail');
    }
    
    // to view the email template
    public function index() {
        $data =array();
        $data['result'] = $this->memail->get_templates();
        $data['title'] = "Email Templates";
        $data['main'] = 'email_templates';
        $data['page_name'] = 'email_template';
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
    
    // to edit the email template
    public function edit($id = false) {
        if(!isset($id)){
            redirect(site_url('/email_templates/'));
        }
        
        $this->load->library('form_validation');	
	if ($this->input->post('action')){
            $this->memail->email_template_update();
            $this->session->set_flashdata('message','Email Template has been updated successfully.');
        }
                
        $data =array();
        $data['result'] = $this->memail->get_templates($id);
        $data['title'] = "Edit Email Templates";
        $data['main'] = 'edit_email_template';
        $data['page_name'] = 'email_template';
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
    }
}    
?>