<?php
class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
         
        if (!isset($_SESSION['userid'])) {
            redirect(site_url('admin'));
        }
    }

    public function index($page_num = 1, $sortfield = 'id', $order = 'asc') { 
        $this->load->library('pagination');
        $data['title'] = "Users Home";
        $data['main'] = 'users';
        $data['page_name'] = 'user_home';

        //pagination
        /* Get the page number from the URI (/index.php/pagination/index/{pageid}) */
        $page_number = $this->uri->segment(3); // it returns the 3rd segement from the url.In my requirement http://localhost:8080/ci/admin/users/2 is the url,  user 2 is page number(3rd segment)
        $config['base_url'] = base_url() . 'admin/user/'; // page url, where we can display all users
        $config['uri_segment'] = 3;
        $config['per_page'] = $this->config->item('per_page'); // set this value how many users per page.
        //$config['num_links'] = 5; // this allow the pagination with 5 links,like 1,2,3,4,5
        if (empty($page_number))
            $page_number = 1;
        $offset = ($page_number - 1) * $config['per_page'];
        $config['use_page_numbers'] = TRUE; // set this value true,so that page number value will be like users/1 , users/2 , users/3 etc, otherwise it will be like users/10 , users/20 , users/30 etc

        $config['total_rows'] = $this->madmins->getAllUsersCount(); // it returns total count of records of tbl_users table.

        $data['admins'] = $this->madmins->getAllUsers($config['per_page'], $offset, $sortfield, $order);
        //print_r($data['admins']); die;
        
        $data['hospitals'] = $this->madmins->gethospitals();
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';
        $data['page_start'] = (($page_num * $config['per_page']) - $config['per_page']) + 1;
        $data['page_end'] = $data['page_start'] + count($data['admins']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->cur_page = $offset;
        $this->pagination->initialize($config);
        $data['page_links'] = $this->pagination->create_links(); // It will returns the pagination links
        //var_dump(var_dump($config));
        


        $this->load->vars($data);
        $this->load->view('admin/template', $data);
      
    }
    
  
     public function login_details($id=0,$page_num = 1, $sortfield = 'id', $order = 'asc') {
       
        $this->load->library('pagination');
        $data['title'] = "Users Logging Details";
        $data['main'] = 'logging_details';
        $data['page_name'] = 'logging_details';
         $id = $this->uri->segment(4);
      
       
        //pagination
        /* Get the page number from the URI (/index.php/pagination/index/{pageid}) */
        $page_number = $this->uri->segment(5); // it returns the 3rd segement from the url.In my requirement http://localhost:8080/ci/admin/users/2 is the url,  user 2 is page number(3rd segment)
        $config['base_url'] = base_url() . 'admin/user/login_details/'.$id.'/'; // page url, where we can display all users
        $config['uri_segment'] = 5;
        $config['per_page'] = $this->config->item('per_page'); // set this value how many users per page.
        //$config['num_links'] = 5; // this allow the pagination with 5 links,like 1,2,3,4,5
       if (empty($page_number))
           $page_number = 1;
        $offset = ($page_number - 1) * $config['per_page'];
        $config['use_page_numbers'] = TRUE; // set this value true,so that page number value will be like users/1 , users/2 , users/3 etc, otherwise it will be like users/10 , users/20 , users/30 etc

        $config['total_rows'] = $this->madmins->getAllLoginCount($id); // it returns total count of records of tbl_users table.

        $data['admins'] = $this->madmins->getAllUsersLogin($id,$config['per_page'], $offset, $sortfield, $order);
        //print_r($data['admins']); die;
        
        
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';
        $data['page_start'] = (($page_num * $config['per_page']) - $config['per_page']) + 1;
        $data['page_end'] = $data['page_start'] + count($data['admins']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->cur_page = $offset;
        $this->pagination->initialize($config);
        $data['page_links'] = $this->pagination->create_links(); // It will returns the pagination links
        //var_dump(var_dump($config));
        


        $this->load->vars($data);
        $this->load->view('admin/template', $data);
    }


    public function add($id = null) {
        
        
        $this->load->library('form_validation');
        $this->load->library('bcrypt');

        if ($this->input->post('action') && $this->form_validation->run('user_' . $this->input->post('action')) == TRUE) {
            if ($this->input->post('action') == 'add') {

                $return = $this->madmins->addUser();
                if ($return) {
                    redirect(site_url('admin/user'));
                } else {
                    redirect(site_url('admin/user/add'));
                }
            } elseif ($this->input->post('action') == '_changetumor') {
                $this->madmins->changeTumorboard($id);
                redirect(site_url('admin/user'));
            } else {
                $this->madmins->updateUser($id);
                if ($this->input->post('password') != "" && $this->input->post('cpassword') != "") {
                    
                }
                $this->session->set_flashdata('message', 'User updated successfully');
                redirect(site_url('admin/user'));
            }
        }

        if ($id != "") {

            $data['userdetail'] = $this->madmins->getUser($id);
            $data['tumor'] = $this->madmins->gettumor($data['userdetail']->tumor_id);
            $data['selectedhospitals'] = $this->madmins->getselectedhospitalsuser($id);
            $data['user_hospital'] = $this->madmins->getalluserlink_to_hospital($id);
        }
        $data['speciality'] = $this->madmins->getspeciality();
        $data['hospitals'] = $this->madmins->gethospitals();

        $data['title'] = "Create User";
        $data['main'] = 'user_add';
        $data['page_name'] = 'user_home';
        $this->load->vars($data);
        $this->load->view('admin/template');
    }

    public function delete() {
        $return = $this->madmins->delete_user($this->input->post('id'), $this->input->post('table_name'));
         $this->session->set_flashdata('success', 'Record deleted successfully.');
        echo $return;
    }

     // to unblock the user
    public function unblock() {
        $this->madmins->unblock_user($this->input->post('id'));
        echo 'success';
    }

    public function active() {
        if ($this->input->post('table_name') == 'hospital_doctor') {
            $this->madmins->status_user($this->input->post('id'), $this->input->post('table_name'), '1');
        } elseif ($this->input->post('table_name') == 'hospital_doctor_tumor_board') {
            $this->madmins->status_hospital_doctor_tumor_board($this->input->post('id'), $this->input->post('table_name'), '1');
        }
        echo 'success';
    }

    public function inactive() {
        if ($this->input->post('table_name') == 'hospital_doctor') {
            $this->madmins->status_user($this->input->post('id'), $this->input->post('table_name'), '0');
        } elseif ($this->input->post('table_name') == 'hospital_doctor_tumor_board') {
            $this->madmins->status_hospital_doctor_tumor_board($this->input->post('id'), $this->input->post('table_name'), '0');
        }
        echo 'success';
    }

    public function logout() {
        unset($_SESSION['userid']);
        unset($_SESSION['username']);
        $this->session->set_flashdata('error', "You have been logged out!");
        redirect(site_url('home/verify'));
    }

    public function tumorboardlist() {
        $list = $this->madmins->tumorboard_list($this->input->post('id'), $this->input->post('tumorid'),$this->input->post('userid'));
        echo $list;
    }

    public function add_data() {
        $return=$this->madmins->add_data_hospital();
        
        if($return=='Noinserstion')
        $this->session->set_flashdata('error', 'Hospital & Tumor Board already Existed.');
        else
         $this->session->set_flashdata('success', 'Record successfully added.');    
    }

    public function change_tumor_data() {
        //print_r($_POST);
        $data = $this->madmins->changeTumorboard($this->input->post('id'));
        //redirect(site_url('admin/user/add/'.$id));
        if ($data) {
            echo 'success';
        } else {
            echo 'failure';
        }
    }

     // to assosciate a hosptial with the users
    public function hostipal_add() {
        $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
        $hospital_id = $this->input->post('hospital_id');
        $doctor_id = $this->input->post('doctor_id');
        $tumor_id = $this->input->post('tumor_id');

        $data = array();

        $data['value'] = $this->madmins->hospitalTumorboard_edit($hospital_doctor_tumor_board_id, $hospital_id, $doctor_id);
        //print_r($data['value']);
        $data['tumor'] = $this->madmins->gettumor($data['value']['tumor_id']);
        //echo '<pre>';
        //print_r($data['tumor']);

        $this->load->vars($data);
        $this->load->view('admin/hospital_edit_model');
    }

    public function managereport() {
        if ($this->input->post('action') && $this->input->post('action') != "") {
            $selectedData = $this->input->post('my_multi_select1');
            if (count($selectedData) > 0) {
				
                $this->musers->getReport();
            } else {
                $this->session->set_flashdata('error', 'Please Move items from the left box to the right box to generate the reports you desire.');
            }
            redirect('admin/user/managereport');
        }
        $data['title'] = "Users Home";
        $data['main'] = 'report';
        $this->load->vars($data);
        $this->load->view('admin/template');
    }
    
    // complete case detail report
    public function completereport() {
        
        
        if ($this->input->post('action') && $this->input->post('action') != "") {
            
       
            $type = $this->input->post('type');
            if ($type!="") {
                $return=$this->musers->CompleteReport();
                               
            } else {
              
            }
         
           
        }
        
        $data['title'] = "Complete Report";
        $data['main'] = 'completereport';
        $this->load->vars($data);
        $this->load->view('admin/template');
    }

     public function usertrackingbackup() {
        
        
        if ($this->input->post('action') && $this->input->post('action') != "") {
            
         
            $type = $this->input->post('type');
            if ($type!="") {
               
                $return=$this->musers->usertrackingbackup();
                               
            } else {
              
            }
         
           
        }
        
        $data['title'] = "usertrackingbackup";
        $data['main'] = 'usertrackingbackup';
        $this->load->vars($data);
        $this->load->view('admin/template');
    }
    
    // to manage on which weekly notification will be sent
    public function notification() {
        $result = $this->musers->getnotification();
        $data['result'] = $result[0];
         if($this->input->post()){
             
            $this->load->library('form_validation');
            $this->form_validation->set_rules('day','Day','required');
            if(!$this->form_validation->run()){
                $this->session->set_flashdata('error', validation_errors());
            }else{
                $this->musers->update_notification();
                if($this->input->post('id')){
                    $this->session->set_flashdata('success', 'Notification Updated Successfully');
                }
                redirect(base_url('admin/user/notification/'));
            }
        }
        $data['title'] = "Manage Weekly Notification";
        $data['main'] = 'notification_form';
        $this->load->vars($data);
        $this->load->view('admin/template');
    }
    
    // to track various activities of user
    public function audit_log(){
         $this->load->library('pagination');
        $data['title'] = "Audit Logs";
        $data['main'] = 'audit_log';
        $data['page_name'] = 'audit_log';
        
       
        $config['per_page'] = $this->config->item('per_page');
       // print "<pre>";
       // print($this->uri->segment(4));
        
        if($this->session->userdata('user_trackid'))
        {
            
            
            
            
        }
        
         $page_number = $this->uri->segment(7);
       
        if (empty($page_number))
            $page_number = 1;
        $offset = ($page_number - 1) * $config['per_page'];
        $config['use_page_numbers'] = TRUE;
        
     
      //  if($this->s)
        
      
        if($this->input->post('user_id') && $this->input->post('user_id')!="")
              $user_id=$this->input->post('user_id');
        else
              $user_id=$this->uri->segment(6);
        
         if($this->input->post('dTo') && $this->input->post('dTo')!="")
              $dTo=$this->input->post('dTo');
        else
              $dTo=$this->uri->segment(5);
        
        
        
         if($this->input->post('dFrom') && $this->input->post('dFrom')!="")
              $datefrom=$this->input->post('dFrom');
        else
              $datefrom=$this->uri->segment(4);
        
        
        $dTo=date("Y-m-d",strtotime($dTo));
        $datefrom=date("Y-m-d",strtotime($datefrom));
        
        
     
        
            $filter = array(            
             'user_id' =>$user_id,
             'daysto'  =>$dTo,
             'daysfrom'  =>$datefrom,               
             'offset' => $offset,
             'per_page'=>$this->config->item('per_page')   
           );
        
            
           
            
         $config['base_url'] = base_url() . 'admin/user/audit_log/'.$datefrom.'/'.$dTo.'/'.$user_id.'/';
           
           
         $config['uri_segment'] = 7;
         $data['users'] = $this->madmins->getAllUserstrack();
        
         $config['total_rows'] = $this->madmins->getUserstrack($filter,1); // it returns total count of records of tbl_users table.

        $data['table'] = $this->madmins->getUserstrack($filter,0);
        
     
        
        //$data['table'] = $this->madmins->getAuditLog($config["per_page"], $offset, $table);
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';
       $data['page_start'] = (($page_number * $config['per_page']) - $config['per_page']) + 1;
        $data['page_end'] = $data['page_start'] + count($data['table']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->cur_page = $offset;
        $this->pagination->initialize($config);
        $data['links'] = $this->pagination->create_links();
        $this->load->vars($data);
        $this->load->view('admin/template', $data);
    }

}
?>