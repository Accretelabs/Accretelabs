<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if(!isset($_SESSION['userid'])){
            redirect(site_url('admin','refresh'));
	}
        //$this->load->model('mpage');
    }
    
    public function index() {
        $data =array();
        $data['result'] = $this->madmins->pages();
        
        $data['title'] = "Pages";
        $data['main'] = 'page';
        $data['page_name'] = 'page';
        $this->load->vars($data);
	$this->load->view('admin/template',$data);
        
    }
        
   // to view and update the page details 
    public function detail() {
        $id = $this->uri->segment(4);
        if(!isset($id)){
            redirect(site_url('/page/'));
        }
        
        $this->load->library('form_validation');	
	if ($this->input->post('action')){
            //echo $this->input->post('content');
            //die;
            $this->madmins->page_update();
            $this->session->set_flashdata('message','Page detail has been updated successfully.');
        }
         
        $data =array();
        $data['result'] = $this->madmins->page_detail($id);
        
        $data['title'] = "Page Details";
        $data['main'] = 'page_details';
        $data['page_name'] = 'page';
        $this->load->vars($data);
        $this->load->view('admin/template',$data);
        
    }
    
     public function image_upload() {
            $dir_name = "upload/content/".time().$_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'],$dir_name);
            echo  base_url().$dir_name;

     }
    
    
    
    
}    
?>