<?php
class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!isset($_SESSION['userid'])){
		 redirect(site_url('admin'));
		}
	}
	

	public function index(){
		$data['title'] = "Dashboard Home";
		$data['main'] = 'home';
		//$data['admins'] = $this->MAdmins->getAllUsers();
		$this->load->vars($data);
		$this->load->view('admin/template',$data);
	}
	
	

}
?>