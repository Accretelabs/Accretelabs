<?php
class AdminProfile extends CI_Controller {

	public function __construct(){
		parent::__construct();
		if(!isset($_SESSION['userid'])){
		 redirect(site_url('admin'));
		}
	}
	

         // to view and edit the admin profile
	public function index($uri=0){
		$this->load->library('form_validation');
			if($this->input->post('action') == 'update'){
				$validate = 'adminprofile';
			}else{
				$validate = 'adminpassword';
			}
		
		if ($this->input->post('action') && $this->form_validation->run($validate) == TRUE){
			if($this->input->post('action') == 'add'){
				$this->madmins->adminprofile_add();
				$this->session->set_flashdata('success','Profile added successfully');
                               redirect(site_url('admin/adminprofile/index/profile'));
			}elseif($this->input->post('action') == 'update'){
				$this->madmins->adminprofile_update();
				$this->session->set_flashdata('success','Profile updated successfully');
                               redirect(site_url('admin/adminprofile/index/profile'));
			}elseif($this->input->post('action') == 'password'){
				$data_message = $this->madmins->adminprofile_password();
                                if($data_message)
				$this->session->set_flashdata('success','Password Updated Successfully!');
                                else
                                $this->session->set_flashdata('error','Old Password doesn\'t match!');
                                redirect(site_url('admin/adminprofile/index/password'));
			}
			
			
		}else{
			$data['uri']= $uri;
			$data['title'] = "Admin Profile";
			$data['main'] = 'admin_profile';
			$data['admindata'] = $this->madmins->adminprofile();
			$this->load->vars($data);
			$this->load->view('admin/template',$data);
		}	

			
	}


}
?>