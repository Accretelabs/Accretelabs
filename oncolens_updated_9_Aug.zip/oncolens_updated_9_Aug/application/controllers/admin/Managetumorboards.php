<?php

class Managetumorboards extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['userid'])) {
            redirect(site_url('admin', 'refresh'));
        }
    }

     // to view list of Tumor Boards
    public function index($table = 0) {
      
        $this->load->library('pagination');
        $data['title'] = "Tumor Board";
        $data['main'] = 'managetumorboards';
        $data['page_name'] = 'manage_tumorboard';
        $config['base_url'] = base_url() . 'admin/managetumorboards/';
        $config['per_page'] = $this->config->item('per_page');
        $page_number = $this->uri->segment(3);
        if (empty($page_number))
            $page_number = 1;
        $offset = ($page_number - 1) * $config['per_page'];
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $this->madmins->getAlltumorboardcount();
        
        $data['table'] = $this->madmins->getAlltumorboards($config["per_page"], $offset, $table);
        
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';
        $data['page_start'] = (($page_number * $config['per_page']) - $config['per_page']) + 1;
        $data['page_end'] = $data['page_start'] + count($data['table']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->pagination->initialize($config);
        $data['links'] = $this->pagination->create_links();
        $this->load->vars($data);
        $this->load->view('admin/template', $data);
    }

    
    public function add($id = null) {
        $this->load->library('form_validation');
        if ($this->input->post('action') && $this->form_validation->run('tumor_' . $this->input->post('action')) == TRUE) {
            if ($this->input->post('action') == 'add') {
                $result=$this->madmins->addTumorboard();
                if($result=='success')
                $this->session->set_flashdata('success', 'Tumor Board added successfully');
                else
                 $this->session->set_flashdata('error', 'Tumor Board already Existed in respective hospital');
            } else {
                $result=$this->madmins->updateTumorboard($id);
                if($result=='success')                                 
                $this->session->set_flashdata('success', 'Tumor Board updated successfully');
                 else
                 $this->session->set_flashdata('error', 'Tumor Board cannot updated As same tumor board existed in respective hospital');
               
            }
            redirect(site_url('admin/managetumorboards'));
        } else {
            if ($id != "") {
                $data['tumorboardsdetail'] = $this->madmins->getTumorboardsdetail($id);
         $data['selectedhospital'] = $this->madmins->getselectedhospitaltumor($data['tumorboardsdetail']->tumor_id);
         
        
           
         
            }
            $data['cancercategory'] = $this->madmins->getCancertype();
            $data['hospitals'] = $this->madmins->gethospitals();

            $data['title'] = "Create Tumor Board";
            $data['main'] = 'tumorboard_add';
            $data['page_name'] = 'manage_tumorboard';
            $this->load->vars($data);
            $this->load->view('admin/template');
        }
    }

    public function delete() {
      $this->madmins->delete_tumorboard($this->input->post('id'), $this->input->post('table_name'));
        echo 'success';
     
    }

    public function active() {
        
       
        $this->madmins->status_tumorboard_active($this->input->post('id'), $this->input->post('table_name'), '1');
        $this->session->set_flashdata('success', 'Tumor Board Active Successfully.');
        echo 'success';
    }

    public function inactive() {
        
        
        
        $result=$this->madmins->status_tumorboard_inactive($this->input->post('id'), $this->input->post('table_name'), '0');
        
              if($result=='success')
                    $this->session->set_flashdata('success', 'Tumor Board Inactive Successfully.');
                else
                    $this->session->set_flashdata('error', 'Tumor Board cannot be  inactive as either there is  tumor board meeting  or  active users  associated with it ');
        
           
    }

}

?>