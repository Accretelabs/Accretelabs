<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Tumorboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }
        $this->load->model('mtumorboard');
        $this->load->model('mcase');
    }

    //create and list in person tumor board
    public function index($pageno = 1) {
        $data['title'] = "Dashboard";
        $data['main'] = 'create_tumor_board_schedule';
        $data['tumor_boards'] = $this->mtumorboard->get_tumorboards();
        $data['schedule_reccurance'] = $this->config->item('schedule_reccurance');
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');

        if ($this->input->post()) {//If post data is available create a new meeting
            $this->load->library('form_validation');
            if ($this->form_validation->run('create_schedule') == TRUE) {
                if($this->input->post('recurrence_type')=='biweek' && (count($this->input->post('biweek_days'))<2 || count($this->input->post('biweek_days'))>2)){
                    $this->session->set_flashdata('error', 'You have to select two week days.');
                    $data['error'] = 'You have to select two week days.';
                }else{
                    if ($this->mtumorboard->create_schedule()) {
                        $data['success'] = 'Meeting successfully scheduled.';
                        $this->session->set_flashdata('success', 'Tumor Board Successfully Scheduled.');
                        redirect(site_url('tumorboard'));
                    } else {
                        $data['error'] = 'Something went wrong.';
                    }
                }
            }
        }
        $data['page_list'] = $this->tumor_board_list($pageno, true);
        $data['page_name'] = 'create_tumor_board_schedule';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }


    public function tumor_board_list($pageno = 1, $html = false){
        $data['schedule_reccurance'] = $this->config->item('schedule_reccurance');
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['tumor_board_scedules'] = $this->mtumorboard->get_schedules($filter);
        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard/tumor_board_list/';
        $config['total_rows'] = $this->mtumorboard->get_schedules($filter);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($data['tumor_board_scedules']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        if($html){
            return $this->load->view('tumor_board_list_schedule', $data, true);
        }else{
            $this->load->view('tumor_board_list_schedule', $data);
        }
    }

    //create and list in person tumor board
    public function view($days = 30, $pageno = 1){
        $data['title'] = "Dashboard";
        $data['main'] = 'view_tumor_board_schedule';
        $data['days'] = $days;
        $data['pageno'] = $pageno;

        if($this->input->post()){
            $id = $this->input->post('id');
            $d = array();
            if($this->input->post('meeting_date')){
                $d['meeting_date'] = $this->input->post('meeting_date');
            }
            if($this->input->post('meeting_time')){
                $d['meeting_time'] = $this->input->post('meeting_time');
            }
            $this->mtumorboard->update_detailed_schedules($id, $d);
            $this->session->set_flashdata('success', 'Record has been updated successfully');
        }



        $data['page_list'] = $this->in_person_tumor_board_list($days, $pageno, true);
        $data['page_name'] = 'view_inperson_tumor_board';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }
    public function in_person_tumor_board_list($days = 7, $pageno = 1, $html = false){
        $limit = $this->config->item('per_page');
        $filter = array(
            'days' => $days,
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['tumor_board_scedules'] = $this->mtumorboard->get_detailed_schedules($filter);
        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard/in_person_tumor_board_list/'.$days.'/';
        $config['total_rows'] = $this->mtumorboard->get_detailed_schedules($filter);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($data['tumor_board_scedules']) - 1;
        $data['page_total'] = $config['total_rows'];
        if(!count($data['tumor_board_scedules']) && $pageno>0 && $config['total_rows']>0){
            $pageno--;
            redirect(site_url("tumorboard/view/$days/$pageno"));
        }
        $config['per_page'] = $limit;
        $config['uri_segment'] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        if($html){
            return $this->load->view('in_person_tumor_board_list', $data, true);
        }else{
            $this->load->view('in_person_tumor_board_list', $data);
        }
    }

    //remove tumor board meeting
    public function delete_detailed($id, $days = 7, $pageno = 1){
        $data = array('is_deleted' => '1');
        $return=$this->mtumorboard->delete_submetting($id, $data);

              echo $return;
              die;

//        if($return==true)
//
//        $this->session->set_flashdata('success', 'Meeting deleted successfully.');
//        else
//        $this->session->set_flashdata('error', 'Meeting Cannot be removed  as there are cases associated with it.');
//
//        redirect(site_url("tumorboard/view/$days/$pageno"));
    }


     public function delete_meeting($id){
        $return=$this->mtumorboard->delete_tumormetting($id);
        if($return==true)
        $this->session->set_flashdata('success', 'Meeting deleted successfully.');
        else
        $this->session->set_flashdata('error', 'Event cannot be deleted. Please remove all cases assigned to the event before deleting.');

    }


    //update tumor board meeting
    public function update_detailed(){
        if(!$this->input->post()){
            echo json_encode(array('status'=>0));
            exit();
        }
        if(!$this->input->post('id')){
            echo json_encode(array('status'=>0));
            exit();
        }else{
            $id = $this->input->post('id');
        }
        $data = array();
        if($this->input->post('new_date')){
            $data['meeting_date'] = date('Y-m-d', strtotime($this->input->post('new_date')));
        }
        if($this->input->post('new_time')){
            $data['meeting_time'] = date('H:i:s', strtotime($this->input->post('new_time')));
        }
        $this->mtumorboard->update_detailed_schedules($id, $data);
        echo json_encode(array('status'=>1));
        exit();
    }

    //create and list in person tumor board
    public function case_list($tumor_board_id = 0, $days = 30, $pageno = 1){
        $data['title'] = "Dashboard";
        $data['main'] = 'case_list';
        $data['tumor_board_id'] = $tumor_board_id;
        $data['days'] = $days;
        $data['pageno'] = $pageno;
        $data['tumor_boards'] = $this->mtumorboard->get_tumorboards();
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        $data['page_list'] = $this->case_list_page($tumor_board_id, $days, $pageno, true);
        $data['page_name'] = 'assign_cases';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }
    public function case_list_page($tumor_board_id = 0, $days = 30, $pageno = 1, $html = false){

        $limit = $this->config->item('per_page');
        $filter = array(
            'tumor_board_id' => $tumor_board_id,
            'days' => $days,
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['cases'] = $this->mtumorboard->get_cases($filter);
        $session = $this->mtumorboard->admin_view_next_id($filter);
        $schedules = $this->mtumorboard->get_detailed_schedules(array('days'=>$days));
        $meeting_schedules = array();
        foreach ($schedules as $schedule){
            $meeting_schedules[$schedule->tumor_id][] = $schedule;
        }
        $data['meeting_schedules'] = $meeting_schedules;
        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard/case_list_page/'.$tumor_board_id.'/'.$days.'/';
        $config['total_rows'] = $this->mtumorboard->get_cases($filter);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($data['cases']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 5;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        if($html){
            return $this->load->view('case_list_page', $data, true);
        }else{
            $this->load->view('case_list_page', $data);
        }
    }

    public function assign_case(){
        $flag = false;
        foreach($this->input->post() as $case_id => $meeting_id){
            $meeting = explode(':', $meeting_id);
            $meeting_id = $meeting[0];
            $catb_id = $meeting[1];
            $data = array(
                'sub_meeting_id' => $meeting_id,
                'case_id' => $case_id,
                'catb_id' => $catb_id
            );
            $this->mtumorboard->assign_case($data);
            $flag = true;
        }
        if($flag){
            $this->session->set_flashdata('message', 'Case Successfully Assigned.');
        }
    }

    //create and list in person tumor board
    public function meeting_case_list($sub_meeting_id = 0, $pageno = 1){
        $data['title'] = "Dashboard";
        $data['main'] = 'meeting_case_list';
        $data['sub_meeting_id'] = $sub_meeting_id;
        $data['pageno'] = $pageno;
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $filter = array('sub_meeting_id' => $sub_meeting_id, 'count'=>true, 'status'=>'all');
        $data['total_cases'] = $this->mtumorboard->get_meeting_cases($filter);
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        $data['page_list'] = $this->meeting_case_list_page($sub_meeting_id, $pageno, true);

        $data['page_name'] = 'view_inperson_tumor_board';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }
    public function meeting_case_list_page($sub_meeting_id = 0, $pageno = 1, $html = false){
        $limit = $this->config->item('per_page');
        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit,
            'status' => 'all'
        );
        $data['cases'] = $this->mtumorboard->get_meeting_cases($filter);


        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard/meeting_case_list_page/'.$sub_meeting_id.'/';
        $config['total_rows'] = $this->mtumorboard->get_meeting_cases($filter);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($data['cases']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;
        if(!count($data['cases']) && $pageno>0 && $config['total_rows']>0){
            $pageno--;
            redirect(site_url("tumorboard/meeting_case_list/$sub_meeting_id/$pageno"));
        }
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        if($html){
            return $this->load->view('meeting_case_list_page', $data, true);
        }else{
            $this->load->view('meeting_case_list_page', $data);
        }
    }

    //remove case from tumor board meeting
    public function remove_case($cma_id){
        $this->mtumorboard->remove_case_from_meeting($cma_id);
    }

    public function meeting_attendees($sub_meeting_id = 0){
        $data['title'] = "Dashboard";
        $data['main'] = 'meeting_attendees';
        $data['sub_meeting_id'] = $sub_meeting_id;
        $data['attendees'] = $this->mtumorboard->get_attendees($sub_meeting_id);
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        $attendees = $this->mtumorboard->get_meeting_attendees($sub_meeting_id);
        $count = 0;
        foreach ($attendees as $attendee){
            switch($attendee->speciality_id){
                case ONCOLOGY_SPECILITY:
				$data['oncology'][] = $attendee;
                    $count = count($data['oncology'])>$count?count($data['oncology']):$count;
                    break;
                case RADIATION_ONCOLOGY_SPECILITY:
                    $data['radoncology'][] = $attendee;
                    $count = count($data['radoncology'])>$count?count($data['radoncology']):$count;
                    break;
                case PATHOLOGY_SPECILITY:
                    $data['pathology'][] = $attendee;
                    $count = count($data['pathology'])>$count?count($data['pathology']):$count;
                    break;
                case RADIOLOGY_SPECILITY:
                    $data['radiology'][] = $attendee;
                    $count = count($data['radiology'])>$count?count($data['radiology']):$count;
                    break;
                case SURGERY_SPECILITY:
                    $data['surgery'][] = $attendee;
                    $count = count($data['surgery'])>$count?count($data['surgery']):$count;
                    break;
                default :
                    $data['others'][] = $attendee;
                    $count = count($data['others'])>$count?count($data['others']):$count;
                    break;
            }
        }
        $data['page_name'] = 'view_inperson_tumor_board';
        $data['count'] = $count;
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }


    // To save Attendees
    public function save_attendee($sub_meeting_id = 0){
        $this->mtumorboard->save_attendee($sub_meeting_id, $this->input->post('attendee'));
        $this->session->set_flashdata('message', 'Attendees Successfully Marked.');
        redirect(site_url('tumorboard/meeting_attendees/'.$sub_meeting_id));
    }

    public function meeting_dashboard($sub_meeting_id = 0, $pageno = 1){
        $data['title'] = "Dashboard";
        $data['main'] = 'meeting_dashboard';
        $data['sub_meeting_id'] = $sub_meeting_id;
        $data['pageno'] = $pageno;
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        $data['page_list'] = $this->meeting_dashboard_case($sub_meeting_id, $pageno, true);
        $data['page_name'] = 'view_inperson_tumor_board';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }




    public function meeting_dashboard_case($sub_meeting_id = 0, $pageno = 1, $html = false){
        //prd($this->session->all_userdata());
        $limit = 1;
        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit,
            'status' => 'all'
        );
        $sub_meeting_detail = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $schedules = $this->mtumorboard->get_detailed_schedules(array('days'=>90));

        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');

        $case = $this->mtumorboard->get_meeting_cases($filter);
        //prd($case[0]);
//        $this->load->model('mcase');
        $case_id = (int)$case[0]->case_id;
        $case_schedule_array = $this->mtumorboard->get_case_schedules($case_id);
        $schedule_array = array();
        foreach($case_schedule_array as $val){
            $schedule_array[] = $val->sub_meeting_id;
        }
        //prd($schedule_array);
        $meeting_schedules = array();
        foreach ($schedules as $schedule){
            if($sub_meeting_detail['tumor_board_id'] == $schedule->tumor_id && $schedule->cmd_id!=$sub_meeting_id && !in_array($schedule->cmd_id, $schedule_array)){
                $meeting_schedules[] = $schedule;
            }
        }
        $data['meeting_schedules'] = $meeting_schedules;
        $data['cases'] = $this->mtumorboard->case_detail($case_id);
        $data['case_meeting'] = $case[0];
        //prd($data['cases']);
        $data['pageno'] = $pageno;
        $data['sub_meeting_id'] = $sub_meeting_id;

        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard/meeting_dashboard_case/'.$sub_meeting_id.'/';
        $config['total_rows'] = $this->mtumorboard->get_meeting_cases($filter);
        $data['page_start'] = (($pageno * $limit) - $limit)+1;
        $data['page_end'] = $data['page_start'] + count($data['cases']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 4;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;
        if(!count($data['cases']) && $pageno>0 && $config['total_rows']>0){
            $pageno--;
            redirect(site_url("tumorboard/meeting_case_list/$sub_meeting_id/$pageno"));
        }
        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        if($html){
            return $this->load->view('meeting_dashboard_case', $data, true);
        }else{
            $this->load->view('meeting_dashboard_case', $data);
        }
    }

    public function case_detail($case_id = 0, $source = ''){
        $data['title'] = "Dashboard";
        $data['main'] = 'admin_case_details';
        $this->load->model('mcustom');
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        $data['hospital'] = $this->mcustom->get_our_hospitals();
        $data['cases'] = $this->mtumorboard->case_detail($case_id);
        $data['cases_summary'] = $this->mtumorboard->get_case_meeting_summaries($case_id);

        $data['pagination'] = '';
        $data['pageno'] = $case_id;
        $data['page_name'] = $source;
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }
    public function updateMRNumber(){

		$case_id=$this->input->post('case_id');
		$mr_id=$this->input->post('mr_id');
		if(isset($case_id) && !empty($case_id) && isset($mr_id) && !empty($mr_id)){
			$return_id=$this->mtumorboard->update_mr_number($case_id,$mr_id);
			if($return_id){

				redirect('tumorboard/case_detail/'.$case_id.'/assign_cases');
			}
		}
	}
        // to print the schedule in pdf format
    public function print_schedule($sub_meeting_id = 0){
        $this->load->helper('mpdf/mpdf');
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'status'=>'all'
        );
        $data['cases'] = $this->mtumorboard->get_meeting_cases($filter);

        $data['page_total'] = 0;
        $data['pagination'] = '';
        $html = $this->load->view('print_schedule', $data, true);
        $mpdf=new mPDF();

        $mpdf->WriteHTML($html);
        $mpdf->Output();
        exit;
    }

    // to print case summary in pdf format
    public function print_case_summary($sub_meeting_id = 0){
        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'status'=>'all'
        );
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $data['cases'] = $this->mtumorboard->get_meeting_cases($filter);
        $data['case_details'] = array();

        foreach($data['cases'] as $case){
   /*      $data['case_details'][$case->case_id]['detail'] = $this->mtumorboard->case_detail($case->case_id);
            $data['case_details'][$case->case_id]['summary'] = $case;
			*/






		}

        $data['page_total'] = 0;
        $data['pagination'] = '';
        $this->load->helper('mpdf/mpdf');
        $mpdf=new mPDF();
		$ii=1;
		$pdfstr='<!DOCTYPE html>
<html class=" ">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta charset="utf-8" />
        <title>Oncolens</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/images/favicon.png" />
        <link href="'.base_url().'assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/fonts/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/fonts/avenir-next-lt-pro/avenir.css" rel="stylesheet" />
        <link href="'.base_url().'assets/css/perfect-scrollbar.css" rel="stylesheet" type="text/css" />
 		<link href="'.base_url().'assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/css/jasny-bootstrap.min.css" rel="stylesheet" />
         <link href="'.base_url().'assets/css/custom.css" rel="stylesheet" type="text/css" />
        <style>
            .table td, .table th {
                text-align: left!important;
                vertical-align: top!important;
                padding: 3px!important;
            }
        </style>
    </head>
    <body class=" ">
   <div class="page-container row-fluid">
     <section id="" class=" ">
                <section class="">
                    <h3 class="title" style="padding-top:35% !important;">In-Person '.ucwords(strtolower($data['schedule']['tumor_board_name'])).'<span> ('.date('m/d/Y', strtotime($data['schedule']['meeting_date'])).' '.date('h:i A', strtotime($data['schedule']['meeting_time'])).')</span></h3>';

		$pdf_array=array();
		array_push($pdf_array,$pdfstr);
		  foreach($data['cases'] as $case){
			    $data['case_details']['detail']=$this->mtumorboard->case_detail($case->case_id);
			    $data['case_details']['summary'] = $case;
			    $data['case_details']['case_id'] = $case->case_id;
				$data['mmi'] = $ii++;
				$m_str=$this->load->view('print_summary', $data, true);
 				array_push($pdf_array,$m_str);
/*				$mpdf->WriteHTML($pdfstr);
				$mpdf->AddPage();
*/

		  }
		  $d=0;
		foreach($pdf_array as $pdf){
			$mpdf->WriteHTML($pdf);

			if($d<=0){
			}
			else{
				if($d==(count($pdf_array)-1)){
				}
				else{
				$mpdf->AddPage();
				}
			}
			$d++;
		}

        $mpdf->Output();
        exit;
    }
	public function print_case_summary_with_info($sub_meeting_id = 0){/*
        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'status'=>'all'
        );
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $data['cases'] = $this->mtumorboard->get_meeting_cases($filter);
        $data['case_details'] = array();
        foreach($data['cases'] as $case){
            $data['case_details'][$case->case_id]['detail'] = $this->mtumorboard->case_detail($case->case_id);
            $data['case_details'][$case->case_id]['summary'] = $case;
        }
        $data['page_total'] = 0;
        $data['pagination'] = '';
        $html = $this->load->view('print_summary_info', $data, true);
        $this->load->helper('mpdf/mpdf');
        $mpdf=new mPDF();

        $mpdf->WriteHTML($html);
        $mpdf->Output();
        exit;
    */

        $filter = array(
            'sub_meeting_id' => $sub_meeting_id,
            'status'=>'all'
        );
        $data['schedule'] = $this->mtumorboard->get_detailed_schedules(array('sub_meeting_id'=>$sub_meeting_id));
        $data['cases'] = $this->mtumorboard->get_meeting_cases($filter);
        $data['case_details'] = array();

        foreach($data['cases'] as $case){
   /*      $data['case_details'][$case->case_id]['detail'] = $this->mtumorboard->case_detail($case->case_id);
            $data['case_details'][$case->case_id]['summary'] = $case;
			*/






		}

        $data['page_total'] = 0;
        $data['pagination'] = '';
        $this->load->helper('mpdf/mpdf');
        $mpdf=new mPDF();
		$ii=1;
		$pdfstr='<!DOCTYPE html>
<html class=" ">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta charset="utf-8" />
        <title>Oncolens</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/images/favicon.png" />
        <link href="'.base_url().'assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/fonts/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/fonts/avenir-next-lt-pro/avenir.css" rel="stylesheet" />
        <link href="'.base_url().'assets/css/perfect-scrollbar.css" rel="stylesheet" type="text/css" />
 		<link href="'.base_url().'assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="'.base_url().'assets/css/jasny-bootstrap.min.css" rel="stylesheet" />
         <link href="'.base_url().'assets/css/custom.css" rel="stylesheet" type="text/css" />
        <style>
            .table td, .table th {
                text-align: left!important;
                vertical-align: top!important;
                padding: 3px!important;
            }
        </style>
    </head>
    <body class=" ">
   <div class="page-container row-fluid">
     <section id="" class=" ">
                <section class="">
                    <h3 class="title">In-Person '.ucwords(strtolower($data['schedule']['tumor_board_name'])).'<span> ('.date('m/d/Y', strtotime($data['schedule']['meeting_date'])).' '.date('h:i A', strtotime($data['schedule']['meeting_time'])).')</span></h3>';

		$pdf_array=array();
		array_push($pdf_array,$pdfstr);
		  foreach($data['cases'] as $case){
			    $data['case_details']['detail']=$this->mtumorboard->case_detail($case->case_id);
			    $data['case_details']['summary'] = $case;
			    $data['case_details']['case_id'] = $case->case_id;
				$data['mmi'] = $ii++;
				$m_str=$this->load->view('print_summary_info', $data, true);
 				array_push($pdf_array,$m_str);
/*				$mpdf->WriteHTML($pdfstr);
				$mpdf->AddPage();
*/

		  }
		  $d=0;
		foreach($pdf_array as $pdf){
			$mpdf->WriteHTML($pdf);

			if($d<=0){
			}
			else{
				if($d==(count($pdf_array)-1)){
				}
				else{
				$mpdf->AddPage();
				}
			}
			$d++;
		}

        $mpdf->Output();
        exit;


	}
    // to update Case Status
    public function update_case_status($sub_meeting_id = 0){
        if($this->input->post()){
            $this->mtumorboard->update_case_meeting_assignment($sub_meeting_id);
            $this->session->set_flashdata('message', 'Case Status Successfully Updated.');
        }
    }


     public function delete_case(){


          if($this->input->post()){
              $return = $this->mcase->delete_case_hospital_admin();
               redirect(site_url('tumorboard/case_list/'));
         }
    }


    public function search_case($page = 1) {

        $data = array();

        //total rows count
        $filter = array(
            'pname' => $this->input->post('pname'),
            'submitted_by' => $this->input->post('submitted_by'),
            'submitted_date' => $this->input->post('submitted_date'),
            'cancer_type' => $this->input->post('cancer_type'),
            'dob' => $this->input->post('dob'),
            'case_open' => $this->input->post('case_open')?$this->input->post('case_open'):'',
            'case_close' => $this->input->post('case_close')?$this->input->post('case_close'):'',
            'urgent' => $this->input->post('urgent')?$this->input->post('urgent'):'',
            'is_tumor' => $this->input->post('is_tumor')?$this->input->post('is_tumor'):'',
            'online' => $this->input->post('online')?$this->input->post('online'):'',
            'inperson' => $this->input->post('inperson')?$this->input->post('inperson'):'',
        );

        $data['page_list'] = $this->search_case_list($page, true);
        //get the  data

        $data['cancertype'] = $this->madmins->getCancertype();
        $data['title'] = "Your Case Results";
        $data['main'] = 'admin_search_case';
        $data['page_name'] = 'search_cases';
        $data['filter']=$filter;
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    public function search_case_list($page = 1, $html = false) {

        $limit = $this->config->item('per_page');
        //total rows count
        $filter = array(
            'pname' => $this->input->post('pname'),
            'submitted_by' => $this->input->post('submitted_by'),
            'submitted_date' => $this->input->post('submitted_date'),
            'cancer_type' => $this->input->post('cancer_type'),
            'dob' => $this->input->post('dob'),
            'case_open' => $this->input->post('case_open')?$this->input->post('case_open'):'',
            'case_close' => $this->input->post('case_close')?$this->input->post('case_close'):'',
            'urgent' => $this->input->post('urgent')?$this->input->post('urgent'):'',
            'is_tumor' => $this->input->post('is_tumor')?$this->input->post('is_tumor'):'',
            'online' => $this->input->post('online')?$this->input->post('online'):'',
            'inperson' => $this->input->post('inperson')?$this->input->post('inperson'):'',
        );

        $params = array(
            $filter,
            'start' => ($page * $limit) - $limit,
            'limit' => $limit,
        );



        $data['caselist'] = $this->mtumorboard->search_CaseList($params);
        $session =$this->mtumorboard->next_id($params);



        $this->load->library('pagination');
        //pagination configuration
        $config['base_url'] = base_url() . 'tumorboard/search_case_list/';
        $config['total_rows'] = $this->mtumorboard->search_CaseList(array($filter), true);
        $data['page_start'] = (($page * $limit) - $limit) + 1;
        $data['page_end'] = $data['page_start'] + count($data['caselist']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Open Cases Awaiting Your Feedback";
        // $data['main'] = 'ajax_answer_opencase';
        // $this->load->vars($data);
        if($html){
            return $this->load->view('admin_search_case_list_filter', $data, true);
        }else{
            $this->load->view('admin_search_case_list_filter', $data, false);
        }
    }
}
