<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Schedule extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }
        $this->load->model('mschedule');
    }

     // to create tumboard meeting       
    public function index($pageno = 1) {
        $data['title'] = "Dashboard";
        $data['main'] = 'create_tumor_board_schedule';
        $data['tumor_boards'] = $this->mschedule->get_tumorboards();
        $data['schedule_reccurance'] = $this->config->item('schedule_reccurance');
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');

        if ($this->input->post()) {//If post data is available create a new meeting
            $this->load->library('form_validation');
            if ($this->form_validation->run('create_schedule') == TRUE) {
                if ($this->mschedule->create_schedule()) {
                    $data['success'] = 'Meeting successfully scheduled.';
                    $this->session->set_flashdata('message', 'Tumor Board Successfully Scheduled.');
                    redirect(site_url('schedule'));
                } else {
                    $data['error'] = 'Something went wrong.';
                }
            }
        }
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $data['tumor_board_scedules'] = $this->mschedule->get_schedules($filter);
        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'schedule/index/';
        $config['total_rows'] = $this->mschedule->get_schedules($filter);
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();

        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }

}
