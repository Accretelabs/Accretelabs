<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }
    }

//    public function index() {
//        $data['title'] = "Dashboard Home";
//        $data['main'] = 'userdashboard';
//        //$data['admins'] = $this->MAdmins->getAllUsers();
//        $this->load->vars($data);
//        $this->load->view('template/template', $data);
//    }
    
    // thanks page after submitting the case
     public function thanks() {
        $data['title'] = "Thanks for submit case";
        $data['main'] = 'thanks';
        //$data['admins'] = $this->MAdmins->getAllUsers();
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }

}
