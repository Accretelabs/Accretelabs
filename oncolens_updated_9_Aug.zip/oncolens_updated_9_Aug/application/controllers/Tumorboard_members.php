<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Tumorboard_members extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }elseif($_SESSION['speciality_id']!=HOSPITAL_ADMIN_SPECILITY){
            redirect(site_url('/'));
        }
        $this->load->model('mtumorboard_members', 'members');
    }

    //create and list in person tumor board
    public function index($pageno = 1) {
        $data['title'] = "Dashboard";
        $data['main'] = 'tumorboard_members';
        if ($this->session->flashdata('message'))
            $data['success'] = $this->session->flashdata('message');
        
        $data['page_list'] = $this->tumorboard_members_list($pageno, true);
        $data['page_name'] = 'manager_tumor_board_members';
        $this->load->helper('form');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }

    
     // display the list of tumorborad members
    public function tumorboard_members_list($pageno = 1, $html = false) {
        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => ($pageno * $limit) - $limit
        );
        $this->load->model('mtumorboard');
        $data['tumor_boards'] = $this->mtumorboard->get_tumorboards();
        $data['tumorboard_members'] = $this->members->get_members($filter);
        $active_members = $this->members->get_active_members($data['tumor_boards']);
        $tumorboard_active_members = array();
        foreach ($active_members as $members) {
            $tumorboard_active_members[$members->tumor_id][] = $members->hospital_doctor_id;
        }
        $data['tumorboard_active_members'] = $tumorboard_active_members;
        $filter['count'] = true;
        unset($filter['limit']);
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'tumorboard_members/tumorboard_members_list/';
        $config['total_rows'] = $this->members->get_members($filter);
        $data['page_start'] = (($pageno * $limit) - $limit) + 1;
        $data['page_end'] = $data['page_start'] + count($data['tumorboard_members']) - 1;
        $data['page_total'] = $config['total_rows'];
        $config['per_page'] = $limit;
        $config['uri_segment'] = 3;
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 3;

        $config['full_tag_open'] = '<nav class="pull-right"><ul class="pagination pagination-lg">';
        $config['full_tag_close'] = '</ul></nav>';

        $config['first_link'] = 'First';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';

        $config['last_link'] = 'Last';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';

        $config['next_link'] = '&gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $config['prev_link'] = '&lt;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';

        $config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $config['cur_tag_close'] = '</a></li>';

        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['pagination'] = $this->pagination->create_links();
        if ($html) {
            return $this->load->view('tumorboard_members_list', $data, true);
        } else {
            $this->load->view('tumorboard_members_list', $data);
        }
    }

      // to save the changes  in  Members in Tumor Board
    public function save_members() {
        foreach ($this->input->post('member') as $members) {
            $member = explode(':', $members);
            $tumor_id = $member[0];
            $hospital_doctor_id = $member[1];
            $is_active = $member[2];
            $this->members->save_members($tumor_id, $hospital_doctor_id, $is_active);
        }
        $this->session->set_flashdata('message', 'Members in Tumor Board are successfully updated.');
    }

}
