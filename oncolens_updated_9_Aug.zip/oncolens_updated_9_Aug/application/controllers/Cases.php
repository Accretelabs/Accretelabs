<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cases extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }
//        if($this->session->userdata('speciality_id') == HOSPITAL_ADMIN_SPECILITY){
//            redirect('tumorboard/view');
//        }
        $this->load->model('mcase');
        $this->load->library('Ajax_pagination');
        $this->load->library('Ajax_pagination1');
        $this->perPage = 10;
    }

    // to view cases assigned to user for comments
    public function answeropen() {

        $data = array();

        //total rows count
        $totalRec = $this->mcase->count_answeropencase($this->input->post('filter'));

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'answeropen_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_answeropen';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination->initialize($config);

        //get the  data
        $data['cases'] = $this->mcase->answeropencase(array('filter' => $this->input->post('filter'), 'limit' => $this->perPage));
        //echo '<pre>';
        //print_r($data['cases']);
        $data['filter'] = $this->input->post('filter');
        $data['title'] = "Open Cases Awaiting Your Feedback";
        $data['page_name'] = 'answer_opencase';
        $data['main'] = 'answer_opencase';
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    // to view cases assigned to user for comments 
    public function ajaxpagination_answeropen() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //total rows count
        $totalRec = $this->mcase->count_answeropencase($this->input->post('filter'));

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'answeropen_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_answeropen';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination->initialize($config);

        //get the posts data
        $data['cases'] = $this->mcase->answeropencase(array('filter' => $this->input->post('filter'), 'start' => $offset, 'limit' => $this->perPage));
        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Open Cases Awaiting Your Feedback";
        // $data['main'] = 'ajax_answer_opencase';
        // $this->load->vars($data);
        $this->load->view('ajax_answer_opencase', $data, false);
    }

    public function details() {
        $last_pram = end(@explode("/", $_SERVER['HTTP_REFERER']));



        $data = array();
        $case_id = $this->uri->segment(3);
        $cases = $this->mcase->case_detail($case_id);

        $d = array('case_id' => $case_id);
        if ($this->uri->segment(4)) {
            $pageid = $this->uri->segment(4);

            if ($pageid == 1) {
                $d['pageid'] = $pageid;
                $nextid = $this->mcase->next_case($d);
            } else if ($pageid == 2) {
                $d['pageid'] = $pageid;
                $nextid = $this->mcase->next_case($d);
            } else if ($pageid == 3) {
                $d['pageid'] = $pageid;
                $nextid = $this->mcase->next_case($d);
            }
            if ($pageid == 1 || $pageid == 2 || $pageid == 3) {
                $data['next_cases'] = $nextid;
                $data['pageid'] = $d['pageid'];
            }
        }


        if ($cases) {
            $data['cases'] = $cases;
        } else {
            $data['cases'] = "";
            $data['notfound'] = true;
        }
		if(isset($last_pram) && !empty($last_pram) && $last_pram=="answeropen"){
			 $data['last_pram'] = $last_pram;
		}
        //print_r($data['cases']);
        //die;
        $data['title'] = "Open Cases Awaiting Your Feedback";
        $data['page_name'] = 'case_details';
        $data['main'] = 'case_details';
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    // to save the comments entered by doctor on answer open page 
    public function savecasescomments() {
        if ($this->input->post('action') && $this->input->post('action') != "") {
            if ($this->input->post('action') == 'specificanswer_form') {
                $return = $this->mcase->savecasescomments();
            } else if ($this->input->post('action') == 'delete_case') {
                $return = $this->mcase->delete_case();
            } else if ($this->input->post('action') == 'close_case') {
                $return = $this->mcase->case_close();
            }
			$answer_open=$this->input->post('last_pram');
			if(isset($answer_open) && !empty($answer_open) && $answer_open=="answeropen"){
				$aopen=$answer_open;
			}
			else{
				$aopen="";
			}
			if($this->input->post('action')=="specificanswer_form" ){
				if($aopen=="answeropen"){
				redirect(site_url('cases/answeropen'));
				}
				else{
				 redirect(site_url('inperson'));
				}
			}
			else{
           redirect(site_url('cases/answeropen'));
			}
	}
    }

    // to view cases assigned to user for image request
    public function openrequest() {

        $data = array();

        //total rows count
        $totalRec = $this->mcase->count_requestdata();
        $totalRec_submitted = $this->mcase->count_requestdata_i_submitted();

        //pagination configuration data request i recieved on top
        $config['first_link'] = 'First';
        $config['div'] = 'openrequest_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_openrequestdata';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination->initialize($config);


        //pagination configuration data request i submitted on second level
        $config['first_link'] = 'First';
        $config['div'] = 'openrequest_List_submitted'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_openrequestdata_i_submitted';
        $config['total_rows'] = $totalRec_submitted;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination1->initialize($config);



        //get the  data
        $data['cases'] = $this->mcase->openrequestData(array('limit' => $this->perPage));
        $data['cases_submitted'] = $this->mcase->openrequestData_submitted(array('limit' => $this->perPage));
        $data['filter'] = $this->input->post('filter');

        $data['title'] = "Open request for data";
        $data['page_name'] = 'open_requestdata';
        $data['main'] = 'open_requestdata';
        $data['page_name'] = 'open-req_for_data';
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    // to view cases assigned to user for image request
    public function ajaxpagination_openrequestdata() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //total rows count
        $totalRec = $this->mcase->count_requestdata();

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'openrequest_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_openrequestdata';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination->initialize($config);

        //get the posts data
        $data['cases'] = $this->mcase->openrequestData(array('start' => $offset, 'limit' => $this->perPage));
        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Open request for data";
        // $data['main'] = 'ajax_answer_opencase';
        // $this->load->vars($data);
        $this->load->view('ajax_requestopen_data', $data, false);
    }

    public function ajaxpagination_openrequestdata_i_submitted() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //total rows count
        $totalRec = $this->mcase->count_requestdata_i_submitted();

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'openrequest_List_submitted'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajaxpagination_openrequestdata_i_submitted';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;

        $this->ajax_pagination->initialize($config);

        //get the posts data
        $data['cases'] = $this->mcase->openrequestData_submitted(array('start' => $offset, 'limit' => $this->perPage));
        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Open request for data";
        // $data['main'] = 'ajax_answer_opencase';
        // $this->load->vars($data);
        $this->load->view('ajax_requestopen_data_i_submitted', $data, false);
    }

    // to upload the  image on request open data page
    public function requestDataUpload() {
        $this->load->library('form_validation');

        if ($this->input->post('action') && $this->input->post('action') != "") {

            $return = $this->mcase->saverequestimage();

            if ($return) {
                $this->session->set_flashdata('success', 'Data has been submitted successfully.');
            } else {
                $this->session->set_flashdata('error', 'Error, Try again later.');
            }
            redirect('cases/openrequest');
        } else {
            $case_id = $this->uri->segment(3);
            $data['cases'] = $this->mcase->getSingleCase($case_id);
            $d = array('case_id' => $case_id, 'pageid' => 4);
            $data['nextid'] = $this->mcase->next_case($d);
            $data_request = $this->mcase->getCaseRequestData($case_id, $this->session->userdata('u_userid'));
            $data['special_requests'] = trim($data_request['comment']);
            $data['img_req_hospital_id'] = $data_request['img_req_hospital_id'];

            if ($data['img_req_hospital_id'] == "")
                redirect(site_url('/cases/openrequest'));
            $data['specific_selectbox'] = $this->mcase->getspecificselectbox($case_id, $this->session->userdata('u_userid'), $data['img_req_hospital_id']);

            $data['title'] = "Open Cases Awaiting Your Feedback";
            $data['main'] = 'case_upload_image';
            $this->load->vars($data);
            $this->load->view('template/template');
        }
    }

    //to forward the image reqest to another doctor
    public function forward() {

        $this->load->library('form_validation');

        $return = $this->mcase->savesendcasetodoctor();


        if ($return == "success") {
            $this->session->set_flashdata('success', 'Your case has been successfully forwarded');
        } else {
            $this->session->set_flashdata('error', 'Error, Try again later.');
        }


        redirect('cases/openrequest');
    }

    // to view cases submitted by user 
    // your case results
    public function yourcase() {
        // print_r($_POST); die;
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $data = array();
        $config['per_page'] = 10;


        $params = array(
            'filter' => $this->input->post('filter'),
            'filter1' => $this->input->post('filter1'),
            'start' => $offset,
            'limit' => $config['per_page'],
        );
        //total rows count for  cases_submitted
        $data['cases_submitted'] = $this->mcase->case_i_submitted($params);
        $data['cases_answer'] = $this->mcase->case_i_answer($params);

        $params['count'] = true;
        unset($params['limit']);
        $totalRec_submitted = $this->mcase->case_i_submitted($params);
        //echo $totalRec_submitted;die;
        //total rows count cases_answer
        $totalRec_answer = $this->mcase->case_i_answer($params);

        //pagination configuration for cases_submitted
        $config['first_link'] = 'First';
        $config['div'] = 'case_i_submitted_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajax_case_i_submitted';
        $config['total_rows'] = $totalRec_submitted;


        $this->ajax_pagination->initialize($config);

        //pagination configuration for cases_answer
        $config['first_link'] = 'First';
        $config['div'] = 'case_i_answer_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajax_case_i_answer';
        $config['total_rows'] = $totalRec_answer;

        $this->ajax_pagination1->initialize($config);

        //echo '<pre>';
        //print_r($data['cases_submitted']); 
        // print_r($data['cases_answer']); 
        //die;
        $data['filter1'] = $this->input->post('filter1');
        $data['filter'] = $this->input->post('filter');
        $data['title'] = "Your Case Results";
        $data['page_name'] = 'your_case';
        $data['main'] = 'your_case';
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    // to view cases submitted by user 
    public function ajax_case_i_submitted() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }


        $data = array();
        $config['per_page'] = 10;


        $params = array(
            'filter' => $this->input->post('filter'),
            'start' => $offset,
            'limit' => $config['per_page'],
        );

        //get the  data
        $data['cases_submitted'] = $this->mcase->case_i_submitted($params);

        $params['count'] = true;
        unset($params['limit']);
        //total rows count for  cases_submitted
        $totalRec_submitted = $this->mcase->case_i_submitted($params);

        //pagination configuration for cases_submitted
        $config['first_link'] = 'First';
        $config['div'] = 'case_i_submitted_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajax_case_i_submitted';
        $config['total_rows'] = $totalRec_submitted;

        $this->ajax_pagination->initialize($config);

        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Cases I Submiited";
        $this->load->view('ajax_case_i_submitted', $data, false);
    }

    // to view cases assigned to user for comments
    public function ajax_case_i_answer() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $data = array();
        $config['per_page'] = 10;


        $params = array(
            'filter1' => $this->input->post('filter1'),
            'start' => $offset,
            'limit' => $config['per_page'],
        );

        //get the  data
        $data['cases_answer'] = $this->mcase->case_i_answer($params);
        //print_r($data['cases_answer']);
        //die;
        $params['count'] = true;
        unset($params['limit']);
        //total rows count for  cases_submitted
        $totalRec_answer = $this->mcase->case_i_answer($params);

        //pagination configuration for cases_answer
        $config['first_link'] = 'First';
        $config['div'] = 'case_i_answer_List'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/ajax_case_i_answer';
        $config['total_rows'] = $totalRec_answer;

        $this->ajax_pagination1->initialize($config);


        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Cases I Answered";
        $this->load->view('ajax_case_i_answer', $data, false);
    }

    // to fetch the answer submitted by various doctor on that case
    public function top_answer() {
        $request = array(
            'case_id' => $this->input->post('case_id'),
            'speciality_id' => $this->input->post('speciality_id'),
        );

        $topanswer = $this->mcase->getanswerdetaillist($request);
        //echo '<pre>';
        //print_r($topanswer);
        if (count($topanswer) > 0) {
            $details = "";
            foreach ($topanswer as $key => $value) {
                $value->comments = "<b>Additional Comments : </b>" . $value->comments;
                $value->comments = wordwrap($value->comments, 70, "<br/>", true);
                if ($value->specific_answers != '0') {
                    $details = $details . '<b>' . $value->enterby . '</b> : ' . $value->spec_text . '<br>' . $value->comments . '<br>';
                } else {
                    $details = $details . '<b>' . $value->enterby . '</b> : ' . $value->other_answers . '<br>' . $value->comments . '<br>';
                }
            }
            echo $details;
        } else {
            echo 'No Record Found';
        }

        exit;
    }

    // to search the case on specific criteria 
    public function search_case() {


        $data = array();

        //total rows count
        $filter = array(
            'pname' => $this->input->post('pname'),
            'submitted_by' => $this->input->post('submitted_by'),
            'cancer_type' => $this->input->post('cancer_type'),
            'pathlogy' => $this->input->post('pathlogy'),
            'status' => $this->input->post('status'),
            'dob' => $this->input->post('dob'),
            'stage' => $this->input->post('Stage'),
            'stage1' => $this->input->post('Stage1')
        );
        $cancersubcat = array();
        if ($this->input->post('cancer_type')) {
            $id = $this->input->post('cancer_type');
            $query = "Select * from cancersubcategories where cancer_id='" . $id . "'";
            $cancersubcat = $this->mcustom->getselectedata($query);
        }
        $data['cancersubcat'] = $cancersubcat;
        $totalRec = $this->mcase->count_searchCase($filter);
        //  echo $totalRec; die;
        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'search_case_filter'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/search_case_list';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['search_filter'] = $filter;
        $params = array(
            $filter,
            'limit' => $config['per_page'],
        );
        $this->ajax_pagination->initialize($config);

        //get the  data
        $data['caselist'] = $this->mcase->search_CaseList($params);
        $session = $this->mcase->next_id($params);



        $data['cancertype'] = $this->mcustom->getCancertype();
        $data['title'] = "Your Case Results";
        $data['main'] = 'search_case';
        $data['page_name'] = 'search_case';
        $data['filter'] = $filter;
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    // to search the case on specific criteria 
    public function search_case_list() {



        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //total rows count
        $filter = array(
            'pname' => $this->input->post('pname'),
            'submitted_by' => $this->input->post('submitted_by'),
            'cancer_type' => $this->input->post('cancer_type'),
            'pathlogy' => $this->input->post('pathlogy'),
            'status' => $this->input->post('status'),
            'dob' => $this->input->post('dob'),
            'stage' => $this->input->post('stage'),
            'stage1' => $this->input->post('stage1')
        );
        $totalRec = $this->mcase->count_searchCase($filter);


        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'search_case_filter'; //parent div tag id
        $config['base_url'] = base_url() . 'cases/search_case_list';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['search_filter'] = $filter;
        $params = array(
            $filter,
            'start' => $offset,
            'limit' => $config['per_page'],
        );
        $this->ajax_pagination->initialize($config);

        //get the posts data
        $data['caselist'] = $this->mcase->search_CaseList($params);
        $data['filter'] = $this->input->post('filter');
        //load the view
        $data['title'] = "Open Cases Awaiting Your Feedback";
        // $data['main'] = 'ajax_answer_opencase';
        // $this->load->vars($data);
        $this->load->view('search_case_list_filter', $data, false);
    }

    // to create report for hospital admin

    public function create_report() {
		
        if ($this->input->post('action') && $this->input->post('action') != "") {
            $selectedData = $this->input->post('my_multi_select1');
            if (count($selectedData) > 0) {
                $this->mcase->getReport();
            } else {
                $this->session->set_flashdata('error', 'Please Move items from the left box to the right box to generate the reports you desire.');
            }
        }

        $data['page_name'] = 'create_reports';
        $data['title'] = "Create Report";
        $data['main'] = 'create_report';
        $this->load->vars($data);
        $this->load->view('template/template');
    }

    public function editCase() {
        $this->load->library('form_validation');
        if ($this->input->post('action') && $this->input->post('action') != "") {
            $case_id = $this->input->post('case_id');
            $return = $this->mcase->case_edit_image();
            if ($return) {
                $this->session->set_flashdata('success', 'Data has been updated successfully.');
            } else {
                $this->session->set_flashdata('error', 'Error, Try again later.');
            }
            redirect('cases/editCase/' . $case_id);
        } else {
            $case_id = $this->uri->segment(3);
            $data['cases'] = $this->mcase->case_detail($case_id);
            $data['title'] = "Edit Case";
            $data['main'] = 'edit_case';
            $this->load->vars($data);
            $this->load->view('template/template');
        }
    }

    public function deleteImage() {
        if ($this->input->post('action') && $this->input->post('action') != "") {
            $return = $this->mcase->case_delete_image();
            if ($return) {
                $this->session->set_flashdata('success', 'Image has been deleted successfully.');
            } else {
                $this->session->set_flashdata('error', 'Error, Try again later.');
            }
        }
    }

    public function submittedDataUpload() {
        $this->load->library('form_validation');

        if ($this->input->post('action') && $this->input->post('action') != "") {
            
            $case_id = $this->input->post('case_id');
            $return = $this->mcase->request_data_edit();
            if ($return) {
                $this->session->set_flashdata('success', 'Data has been updated successfully.');
            } else {
                $this->session->set_flashdata('error', 'Error, Try again later.');
            }
            redirect('cases/submittedDataUpload/' . $case_id);
        } else {
            $case_id = $this->uri->segment(3);
           $cases = $this->mcase->case_detail($case_id);
            $data['cases'] = $cases;
            $speciality = $this->session->userdata('speciality_id');
            switch ($speciality):
                case 8:
                    $spec = "Radiology";
                    $data['images'] = (array) $cases->image_data->radiology;
                    $data['summary'] = $cases->image_data->radiology_summary;
                    break;
                case 11:
                    $spec = "Genetics";
                    $data['images'] = (array) $cases->image_data->genetics;
                    $data['summary'] =  $cases->image_data->genetics_summary;
                    break;
                case 2:
                    $spec = "Hospital Administration";
                    $data['images'] = (array) $cases->image_data->administrator;
                    $data['summary'] =  $cases->image_data->administrator_summary;
                    break;
                case 6:
                    $spec = "Pathology";
                    $data['images'] = (array) $cases->image_data->pathology;
                    $data['summary'] =  $cases->image_data->pathology_summary;
                    break;
                
               
                //path

            endswitch;
            //$data['cases'] = $this->mcase->getSingleCase_submitted($case_id);
            
            $d = array('case_id' => $case_id, 'pageid' => 5);
            $data['nextid'] = $this->mcase->next_case($d);
            $data_request = $this->mcase->getCaseRequestData($case_id, $this->session->userdata('u_userid'));
            $data['special_requests'] = trim($data_request['comment']);
            $data['img_req_hospital_id'] = $data_request['img_req_hospital_id'];

            if ($data['img_req_hospital_id'] == "")
                redirect(site_url('/cases/openrequest'));
            $data['specific_selectbox'] = $this->mcase->getspecificselectbox($case_id, $this->session->userdata('u_userid'), $data['img_req_hospital_id']);

            $data['title'] = "Open Cases Awaiting Your Feedback";
            $data['main'] = 'case_upload_image_submitted';
            $this->load->vars($data);
            $this->load->view('template/template');
        }
    }
    
    

}

?>