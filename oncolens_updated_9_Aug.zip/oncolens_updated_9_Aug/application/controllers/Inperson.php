<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inperson extends CI_Controller {

    public function __construct() {
        parent::__construct();


        if (!isset($_SESSION['u_userid'])) {


            redirect(site_url('/'));
        }

        if($this->session->userdata('speciality_id') == HOSPITAL_ADMIN_SPECILITY && $this->router->fetch_method()!="faq"){
            redirect('tumorboard/view');
        }

        $this->load->model('minperson');
        $this->load->library('Ajax_pagination');
        $this->perPage = 10;
    }

    //tumor board list in which case are assigned

    public function index() {

        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $limit = $this->config->item('per_page');

        $tumor_board = $this->mcustom->get_tumor_board();
        $t = array();
        if(count($tumor_board)>0){
            foreach($tumor_board as $tumor){
                $t[] = $tumor->tumor_id;
            }
        }

        $filter = array(

            'tumorboard' =>$t,
            'days'  => $this->input->post('filter'),
            'limit' => $limit,
            'offset' => $offset
        );




        $data['result']= $this->minperson->inperson_tumorboard($filter);
        $data['p']= $page;
        $filter['count'] = true;
        unset($filter['limit']);
        $total_rows = $this->minperson->inperson_tumorboard($filter);

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'tumor_List'; //parent div tag id
        $config['base_url'] = base_url() . 'inperson/index';
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $this->config->item('per_page');
        $this->ajax_pagination->initialize($config);


        $data['title'] = "Upcoming In-Person Tumor Boards";

        if (isset($page) && $page>=0) {
          $this->load->view('ajax_inperson_tumorboard', $data, false);
        }else{
            $data['page_name'] = 'inperson_tumorboard';
            $data['main'] = 'inperson_tumorboard';
            $this->load->vars($data);
            $this->load->view('template/template');
        }

    }


    //Case information assigned to a particular tumor board
    public function tumorboard_case(){
        $id = $this->uri->segment(3);
        if(empty($id)){
            redirect(site_url('/inperson'));
        }

        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $limit = $this->config->item('per_page');

        $filter = array(
            'id' => $id,
            'limit' => $limit,
            'offset' => $offset
        );

        $data['id']= $id;
        $data['hospital']= $this->minperson->inperson_tumorboard_hospitals($filter);
        $data['result']= $this->minperson->inperson_tumorboard_details($filter);
        $session= $this->minperson->next_id($filter);
        $data['p']= $page;
        $filter['count'] = true;
        unset($filter['limit']);
        $total_rows = $this->minperson->inperson_tumorboard_details($filter);

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'tumor_List'; //parent div tag id
        $config['base_url'] = base_url() . 'inperson/tumorboard_case/'.$id;
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $this->config->item('per_page');
        $config['uri_segment'] = 4;
        $config['show_count'] = true;

        $this->ajax_pagination->initialize($config);
        if (isset($page) && $page>=0) {
            $this->load->view('ajax_inperson_tumorboard_casedetail', $data, false);
        }else{
            $data['page_name'] = 'inperson_tumorboard_casedetail';
            $data['main'] = 'inperson_tumorboard_casedetail';
            $this->load->vars($data);
            $this->load->view('template/template');
        }
    }


      // fag page details
    public function faq(){

        $data['result']= $this->minperson->faq_details($filter);

            $data['page_name'] = 'faq-login';
            $data['main'] = 'faq-login';
            $this->load->vars($data);
            $this->load->view('template/template');

    }



}
