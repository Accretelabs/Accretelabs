<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Contactus extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('captcha');
    }
    
    //contact page view and working
    public function index(){
        $this->load->helper('captcha');
        
        if($this->input->post('action') && $this->input->post('action')!=""  && $this->form_validation->run('contact_form') == TRUE) {
            if(strtolower($this->input->post('captcha')) == strtolower($this->session->userdata('secret'))){
                $this->load->library('email');
                $this->load->model('memail_templates', 'memail');
		$template = $this->memail->get_template_by_name('contactus');
                if($template){
                    $mail_data = array(
                        'LOGO' => base_url()."images/oncolence-logo.png",
                        'NAME' => $this->input->post('name'),
                        'EMAIL' => $this->input->post('email'),
                        'SUBJECT' => $this->input->post('subject'),
                        'COMMENT' => $this->input->post('comments'),
                    );
                    $subject =  $template['subject'];
                    $mailmessage =  $template['body'];
                    foreach ($mail_data as $key=>$val){
                        $mailmessage = str_replace("{{".$key."}}", $val, $mailmessage);
                    }
//                $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png'></p><br/>";
//                $mailmessage .= "<p><b>Contact us Inquiry</b></p><br/>";
//                $mailmessage .= "<p>Your Name: ".$this->input->post('name')."</p>";
//                $mailmessage .= "<p>Email Address: ".$this->input->post('email')."</p>";
//                $mailmessage .= "<p>Subject: ".$this->input->post('subject')."</p>";
//                $mailmessage .= "<p>Message: ".$this->input->post('comments')."</p>";
//                $mailmessage .= "<p><br></p>";
                //$mailmessage .= "<p>Thank you</p>";
                //$mailmessage .= "<p><b>" . $userinfo->fname . ' ' . $userinfo->lname . "</b></p>";
                
                $from_email = $this->input->post('email');
                $from_name = $this->input->post('name');
                $message = $this->input->post('comments');
                
                $this->email->set_mailtype("html");
                $this->email->from($from_email,'Oncolens Contact us Inquiry' );
                $this->email->to('support@oncolens.com', 'Oncolens Support');
                $this->email->subject($subject);
                $this->email->message($mailmessage);
                $this->email->send();
                }
                $this->session->set_flashdata('success', 'Contact us inquiry has been submitted.');
                
            }else{
                 $this->session->set_flashdata('error', 'Verification code is invalid.');
            }
            
        }

        // numeric random number for captcha
        $random_number = $this->generateRandomString('6');
        $vals = array(
            'word' => $random_number,
            'img_path' =>$_SERVER['DOCUMENT_ROOT'].'/assets/images/captcha/',
            'img_url' => base_url().'assets/images/captcha',
            'font_path' =>$_SERVER['DOCUMENT_ROOT'].'/assets/fonts/times_new_yorker.ttf',
            'img_width' => '250',
            'img_height' => 50,
            'word_length'   => 8,
            'font_size'     => 20,
            'img_id'        => 'Imageid',
            'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            'expiration' => 7200,
            'colors'        => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 40, 40)
            )
        );
        
        //print_r($vals);
        $cap = create_captcha($vals);
     //  print_r($cap);
        // die;
        $this->session->set_userdata('secret', $cap['word']);
        $data['title'] = "Contact us";
        $data['main'] = 'contact_us';
        $data['image'] = $cap['image'];
        $this->load->vars($data);
        $this->load->view('template/cms_template');
    }
      // numeric random number for captcha
    public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    // to generate the captcha
    public function new_captcha(){
       $this->load->helper('captcha');
        // numeric random number for captcha
        $random_number = $this->generateRandomString('6');
        $captcha = create_captcha(array(
             'word' => $random_number,
            'img_path' => $_SERVER['DOCUMENT_ROOT'].'/assets/images/captcha/',
            'img_url' => base_url().'assets/images/captcha',
            'font_path' =>$_SERVER['DOCUMENT_ROOT'].'/assets/fonts/times_new_yorker.ttf',
            'img_width' => '250',
            'img_height' => 50,
            'word_length'   => 8,
            'font_size'     => 20,
            'img_id'        => 'Imageid',
            'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            'expiration' => 7200,
            'colors'        => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 40, 40)
                )
        ));
        
        
      
        
        $this->session->set_userdata('secret', $captcha['word']);
        $filename = base_url().'assets/images/captcha/' . $captcha['time'] . '.jpg';
        echo $filename;
//        $this->output->set_header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
//        $this->output->set_header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
//        $this->output->set_header('Cache-Control: post-check=0, pre-check=0', FALSE);
//        $this->output->set_header('Pragma: no-cache');
//        $this->output->set_header('Content-Type: image/jpeg');
//        $this->output->set_header('Content-Length: ' . filesize($filename));
//        echo read_file($filename);
    }
    
}   

?>
