<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

   // to get ip of client machine
    public function get_ip() {
		//Just get the headers if we can or else use the SERVER global
		if ( function_exists( 'apache_request_headers' ) ) {
			$headers = apache_request_headers();
		} else {
			$headers = $_SERVER;
		}
		//Get the forwarded IP if it exists
		if ( array_key_exists( 'X-Forwarded-For', $headers ) && filter_var( $headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$the_ip = $headers['X-Forwarded-For'];
		} elseif ( array_key_exists( 'HTTP_X_FORWARDED_FOR', $headers ) && filter_var( $headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 )
		) {
			$the_ip = $headers['HTTP_X_FORWARDED_FOR'];
		} else {

			$the_ip = filter_var( $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
		}
		return $the_ip;
	}


        // validate the credentials of user and redirecting to a particular page depending upon the user type

    public function index() {
        if ($this->session->userdata('u_userid')) {
            redirect('inperson', 'refresh');
        }
        $this->load->library('form_validation');
        $this->load->library('bcrypt'); // bcrypt library is used to encrpty the password

        if ($this->input->post('action') && $this->input->post('action') != "" && $this->form_validation->run('login_form') == TRUE) {



            $u = $this->input->post('username');
            $pw = $this->input->post('password');
            $lt = $this->input->post('logype');
            $data['username'] = $u;
            $this->musers->verifyAdmin($u, $pw, $lt); // to verfiy the password enter by user
            if ($this->session->userdata('u_userid') && $this->session->userdata('u_userid') > 0) {
             $ip_address = $this->get_ip();

        $query = $this->db->query("insert into login_stats set user_id=".$this->session->userdata('u_userid').",user_login_time='".date('Y-m-d h:i:s')."',user_ip_address='".$ip_address."'");


                    if ($this->session->userdata('speciality_id') == PATHOLOGY_SPECILITY || $this->session->userdata('speciality_id') == RADIOLOGY_SPECILITY ||$this->session->userdata('speciality_id')== GENETICS_SPECILITY) {
                    redirect('cases/openrequest');
                }
                else if( $this->session->userdata('speciality_id') == HOSPITAL_ADMIN_SPECILITY)
                {

                    redirect('tumorboard/view');
                }
                else   {
                    redirect('/inperson');
                }
            } else {
                  redirect(site_url('/'));
            }

        }

        $data['title'] = "User Login";
        $data['main'] = "user_login";
        $this->load->vars($data);
        //$this->load->view('user_login', $data);
        $this->load->view('template/login_template');
    }


    // to logout the user and destroy the session
    public function logout() {


          if($this->session->userdata('u_userid')!="")
          {
           $ip_address = $this->get_ip();

           $query = $this->db->query("update  login_stats set user_logout_time='".date('Y-m-d h:i:s')."' where  user_id=".$this->session->userdata('u_userid')." and user_ip_address='".$ip_address."' order by stat_id desc limit 1");

          }

        session_destroy();

        $this->session->unset_userdata('u_userid');
        $this->session->unset_userdata('u_username');
        $this->session->unset_userdata('u_name');
        $this->session->unset_userdata('speciality_id');
        $this->session->unset_userdata('hospital_id');
        $this->session->set_flashdata('error', "You have been logged out!");
//		redirect('admin/','refresh');
        redirect(site_url('/'));
    }

    public function autologin($url = NULL) {
        echo ltrim(rtrim('OK'));
    }


       public function forgotpassword() {
        $this->load->library('form_validation');
        $this->load->helper('string');

        if ($this->input->post('action') && $this->input->post('action') != "" && $this->form_validation->run('forgot_form') == TRUE) {
            $data = $this->musers->forgotpassword();
            $this->session->set_flashdata('message', $data);
            redirect(site_url('/users/forgotpassword'));
        } else {
            $data['title'] = "Forgot Password";
            $data['main'] = 'forgot_password';
            $this->load->vars($data);
            $this->load->view('template/login_template');
        }
    }


    public function resetpassword() {
        $this->load->library('form_validation');
        $this->load->helper('string'); // to generate random password

        $data['logtype'] = $this->uri->segment(3);
        $data['token'] = $this->uri->segment(4);
        if ($this->input->post('action') && $this->input->post('action') != "" && $this->form_validation->run('reset_form') == TRUE) {
            if ($this->input->post('pass')) {
                $this->musers->resetpassword();
                redirect(current_url());
            }
        } else {
            // check link expire or exist in system
            $return = $this->musers->check_reset_url($data);
        }
        $data['title'] = "Reset Password";
        $data['main'] = 'reset_password';
        $this->load->vars($data);
        $this->load->view('template/login_template');
    }

     // to change the user password
    public function changepassword() {
        $this->load->library('bcrypt');
        if ($this->input->post('action') && $this->input->post('action') != "" && $this->form_validation->run('chnagepass_form') == TRUE) {
            $this->musers->changepassword();
            redirect(site_url('/users/changepassword'));
        }
        $data['title'] = "Change Password";
        $data['main'] = 'change_password';
        $this->load->vars($data);
        $this->load->view('template/template');
    }


    // According to Hippa after 90 days user is forced to change password
    public function force_changepassword() {
        $this->load->library('bcrypt');
        if ($this->input->post('action') && $this->input->post('action') != "" && $this->form_validation->run('force_change_form') == TRUE) {
            $return = $this->musers->forcechangepassword();
            if ($return) {
                redirect(site_url('/users/'));
            } else {
                redirect(site_url('/users/force_changepassword/'));
            }
        }
        $data['title'] = "Force Change Password";
        $data['main'] = 'force_change_password';
        $this->load->vars($data);
        $this->load->view('template/login_template');
    }

    // to get profile data of user
    public function profile() {
		$login_id=$this->session->userdata('u_userid');
		if(!isset($login_id) && empty($login_id)){
			redirect('/');
		}
        $this->load->library('Ajax_pagination');
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        $limit = $this->config->item('per_page');
        $filter = array(
            'limit' => $limit,
            'offset' => $offset
        );
        $condition = 'id='. $this->session->userdata('u_userid');

        $u_notificatin = $this->mcustom->get_field('notification','users',$condition);
        $data['notification'] = $u_notificatin;
        $data['result'] = $this->musers->profile($filter);
        $data['hospitals'] = $this->musers->get_our_hospitals();
        $data['user_speciality_id'] = $this->session->userdata('speciality_id');
        $data['p'] = $page;
        $filter['count'] = true;
        unset($filter['limit']);
        $total_rows = $this->musers->profile($filter);

        //pagination configuration
        $config['first_link'] = 'First';
        $config['div'] = 'profile_List'; //parent div tag id
        $config['base_url'] = base_url() . 'users/profile';
        $config['total_rows'] = $total_rows;
        $config['per_page'] = $this->config->item('per_page');
        //echo $this->db->last_Query(); die;
        $this->ajax_pagination->initialize($config);

        if (isset($page) && $page >= 0) {
            $this->load->view('ajax_profile', $data, false);
        } else {
            $data['main'] = 'profile';
            $this->load->vars($data);
            $this->load->view('template/template', $data);
        }
    }


    // to add tumor board
    public function tumor_board_add() {

        $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
        $hospital_id = $this->input->post('hospital_id');
        $doctor_id = $this->input->post('doctor_id');
        $tumor_id = $this->input->post('tumar_id');

        $data = array();

        $data['value'] = $this->musers->hospitalTumorboard_edit($hospital_doctor_tumor_board_id, $hospital_id, $doctor_id, $tumor_id);

        $data['tumor'] = $this->musers->gettumor($hospital_id);

        // print($data['value']);
        $this->load->vars($data);
        $this->load->view('tumor_board_edit_model');
    }


     // to update  tumor board assosicated with user
    public function change_tumor_data() {
        $data = $this->musers->changeTumorboard($this->input->post('doctor_id'));
        //redirect(site_url('admin/user/add/'.$id));
        if ($data) {
            echo 'success';
        } else {
            echo 'failure';
        }
    }

      // to get list of tumor board
    public function tumorboardlist() {
        $list = $this->musers->tumorboard_list($this->input->post('id'), $this->input->post('tumorid'));
        echo $list;
    }

     // to add tumor board
    public function tumorboard_add() {
        $return = $this->musers->tumor_board_add();
        echo 'success';
        exit;
    }


      // delete the tumor board
    public function tumor_board_delete() {
        $return = $this->musers->tumor_board_delete($this->input->post('id'));
        if ($return) {
            $this->session->set_flashdata('success', 'Tumor board has been deleted successfully.');
            echo 'success';
        } else {
            $this->session->set_flashdata('success', 'Please try again later.');
            echo 'failure';
        }
        exit;
    }

    //to unsubscibe the notification of email weekly
    public function unsubscribe($id=false){

        $return = $this->musers->unsubsribes(($id));
        if ($return)
          $data['success'] = "Successfully unsubscribe";
        else
            $data['error'] =  "Error try again later";

        $data['title'] = "Unsubscribe";
        $data['main'] = 'unsubscribe';
        $data['id'] = $id;
        $this->load->vars($data);
        $this->load->view('template/login_template');
    }

        //to subscibe the notification of email weekly
    public function update_unsubscribe(){
        $return = $this->musers->unsubsribes($this->input->post('id'),$this->input->post('notification'));
        if($return && $this->input->post('notification') =='1')
            echo "You have successfully subscribed from weekly notifications";
        if($return && $this->input->post('notification') =='0')
            echo "You have successfully unsubscribed from weekly notifications";
        exit;
    }



}
