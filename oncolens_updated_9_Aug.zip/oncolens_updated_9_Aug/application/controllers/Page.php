<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mpage');
    }
    
    // to manage pages like Terms and Conditions,How it Works,About Us,Privacy Policy,FAQ Login,FAQ Home,Support
    public function index($slug='') {
       
        $data =array();
        
        $result = $this->mpage->pages($slug);
        if($result){
            $data['result'] = $result[0];
            $data['title'] = $result[0]->page_name;
            $data['main'] = 'page';
            $data['slug'] = $slug;
            $this->load->vars($data);
            $this->load->view('template/cms_template');
        }else{
            show_404();
        }

        
    }  
    
}    
?>