<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cronjob extends CI_Controller {

	
	public function index()
	{
              $this->load->model('mcron');
              $data=  $this->mcron->getusers();
              die;
	}
}
