<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Postcase extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!isset($_SESSION['u_userid'])) {
            redirect(site_url('/'));
        }
        // if($this->session->userdata('speciality_id') == HOSPITAL_ADMIN_SPECILITY){
        //     redirect('tumorboard/view');
        // }
        $this->load->model('mcase');
    }

    public function index() {
        $data['title'] = "Dashboard";
        $data['main'] = 'userdashboard';
        //$data['admins'] = $this->MAdmins->getAllUsers();
        //$data['cancercategory'] = $this->mcustom->getAllrows('cancercategories');
        //$data['race'] = $this->mcustom->getAllrows('race');
        $this->load->vars($data);
        $this->load->view('template/template', $data);
    }

    public function userdashboard() {
        $salt =$this->config->item('salt');
        if ($this->input->post('action') && $this->input->post('action') != "") {
            // to save the post case data
            $data = $this->input->post();
            $this->load->model('mcase');
            $data = $this->mcase->savepostcase($data);
            $this->session->set_flashdata('message', $data);
            redirect(site_url('dashboard/thanks'));

        } elseif ($this->uri->segment(3)) {
            // for repost case
            $caseid = $this->uri->segment(3);
            $query = "select *, AES_DECRYPT(case_description, '$salt') AS case_description, AES_DECRYPT(name,'$salt') as name, AES_DECRYPT(dob,'$salt') as dob,AES_DECRYPT(race,'$salt') as race from case_history where id=" .$caseid;
            $data['casedetail'] = $this->mcustom->getselectedata($query);

            if(isset($data['casedetail'][0]->cancer_id))
            {
            $query = "Select * from cancersubcategories where cancer_id='" . $data['casedetail'][0]->cancer_id . "' and is_active='1'";
            $data['cancersubcat'] = $this->mcustom->getselectedata($query);
            $data['case_id'] = $caseid;
            $data['title'] = "Post Case";
            $data['main'] = 'userpostcase';
            $data['page_name'] = 'userpostcase';
            //$data['admins'] = $this->MAdmins->getAllUsers();
            $query = "Select * from cancercategories where cancer_status='1' order by order_id";
            $data['cancercategory'] = $this->mcustom->getselectedata($query);
            $data['race'] = $this->mcustom->getAllrows('race');
            $this->load->vars($data);
            $this->load->view('template/template', $data);
            }
         else {
             redirect('postcase/userdashboard');
        }
        }

         else {

            $data['title'] = "Post Case";
            $data['main'] = 'userpostcase';
            $data['page_name'] = 'userpostcase';
            //$data['admins'] = $this->MAdmins->getAllUsers();
            $query = "Select * from cancercategories where cancer_status='1'  order by order_id";
            $data['cancercategory'] = $this->mcustom->getselectedata($query);
            $data['race'] = $this->mcustom->getAllrows('race');
            $this->load->vars($data);
            $this->load->view('template/template', $data);
          }
    }

     // to fetch cancer subcategories
    public function cancersubcat() {
        $id = $this->uri->segment(3);
        $query = "Select * from cancersubcategories where cancer_id='" . $id . "' and is_active='1' ";
        $cancersubcat = $this->mcustom->getselectedata($query);
        if (!empty($id)) {
            if ($cancersubcat) {
                echo json_encode($cancersubcat);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

      // to fetch data from neoadjuvant table according to cancer type and cancer mode
    public function getneoadjuvant() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
//        $options = array('cancer_id' => $cancer_id, 'cancer_mode' => $cancer_mode);
//         $cancersubcat = $this->mcustom->getcancersubcat('neoadjuvant',$options);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Neoadjuvant_Therapy']) {
                echo json_encode($cancersubcat['Neoadjuvant_Therapy']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

       // to fetch data from Definitive_Surgery table according to cancer type and cancer mode
    public function getdefinitive() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Definitive_Surgery']) {
                echo json_encode($cancersubcat['Definitive_Surgery']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

     //to fetch data from Systemic Therapy table according to cancer type and cancer mode
    public function getsystemic() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Systemic_Therapy']) {
                echo json_encode($cancersubcat['Systemic_Therapy']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

      // to fetch data from adjuvanthormonaltherapy table according to cancer type and cancer mode
    public function gethormonal() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Hormonal_Therapy']) {
                echo json_encode($cancersubcat['Hormonal_Therapy']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }


        exit();
    }

     //to fetch data from Adjuvant Radiation table according to cancer type and cancer mode
    public function getradiation() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Adjuvant_Radiation']) {
                echo json_encode($cancersubcat['Adjuvant_Radiation']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

     //to fetch data from oncotype table according to cancer type and cancer mode
    public function getoncotype() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Oncotype']) {
                echo json_encode($cancersubcat['Oncotype']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

    // to fetch data from mammaprint table according to cancer type and cancer mode
    public function getmammaprint() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Mammaprint']) {
                echo json_encode($cancersubcat['Mammaprint']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

       // to fetch data from metasurgery table according to cancer type and cancer mode
    public function getmetasurgery() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Meta_Surgery']) {
                echo json_encode($cancersubcat['Meta_Surgery']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }



     // to fetch data from metaradiation table according to cancer type and cancer mode
    public function getmetaradiation() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Meta_Radiation']) {
                echo json_encode($cancersubcat['Meta_Radiation']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

     // to fetch data from chemotherapy table according to cancer type and cancer mode
     public function getchemotherapy() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['chemotherapy']) {
                echo json_encode($cancersubcat['chemotherapy']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

     // to fetch data from metasystemictherapy table according to cancer type and cancer mode
    public function getmetasystemic() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $cancersubcat = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
        if (!empty($cancer_id)) {
            if ($cancersubcat['Meta_Systemic']) {
                echo json_encode($cancersubcat['Meta_Systemic']);
                exit;
            } else {
                echo json_encode($cancersubcat);
                exit;
            }
        } else {
            echo json_encode($cancersubcat);
            exit;
        }

        exit();
    }

    // list of tumor board for post 4 page
    public function gettumorboard() {
        //$query = "SELECT a.*,b.id AS tumor_board_id,c.*,h.hospital_network,(SELECT COUNT(hdtb.id) FROM `hospital_doctor_tumor_board` hdtb LEFT JOIN hospital_doctor hd ON hd.hospital_doctor_id = hdtb.hospital_doctor_id  WHERE hd.`doctor_id`!=87 AND hdtb.tumor_id = c.tumor_id) AS usercount FROM hospital_doctor AS a INNER JOIN hospital_doctor_tumor_board AS b ON a.hospital_doctor_id = b.hospital_doctor_id INNER JOIN tumor_board AS c ON c.tumor_id = b.tumor_id INNER JOIN hospital_network AS h ON a.hospital_id = h.id WHERE a.doctor_id =  " . $_SESSION['u_userid']." and c.is_active='1'";
        $query = "SELECT a.*,b.id AS tumor_board_id,c.*,h.hospital_network,(SELECT COUNT(hdtb.id) FROM `hospital_doctor_tumor_board` hdtb LEFT JOIN hospital_doctor hd ON hd.hospital_doctor_id = hdtb.hospital_doctor_id inner join users u on u.id=hd.doctor_id WHERE hd.`doctor_id`!=" . $_SESSION['u_userid']." AND hdtb.tumor_id = c.tumor_id and hd.is_active='1' and hdtb.is_active='1' and u.is_active='1') AS usercount FROM hospital_doctor AS a INNER JOIN hospital_doctor_tumor_board AS b ON a.hospital_doctor_id = b.hospital_doctor_id INNER JOIN tumor_board AS c ON c.tumor_id = b.tumor_id INNER JOIN hospital_network AS h ON a.hospital_id = h.id WHERE a.doctor_id =  " . $_SESSION['u_userid']." and c.is_active='1'  and a.is_active='1' and b.is_active='1' and h.is_active='1'";

        if ($this->session->userdata('speciality_id') == HOSPITAL_ADMIN_SPECILITY) {
            //Different query for Hospital Admins
            $query = "SELECT a.*,b.id AS tumor_board_id,c.*,h.hospital_network, (SELECT Count(hdtb.id) FROM `hospital_doctor_tumor_board` hdtb LEFT JOIN hospital_doctor hd ON hd.hospital_doctor_id = hdtb.hospital_doctor_id  INNER JOIN users u  ON u.id = hd.doctor_id WHERE hd.`doctor_id` !=" . $_SESSION['u_userid'] . " AND hdtb.tumor_id = c.tumor_id AND hd.is_active = '1' AND hdtb.is_active = '1' AND u.is_active = '1') AS usercount FROM hospital_doctor AS a INNER JOIN hospital_tumor_board AS b ON a.hospital_id = b.hospital_id INNER JOIN tumor_board AS c ON c.tumor_id = b.tumor_id INNER JOIN hospital_network AS h ON a.hospital_id = h.id WHERE  a.doctor_id =" . $_SESSION['u_userid'] . " AND c.is_active = '1' AND a.is_active = '1' AND h.is_active = '1'";
        }

        $gettumordata = $this->mcustom->getselectedata($query);
        if ($gettumordata) {
            echo json_encode($gettumordata);
            exit;
        } else {
            echo json_encode($gettumordata);
            exit;
        }
    }

     // list of providers for data request for post case 3 page
    public function getproviders() {
        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
//        $hospital = "Select hospital_id from hospital_doctor as a inner join hospital_network as b on b.id = a.hospital_id where doctor_id = '" . $_SESSION['u_userid'] . "'";
//        $hospitalid = $this->mcustom->getselectedata($hospital);

        $hospital_id = $this->musers->get_user_hospitals($_SESSION['u_userid']);

        $query = "SELECT b.id, a.hospital_doctor_id, a.hospital_id, b.fname, b.lname, h.hospital_network, d.speciality_name FROM hospital_doctor AS a INNER JOIN users AS b ON a.doctor_id = b.id INNER JOIN speciality_hospital_doctor AS c ON c.hospital_doctor_id = a.hospital_doctor_id INNER JOIN speciality AS d ON d.speciality_id = c.speciality_id INNER JOIN hospital_network AS h ON a.hospital_id = h.id WHERE a.hospital_id in ($hospital_id) and a.doctor_id != " . $_SESSION['u_userid'] . " and b.speciality_id !=" . HOSPITAL_ADMIN_SPECILITY ." and a.is_active='1' and  b.is_active='1' and h.is_active='1' ORDER BY h.hospital_network, d.speciality_name, b.fname";

        $getprovidersdata = $this->mcustom->getselectedata($query);
        if ($getprovidersdata) {
            echo json_encode($getprovidersdata);
            exit;
        } else {
            echo json_encode($getprovidersdata);
            exit;
        }
    }


      // list of specialty for data request for post case 3 page
    public function getspecialty() {
        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
//        $hospital = "Select hospital_id from hospital_doctor as a inner join hospital_network as b on b.id = a.hospital_id where doctor_id = '" . $_SESSION['u_userid'] . "'";
//        $hospitalid = $this->mcustom->getselectedata($hospital);
        $hospital_id = $this->musers->get_user_hospitals($_SESSION['u_userid']);


        $query = "SELECT b.speciality_id,c.speciality_name,  h.hospital_network, a.hospital_id FROM hospital_doctor as a inner join speciality_hospital_doctor as b on a.hospital_doctor_id = b.hospital_doctor_id inner join speciality as c on c.speciality_id = b.speciality_id  INNER JOIN hospital_network AS h ON a.hospital_id = h.id  where a.hospital_id in ($hospital_id) and a.doctor_id != '" . $_SESSION['u_userid'] . "' and b.speciality_id !=" . HOSPITAL_ADMIN_SPECILITY ." and a.is_active='1'  and h.is_active='1' group by b.speciality_id, a.hospital_id order by c.speciality_name,  h.hospital_network";

        $getspecialtydata = $this->mcustom->getselectedata($query);
        if ($getspecialtydata) {
            echo json_encode($getspecialtydata);
            exit;
        } else {
            echo json_encode($getspecialtydata);
            exit;
        }
    }

    public function getmultipledata() {
        $cancer_id = $this->uri->segment(3);
        $cancer_mode = $this->uri->segment(4);
        $getfinalarray = $this->mcase->getmultipledata($cancer_id, $cancer_mode);
    }

     // load the content page
    public function getcontent() {
        $data['cancer_id'] = $this->uri->segment(3);
        $data['cancer_mode'] = $this->uri->segment(4);
        if ($this->uri->segment(5))
            $data['caseid'] = $this->uri->segment(5);
        $this->load->view('contentpage', $data);
    }

    // list of specifc question for post last page
    public function getspecificques() {
        $query = "SELECT * FROM specificquestion";
        $getspecialtydata = $this->mcustom->getselectedata($query);

        foreach($getspecialtydata as $key => $val) {
            if($val->spec_question == "Other - please specify as a comment below") {
                $item = $getspecialtydata[$key];
                unset($getspecialtydata[$key]);
                array_push($getspecialtydata, $item);
                break;
            }
        }

        if ($getspecialtydata) {
            echo json_encode($getspecialtydata);
            exit;
        } else {
            echo json_encode($getspecialtydata);
            exit;
        }
    }

    //to get name for  pathlogy image request in post  case
    public function getpathlogy() {
        $userdata = $_SESSION['u_userid'];
        $pathlogydata = $this->mcase->getimagerequest($userdata);

        if (count($pathlogydata) > 0) {
            if ($pathlogydata['pathology_image']) {
                echo json_encode($pathlogydata['pathology_image']);
                exit;
            } else {
                echo json_encode($pathlogydata);
                exit;
            }
        } else {
            echo json_encode($pathlogydata);
            exit;
        }

        exit();
    }

     //to get name for  radiology image request in post  case
    public function getradiology() {
        $userdata = $_SESSION['u_userid'];
        $radiology = $this->mcase->getimagerequest($userdata);

        if (count($radiology) > 0) {
            if ($radiology['radiology_image']) {
                echo json_encode($radiology['radiology_image']);
                exit;
            } else {
                echo json_encode($radiology);
                exit;
            }
        } else {
            echo json_encode($radiology);
            exit;
        }

        exit();
    }

     //to get name for  genetics image request in post  case
    public function getgenetics() {
        $userdata = $_SESSION['u_userid'];
        $genetics = $this->mcase->getimagerequest($userdata);
        if (count($genetics) > 0) {
            if ($genetics['genetic_image']) {
                echo json_encode($genetics['genetic_image']);
                exit;
            } else {
                echo json_encode($genetics);
                exit;
            }
        } else {
            echo json_encode($genetics);
            exit;
        }

        exit();
    }

}
