<?php

class Mcase extends CI_Model {

    // to save posted case data
    public function savepostcase($postData) {
        $cancer_id = (isset($postData['cancer_id']) ? $postData['cancer_id'] : '');
        $user_id = $_SESSION['u_userid'];
        $pathology = (isset($postData['pathology']) ? $postData['pathology'] : '');
        $cancer_mode = (isset($postData['cancersettting']) ? $postData['cancersettting'] : '0' );
        $name = (isset($postData['p_name']) ? $this->db->escape($postData['p_name']) : '' );
        $dob = (isset($postData['dob']) ? $postData['dob'] : '');
        $race = (isset($postData['race']) ? $postData['race'] : '');
        $sex = (isset($postData['gender']) ? $postData['gender'] : '');
        $performance_status = (isset($postData['performance_status']) ? $postData['performance_status'] : '');
        $menopausal_status = (isset($postData['menopausal_status']) ? $postData['menopausal_status'] : '');
        $final_case_assignment = "";
//$situation = (isset($postData['situation'];
        $diagnosis_date = (isset($postData['dbiopsy']) ? $postData['dbiopsy'] : '');
        $relapse_date = (isset($postData['drelapse']) ? $postData['drelapse'] : '');
        $other_serious_medical_conditions = (isset($postData['other_serious_medical_conditions']) ? $postData['other_serious_medical_conditions'] : '');
        $family_history = (isset($postData['family_history']) ? $postData['family_history'] : '');
        $pathology_others_text = (isset($postData['pathology_others_text']) ? $postData['pathology_others_text'] : '');
        $userinfo = $this->mcustom->getUser($user_id);


        $other_solid_array = array(12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46);

        $salt = $this->config->item('salt');
        $this->db->set('name', 'AES_ENCRYPT(' . $name . ',"' . $salt . '")', FALSE);
        $this->db->set('sex', "AES_ENCRYPT('$sex','$salt')", FALSE);
        $dob = date('Y-m-d', strtotime($dob));
        $this->db->set('dob', "AES_ENCRYPT('$dob','$salt')", FALSE);
        $this->db->set('race', "AES_ENCRYPT('$race','$salt')", FALSE);

        $question = $postData['add_comts'];



        $case_description = $this->db->escape($postData['preview'] . '<br>Topic for Discussion:<br>' . $question);

        //$this->db->set('case_description','AES_ENCRYPT("$case_description","$salt")',FALSE);
        $this->db->set('case_description', 'AES_ENCRYPT(' . $case_description . ',"' . $salt . '")', FALSE);
        $userData = array(
            'performance_status' => $performance_status,
            'menopausal_status' => $menopausal_status,
            'cancer_id' => $cancer_id,
            'cancer_mode' => $cancer_mode,
            'pathology' => db_clean(trim($pathology)),
            'diagnosis_date' => date('Y-m-d', strtotime($diagnosis_date)),
            'relapse_date' => date('Y-m-d', strtotime($relapse_date)),
            'pathology_others_text' => db_clean(trim($pathology_others_text)),
            'other_serious_medical_conditions' => db_clean(trim($other_serious_medical_conditions)),
            'family_history' => db_clean(trim($family_history)),
            'case_submit_date' => date('Y-m-d H:i:s'),
            'case_entered_by' => $user_id,
            'case_status' => '1',
            'is_deleted' => '0',
            'is_forwarded' => '0',
            'forwarded_case_id' => '0',
            'case_updated_date' => date('Y-m-d H:i:s'),
            'assigned_hospital' => $postData['hid']
                //'case_description' => $_COOKIE['preview']
        );

        $this->db->insert('case_history', $userData);
        $last_id = $this->db->insert_id();
        if ($last_id) {
            if (isset($cancer_id) && !empty($cancer_id) && $cancer_id == 1) {
                if ($cancer_mode == "0") {
                    $case_id = $last_id;
                    if ($postData['cancerleft'] == 'L') {
                        $breast_side = (isset($postData['cancerleft']) ? $postData['cancerleft'] : '');
                        $er_pr = (isset($postData['erprL']) ? $postData['erprL'] : '' );
                        $her2 = (isset($postData['her2L']) ? $postData['her2L'] : '');
                        $time_of_statging = (isset($postData['time_of_statgingL']) ? $postData['time_of_statgingL'] : '');
                        $multicentric = (isset($postData['mutlicentricL']) ? $postData['mutlicentricL'] : '');
                        $multifocal = (isset($postData['multifocalL']) ? $postData['multifocalL'] : '' );
                        $t = (isset($postData['stagingtL']) ? $postData['stagingtL'] : '');
                        $n = (isset($postData['stagingnL']) ? $postData['stagingnL'] : '');
                        $m = (isset($postData['stagingmL']) ? $postData['stagingmL'] : '');
                        $grade = (isset($postData['staginggradeL']) ? $postData['staginggradeL'] : '');
                        $stage = (isset($postData['stagingstageL']) ? (int) $postData['stagingstageL'] : 0);
                        $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapyL']) ? (int) $postData['neoadjuvant_therapyL'] : 0);
                        $definitive_surgery = (isset($postData['definitive_surgeryL']) ? (int) $postData['definitive_surgeryL'] : 0);
                        $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapyL']) ? (int) $postData['adjuvant_systemic_therapyL'] : 0);
                        $adjuvant_hormonal_therapy = (isset($postData['adjuvant_hormonal_therapyL']) ? (int) $postData['adjuvant_hormonal_therapyL'] : 0);
                        $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapyL']) ? (int) $postData['adjuvant_radiation_therapyL'] : 0);
                        $oncotype = (isset($postData['oncotypeL']) ? (int) $postData['oncotypeL'] : 0);
                        $mammaprint = (isset($postData['mammaprintL']) ? (int) $postData['mammaprintL'] : 0);
                        $postsurgerystage = (isset($postData['post_surgery_stageL']) ? $postData['post_surgery_stageL'] : NULL);
                        $provide_details_case = (isset($postData['provide_details_caseL']) ? $postData['provide_details_caseL'] : '');
                        $genetic_testing_result = (isset($postData['genetic_testing_resultL']) ? $postData['genetic_testing_resultL'] : '');


                        if ($er_pr == "" && $her2 == "" && $time_of_statging == "" && $multicentric == "" && $multifocal == "" && $t == "" && $n == "" && $m == "" && $grade == "" && $stage == "0" && $neoadjuvant_therapy == "0" && $definitive_surgery == "0" && $adjuvant_systemic_therapy == "0" && $adjuvant_hormonal_therapy == "0" && $adjuvant_radiation_therapy == "0" && $oncotype == "0" && $mammaprint == "0" && $postsurgerystage == NUll && $provide_details_case == "" && $genetic_testing_result == "") {

                        } else {



                            if (isset($case_id) && $case_id != '' && $case_id != '0' && $postData['cancerleft'] == 'L') {
                                $nonmetastatic_query = array('case_id' => $case_id,
                                    'breast_side' => $breast_side,
                                    'er_pr' => $er_pr,
                                    'her2' => $her2,
                                    'time_of_statging' => $time_of_statging,
                                    'mutlicentric' => $multicentric,
                                    'multifocal' => $multifocal,
                                    't' => $t,
                                    'n' => $n,
                                    'm' => $m,
                                    'grade' => $grade,
                                    //          'pathology_others_text' => db_clean(trim($pathology_others_text)),
                                    'stage' => $stage,
                                    'neoadjuvant_therapy' => $neoadjuvant_therapy,
                                    'definitive_surgery' => $definitive_surgery,
                                    'adjuvant_systemic_therapy' => $adjuvant_systemic_therapy,
                                    'adjuvant_hormonal_therapy' => $adjuvant_hormonal_therapy,
                                    'adjuvant_radiation_therapy' => $adjuvant_radiation_therapy,
                                    'oncotype' => $oncotype,
                                    'mammaprint' => $mammaprint,
                                    'post_surgery_stage' => $postsurgerystage,
                                    'provide_details_case' => $provide_details_case,
                                    'genetic_testing_result' => $genetic_testing_result
                                );
                                $this->db->insert('case_breast_non_metastatic', $nonmetastatic_query);
                                $nonmetastatic_query_id = $this->db->insert_id();
                                if ($nonmetastatic_query_id) {
// flash data sucess;
                                } else {
// flash data error;
                                }
                            }
                        }
                    }
                    if ($postData['cancerright'] == 'R') {


                        $breast_side = (isset($postData['cancerright']) ? $postData['cancerright'] : '');
                        $er_pr = (isset($postData['erprR']) ? $postData['erprR'] : '' );
                        $her2 = (isset($postData['her2R']) ? $postData['her2R'] : '');
                        $time_of_statging = (isset($postData['time_of_statgingR']) ? $postData['time_of_statgingR'] : '');
                        $multicentric = (isset($postData['mutlicentricR']) ? $postData['mutlicentricR'] : '');
                        $multifocal = (isset($postData['multifocalR']) ? $postData['multifocalR'] : '' );
                        $t = (isset($postData['stagingtR']) ? $postData['stagingtR'] : '');
                        $n = (isset($postData['stagingnR']) ? $postData['stagingnR'] : '');
                        $m = (isset($postData['stagingmR']) ? $postData['stagingmR'] : '');
                        $grade = (isset($postData['staginggradeR']) ? $postData['staginggradeR'] : '');
                        $stage = (isset($postData['stagingstageR']) ? (int) $postData['stagingstageR'] : 0);
                        $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapyR']) ? (int) $postData['neoadjuvant_therapyR'] : 0);
                        $definitive_surgery = (isset($postData['definitive_surgeryR']) ? (int) $postData['definitive_surgeryR'] : 0);
                        $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapyR']) ? (int) $postData['adjuvant_systemic_therapyR'] : 0);
                        $adjuvant_hormonal_therapy = (isset($postData['adjuvant_hormonal_therapyR']) ? (int) $postData['adjuvant_hormonal_therapyR'] : 0);
                        $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapyR']) ? (int) $postData['adjuvant_radiation_therapyR'] : 0);
                        $oncotype = (isset($postData['oncotypeR']) ? (int) $postData['oncotypeR'] : 0);
                        $mammaprint = (isset($postData['mammaprintR']) ? (int) $postData['mammaprintR'] : 0);
                        $postsurgerystage = (isset($postData['post_surgery_stageR']) ? $postData['post_surgery_stageR'] : NULL);
                        $provide_details_case = (isset($postData['provide_details_caseR']) ? $postData['provide_details_caseR'] : '');
                        $genetic_testing_result = (isset($postData['genetic_testing_resultR']) ? $postData['genetic_testing_resultR'] : '');
                        if (isset($case_id) && $case_id != '' && $case_id != '0' && $postData['cancerright'] == 'R') {

                            if ($er_pr == "" && $her2 == "" && $time_of_statging == "" && $multicentric == "" && $multifocal == "" &&
                                    $t == "" && $n == "" && $m == "" && $grade == "" && $stage == "0" && $neoadjuvant_therapy == "0" && $definitive_surgery == "0" && $adjuvant_systemic_therapy == "0" && $adjuvant_hormonal_therapy == "0" &&
                                    $adjuvant_radiation_therapy == "0" && $oncotype == "0" && $mammaprint == "0" && $postsurgerystage == NUll &&
                                    $provide_details_case == "" && $genetic_testing_result == "") {

                            } else {

                                $nonmetastatic_query = array('case_id' => $case_id,
                                    'breast_side' => $breast_side,
                                    'er_pr' => $er_pr,
                                    'her2' => $her2,
                                    'time_of_statging' => $time_of_statging,
                                    'mutlicentric' => $multicentric,
                                    'multifocal' => $multifocal,
                                    't' => $t,
                                    'n' => $n,
                                    'm' => $m,
                                    'grade' => $grade,
                                    //          'pathology_others_text' => db_clean(trim($pathology_others_text)),
                                    'stage' => $stage,
                                    'neoadjuvant_therapy' => $neoadjuvant_therapy,
                                    'definitive_surgery' => $definitive_surgery,
                                    'adjuvant_systemic_therapy' => $adjuvant_systemic_therapy,
                                    'adjuvant_hormonal_therapy' => $adjuvant_hormonal_therapy,
                                    'adjuvant_radiation_therapy' => $adjuvant_radiation_therapy,
                                    'oncotype' => $oncotype,
                                    'mammaprint' => $mammaprint,
                                    'post_surgery_stage' => $postsurgerystage,
                                    'provide_details_case' => $provide_details_case,
                                    'genetic_testing_result' => $genetic_testing_result
                                );
                                $this->db->insert('case_breast_non_metastatic', $nonmetastatic_query);
                                $nonmetastatic_query_id = $this->db->insert_id();
                                if ($nonmetastatic_query_id) {
// flash data sucess;
                                } else {
// flash data error;
                                }
                            }
                        }
                    }
                } elseif ($cancer_mode == "1" || $cancer_mode == "2") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $er_pr = (isset($postData['erpr']) ? $postData['erpr'] : '');
                    $her2 = (isset($postData['her2']) ? $postData['her2'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '' );
                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $surgery = (isset($postData['surgery']) ? $postData['surgery'] : '');
                    if (is_array($surgery)) {
                        $surgery = implode(",", $surgery);
                    }
                    $radiation_recieved = (isset($postData['radiation_recieved']) ? $postData['radiation_recieved'] : '');
                    if (is_array($radiation_recieved)) {
                        $radiation_recieved = implode(",", $radiation_recieved);
                    }
                    $systemic_therapy = (isset($postData['systemic_therapy']) ? $postData['systemic_therapy'] : '');
                    if (is_array($systemic_therapy)) {
                        $systemic_therapy = implode(",", $systemic_therapy);
                    }
                    $cancer_recurrence_others_text = (isset($postData['cancer_recurrence_others_text']) ? $postData['cancer_recurrence_others_text'] : '');
                    if (empty($cancer_recurrence_others_text)) {
                        $cancer_recurrence_others_text = "";
                    }
                    $other_details = (isset($postData['other_details']) ? $postData['other_details'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0')
                        $nonmetastatic_query = array('case_id' => $case_id,
                            'areaof_cancer_recurrence' => $areaof_cancer_recurrence,
                            'cancer_recurrence_others_text' => $cancer_recurrence_others_text,
                            //'tnbc' => $t,
                            'er_pr' => $er_pr,
                            'her2' => $her2,
                            't' => $t,
                            'n' => $n,
                            'm' => $m,
                            'grade' => $grade,
                            'stage' => $stage,
                            'surgery' => $surgery,
                            'radiation_recieved' => $radiation_recieved,
                            'systemic_therapy' => $systemic_therapy,
                            'other_details' => $other_details
                        );
                    if ($cancer_mode == '1') {
                        $this->db->insert('case_breast_recurrent', $nonmetastatic_query);
                    } elseif ($cancer_mode == '2') {
                        $this->db->insert('case_breast_metastatic', $nonmetastatic_query);
                    }
                    $recurrent_query_id = $this->db->insert_id();


                    if ($recurrent_query_id) {
// flash data sucess;
                    } else {
// flash data error;
                    }
                }
            } elseif (isset($cancer_id) && !empty($cancer_id) && $cancer_id == 2) {
                if ($cancer_mode == "0") {
                    $case_id = $last_id;
                    if ($postData['cancerleft'] == 'L') {
                        $lung_side = (isset($postData['cancerleft']) ? $postData['cancerleft'] : '');
                        $egfr = (isset($postData['egfrL']) ? $postData['egfrL'] : '');
                        $alk = (isset($postData['alkL']) ? $postData['alkL'] : '');
                        $time_of_statging = (isset($postData['time_of_statgingL']) ? $postData['time_of_statgingL'] : '');
                        $pulmonary_function = (isset($postData['pulmonary_functionL']) ? $postData['pulmonary_functionL'] : '');
                        $t = (isset($postData['stagingtL']) ? $postData['stagingtL'] : '');
                        $n = (isset($postData['stagingnL']) ? $postData['stagingnL'] : '');
                        $m = (isset($postData['stagingmL']) ? $postData['stagingmL'] : '');
                        $stage = (isset($postData['stagingstageL']) ? (int) $postData['stagingstageL'] : 0);
                        $grade = (isset($postData['gradeL']) ? $postData['gradeL'] : '');
                        $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapyL']) ? (int) $postData['neoadjuvant_therapyL'] : 0);
                        $definitive_surgery = (isset($postData['definitive_surgeryL']) ? (int) $postData['definitive_surgeryL'] : 0);
                        $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapyL']) ? (int) $postData['adjuvant_systemic_therapyL'] : 0);
                        $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapyL']) ? (int) $postData['adjuvant_radiation_therapyL'] : 0 );
                        $postsurgerystage = (isset($postData['post_surgery_stageL']) ? $postData['post_surgery_stageL'] : '');
                        $provide_details_case = (isset($postData['provide_details_caseL']) ? $postData['provide_details_caseL'] : '');
                        $genetic_testing_result = (isset($postData['genetic_testing_resultL']) ? $postData['genetic_testing_resultL'] : '');
                        if (isset($case_id) && $case_id != '' && $case_id != '0' && $lung_side == 'L' && $postData['cancerleft'] == 'L') {

                            if ($egfr == "" && $alk == "" && $time_of_statging == "" && $pulmonary_function == "" && $t == "" && $n == "" && $m == "" && $stage == "0" && $grade == "" && $neoadjuvant_therapy == "0" && $definitive_surgery == "0" && $adjuvant_systemic_therapy == "0" && $adjuvant_radiation_therapy == "0" && $postsurgerystage == "" && $provide_details_case == "" && $genetic_testing_result == "") {

                            } else {


                                $nonmetastatic_query = $this->db->query("Insert into case_lung_non_metastatic (case_id,lung_side,egfr,alk,time_of_statging,pulmonary_function,t,n,m,grade,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,adjuvant_radiation_therapy,post_surgery_stage,provide_details_case,genetic_testing_result)values('" . $case_id . "','" . $lung_side . "','" . $egfr . "','" . $alk . "','" . $time_of_statging . "','" . $pulmonary_function . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $adjuvant_systemic_therapy . "','" . $adjuvant_radiation_therapy . "','" . $postsurgerystage . "','" . $provide_details_case . "','" . $genetic_testing_result . "')");
                            }
                        }
                    }
                    if ($postData['cancerright'] == 'R') {
                        $lung_side = (isset($postData['cancerright']) ? $postData['cancerright'] : '');
                        $egfr = (isset($postData['egfrR']) ? $postData['egfrR'] : '');
                        $alk = (isset($postData['alkR']) ? $postData['alkR'] : '');
                        $time_of_statging = (isset($postData['time_of_statgingR']) ? $postData['time_of_statgingR'] : '');
                        $pulmonary_function = (isset($postData['pulmonary_functionR']) ? $postData['pulmonary_functionR'] : '');
                        $t = (isset($postData['stagingtR']) ? $postData['stagingtR'] : '');
                        $n = (isset($postData['stagingnR']) ? $postData['stagingnR'] : '');
                        $m = (isset($postData['stagingmR']) ? $postData['stagingmR'] : '');
                        $stage = (isset($postData['stagingstageR']) ? (int) $postData['stagingstageR'] : 0);
                        $grade = (isset($postData['gradeR']) ? $postData['gradeR'] : '');
                        $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapyR']) ? (int) $postData['neoadjuvant_therapyR'] : 0);
                        $definitive_surgery = (isset($postData['definitive_surgeryR']) ? (int) $postData['definitive_surgeryR'] : 0);
                        $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapyR']) ? (int) $postData['adjuvant_systemic_therapyR'] : 0);
                        $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapyR']) ? (int) $postData['adjuvant_radiation_therapyR'] : 0 );
                        $postsurgerystage = (isset($postData['post_surgery_stageR']) ? $postData['post_surgery_stageR'] : '');
                        $provide_details_case = (isset($postData['provide_details_caseR']) ? $postData['provide_details_caseR'] : '');
                        $genetic_testing_result = (isset($postData['genetic_testing_resultR']) ? $postData['genetic_testing_resultR'] : '');
                        if (isset($case_id) && $case_id != '' && $case_id != '0' && $lung_side == 'R' && $postData['cancerright'] == 'R') {

                            if ($egfr == "" && $alk == "" && $time_of_statging == "" && $pulmonary_function == "" && $t == "" && $n == "" && $m == "" && $stage == "0" && $grade == "" && $neoadjuvant_therapy == "0" && $definitive_surgery == "0" && $adjuvant_systemic_therapy == "0" && $adjuvant_radiation_therapy == "0" && $postsurgerystage == "" && $provide_details_case == "" && $genetic_testing_result == "") {

                            } else {
                                $nonmetastatic_query = $this->db->query("Insert into case_lung_non_metastatic (case_id,lung_side,egfr,alk,time_of_statging,pulmonary_function,t,n,m,grade,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,adjuvant_radiation_therapy,post_surgery_stage,provide_details_case,genetic_testing_result)values('" . $case_id . "','" . $lung_side . "','" . $egfr . "','" . $alk . "','" . $time_of_statging . "','" . $pulmonary_function . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $adjuvant_systemic_therapy . "','" . $adjuvant_radiation_therapy . "','" . $postsurgerystage . "','" . $provide_details_case . "','" . $genetic_testing_result . "')");
                            }
                        }
                    }
                    if ($nonmetastatic_query) {
// $response = "Data saved successfully";
                    } else {
// throw new Exception("There is some error in saving the data.", 403);
                    }
                } elseif ($cancer_mode == "1" || $cancer_mode == "2") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $egfr = (isset($postData['egfr']) ? $postData['egfr'] : '');
                    $alk = (isset($postData['alk']) ? $postData['alk'] : '');
                    $ros1 = (isset($postData['ros1']) ? $postData['ros1'] : '');
                    $kras = (isset($postData['kras']) ? $postData['kras'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    if (is_array($t)) {
                        $t = implode(",", $t);
                    }
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    if (is_array($n)) {
                        $n = implode(",", $n);
                    }
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $grade = (isset($postData['grade']) ? $postData['grade'] : '');
                    $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapy']) ? (int) $postData['neoadjuvant_therapy'] : 0);
                    $definitive_surgery = (isset($postData['definitive_surgery']) ? (int) $postData['definitive_surgery'] : 0);


                    $systemic_therapy = (isset($postData['adjuvant_systemic_therapy']) ? $postData['adjuvant_systemic_therapy'] : '');



                    if (is_array($systemic_therapy)) {
                        $systemic_therapy = implode(",", $systemic_therapy);
                    }



                    $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapy']) ? (int) $postData['adjuvant_radiation_therapy'] : 0);
                    $palliative_radiation = (isset($postData['adjuvant_radiation_therapy']) ? (int) $postData['adjuvant_radiation_therapy'] : 0);
                    $cancer_recurrence_others_text = (isset($postData['other_detail']) ? $postData['other_detail'] : '');
                    $other_details = (isset($postData['other_details']) ? $postData['other_details'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0') {
                        if ($cancer_mode == '1') {
                            $recurrent_query = $this->db->query("Insert into case_lung_recurrent (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,egfr,alk,ros1,kras,t,n,m,grade,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,adjuvant_radiation_therapy,other_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $cancer_recurrence_others_text . "','" . $egfr . "','" . $alk . "','" . $ros1 . "','" . $kras . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $systemic_therapy . "','" . $adjuvant_radiation_therapy . "','" . $other_details . "')");
                        } elseif ($cancer_mode == '2')
                            $metastatic_query = $this->db->query("Insert into case_lung_metastatic (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,efgr,alk,ros1,kras,t,n,m,grade,stage,systemic_therapy,palliative_radiation,other_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $cancer_recurrence_others_text . "','" . $egfr . "','" . $alk . "','" . $ros1 . "','" . $kras . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $systemic_therapy . "','" . $palliative_radiation . "','" . $other_details . "')");
                    }
                }
            }
            elseif (isset($cancer_id) && !empty($cancer_id) && $cancer_id == 3) {
                if ($cancer_mode == "0") {
                    $case_id = $last_id;
                    $obstruction = (isset($postData['obstruction']) ? $postData['obstruction'] : '');
                    $preforation = (isset($postData['perforation']) ? $postData['perforation'] : '');
                    $mmr = (isset($postData['mmr']) ? $postData['mmr'] : '');
                    $k167 = (isset($postData['k167']) ? $postData['k167'] : '');
                    // $er_pr = (isset($postData['er_pr'];
                    $braf = (isset($postData['kars']) ? $postData['kars'] : '');
                    $time_of_statging = (isset($postData['time_of_statging']) ? $postData['time_of_statging'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    if (is_array($t)) {
                        $t = implode(",", $t);
                    }
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    if (is_array($n)) {
                        $n = implode(",", $n);
                    }
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapy']) ? (int) $postData['neoadjuvant_therapy'] : 0);
                    $definitive_surgery = (isset($postData['definitive_surgery']) ? (int) $postData['definitive_surgery'] : 0);
                    $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapy']) ? (int) $postData['adjuvant_systemic_therapy'] : 0);
                    $adjuvant_radiation_therapy = (isset($postData['adjuvant_radiation_therapy']) ? (int) $postData['adjuvant_radiation_therapy'] : 0);
                    $oncotype = (isset($postData['oncotype']) ? (int) $postData['oncotype'] : 0);
                    $postsurgerystage = (isset($postData['post_surgery_stage']) ? $postData['post_surgery_stage'] : '');
                    $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                    $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0')
//echo "Insert into case_colon_non_metastatic (case_id,obstruction,preforation,mmr,k167,braf,time_of_statging,t,n,m,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,adjuvant_radiation_therapy,oncotype,provide_details_case,genetic_testing_result,tumor_board,specific_providers,speciality,emailid_1,emailid_2,emailid_3,pathologist_id_for_images,radiologist_id_for_images,genetic_id_for_images,specific_question,my_thoughts)values('" . $case_id . "','" . $obstruction . "','".$preforation."','".$mmr."','".$k167."','" . $braf . "','" . $time_of_statging . "','" . $t . "','" . $n . "','" . $m . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $adjuvant_systemic_therapy . "','" . $adjuvant_radiation_therapy . "','" . $oncotype . "','" . $provide_details_case . "','" . $genetic_testing_result . "','" . $tumor_board . "','" . $specific_providers . "','" . $speciality . "','" . $emailid_1 . "','" . $emailid_2 . "','" . $emailid_3 . "','" . $pathology_images . "','".$radiology_images."','" . $genetic_images . "','" . $specific_question . "','" . $my_thoughts . "')";
                        $nonmetastatic_query = $this->db->query("Insert into case_colon_non_metastatic (case_id,obstruction,preforation,mmr,k167,braf,time_of_statging,t,n,m,grade,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,adjuvant_radiation_therapy,oncotype,post_surgery_stage,provide_details_case,genetic_testing_result)values('" . $case_id . "','" . $obstruction . "','" . $preforation . "','" . $mmr . "','" . $k167 . "','" . $braf . "','" . $time_of_statging . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $adjuvant_systemic_therapy . "','" . $adjuvant_radiation_therapy . "','" . $oncotype . "','" . $postsurgerystage . "','" . $provide_details_case . "','" . $genetic_testing_result . "')");
                    if ($nonmetastatic_query) {
//$response = "Data saved successfully";
                    } else {
// throw new Exception("There is some error in saving the data.", 403);
                    }
                } elseif ($cancer_mode == "1" || $cancer_mode == "2") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $kras = (isset($postData['kras']) ? $postData['kras'] : '');
                    $other = (isset($postData['other']) ? $postData['other'] : '');
                    $braf = (isset($postData['braf']) ? $postData['braf'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    if (is_array($t)) {
                        $t = implode(",", $t);
                    }
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    if (is_array($n)) {
                        $n = implode(",", $n);
                    }
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    $surgery = (isset($postData['surgery']) ? $postData['surgery'] : '');
                    $radiation_recieved = (isset($postData['radiation_recieved']) ? $postData['radiation_recieved'] : '');
                    $systemic_therapy = (isset($postData['systemic_therapy']) ? $postData['systemic_therapy'] : '');
                    if (is_array($systemic_therapy)) {
                        $systemic_therapy = implode(",", $systemic_therapy);
                    }
                    $additional_details = (isset($postData['other_detail']) ? $postData['other_detail'] : '');
                    $cancer_recurrence_others_text = (isset($postData['cancer_recurrence_others_text']) ? $postData['cancer_recurrence_others_text'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0')
                        if ($cancer_mode == '1')
                            $nonmetastatic_query = $this->db->query("Insert into case_colon_recurrent (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,kras,braf,other,t,n,m,grade,stage,surgery,radiation_recieved,systemic_therapy,additional_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $additional_details . "','" . $kras . "','" . $braf . "','" . $other . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $surgery . "','" . $radiation_recieved . "','" . $systemic_therapy . "','" . $cancer_recurrence_others_text . "')");
                    if ($cancer_mode == '2')
                        $nonmetastatic_query = $this->db->query("Insert into case_colon_metastatic (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,kras,braf,other,t,n,m,grade,stage,surgery,radiation_recieved,systemic_therapy,additional_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $additional_details . "','" . $kras . "','" . $braf . "','" . $other . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $surgery . "','" . $radiation_recieved . "','" . $systemic_therapy . "','" . $cancer_recurrence_others_text . "')");
                    if ($nonmetastatic_query) {
//$response = "Data saved successfully";
                    } else {
//throw new Exception("There is some error in saving the data.", 403);
                    }
                }
            } elseif (isset($cancer_id) && !empty($cancer_id) && $cancer_id == 4) {
                if ($cancer_mode == "0") {
                    $case_id = $last_id;
                    $no_of_cores = (isset($postData['no_of_cores']) ? (int) $postData['no_of_cores'] : 0);
                    $positive_number = (isset($postData['positive_number']) ? (int) $postData['positive_number'] : 0);
                    $psa = (isset($postData['psa']) ? $postData['psa'] : '');
                    $gleason_score_primary = (isset($postData['gleason_score_primary']) ? (int) $postData['gleason_score_primary'] : 0);
                    $gleason_score_secondary = (isset($postData['gleason_score_secondary']) ? (int) $postData['gleason_score_secondary'] : 0);
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    if (is_array($t)) {
                        $t = implode(",", $t);
                    }
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    if (is_array($n)) {
                        $n = implode(",", $n);
                    }
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $grade = (isset($postData['grade']) ? $postData['grade'] : 0);
                    $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapy']) ? (int) $postData['neoadjuvant_therapy'] : 0);
                    $definitive_surgery = (isset($postData['definitive_surgery']) ? (int) $postData['definitive_surgery'] : 0);
                    $adjuvant_systemic_therapy = (isset($postData['adjuvant_systemic_therapy']) ? (int) $postData['adjuvant_systemic_therapy'] : 0);
                    $definitive_radiation_therapy = (isset($postData['adjuvant_radiation_therapy']) ? (int) $postData['adjuvant_radiation_therapy'] : 0);
                    $other_details = (isset($postData['other_details']) ? $postData['other_details'] : '');
                    $oncotype = (isset($postData['oncotype']) ? (int) $postData['oncotype'] : 0);
                    $postsurgerystage = (isset($postData['post_surgery_stageL']) ? $postData['post_surgery_stageL'] : '');
                    $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                    $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0')
                        $nonmetastatic_query = $this->db->query("Insert into case_prostate_non_metastatic (case_id,no_of_cores,positive_number,psa,gleason_score_primary,gleason_score_secondary,t,n,m,grade,stage,neoadjuvant_therapy,definitive_surgery,adjuvant_systemic_therapy,definitive_radiation_therapy,other_details,oncotype,post_surgery_stage,provide_details_case,genetic_testing_result)values('" . $case_id . "','" . $no_of_cores . "','" . $positive_number . "','" . $psa . "','" . $gleason_score_primary . "','" . $gleason_score_secondary . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $adjuvant_systemic_therapy . "','" . $definitive_radiation_therapy . "','" . $other_details . "','" . $oncotype . "','" . $postsurgerystage . "', '" . $provide_details_case . "' ,'" . $genetic_testing_result . "')");
                    if ($nonmetastatic_query) {
// $response = "Data saved successfully";
                    } else {
// throw new Exception("There is some error in saving the data.", 403);
                    }
                } elseif ($cancer_mode == "1" || $cancer_mode == "2") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $gleason_score_primary = (isset($postData['gleason_score_primary']) ? (int) $postData['gleason_score_primary'] : 0);
                    $gleason_score_secondary = (isset($postData['gleason_score_secondary']) ? (int) $postData['gleason_score_secondary'] : 0);
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    if (is_array($t)) {
                        $t = implode(",", $t);
                    }
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    if (is_array($n)) {
                        $n = implode(",", $n);
                    }
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $psa = (isset($postData['psa']) ? $postData['psa'] : 0);
                    $stage = (isset($postData['stagingstage']) ? (int) $postData['stagingstage'] : 0);
                    $grade = (isset($postData['grade']) ? $postData['grade'] : '');
                    $neoadjuvant_therapy = (isset($postData['neoadjuvant_therapy']) ? (int) $postData['neoadjuvant_therapy'] : 0);
                    $definitive_surgery = (isset($postData['definitive_surgery']) ? (int) $postData['definitive_surgery'] : 0);
                    $systemic_therapy = (isset($postData['adjuvant_systemic_therapy']) ? $postData['adjuvant_systemic_therapy'] : '');
                    if (is_array($systemic_therapy)) {
                        $systemic_therapy = implode(",", $systemic_therapy);
                    }
                    $definitive_radiation = (isset($postData['adjuvant_radiation_therapy']) ? (int) $postData['adjuvant_radiation_therapy'] : 0);
                    $oncotype = (isset($postData['oncotype']) ? (int) $postData['oncotype'] : 0);
                    $other_details = (isset($postData['cancer_recurrence_others_text']) ? $postData['cancer_recurrence_others_text'] : '');
                    $cancer_recurrence_others_text = (isset($postData['other_detail']) ? $postData['other_detail'] : '');

                    $palliative_radiation = (isset($postData['radiation_recieved']) ? (int) $postData['radiation_recieved'] : 0);

                    if (isset($case_id) && $case_id != '' && $case_id != '0')
                        if ($cancer_mode == '1') {
                            $definitive_surgery = (isset($postData['definitive_surgery']) ? (int) $postData['definitive_surgery'] : 0);

                            $systemic_therapy = (isset($postData['adjuvant_systemic_therapy']) ? $postData['adjuvant_systemic_therapy'] : '');

                            if (is_array($systemic_therapy)) {
                                $systemic_therapy = implode(",", $systemic_therapy);
                            }


                            $nonmetastatic_query = $this->db->query("Insert into case_prostate_recurrent (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,gleason_score_primary,gleason_score_secondary,t,n,m,psa,grade,stage,neoadjuvant_therapy,definitive_surgery,systemic_therapy,definitive_radiation,oncotype,other_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $cancer_recurrence_others_text . "','" . $gleason_score_primary . "','" . $gleason_score_secondary . "','" . $t . "','" . $n . "','" . $m . "','" . $psa . "','" . $grade . "','" . $stage . "','" . $neoadjuvant_therapy . "','" . $definitive_surgery . "','" . $systemic_therapy . "','" . $definitive_radiation . "','" . $oncotype . "','" . $other_details . "')");
                        }

                    if ($cancer_mode == '2') {
                        $definitive_surgery = (isset($postData['surgery']) ? (int) $postData['surgery'] : 0);
                        $systemic_therapy = (isset($postData['systemic_therapy']) ? $postData['systemic_therapy'] : '');


                        if (is_array($systemic_therapy)) {
                            $systemic_therapy = implode(",", $systemic_therapy);
                        }


                        $nonmetastatic_query = $this->db->query("Insert into case_prostate_metastatic (case_id,areaof_cancer_recurrence,cancer_recurrence_others_text,psa,gleason_score_primary,gleason_score_secondary,t,n,m,grade,stage,definitive_surgery,palliative_radiation,systemic_therapy,other_details)values('" . $case_id . "','" . $areaof_cancer_recurrence . "','" . $cancer_recurrence_others_text . "','" . $psa . "','" . $gleason_score_primary . "','" . $gleason_score_secondary . "','" . $t . "','" . $n . "','" . $m . "','" . $grade . "','" . $stage . "','" . $definitive_surgery . "','" . $palliative_radiation . "','" . $systemic_therapy . "','" . $other_details . "')");
                    }

                    if ($nonmetastatic_query) {
// $response = "Data saved successfully";
                    } else {
// throw new Exception("There is some error in saving the data.", 403);
                    }
                }
            } else if (isset($cancer_id) && !empty($cancer_id) && $cancer_id == 11) {


                $case_id = $last_id;
                $surgery = (isset($postData['surgery_hematologic']) ? $postData['surgery_hematologic'] : '');

                $chemotherapy = (isset($postData['chemotherapy_hematologic']) ? $postData['chemotherapy_hematologic'] : '');

                if (is_array($chemotherapy)) {
                    $chemotherapy = implode(",", $chemotherapy);
                }

                $radiationtherapy = (isset($postData['radiationtherapy_hematologic']) ? $postData['radiationtherapy_hematologic'] : '');
                ;
                $other_details = (isset($postData['other_details']) ? $postData['other_details'] : '');
                $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                $alternate_stage = (isset($postData['alternate_stage']) ? $postData['alternate_stage'] : '');
                $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                $t1 = (isset($postData['stagingt1']) ? $postData['stagingt1'] : '');
                $t = $t . $t1;
                $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                $n1 = (isset($postData['stagingn1']) ? $postData['stagingn1'] : '');
                $n = $n . $n1;
                $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                $m1 = (isset($postData['stagingm1']) ? $postData['stagingm1'] : '');
                $m = $m . $m1;
                $stage = (isset($postData['stagingstage']) ? $postData['stagingstage'] : '');
                $stage1 = (isset($postData['stagingstage1']) ? $postData['stagingstage1'] : '');
                $stage = $stage . $stage1;

                $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');


                if (isset($case_id) && $case_id != '' && $case_id != '0') {
                    $nonmetastatic_query = array('case_id' => $case_id,
                        'provide_details_case' => $provide_details_case,
                        'genetic_testing_result' => $genetic_testing_result,
                        'alternate_stage' => $alternate_stage,
                        't' => $t,
                        'n' => $n,
                        'm' => $m,
                        'grade' => $grade,
                        'stage' => $stage,
                        'surgery' => $surgery,
                        'chemotherapy' => $chemotherapy,
                        'radiationtherapy' => $radiationtherapy
//'other_details' => $other_details
                    );
                    $this->db->insert('case_hematologic_general', $nonmetastatic_query);
                    $nonmetastatic_query_id = $this->db->insert_id();
                    if ($nonmetastatic_query_id) {
// flash data sucess;
                    } else {
// flash data error;
                    }
                }
            } else if (isset($cancer_id) && !empty($cancer_id) && in_array($cancer_id, $other_solid_array)) {
                if ($cancer_mode == "0") {
                    $case_id = $last_id;
                    $surgery_other = (isset($postData['surgery_other']) ? $postData['surgery_other'] : '');
                    if (is_array($surgery_other)) {
                        $surgery = implode(",", $surgery_other);
                    }
                    $chemotherapy_other = (isset($postData['chemotherapy_other']) ? $postData['chemotherapy_other'] : '');
                    if (is_array($chemotherapy_other)) {
                        $chemotherapy = implode(",", $chemotherapy_other);
                    }

                    $radiationtherapy = (isset($postData['radiationtherapy_other']) ? $postData['radiationtherapy_other'] : '');
                    $other_details = (isset($postData['other_details']) ? $postData['other_details'] : '');
                    $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                    $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                    $staging_comments = (isset($postData['staging_comments']) ? $postData['staging_comments'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    $t1 = (isset($postData['stagingt1']) ? $postData['stagingt1'] : '');
                    $t = $t . $t1;
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    $n1 = (isset($postData['stagingn1']) ? $postData['stagingn1'] : '');
                    $n = $n . $n1;
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $m1 = (isset($postData['stagingm1']) ? $postData['stagingm1'] : '');
                    $m = $m . $m1;
                    $stage = (isset($postData['stagingstage']) ? $postData['stagingstage'] : '');
                    $stage1 = (isset($postData['stagingstage1']) ? $postData['stagingstage1'] : '');
                    $stage = $stage . $stage1;

                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0') {
                        $nonmetastatic_query = array('case_id' => $case_id,
                            'provide_details_case' => $provide_details_case,
                            'genetic_testing_result' => $genetic_testing_result,
                            'staging_comments' => $staging_comments,
                            't' => $t,
                            'n' => $n,
                            'm' => $m,
                            'grade' => $grade,
                            'stage' => $stage,
                            'surgery' => $surgery,
                            'chemotherapy' => $chemotherapy,
                            'radiationtherapy' => $radiationtherapy
//'other_details' => $other_details
                        );
                        $this->db->insert('case_other_non_metastatic', $nonmetastatic_query);


                        $nonmetastatic_query_id = $this->db->insert_id();
                        if ($nonmetastatic_query_id) {
// flash data sucess;
                        } else {
// flash data error;
                        }
                    }
                } elseif ($cancer_mode == "1") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $surgery_other = (isset($postData['surgery_other']) ? $postData['surgery_other'] : '');
                    if (is_array($surgery_other)) {
                        $surgery = implode(",", $surgery_other);
                    }
                    $chemotherapy_other = (isset($postData['chemotherapy_other']) ? $postData['chemotherapy_other'] : '');
                    if (is_array($chemotherapy_other)) {
                        $chemotherapy = implode(",", $chemotherapy_other);
                    }

                    $radiationtherapy = (isset($postData['radiationtherapy_other']) ? $postData['radiationtherapy_other'] : '');
                    $other_detail = (isset($postData['other_detail']) ? $postData['other_detail'] : '');
                    $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                    $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                    $staging_comments = (isset($postData['staging_comments']) ? $postData['staging_comments'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    $t1 = (isset($postData['stagingt1']) ? $postData['stagingt1'] : '');
                    $t = $t . $t1;
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    $n1 = (isset($postData['stagingn1']) ? $postData['stagingn1'] : '');
                    $n = $n . $n1;
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $m1 = (isset($postData['stagingm1']) ? $postData['stagingm1'] : '');
                    $m = $m . $m1;
                    $stage = (isset($postData['stagingstage']) ? $postData['stagingstage'] : '');
                    $stage1 = (isset($postData['stagingstage1']) ? $postData['stagingstage1'] : '');
                    $stage = $stage . $stage1;

                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0') {
                        $recurrent_query = array('case_id' => $case_id,
                            'areaof_cancer_recurrence' => $areaof_cancer_recurrence,
                            'cancer_recurrence_others_text' => $other_detail,
                            'provide_details_case' => $provide_details_case,
                            'genetic_testing_result' => $genetic_testing_result,
                            'staging_comments' => $staging_comments,
                            't' => $t,
                            'n' => $n,
                            'm' => $m,
                            'grade' => $grade,
                            'stage' => $stage,
                            'surgery' => $surgery,
                            'chemotherapy' => $chemotherapy,
                            'radiationtherapy' => $radiationtherapy,
                                //'other_details' => $other_details
                        );
                        $this->db->insert('case_other_recurrent', $recurrent_query);
                        $recurrent_query_id = $this->db->insert_id();
                        if ($recurrent_query_id) {
// flash data sucess;
                        } else {
// flash data error;
                        }
                    }
                } elseif ($cancer_mode == "2") {
                    $case_id = $last_id;
                    $areaof_cancer_recurrence = (isset($postData['recurrence']) ? $postData['recurrence'] : '');
                    if (is_array($areaof_cancer_recurrence)) {
                        $areaof_cancer_recurrence = implode(",", $areaof_cancer_recurrence);
                    }
                    $surgery_other = (isset($postData['surgery_other']) ? $postData['surgery_other'] : '');
                    if (is_array($surgery_other)) {
                        $surgery = implode(",", $surgery_other);
                    }
                    $chemotherapy_other = (isset($postData['chemotherapy_other']) ? $postData['chemotherapy_other'] : '');
                    if (is_array($chemotherapy_other)) {
                        $chemotherapy = implode(",", $chemotherapy_other);
                    }

                    $radiationtherapy = (isset($postData['radiationtherapy_other']) ? $postData['radiationtherapy_other'] : '');
                    $other_detail = (isset($postData['other_detail']) ? $postData['other_detail'] : '');
                    $provide_details_case = (isset($postData['provide_details_case']) ? $postData['provide_details_case'] : '');
                    $genetic_testing_result = (isset($postData['genetic_testing_result']) ? $postData['genetic_testing_result'] : '');
                    $staging_comments = (isset($postData['staging_comments']) ? $postData['staging_comments'] : '');
                    $t = (isset($postData['stagingt']) ? $postData['stagingt'] : '');
                    $t1 = (isset($postData['stagingt1']) ? $postData['stagingt1'] : '');
                    $t = $t . $t1;
                    $n = (isset($postData['stagingn']) ? $postData['stagingn'] : '');
                    $n1 = (isset($postData['stagingn1']) ? $postData['stagingn1'] : '');
                    $n = $n . $n1;
                    $m = (isset($postData['stagingm']) ? $postData['stagingm'] : '');
                    $m1 = (isset($postData['stagingm1']) ? $postData['stagingm1'] : '');
                    $m = $m . $m1;
                    $stage = (isset($postData['stagingstage']) ? $postData['stagingstage'] : '');
                    $stage1 = (isset($postData['stagingstage1']) ? $postData['stagingstage1'] : '');
                    $stage = $stage . $stage1;

                    $grade = (isset($postData['staginggrade']) ? $postData['staginggrade'] : '');
                    if (isset($case_id) && $case_id != '' && $case_id != '0') {
                        $recurrent_query = array('case_id' => $case_id,
                            'areaof_cancer_recurrence' => $areaof_cancer_recurrence,
                            'cancer_recurrence_others_text' => $other_detail,
                            'provide_details_case' => $provide_details_case,
                            'genetic_testing_result' => $genetic_testing_result,
                            'staging_comments' => $staging_comments,
                            't' => $t,
                            'n' => $n,
                            'm' => $m,
                            'grade' => $grade,
                            'stage' => $stage,
                            'surgery' => $surgery,
                            'chemotherapy' => $chemotherapy,
                            'radiationtherapy' => $radiationtherapy,
                                //'other_details' => $other_details
                        );
                        $this->db->insert('case_other_metastatic', $recurrent_query);
                        $recurrent_query_id = $this->db->insert_id();
                        if ($recurrent_query_id) {
// flash data sucess;
                        } else {
// flash data error;
                        }
                    }
                }
            }
            $case_id = $last_id;
            $user_id = $_SESSION['u_userid'];
            $is_tumor = isset($postData['is_tumor']) ? $postData['is_tumor'] : '0';
            $is_specific_provider = isset($postData['is_specific_provider']) ? $postData['is_specific_provider'] : '0';
            $is_speciality = isset($postData['is_speciality']) ? $postData['is_speciality'] : '0';
            $is_other = isset($postData['is_other']) ? $postData['is_other'] : '0';
            $speciality = isset($postData['sendother']) ? $postData['sendother'] : '0';
            $cron_status = '0';
            if (isset($case_id) && $case_id != '' && $case_id != '0') {
                $assignment_query = array('case_id' => $case_id,
                    'is_tumor' => $is_tumor,
                    'is_specific_provider' => $is_specific_provider,
                    'is_speciality' => $is_speciality,
                    'is_other' => $is_other,
                    'cron_status' => $cron_status,
                    'case_priority_id' => 0
                );
                $assignment_id = $this->db->insert('case_assignments', $assignment_query);
            }
            $casenotifyarray1 = array();
            $imagenotifyarray1 = array();
            if ($assignment_id) {
                if (isset($is_tumor) && !empty($is_tumor) && $is_tumor == 1) {
                    $cancer_id = $postData['cancer_id'];
                    $tumor_board_id = $postData['tumorboard'];
                    foreach ($tumor_board_id as $value) {
                        $assignment_query = array('case_id' => $case_id,
                            'tumor_board_id' => $value
                        );
                        $tumor_query = $this->db->insert('case_assignment_tumor_board', $assignment_query);
                        //image request to admin
                        if (isset($postData['is_admin']) && $postData['is_admin'] != "" && $postData['is_admin'] == '1') {
                            $doctor_query1 = "SELECT hdt.`doctor_id` as id  FROM `speciality_hospital_doctor` shd INNER JOIN  `hospital_doctor`  hdt ON  hdt.`hospital_doctor_id`=shd.`hospital_doctor_id` INNER JOIN `hospital_tumor_board` ht ON ht.`hospital_id`=hdt.`hospital_id` AND shd.`speciality_id`=" . HOSPITAL_ADMIN_SPECILITY . " AND ht.`tumor_id`=$value";
                            $tumor = $this->mcustom->getselectedata($doctor_query1);
                            //echo $doctor_query1; die;
                            if ($tumor != FALSE) {
                                if (count($tumor) > 0) {
                                    foreach ($tumor as $mytumor) {
                                        $check_Image_Request = $this->mcustom->getselectedata("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id='" . $mytumor->id . "'");
                                        $myCheckImageRequest = $check_Image_Request[0]->count;
                                        if ($myCheckImageRequest == 0) {
                                            $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_admin,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments)values('" . $case_id . "','" . $mytumor->id . "','1','0','0','0','0'," . $this->db->escape($postData['admComments']) . ")");
                                        }
                                    }
                                }
                            }
                        }
                        //$doctor_query = "select b.doctor_id,b.hospital_id,e.speciality_id from users as a inner join hospital_doctor as b on a.id = b.doctor_id inner join hospital_doctor_tumor_board as c on b.hospital_doctor_id = c.hospital_doctor_id inner join tumor_board as d on c.tumor_id = d.tumor_id inner join speciality_hospital_doctor as e on e.hospital_doctor_id = c.hospital_doctor_id where b.doctor_id !='" . $user_id . "' and b.hospital_id = (select h.hospital_id from hospital_doctor as h inner join  hospital_doctor_tumor_board as z on h.hospital_doctor_id = z.hospital_doctor_id  where z.id ='" . $value . "') and c.tumor_id = (select tumor_id from hospital_doctor_tumor_board where id = '" . $value . "')";
                        $doctor_query = "SELECT hospital_doctor.doctor_id FROM `hospital_doctor_tumor_board` left join hospital_doctor on hospital_doctor.hospital_doctor_id = hospital_doctor_tumor_board.hospital_doctor_id inner join users on users.id=hospital_doctor.doctor_id where hospital_doctor_tumor_board.tumor_id = '" . $value . "' and hospital_doctor.doctor_id != '" . $user_id . "' and hospital_doctor_tumor_board.is_active='1' and hospital_doctor.is_active='1' and users.is_active='1'";

                        $doctor_id = $this->mcustom->getselectedata($doctor_query);

                        if (count($doctor_id) > 0) {
                            foreach ($doctor_id as $mydoctor_id) {
                                if (isset($mydoctor_id) && $mydoctor_id != '' && $mydoctor_id != '0') {
                                    $check_doctor_id = $this->mcustom->getselectedata("select count(*) as count from case_doc_email_status where case_id ='" . $case_id . "' and doctor_id='" . $mydoctor_id->doctor_id . "'");
                                    $myCheckdoctor_id = $check_doctor_id[0]->count;
                                    if ($myCheckdoctor_id == 0) {
                                        $final_case_assignment_data = array('case_id' => $case_id,
                                            'doctor_id' => $mydoctor_id->doctor_id,
                                            'is_mail_send' => '0'
                                        );
                                        $final_case_assignment = $this->db->insert('case_doc_email_status', $final_case_assignment_data);
                                    }
                                    $myspeciality = "select a.doctor_id,b.* from hospital_doctor as a inner join speciality_hospital_doctor as b on a.hospital_doctor_id = b.hospital_doctor_id where a.doctor_id ='" . $mydoctor_id->doctor_id . "'";
                                    $myspeciality_doctor_id = $this->mcustom->getselectedata($myspeciality);

                                    foreach ($myspeciality_doctor_id as $myspeciality_doctor) {
                                        $check_Image_Request = $this->mcustom->getselectedata("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id='" . $myspeciality_doctor->doctor_id . "'");
                                        $myCheckImageRequest = $check_Image_Request[0]->count;
                                        if ($myCheckImageRequest == 0) {
                                            if (isset($myspeciality_doctor_id) && !empty($myspeciality_doctor_id) && $myspeciality_doctor->speciality_id == '6' && isset($postData['is_pathlogy']) && $postData['is_pathlogy'] != "" && $postData['is_pathlogy'] == '1') {
                                                $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments)values('" . $case_id . "','" . $myspeciality_doctor->doctor_id . "','1','0','0','0','0'," . $this->db->escape($postData['pathComments']) . ")");
                                            } if (isset($myspeciality_doctor_id) && !empty($myspeciality_doctor_id) && $myspeciality_doctor->speciality_id == '8' && isset($postData['is_radiology']) && $postData['is_radiology'] != "" && $postData['is_radiology'] == '1') {
                                                $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments)values('" . $case_id . "','" . $myspeciality_doctor->doctor_id . "','0','1','0','0','0'," . $this->db->escape($postData['radioComments']) . ")");
                                            } if (isset($myspeciality_doctor_id) && !empty($myspeciality_doctor_id) && $myspeciality_doctor->speciality_id == '11' && isset($postData['is_genetics']) && $postData['is_genetics'] != "" && $postData['is_genetics'] == '1') {
                                                $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments)values('" . $case_id . "','" . $myspeciality_doctor->doctor_id . "','0','0','1','0','0'," . $this->db->escape($postData['geneComments']) . ")");
                                            } if (isset($myspeciality_doctor_id) && !empty($myspeciality_doctor_id) && $myspeciality_doctor->speciality_id == '2' && isset($postData['is_admin']) && $postData['is_admin'] != "" && $postData['is_admin'] == '1') {
                                                $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments,is_admin)values('" . $case_id . "','" . $myspeciality_doctor->doctor_id . "','0','0','0','0','0'," . $this->db->escape($postData['geneComments']) . ", '1')");
                                            }
                                        }
                                        $imagenotifyarray1[] = array(
                                            'doctor_id' => $myspeciality_doctor->doctor_id,
                                            'case_id' => $case_id
                                        );
                                        $casenotifyarray1[] = array(
                                            'doctor_id' => $myspeciality_doctor->doctor_id,
                                            'case_id' => $case_id
                                        );
                                    }
                                }
                            }
                        }
                        if ($final_case_assignment) {
// echo "success";
                        } else {
//echo "fail";
                        }
                    }
                } elseif (isset($is_specific_provider) && !empty($is_specific_provider) && $is_specific_provider == '1') {
                    $hd_id = $postData['providers'];
                    if (isset($hd_id) && $hd_id != '' && $hd_id != '0')
                        foreach ($hd_id as $entry) {
                            $specific_provider_query = $this->db->query("Insert into case_assignment_specific_provider (case_id,hospital_doctor_id)values('" . $case_id . "','" . $entry . "')");
                            $doctor_query = "SELECT doctor_id FROM hospital_doctor where hospital_doctor_id = '" . $entry . "'";
                            $doctorData = $this->mcustom->getselectedata($doctor_query);
                            $mydoctor_id = $doctorData[0]->doctor_id;
                            $final_case_assignment = $this->db->query("Insert into case_doc_email_status (case_id,doctor_id,is_mail_send)values('" . $case_id . "','" . $mydoctor_id . "','0')");

                            $casenotifyarray1[] = array(
                                'doctor_id' => $mydoctor_id,
                                'case_id' => $case_id
                            );
                        }


                    if ($specific_provider_query) {
                        // $response = "Data saved successfully";
                    } else {
                        // throw new Exception("There is some error in saving the data.", 403);
                    }
                } elseif (isset($is_speciality) && !empty($is_speciality) && $is_speciality == '1') {
                    $speciality = $postData['specialty'];

                    foreach ($speciality as $data) {
                        $data = explode('-', $data);
                        $specialityid = $data[0];
                        $hospitalid = $data[1];
                        $speciality_hos_doc_query = "SELECT * FROM speciality_hospital_doctor as a INNER JOIN hospital_doctor as b on a.hospital_doctor_id = b.hospital_doctor_id where a.speciality_id = '" . $specialityid . "' and b.doctor_id != '" . $user_id . "' and b.hospital_id='" . $hospitalid . "'";

                        $speciality_hos_doc_id = $this->mcustom->getselectedata($speciality_hos_doc_query);
                        //echo "<pre>"; print_r($speciality_hos_doc_id); exit;
                        foreach ($speciality_hos_doc_id as $speciality_hos_doc_id_data) {
                            if (isset($speciality_hos_doc_id))
                                $speciality_query = $this->db->query("Insert into case_assignment_speciality (case_id,speciality_hos_doc_id)values('" . $case_id . "','" . $speciality_hos_doc_id_data->speciality_hos_doc_id . "')");
                            $final_case_assignment = $this->db->query("Insert into case_doc_email_status (case_id,doctor_id,is_mail_send)values('" . $case_id . "','" . $speciality_hos_doc_id_data->doctor_id . "','0')");
                        }
                    }


                    if ($speciality_query) {
                        //  $response = "Data saved successfully";
                    } else {
                        // throw new Exception("There is some error in saving the data.", 403);
                    }
                } else {
                    $email = $postData['sendother'];
                    $case_id = $last_id;
                    $userinfo = $this->mcustom->getUser($user_id);

                    if (isset($email)) {
                        $this->load->model('memail_templates', 'memail');
                        foreach ($email as $value) {
                            if ($value != "") {
                                $email_query = $this->db->query("Insert into case_assignment_email (case_id,email_id)values('" . $case_id . "','" . $value . "')");



                                $template = $this->memail->get_template_by_name('postcase');
                                if ($template) {
                                    $this->db->select("*");
                                    $this->db->from("specificquestion");
                                    $this->db->where("id = " . $postData['question']);
                                    $query = $this->db->get();
                                    $data = $query->result();
                                    $case_des = str_replace($name, ' ', $_COOKIE['preview']);
                                    $dob = date("m/d/Y", strtotime($dob));
                                    $days_count = $this->mcustom->days_count($dob);
                                    $day_details = day_details_find($days_count);
                                    $case_des = str_replace(', DOB', '', $case_des);
                                    $case_des = str_replace($dob . ', is an', 'is a ' . $day_details, $case_des);
                                    $case_des = str_replace($dob . ', is a', 'is a ' . $day_details, $case_des);



                                    $mail_data = array(
                                        'LOGO' => base_url() . "images/oncolence-logo.png",
                                        'NAME' => $userinfo->fname . ' ' . $userinfo->lname,
                                        'CASE_ID' => $case_id,
                                        'POSTER_EMAIL' => $userinfo->email,
                                        'CASE_DESCRIPTION' => $case_des,
                                        'QUESTION' => $data[0]->spec_question
                                    );
                                    $subject = $template['subject'];
                                    $mailmessage = $template['body'];
                                    foreach ($mail_data as $key => $val) {
                                        $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
                                        $subject = str_replace("{{" . $key . "}}", $val, $subject);
                                    }
//                                $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png'></p><br/>";
//                                $mailmessage .= "<p>hello, Case is submitted by user.</p>";
//                                $mailmessage .= "<p><b>Case id</b> " . $case_id . "</p>";
//                                $mailmessage .= "<p>" . $content . "</p>";
//                                $mailmessage .= "<p>Thank you</p>";
//                                $mailmessage .= "<p><b>" . $userinfo->fname . ' ' . $userinfo->lname . "</b></p>";
                                    $this->email->set_mailtype("html");
                                    $this->email->from('support@oncolens.com', 'OncolensSupport');
                                    $this->email->to($value);
                                    $this->email->subject($subject);
                                    $this->email->message($mailmessage);
                                    $this->email->send();
                                    setcookie('preview', '', time() - 300, "/");
                                }
                            }
                        }
                        //  $response = "Data saved successfully";
                    } else {
                        // throw new Exception("There is some error in saving the data.", 403);
                    }
                }



                if (isset($postData['is_pathlogyP']) && $postData['is_pathlogyP'] != "" && $postData['is_pathlogyP'] == '1' && isset($postData['rProvider']) && count($postData['rProvider']) > 0) {
                    foreach ($postData['rProvider'] as $myspeciality_doctor) {
                        $r_path_arra = explode("-", $myspeciality_doctor);
                        $r_path_id = $r_path_arra['0'];
                        $r_path_hispital = $r_path_arra['1'];
                        $check_Image_Request = $this->mcustom->getselectedata("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id='" . $r_path_id . "'");
                        $myCheckImageRequest = $check_Image_Request[0]->count;
                        if ($myCheckImageRequest == 0) {
                            $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments,img_req_hospital_id)values('" . $case_id . "','" . $r_path_id . "','1','0','0','0','0'," . $this->db->escape($postData['pathCommentsP']) . ",'" . $r_path_hispital . "')");
                            $imagenotifyarray1[] = array(
                                'doctor_id' => $r_path_id,
                                'case_id' => $case_id
                            );
                        }
                    }
                }
                if (isset($postData['is_radiologyP']) && $postData['is_radiologyP'] != "" && $postData['is_radiologyP'] == '1' && isset($postData['rRadiology']) && count($postData['rRadiology']) > 0) {
                    foreach ($postData['rRadiology'] as $myspeciality_doctor) {
                        $r_rad_arra = explode("-", $myspeciality_doctor);
                        $r_rad_id = $r_rad_arra['0'];
                        $r_rad_hispital = $r_rad_arra['1'];
                        $check_Image_Request = $this->mcustom->getselectedata("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id='" . $r_rad_id . "'");
                        $myCheckImageRequest = $check_Image_Request[0]->count;
                        if ($myCheckImageRequest == 0) {
                            $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments,img_req_hospital_id)values('" . $case_id . "','" . $r_rad_id . "','0','1','0','0','0'," . $this->db->escape($postData['radioCommentsP']) . ",'" . $r_rad_hispital . "')");
                            $imagenotifyarray1[] = array(
                                'doctor_id' => $r_rad_id,
                                'case_id' => $case_id
                            );
                        }
                    }
                }
                if (isset($postData['is_geneticsP']) && $postData['is_geneticsP'] != "" && $postData['is_geneticsP'] == '1' && isset($postData['rGenetics']) && count($postData['rGenetics']) > 0) {
                    foreach ($postData['rGenetics'] as $myspeciality_doctor) {
                        $r_gen_arra = explode("-", $myspeciality_doctor);
                        $r_gen_id = $r_gen_arra['0'];
                        $r_gen_hispital = $r_gen_arra['1'];
                        $check_Image_Request = $this->mcustom->getselectedata("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id='" . $r_gen_id . "'");
                        $myCheckImageRequest = $check_Image_Request[0]->count;
                        if ($myCheckImageRequest == 0) {
                            $image_request = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_notification_sent,is_forwarded,comments,img_req_hospital_id)values('" . $case_id . "','" . $r_gen_id . "','0','0','1','0','0'," . $this->db->escape($postData['geneCommentsP']) . ",'" . $r_gen_hispital . "')");
                            $imagenotifyarray1[] = array(
                                'doctor_id' => $r_gen_id,
                                'case_id' => $case_id
                            );
                        }
                    }
                }


                $case_id = $last_id;
                $speciality_id = $userinfo->speciality_id;
                for ($i = 0; $i <= 5; $i++) {
                    $path = '';
                    if (isset($_FILES['rImageFile' . $i]['name'])) {
                        if ($_FILES['rImageFile' . $i]["size"] < 50000000) {
                            $path = time() . $i . $_FILES['rImageFile' . $i]['name'];
                            $path = str_replace(" ", "_", $path);
                            if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                                $file_uploaded = $this->db->query("Insert into case_save_images (case_id,doctor_id,image_name,comments,speciality_id)values('" . $case_id . "','" . $user_id . "','" . $path . "'," . $this->db->escape($postData['comment'][$i]) . ",'" . $speciality_id . "')");
                            } else {
                                $this->session->set_flashdata('error', 'Try again later');
                            }
                        }
                    }
                }
                if ($is_tumor == '1' && isset($postData['urgent']) && $postData['urgent'] == '1') {
                    $case_priority_id = array('2', '3');
                } else if (($is_specific_provider == '1' || $is_speciality == '1' ) && isset($postData['urgent']) && $postData['urgent'] == '1') {
                    $case_priority_id = array('2', '1');
                } else if ($is_tumor == '1' && !isset($postData['urgent'])) {
                    $case_priority_id = array('3');
                } else if (($is_specific_provider == '1' || $is_speciality == '1' ) && !isset($postData['urgent'])) {
                    $case_priority_id = array('1');
                } else if ($is_other == '1' && isset($postData['urgent']) && $postData['urgent'] == '1') {
                    $case_priority_id = array('2');
                }
                if (isset($case_priority_id) && !empty($case_priority_id))
                    foreach ($case_priority_id as $value) {
                        $questions_query = $this->db->query("Insert into case_assignment_priority (case_id,doctor_id,priority_id)values('" . $case_id . "','" . $user_id . "','" . $value . "')");
                    }
                $comments = (isset($postData['add_comts']) ? $postData['add_comts'] : '');
                $specific_question_id = $postData['question'];
                if ($comments != "")
                    $speciality = $userinfo->speciality_id;
                else
                    $speciality = 0;
                if (isset($specific_question_id))
                    $data = array(
                        'case_id' => $case_id,
                        'doctor_id' => $user_id,
                        'speciality_id' => $speciality,
                        'specific_question_id' => $specific_question_id,
                        'date' => date('Y-m-d H:i:s'),
                        'comments' => $comments,
                        'other_answer' => '',
                        'my_thought_id' => 0,
                    );

                $questions_query = $this->db->insert("case_question_answer", $data);

                if ($case_id != "") {
                    $casenotifyarray = array();
                    $imagenotifyarray = array();
                    //echo '<pre>';
                    //print_r($casenotifyarray1); die;
                    if (isset($casenotifyarray1) && !empty($casenotifyarray1)) {
                        $casenotifyarray = array_merge($casenotifyarray, $casenotifyarray1);
                    }
                    if (isset($imagenotifyarray1) && !empty($imagenotifyarray1)) {
                        $imagenotifyarray = array_merge($imagenotifyarray, $imagenotifyarray1);
                    }

                    $this->sendcasenotification($casenotifyarray, $imagenotifyarray, $last_id);
                    if (isset($postData['caseid']) && $postData['caseid'] != "") {
                        $data = array(
                            'is_forwarded' => '1',
                            'forwarded_case_id' => $postData['caseid']
                        );
                        $this->db->where('id', $case_id);
                        $this->db->update('case_history', $data);
                    }
                    $this->session->set_flashdata('success', 'Case posted successfully. You can view your case under "View Case Results".<br/>
If this is a tumor board case, your hospital administrator may assign the case to an upcoming in-person meeting. In the meantime, please "Answer Open Cases".');
                } else {
                    $this->session->set_flashdata('error', 'Try again later');
                }
            }
        }
    }

    // sending notification to ios device

    public function sendcasenotification($casenotifyarray = NULL, $imagenotifyarray = NULL, $insert_id = NULL) {

//        echo $insert_id;
//        print_r($casenotifyarray);
//        print_r($imagenotifyarray);
//
//        die;




        if (isset($casenotifyarray)) {
            $post = 0;

            $post_arr = array();
            $case_id = $insert_id;

            $case_data = "SELECT * FROM `case_doc_email_status` WHERE case_id=$case_id";
            $case_data_result = $this->mcustom->getselectedata($case_data);



            foreach ($case_data_result as $case_data_result_id) {
                if (isset($case_data_result_id)) {

                    $doctor_id = $case_data_result_id->doctor_id;

                    if (!(in_array($doctor_id, $post_arr))) {
                        $post_arr[] = $doctor_id;


                        $token = $this->db->query("Select device_token from app_device where doctor_id = '" . $doctor_id . "'");
                        foreach ($token->result_object() as $token_status) {

                            $deviceToken = $token_status->device_token;
                            $i = 0;
                            if (isset($deviceToken) && !empty($deviceToken)) {
                                $passphrase = "";
                                $message = "A new case has been sent to you requesting your feedback";

                                try {
                                    $ctx = stream_context_create();
                                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'OncoLensDev.pem');
                                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
                                    $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
                                    if (!$fp) {
                                        $response = "Failed to connect: $err $errstr" . PHP_EOL;
                                        return $response;
                                    }
                                } catch (Exception $exc) {

//echo $exc->getTraceAsString();
                                    $response = "";
                                    return $response;
                                }

                                $body['aps'] = array(
                                    'alert' => $message,
                                    'sound' => 'default',
                                    'badge' => '1'
                                );
                                $payload = json_encode($body);
                                $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
                                $result = fwrite($fp, $msg, strlen($msg));

                                $save_case_info = $this->db->query("Update case_assignments  SET cron_status ='1' where case_id = '" . $case_id . "'");
                                $save_mail_status = $this->db->query("Update case_doc_email_status  SET is_mail_send ='1' where case_id = '" . $case_id . "'");

                                if (!$result)
                                    $response = 'Notification not sent' . PHP_EOL;
                                else
                                    $response = 'Notification successfully sent' . PHP_EOL;
                                fclose($fp);
                                $i++;
                            }
                            else {
                                continue;
                            }
                        }
                    }
                }
            }
        }

        if (isset($imagenotifyarray)) {
            $image = 0;
            $image_arr = array();



            $image_data = "SELECT * FROM `case_request_images` WHERE case_id=$case_id";
            $image_data_result = $this->mcustom->getselectedata($image_data);


            foreach ($image_data_result as $image_data_result_id) {
                if (isset($image_data_result_id)) {

                    $doctor_id = $image_data_result_id->doctor_id;

                    if ((!in_array($doctor_id, $image_arr))) {

                        $image_arr[] = $doctor_id;

                        $token = $this->db->query("Select device_token from app_device where doctor_id = '" . $doctor_id . "'");
                        foreach ($token->result_object() as $token_status) {
                            $deviceToken = $token_status->device_token;
                            $i = 0;
                            if (isset($deviceToken) && !empty($deviceToken)) {
                                $passphrase = '';
                                $message = 'A new data request has been sent to you.';
////////////////////////////////////////////////////////////////////////////////

                                try {
                                    $ctx = stream_context_create();
                                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'OncoLensDev.pem');
                                    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
                                    $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

                                    if (!$fp) {
                                        $response = "Failed to connect: $err $errstr" . PHP_EOL;
                                        return $response;
                                    }
                                } catch (Exception $exc) {
                                    $response = "";
                                    return $response;
                                }
// echo 'Connected to APNS' . PHP_EOL;
                                $body['aps'] = array(
                                    'alert' => $message,
                                    'sound' => 'default',
                                    'badge' => '1'
                                );
                                $payload = json_encode($body);
                                $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
                                $result1 = fwrite($fp, $msg, strlen($msg));
                                $save_case_info = $this->db->query("Update case_request_images  SET is_notification_sent ='1' where case_id = '" . $case_id . "'");
                                if (!$result1)
                                    $response = 'Image Notification Not Sent' . PHP_EOL;
                                else
                                    $response = 'Image Notification Successfully Sent' . PHP_EOL;
                                fclose($fp);
                                $i++;
                            }
                            else {
                                continue;
                            }
                        }
                    }
                }
            }
        }

//
//            echo "<pre>";
//            print_r($post_arr);
//           print_r($image_arr);
//
//            die;

        unset($_COOKIE['preview']);
        setcookie("preview", "", time() - 3600);

        return true;
    }

    // to fetch cases assigned to user for comments
    public function count_answeropencase($filter = NULL) {
        $query = "SELECT
                        e.name,
                        e.dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        e.id as case_id,
					    b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        (SELECT
                          CONCAT(fname, ' ', lname)
                        FROM
                          users
                        WHERE id = e.case_entered_by) AS submitted_by,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_assignment_priority
                        WHERE priority_id = '2'
                          AND ";

        $query = $query . " case_id = e.id ) as count_priority,
         e.case_entered_by as doctor_id,d.speciality_id,e.case_status
          FROM
            case_history AS e
            INNER JOIN case_assignments AS b
              ON (e.id = b.case_id)
            LEFT JOIN case_doc_email_status AS a
              ON (b.case_id = a.case_id)
            LEFT JOIN users AS d
              ON (a.doctor_id = d.id)";

        if ($filter != "") {
            $query = $query . " inner join  case_assignment_priority as p  on e.id = p.case_id ";
        }

        $query = $query . " where (a.doctor_id ='" . $_SESSION['u_userid'] . "') ";

        if ($filter != "") {
            $query = $query . " and p.priority_id='" . db_clean($filter) . "' ";
        }

        $query = $query . " and e.case_status = '1' and e.is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '" . $_SESSION['u_userid'] . "')

         group by e.id order by e.case_updated_date DESC";

        $case_query = $this->db->query($query);

        return $case_query->num_rows();

//$case_data = $case_query->result_object();
    }

    // to fetch cases assigned to user for comments
    public function answeropencase($params = array()) {
        $salt = $this->config->item('salt');
        if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['start'] . ' , ' . $params['limit'];
// $this->db->limit($params['limit'],$params['start']);
        } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['limit'];
//$this->db->limit($params['limit']);
        }

        $query = "SELECT
                    e.case_entered_by,
                    AES_DECRYPT(e.case_description, '$salt') AS case_description,
                    AES_DECRYPT(e.name, '$salt') AS name,
                    AES_DECRYPT(e.dob, '$salt') AS dob,
                    e.case_submit_date,
						e.case_mr_number,
                    DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                    e.pathology_others_text,
                    e.id as case_id,
                    b.is_tumor,
                    b.is_specific_provider,
                    b.is_speciality,
                    b.is_other,
                    (SELECT
                      CONCAT(fname, ' ', lname)
                    FROM
                      users
                    WHERE id = e.case_entered_by) AS submitted_by,
                    (SELECT
                      COUNT(id)
                    FROM
                      case_assignment_priority
                    WHERE priority_id = '2'
                      AND  ";

        $query = $query . " case_id = e.id) AS count_priority,
                e.case_entered_by AS doctor_id,
                d.speciality_id,
                e.case_status
                FROM
                    case_history AS e
                    INNER JOIN case_assignments AS b
                      ON (e.id = b.case_id)
                    LEFT JOIN case_doc_email_status AS a
                      ON (b.case_id = a.case_id)
                    LEFT JOIN users AS d
                      ON (a.doctor_id = d.id)
                 ";
        if ($params['filter'] != "") {
            $query = $query . " inner join  case_assignment_priority as p  on e.id = p.case_id ";
        }

        $query = $query . "  where (a.doctor_id ='" . $_SESSION['u_userid'] . "') ";

        if ($params['filter'] != "") {
            $query = $query . " and p.priority_id='" . db_clean($params['filter']) . "' ";
        }

        $query = $query . " and e.case_status = '1' and is_deleted = '0'
         and e.id
         not in( select case_id from case_doctor_comments where doctor_id = '" . $_SESSION['u_userid'] . "') ";

        $query = $query . "  group by e.id  order by e.case_updated_date DESC ";

        if ($limit != "") {
            $query = $query . $limit;
        }
//echo $this->db->last_Query();die;
        $case_query = $this->db->query($query);

        $case_data = $case_query->result_object();

        $data = array();
        $session = array();
        foreach ($case_data as $key => $value) {
            $session[] = $value->case_id;
            if ($value->is_tumor == 1) {

//$tumor_query = $this->db->query("select b.tumor_board_name from case_assignment_tumor_board as a INNER JOIN tumor_board as b on a.tumor_board_id = b.tumor_id where a.case_id='".$value->case_id."'");
                $tumor_query = $this->db->query("SELECT h.hospital_network ,c.tumor_board_name
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "' group by d.id");

                $submitted_to = array();
                foreach ($tumor_query->result_object() as $data) {
                    $submitted_to[] = $data->tumor_board_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "'  group by d.id ");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_specific_provider == 1) {
                $speciality_query = $this->db->query("select u.fname, u.lname,  h.hospital_network ,d.speciality_name
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN hospital_doctor as c
                      on c.hospital_doctor_id = a.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = c.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "' ");
                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->fname . ' ' . $data->lname . ' - ' . $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = b.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_speciality == 1) {
//$speciality_query = $this->db->query("select c.speciality_name from case_assignment_speciality as a INNER JOIN speciality_hospital_doctor as b on a.speciality_hos_doc_id = b.speciality_hos_doc_id INNER JOIN speciality as c  on b.speciality_id = b.speciality_id where a.case_id='".$value->case_id."'");
                $speciality_query = $this->db->query(" select h.hospital_network,c.speciality_name
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id

                    where a.case_id='" . $value->case_id . "' GROUP BY c.speciality_name ");

                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'  GROUP BY h.hospital_network");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_other == 1) {
                $this->db->select("cae.email_id as submitted_to");
                $this->db->from("case_history ch");
                $this->db->join("case_assignment_email cae", "cae.case_id=ch.id");
                $this->db->where("ch.id = $value->case_id");
                $query = $this->db->get();
                $row = $query->row();
                //print_r($row);die;
                $submitted_to = array();
                $hospital_network = array();
                $submitted_to[] = $row->submitted_to;
                $hospital_network[] = "";
            }


            $case_data[$key]->submitted_to = @implode(',<br>', $submitted_to);
            $case_data[$key]->hospital_network = @implode(',<br> ', $hospital_network);
        }
        $_SESSION['nextcase'] = $session;
        return $case_data;
    }

    // to fetch the cases on which user has submitted

    public function case_i_submitted($params = array()) {
        $salt = $this->config->item('salt');
        if (isset($params['limit'])) {
            if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                $limit = "limit " . $params['start'] . ' , ' . $params['limit'];
// $this->db->limit($params['limit'],$params['start']);
            } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                $limit = "limit " . $params['limit'];
//$this->db->limit($params['limit']);
            }
        }

//        $query = "Select  AES_DECRYPT(e.name,'$salt') as name , AES_DECRYPT(e.dob,'$salt') as dob , e.case_submit_date, DATE_FORMAT(e.case_updated_date,'%m/%d/%y') as
//                case_updated_date,e.pathology_others_text,a.case_id,b.is_tumor,b.is_specific_provider,b.is_speciality,b.is_other,
//            e.case_entered_by as doctor_id,d.speciality_id,e.case_status,e.mark_as_discussed_live,
//             (select count(id) from case_doctor_comments where case_id = e.id ) as online,
//             (select GROUP_CONCAT(DATE_FORMAT(meeting_date,'%d/%m/%y'),' ',DATE_FORMAT(meeting_time,'%h:%i %p'))  from  case_meeting_assignments as cma inner join case_meeting_details as cmd on cma.sub_meeting_id = cmd.id where cma.case_id=e.id ) as assigned
//
//             from case_doc_email_status as a
//
//            LEFT JOIN case_assignments as b
//               on a.case_id = b.case_id
//
//            INNER JOIN users as d
//               on d.id = a.doctor_id
//
//            inner join case_history as e
//               on a.case_id = e.id";

        $query = "SELECT
                            AES_DECRYPT(e.name, '$salt') AS name,
                            DATE_FORMAT(AES_DECRYPT(e.dob, '$salt'),'%m/%d/%Y') AS dob,
                            e.case_submit_date,
                            DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                            e.pathology_others_text,
                            AES_DECRYPT(e.case_description, '$salt') AS case_description,
                            e.case_entered_by,
							   e.case_mr_number,
                            e.id AS case_id,
                            b.is_tumor,
                            b.is_specific_provider,
                            b.is_speciality,
                            b.is_other,
                            e.case_entered_by AS doctor_id,
                            d.speciality_id,
                            e.case_status,
                            e.mark_as_discussed_live,
                            (SELECT
                              COUNT(id)
                            FROM
                              case_doctor_comments
                            WHERE case_id = e.id) AS online,
                            (SELECT
                              GROUP_CONCAT(
                                DATE_FORMAT(meeting_date, '%m/%d/%Y'),
                                ' ',
                                DATE_FORMAT(meeting_time, '%h:%i %p')
                              )
                            FROM
                              case_meeting_assignments AS cma
                              INNER JOIN case_meeting_details AS cmd
                                ON cma.sub_meeting_id = cmd.id
                            WHERE cma.case_id = e.id) AS assigned
                          FROM
                            case_history AS e
                            INNER JOIN case_assignments AS b
                              ON (e.id = b.case_id)
                            LEFT JOIN case_doc_email_status AS a
                              ON (b.case_id = a.case_id)
                             LEFT JOIN users AS d
                              ON (a.doctor_id = d.id)
                        ";


        if ($params['filter'] != "") {
            $query = $query . " inner join  case_assignment_priority as p  on e.id = p.case_id ";
        }

        $query = $query . "  where e.case_status='1' and   e.case_entered_by='" . $_SESSION['u_userid'] . "'  ";

        if ($params['filter'] != "") {
            $query = $query . " and p.priority_id='" . db_clean($params['filter']) . "' ";
        }

        $query = $query . " and e.is_deleted = '0'
                        GROUP BY e.id
                    order by e.case_updated_date DESC ";

        if (isset($params['limit'])) {
            $query = $query . $limit;
        }

        $case_query = $this->db->query($query);
        //echo $this->db->last_Query(); die;
        $count = isset($params['count']) ? true : false;
        if ($count) {
            return $case_query->num_rows();
        } else {

            $case_data = $case_query->result_object();

            $data = array();
            $session = array();
            foreach ($case_data as $key => $value) {
                $session[] = $value->case_id;
                if ($value->is_tumor == 1) {

//$tumor_query = $this->db->query("select b.tumor_board_name from case_assignment_tumor_board as a INNER JOIN tumor_board as b on a.tumor_board_id = b.tumor_id where a.case_id='".$value->case_id."'");
                    $tumor_query = $this->db->query("SELECT h.hospital_network ,c.tumor_board_name
                                FROM case_assignment_tumor_board as d
                                INNER JOIN tumor_board AS c
                                on d.tumor_board_id= c.tumor_id
                                INNER JOIN hospital_doctor_tumor_board AS b
                                 on c.tumor_id = b.tumor_id
                                INNER JOIN hospital_doctor AS a
                                ON a.hospital_doctor_id = b.hospital_doctor_id
                                INNER JOIN
                                hospital_network AS h ON a.hospital_id = h.id
                                 where d.case_id='" . $value->case_id . "' group by d.id");

                    $submitted_to = array();
                    foreach ($tumor_query->result_object() as $data) {
                        $submitted_to[] = $data->tumor_board_name;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                                FROM case_assignment_tumor_board as d
                                INNER JOIN tumor_board AS c
                                on d.tumor_board_id= c.tumor_id
                                INNER JOIN hospital_doctor_tumor_board AS b
                                 on c.tumor_id = b.tumor_id
                                INNER JOIN hospital_doctor AS a
                                ON a.hospital_doctor_id = b.hospital_doctor_id
                                INNER JOIN
                                hospital_network AS h ON a.hospital_id = h.id
                                 where d.case_id='" . $value->case_id . "'  group by d.id ");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_specific_provider == 1) {
                    $speciality_query = $this->db->query("select u.fname, u.lname,  h.hospital_network ,d.speciality_name
                        from case_assignment_specific_provider as a
                        INNER JOIN hospital_doctor AS b
                          on a.hospital_doctor_id = b.hospital_doctor_id
                       INNER JOIN hospital_doctor as c
                          on c.hospital_doctor_id = a.hospital_doctor_id
                       INNER JOIN users AS u
                        ON b.doctor_id = u.id
                       INNER JOIN speciality_hospital_doctor AS sh
                            ON sh.hospital_doctor_id = c.hospital_doctor_id
                      INNER JOIN speciality AS d
                           ON d.speciality_id = sh.speciality_id
                      INNER JOIN hospital_network AS h
                           ON b.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "' ");
                    $submitted_to = array();
                    foreach ($speciality_query->result_object() as $data) {
                        $submitted_to[] = $data->fname . ' ' . $data->lname . ' - ' . $data->speciality_name;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                        from case_assignment_specific_provider as a
                        INNER JOIN hospital_doctor AS b
                          on a.hospital_doctor_id = b.hospital_doctor_id
                       INNER JOIN users AS u
                        ON b.doctor_id = u.id
                       INNER JOIN speciality_hospital_doctor AS sh
                            ON sh.hospital_doctor_id = b.hospital_doctor_id
                      INNER JOIN speciality AS d
                           ON d.speciality_id = sh.speciality_id
                      INNER JOIN hospital_network AS h
                           ON b.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "'");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_speciality == 1) {
//$speciality_query = $this->db->query("select c.speciality_name from case_assignment_speciality as a INNER JOIN speciality_hospital_doctor as b on a.speciality_hos_doc_id = b.speciality_hos_doc_id INNER JOIN speciality as c  on b.speciality_id = b.speciality_id where a.case_id='".$value->case_id."'");
                    $speciality_query = $this->db->query(" select h.hospital_network ,c.speciality_name
                        from case_assignment_speciality as a
                        INNER JOIN speciality_hospital_doctor as b
                        on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                        INNER JOIN hospital_doctor as hs
                        on hs.hospital_doctor_id = b.hospital_doctor_id
                        INNER JOIN speciality as c
                        on c.speciality_id = b.speciality_id
                        INNER JOIN hospital_network AS h
                        ON hs.hospital_id = h.id

                        where a.case_id='" . $value->case_id . "' GROUP BY c.speciality_name ");

                    $submitted_to = array();
                    foreach ($speciality_query->result_object() as $data) {
                        $submitted_to[] = $data->speciality_name . ' - ' . $data->hospital_network;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                        from case_assignment_speciality as a
                        INNER JOIN speciality_hospital_doctor as b
                        on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                        INNER JOIN hospital_doctor as hs
                        on hs.hospital_doctor_id = b.hospital_doctor_id
                        INNER JOIN speciality as c
                        on c.speciality_id = b.speciality_id
                        INNER JOIN hospital_network AS h
                        ON hs.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "'  GROUP BY h.hospital_network");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_other == 1) {

                    $this->db->select("cae.email_id as submitted_to");
                    $this->db->from("case_history ch");
                    $this->db->join("case_assignment_email cae", "cae.case_id=ch.id");
                    $this->db->where("ch.id = $value->case_id");
                    $query = $this->db->get();

                    //print_r($row);die;
                    $submitted_to = array();
                    $hospital_network = array();
                    foreach ($query->result_object() as $data) {
                        $submitted_to[] = $data->submitted_to;
                    }
//                    echo "<pre>"; print_r($row); echo "</pre>";
//                    $submitted_to[] = $row->submitted_to;
                    $hospital_network[] = "";
                }

                $case_data[$key]->submitted_to = @implode(',<br>', $submitted_to);
                $case_data[$key]->hospital_network = @implode(',<br> ', $hospital_network);
            }
            $_SESSION['nextcase1'] = $session;
            return $case_data;
//echo '<pre>';
//print_r($case_data);
//die;
        }
    }

    // to fetch the cases on which logged user has answered
    public function case_i_answer($params = array()) {
        $salt = $this->config->item('salt');

        if (isset($params['limit'])) {
            if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                $limit = "limit " . $params['start'] . ' , ' . $params['limit'];
// $this->db->limit($params['limit'],$params['start']);
            } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
                $limit = "limit " . $params['limit'];
//$this->db->limit($params['limit']);
            }
        }

        $query = "SELECT
                        AES_DECRYPT(e.name, '$salt') AS name,
                        DATE_FORMAT(AES_DECRYPT(e.dob, '$salt'),'%m/%d/%Y') AS dob,
                        e.case_submit_date,
                        DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                        e.pathology_others_text,
                        AES_DECRYPT(e.case_description, '$salt') AS case_description,
                        e.id AS case_id,
                        e.case_entered_by,
						 e.case_mr_number,
                        b.is_tumor,
                        b.is_specific_provider,
                        b.is_speciality,
                        b.is_other,
                        e.case_entered_by AS doctor_id,
                        d.speciality_id,
                        e.case_status,
                        e.mark_as_discussed_live,
                        (SELECT
                          COUNT(id)
                        FROM
                          case_doctor_comments
                        WHERE case_id = e.id) AS online,
                        (SELECT
                          id
                        FROM
                          case_doctor_comments
                        WHERE case_id = e.id
                          AND doctor_id = '" . $_SESSION['u_userid'] . "' Limit 1) AS commentdocotor,
                        (SELECT
                          GROUP_CONCAT(
                            DATE_FORMAT(meeting_date, '%m/%d/%Y'),
                            ' ',
                            DATE_FORMAT(meeting_time, '%h:%i %p')
                          )
                        FROM
                          case_meeting_assignments AS cma
                          INNER JOIN case_meeting_details AS cmd
                            ON cma.sub_meeting_id = cmd.id
                        WHERE cma.case_id = e.id) AS assigned
                      FROM
                        case_history AS e
                        INNER JOIN case_assignments AS b
                          ON (e.id = b.case_id)
                        LEFT JOIN case_doc_email_status AS a
                          ON (b.case_id = a.case_id)
                        LEFT JOIN users AS d
                          ON (a.doctor_id = d.id)";

        if ($params['filter1'] != "") {
            $query = $query . " inner join  case_assignment_priority as p  on e.id = p.case_id ";
        }

        $query = $query . "  where is_deleted = '0'   ";

        if ($params['filter1'] != "") {
            $query = $query . " and p.priority_id='" . db_clean($params['filter1']) . "' ";
        }

        $query = $query . " and e.case_status='1' and  e.id in( select case_id from case_doctor_comments where doctor_id = '" . $_SESSION['u_userid'] . "')

          group by e.id  order by commentdocotor DESC ";

        if (isset($params['limit'])) {
            $query = $query . $limit;
        }
        //echo $query; die;
        $case_query = $this->db->query($query);

//echo $this->db->last_Query();die;
        $count = isset($params['count']) ? true : false;

        if ($count) {
            return $case_query->num_rows();
        } else {

            $case_data = $case_query->result_object();

//echo '<pre>';
//print_r($case_data);
//return $case_data;
//echo $this->db->last_Query(); die;
            $data = array();
            $session = array();
            foreach ($case_data as $key => $value) {
                $session[] = $value->case_id;
                if ($value->is_tumor == 1) {

//$tumor_query = $this->db->query("select b.tumor_board_name from case_assignment_tumor_board as a INNER JOIN tumor_board as b on a.tumor_board_id = b.tumor_id where a.case_id='".$value->case_id."'");
                    $tumor_query = $this->db->query("SELECT h.hospital_network ,c.tumor_board_name
                                FROM case_assignment_tumor_board as d
                                INNER JOIN tumor_board AS c
                                on d.tumor_board_id= c.tumor_id
                                INNER JOIN hospital_doctor_tumor_board AS b
                                 on c.tumor_id = b.tumor_id
                                INNER JOIN hospital_doctor AS a
                                ON a.hospital_doctor_id = b.hospital_doctor_id
                                INNER JOIN
                                hospital_network AS h ON a.hospital_id = h.id
                                 where d.case_id='" . $value->case_id . "' group by d.id");

                    $submitted_to = array();
                    foreach ($tumor_query->result_object() as $data) {
                        $submitted_to[] = $data->tumor_board_name;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                                FROM case_assignment_tumor_board as d
                                INNER JOIN tumor_board AS c
                                on d.tumor_board_id= c.tumor_id
                                INNER JOIN hospital_doctor_tumor_board AS b
                                 on c.tumor_id = b.tumor_id
                                INNER JOIN hospital_doctor AS a
                                ON a.hospital_doctor_id = b.hospital_doctor_id
                                INNER JOIN
                                hospital_network AS h ON a.hospital_id = h.id
                                 where d.case_id='" . $value->case_id . "'  group by d.id ");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_specific_provider == 1) {
                    $speciality_query = $this->db->query("select u.fname, u.lname,  h.hospital_network ,d.speciality_name
                        from case_assignment_specific_provider as a
                        INNER JOIN hospital_doctor AS b
                          on a.hospital_doctor_id = b.hospital_doctor_id
                       INNER JOIN hospital_doctor as c
                          on c.hospital_doctor_id = a.hospital_doctor_id
                       INNER JOIN users AS u
                        ON b.doctor_id = u.id
                       INNER JOIN speciality_hospital_doctor AS sh
                            ON sh.hospital_doctor_id = c.hospital_doctor_id
                      INNER JOIN speciality AS d
                           ON d.speciality_id = sh.speciality_id
                      INNER JOIN hospital_network AS h
                           ON b.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "' ");
                    $submitted_to = array();
                    foreach ($speciality_query->result_object() as $data) {
                        $submitted_to[] = $data->fname . ' ' . $data->lname . ' - ' . $data->speciality_name;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                        from case_assignment_specific_provider as a
                        INNER JOIN hospital_doctor AS b
                          on a.hospital_doctor_id = b.hospital_doctor_id
                       INNER JOIN users AS u
                        ON b.doctor_id = u.id
                       INNER JOIN speciality_hospital_doctor AS sh
                            ON sh.hospital_doctor_id = b.hospital_doctor_id
                      INNER JOIN speciality AS d
                           ON d.speciality_id = sh.speciality_id
                      INNER JOIN hospital_network AS h
                           ON b.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "'");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_speciality == 1) {
//$speciality_query = $this->db->query("select c.speciality_name from case_assignment_speciality as a INNER JOIN speciality_hospital_doctor as b on a.speciality_hos_doc_id = b.speciality_hos_doc_id INNER JOIN speciality as c  on b.speciality_id = b.speciality_id where a.case_id='".$value->case_id."'");
                    $speciality_query = $this->db->query(" select h.hospital_network ,c.speciality_name
                        from case_assignment_speciality as a
                        INNER JOIN speciality_hospital_doctor as b
                        on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                        INNER JOIN hospital_doctor as hs
                        on hs.hospital_doctor_id = b.hospital_doctor_id
                        INNER JOIN speciality as c
                        on c.speciality_id = b.speciality_id
                        INNER JOIN hospital_network AS h
                        ON hs.hospital_id = h.id

                        where a.case_id='" . $value->case_id . "' GROUP BY c.speciality_name ");

                    $submitted_to = array();
                    foreach ($speciality_query->result_object() as $data) {
                        $submitted_to[] = $data->speciality_name . ' - ' . $data->hospital_network;
                    }

                    $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                        from case_assignment_speciality as a
                        INNER JOIN speciality_hospital_doctor as b
                        on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                        INNER JOIN hospital_doctor as hs
                        on hs.hospital_doctor_id = b.hospital_doctor_id
                        INNER JOIN speciality as c
                        on c.speciality_id = b.speciality_id
                        INNER JOIN hospital_network AS h
                        ON hs.hospital_id = h.id
                        where a.case_id='" . $value->case_id . "'  GROUP BY h.hospital_network");
                    $hospital_network = array();

                    foreach ($network_query->result_object() as $data) {
                        $hospital_network[] = $data->hospital_network;
                    }
                } elseif ($value->is_other == 1) {

                    $this->db->select("cae.email_id as submitted_to");
                    $this->db->from("case_history ch");
                    $this->db->join("case_assignment_email cae", "cae.case_id=ch.id");
                    $this->db->where("ch.id = $value->case_id");
                    $query = $this->db->get();
                    $row = $query->row();
                    //print_r($row);die;
                    $submitted_to = array();
                    $hospital_network = array();
                    $submitted_to[] = $row->submitted_to;
                    $hospital_network[] = "";
                }

                $case_data[$key]->submitted_to = @implode(',<br>', $submitted_to);
                $case_data[$key]->hospital_network = @implode(',<br> ', $hospital_network);
            }
            $_SESSION['nextcase2'] = $session;
            return $case_data;
        }
    }

    // to fetch the complete detail of case
    public function case_detail($case_id) {

        $salt = $this->config->item('salt');

        if ($this->uri->segment(4) == "7")
            $where_tumor = "|| 1=1";
        else
            $where_tumor = "|| e.case_entered_by = '" . $_SESSION['u_userid'] . "'";
        $user_case_query = "SELECT
                            AES_DECRYPT(e.case_description,'$salt') as case_description,
                            e.case_entered_by,
                            e.cancer_id,
                            DATE_FORMAT(AES_DECRYPT(e.dob,'$salt'),'%m/%d/%Y') as dob,
                            AES_DECRYPT(e.name,'$salt') as pname,
                            AES_DECRYPT(e.race,'$salt') as race,
                            e.cancer_mode,
                            e.case_submit_date,
                            e.family_history,
                            DATE_FORMAT(e.case_updated_date, '%m/%d/%y') AS case_updated_date,
                            e.pathology_others_text,
                            e.id as case_id,
                            e.case_status as case_status,
                            b.is_tumor,
                            b.is_specific_provider,
                            b.is_speciality,
                            b.is_other,
                            (SELECT
                              CONCAT(fname, ' ', lname)
                            FROM
                              users
                            WHERE id = e.case_entered_by) AS name,
                            (SELECT
                              comments
                            FROM
                              case_doctor_comments
                            WHERE case_id = a.case_id
                              AND doctor_id = '" . $_SESSION['u_userid'] . "') AS COMMENT,
                            e.case_entered_by AS doctor_id,
                            d.speciality_id,
                            e.case_status
                          FROM
                            case_history AS e
                            INNER JOIN case_assignments AS b
                              ON (e.id = b.case_id)
                            LEFT JOIN case_doc_email_status AS a
                              ON (b.case_id = a.case_id)
                            LEFT JOIN users AS d
                              ON (a.doctor_id = d.id)

                          WHERE ";
        if ($this->session->userdata('speciality_id') != HOSPITAL_ADMIN_SPECILITY)
            $user_case_query .= "(
                              a.doctor_id = '" . $_SESSION['u_userid'] . "' $where_tumor
                            ) AND ";
        $user_case_query .= " is_deleted = '0'
                            AND e.id = '" . $case_id . "'
                            GROUP BY e.id
                          ORDER BY e.case_updated_date DESC ";


        $user_case_assigned = $this->db->query($user_case_query);
//echo $user_case_assigned->num_rows(); die;
        if ($user_case_assigned->num_rows() > 0) {
            $case_array = array();
            $final_array = array();
            $case_list_ids = $user_case_assigned->row();
//        echo '<pre>';
//        print_r($case_list_ids);
//        die;
//echo $case_list_ids->speciality_id;
            $result = "";

            $image_data = $this->db->query("Select * from case_save_images where case_id = '" . $case_id . "'");
            $images = array();
            $pathology = array();
            $radiology = array();
            $genetics = array();
            $administrator = array();
//echo '<pre>';
//print_r($image_data->result_object()); die;
            foreach ($image_data->result_object() as $image) {

                if (($image->doctor_id == $case_list_ids->doctor_id)) {
                    $images[] = (object) array(
                                'case_id' => $image->case_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments,
                                'id' => $image->id
                    );
                }


                if ($image->speciality_id == 6 && $image->doctor_id != $case_list_ids->doctor_id) {
                    $pathology[] = (object) array(
                                'case_id' => $image->case_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments,
                                'id' => $image->id
                    );
                }


                if ($image->speciality_id == 8 && $image->doctor_id != $case_list_ids->doctor_id) {
                    $radiology[] = (object) array(
                                'case_id' => $image->case_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments,
                                'id' => $image->id
                    );
                }


                if ($image->speciality_id == 11 && $image->doctor_id != $case_list_ids->doctor_id) {
                    $genetics[] = (object) array(
                                'case_id' => $image->case_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments,
                                'id' => $image->id
                    );
                }

                if ($image->speciality_id == 2 && $image->doctor_id != $case_list_ids->doctor_id) {
                    $administrator[] = (object) array(
                                'case_id' => $image->case_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments,
                                'id' => $image->id
                    );
                }
            }

            $result = (object) array(
                        'images' => (object) $images,
                        'pathology' => (object) $pathology,
                        'radiology' => (object) $radiology,
                        'genetics' => (object) $genetics,
                        'administrator' => (object) $administrator,
            );

//echo '<pre>';
//print_r($result); die;
            $summary_data = $this->db->query("Select a.case_summary,b.speciality_id from case_save_images_summary as a INNER JOIN case_save_images as b on a.speciality_id=b.speciality_id where a.case_id = '" . $case_id . "' and b.speciality_id IN (2,6,8,11) group by a.speciality_id");

            foreach ($summary_data->result_object() as $summary) {
                if ($summary->speciality_id == 2) {
                    $result->administrator_summary = $summary->case_summary;
                }
                if ($summary->speciality_id == 6) {
                    $result->pathology_summary = $summary->case_summary;
                }
                if ($summary->speciality_id == 8) {
                    $result->radiology_summary = $summary->case_summary;
                }

                if ($summary->speciality_id == 11) {
                    $result->genetics_summary = $summary->case_summary;
                }
            }
//print_r($result);


            $comment = "";
            $comment_data = $this->db->query("Select * from case_doctor_comments where case_id = '" . $case_id . "' and doctor_id='" . $_SESSION['u_userid'] . "' ");
            if (count($comment_data->num_rows() > 0)) {
                foreach ($comment_data->result() as $c) {
                    $comment = array(
                        'id' => $c->id,
                        'comments' => $c->comments,
                        'specific_answers' => $c->specific_answers,
                        'other_answer' => $c->other_answer,
                    );
                }
            }

//        $answer_array = array();
//        if (isset($case_list_ids->case_id) && !empty($case_list_ids->case_id)) {
//            $answer_data = $this->db->query("Select a.*,concat(b.fname,' ',b.lname) as enterby,d.* from case_doctor_comments as a inner join users as b on a.doctor_id = b.id  inner join speciality as d on d.speciality_id = a.speciality_id  where a.case_id = '" . $case_list_ids->case_id . "' group by a.id");
//            foreach ($answer_data->result_object() as $answer) {
//                if (count($answer) > 0) {
//                    if (!empty($answer->specific_answers) && isset($answer->specific_answers)) {
//                        $spec_data = $this->db->query("Select specific_answers from specificanswer where id = '" . $answer->specific_answers . "'");
//                        $spec_text = $this->db->result_object($spec_data);
//                    } else {
//                        $spec_text['specific_answers'] = "";
//                    }
//
            //                    $answer_array[] = (object) array(
//                                'answer_id' => $answer->id,
//                                'case_id' => $answer->case_id,
//                                'doctor_id' => $answer->doctor_id,
//                                'date' => $answer->date,
//                                'comments' => $answer->comments,
//                                'specific_answers' => $answer->specific_answers,
//                                'other_answers' => $answer->other_answer,
//                                'enterby' => $answer->enterby,
//                                'speciality_id' => $answer->speciality_id,
//                                'speciality_name' => $answer->speciality_name,
//                                'spec_text' => $spec_text->specific_answers,
//                    );
//                }
//            }
//        }

            $Poster_question_answer = array();
            if (isset($case_list_ids->case_id) && !empty($case_list_ids->case_id)) {
                $question_data = $this->db->query("SELECT x.case_entered_by as doctor_id, a.specific_question_id,b.spec_question FROM case_question_answer as a inner join case_history as x on a.case_id=x.id INNER JOIN specificquestion as b on a.specific_question_id=b.id where a.case_id='" . $case_list_ids->case_id . "'");
                foreach ($question_data->result() as $question) {
                    $answer_data = $this->db->query("SELECT * FROM case_question_answer WHERE case_id='" . $case_list_ids->case_id . "' and doctor_id='" . $question->doctor_id . "'");
                    foreach ($answer_data->result() as $answer1) {
                        if ($answer1->my_thought_id == '0') {
                            $Poster_question_answer[] = (object) array(
                                        'question_id' => $question->specific_question_id,
                                        'spec_question_name' => $question->spec_question,
                                        'answer_name' => $answer1->other_answer,
                                        'comments' => $answer1->comments
                            );
                        } else {
                            $answer_data = $this->db->query("SELECT specific_answers FROM specificanswer WHERE id='" . $answer1->my_thought_id . "'");
                            $answer1 = $answer_data->row();
                            $Poster_question_answer[] = (object) array(
                                        'question_id' => $question->specific_question_id,
                                        'spec_question_name' => $question->spec_question,
                                        'answer_name' => $answer1->specific_answers,
                                        'comments' => $answer1->comments,
                            );
                        }
                    }
                }
            }

            $final_array = array(
                'case_id' => $case_list_ids->case_id,
                'doctor_id' => $case_list_ids->doctor_id,
                'doctor_name' => $case_list_ids->name,
                'pname' => $case_list_ids->pname,
                'dob' => $case_list_ids->dob,
                'pathology_others_text' => $case_list_ids->pathology_others_text,
                'is_tumor' => $case_list_ids->is_tumor,
                'is_specific_provider' => $case_list_ids->is_specific_provider,
                'is_speciality' => $case_list_ids->is_speciality,
                'is_other' => $case_list_ids->is_other,
                'comment' => (object) $comment,
                'case_description' => $case_list_ids->case_description,
                'case_entered_by' => $case_list_ids->case_entered_by,
                'case_updated_date' => $case_list_ids->case_updated_date,
                'case_status' => $case_list_ids->case_status,
                'image_data' => (object) $result,
                //'answer_data' => (object) $answer_array,
                'my_question_answer' => (object) $Poster_question_answer,
            );


            $top_answer = "";
            $top_answer = $this->getmaxanswerslist(array('case_id' => $case_list_ids->case_id));
            if ($top_answer) {
                $final_array['top_answer'] = (object) $top_answer;
            }
            $getanswer = "";
            if (!empty($case_list_ids->speciality_id)) {
                //echo '<pre>';
                //print_r($top_answer); die;

                $getanswer = $this->getspecificanswerlist(array('cancer_id' => $case_list_ids->cancer_id, 'cancer_mode' => $case_list_ids->cancer_mode, 'speciality_id' => $this->session->userdata('speciality_id')));
                if ($getanswer) {
                    $final_array['specific_answer'] = (object) $getanswer;
                }
            }

            $final_array = (object) $final_array;


            return $final_array;
        } else {
            return false;
        }
    }

    // to fetch the next case on case description page
    public function next_case($data) {
        if ($data['pageid'] == 1) {
            $query = "SELECT
                       e.case_entered_by,e.case_updated_date,
                       e.id AS case_id
                     FROM
                       case_history AS e
                       INNER JOIN case_assignments AS b
                         ON (e.id = b.case_id)
                       LEFT JOIN case_doc_email_status AS a
                         ON (b.case_id = a.case_id)
                       LEFT JOIN users AS d
                         ON (a.doctor_id = d.id)
                     WHERE e.case_status = '1'
                       AND e.case_entered_by='" . $_SESSION['u_userid'] . "'
                       AND e.is_deleted = '0'
                       AND e.case_updated_date<(SELECT case_updated_date FROM case_history WHERE id='" . $data['case_id'] . "')
                     GROUP BY e.id
                     ORDER BY e.case_updated_date DESC
                     LIMIT 1";
        } else if ($data['pageid'] == 2) {
            $query = "SELECT * FROM(SELECT
                            e.id AS case_id,
                            e.case_entered_by,
                              (SELECT
                                    id
                                  FROM
                                    case_doctor_comments
                                  WHERE case_id = e.id
                                    AND doctor_id = '" . $_SESSION['u_userid'] . "' limit 1 ) AS commentdocotor
                          FROM
                            case_history AS e
                            INNER JOIN case_assignments AS b
                              ON (e.id = b.case_id)
                            LEFT JOIN case_doc_email_status AS a
                              ON (b.case_id = a.case_id)
                            LEFT JOIN users AS d
                              ON (a.doctor_id = d.id)
                          WHERE is_deleted = '0'
                            AND e.case_status = '1'
                            AND e.id IN
                            (SELECT
                              case_id
                            FROM
                              case_doctor_comments
                            WHERE doctor_id = '" . $_SESSION['u_userid'] . "') ) X
                          WHERE  X.commentdocotor < (SELECT  id FROM case_doctor_comments WHERE case_id = '" . $data['case_id'] . "' LIMIT 1)
                          GROUP BY X.case_id
                          ORDER BY X.commentdocotor DESC
                          LIMIT 1";
        } else if ($data['pageid'] == 3) {
            $query = "SELECT
                        e.id AS case_id
                      FROM
                        case_history AS e
                        INNER JOIN case_assignments AS b
                          ON (e.id = b.case_id)
                        LEFT JOIN case_doc_email_status AS a
                          ON (b.case_id = a.case_id)
                        LEFT JOIN users AS d
                          ON (a.doctor_id = d.id)
                      WHERE (a.doctor_id = '" . $_SESSION['u_userid'] . "')
                        AND e.case_status = '1'
                        AND e.is_deleted = '0'
                        AND e.case_updated_date<(SELECT case_updated_date FROM case_history WHERE id='" . $data['case_id'] . "')
                        AND e.id NOT IN
                        (SELECT
                          case_id
                        FROM
                          case_doctor_comments
                        WHERE doctor_id = '" . $_SESSION['u_userid'] . "')
                      GROUP BY e.id
                      ORDER BY e.case_updated_date DESC
                      LIMIT 1";
        } else if ($data['pageid'] == 4) {
            $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
            $speciality_id = $userdata->speciality_id;

            $query = "SELECT
                        a.case_id ,
                         h.case_updated_date
                       FROM
                         case_request_images AS a
                         INNER JOIN case_assignments AS b
                           ON a.case_id = b.case_id
                         INNER JOIN case_history AS h
                           ON h.id = b.case_id
                         INNER JOIN users AS d
                           ON d.id != h.case_entered_by
                         LEFT JOIN `hospital_network` h1
                           ON h1.`id` = h.assigned_hospital
                       WHERE a.doctor_id = '" . $_SESSION['u_userid'] . "'
                         AND h.case_status = '1'
                         AND h.is_deleted = '0'
                         AND a.is_forwarded = '0'
                         AND h.case_updated_date < (SELECT case_updated_date FROM case_history WHERE id='" . $data['case_id'] . "')
                         AND a.case_id NOT IN
                         (SELECT
                           case_id
                         FROM
                           case_save_images
                         WHERE doctor_id = '" . $_SESSION['u_userid'] . "'
                         UNION
                         SELECT
                           case_id
                         FROM
                           case_save_images
                         WHERE speciality_id = '" . $speciality_id . "'
                           AND case_id NOT IN
                           (SELECT
                             cs.`case_id`
                           FROM
                             `case_save_images` cs
                             INNER JOIN case_history ch
                               ON cs.`case_id` = ch.`id`
                               AND cs.`doctor_id` = ch.`case_entered_by`
                               AND cs.`doctor_id` !='" . $_SESSION['u_userid'] . "'
                           GROUP BY case_id))
                       GROUP BY b.case_id
                       ORDER BY h.case_updated_date DESC

                       LIMIT 1";
        } else if ($data['pageid'] == 5) {
            $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
            $speciality_id = $userdata->speciality_id;

            $query = "SELECT
                        a.case_id ,
                         h.case_updated_date
                       FROM
                         case_request_images AS a
                         INNER JOIN case_assignments AS b
                           ON a.case_id = b.case_id
                         INNER JOIN case_history AS h
                           ON h.id = b.case_id
                         INNER JOIN users AS d
                           ON d.id != h.case_entered_by
                         LEFT JOIN `hospital_network` h1
                           ON h1.`id` = h.assigned_hospital
                       WHERE a.doctor_id = '" . $_SESSION['u_userid'] . "'
                         AND h.case_status = '1'
                         AND h.is_deleted = '0'
                         AND a.is_forwarded = '0'
                         AND h.case_updated_date < (SELECT case_updated_date FROM case_history WHERE id='" . $data['case_id'] . "')
                         AND a.case_id IN
                         (SELECT
                           case_id
                         FROM
                           case_save_images
                         WHERE doctor_id = '" . $_SESSION['u_userid'] . "'
                         UNION
                         SELECT
                           case_id
                         FROM
                           case_save_images
                         WHERE speciality_id = '" . $speciality_id . "'
                           AND case_id IN
                           (SELECT
                             cs.`case_id`
                           FROM
                             `case_save_images` cs
                             INNER JOIN case_history ch
                               ON cs.`case_id` = ch.`id`
                               AND cs.`doctor_id` = ch.`case_entered_by`
                               AND cs.`doctor_id` !='" . $_SESSION['u_userid'] . "'
                           GROUP BY case_id))
                       GROUP BY b.case_id
                       ORDER BY h.case_updated_date DESC

                       LIMIT 1";
        }



        $querys = $this->db->query($query);
        $case = $querys->row();
        if (!empty($case)) {
            return $case->case_id;
        }
    }

    //list of answer list
    public function getspecificanswerlist($request) {
        $cancer_id = $request['cancer_id'];

        $other_solid_array = array(12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46);

        if (in_array($cancer_id, $other_solid_array))
            $cancer_id = 12;

        $cancer_mode = $request['cancer_mode'];
        $speciality_id = $request['speciality_id'];
        $result = $this->db->query("SELECT * FROM specificanswer as a inner join cancercategories as b on a.cancer_id = b.cancer_id inner join speciality as c on a.speciality_id = c.speciality_id where a.cancer_id = '" . $cancer_id . "' and a.cancer_mode = '" . $cancer_mode . "' and a.speciality_id = '" . $speciality_id . "' and a.is_active='1' ");
        $answerarray = array();
        foreach ($result->result_object() as $answer_fetch) {
            $answerarray[] = (object) array(
                        'answer_id' => $answer_fetch->id,
                        'specific_answer' => $answer_fetch->specific_answers,
                        'speciality_id' => $answer_fetch->speciality_id,
                        'speciality_name' => $answer_fetch->speciality_name,
                        'cancer_id' => $answer_fetch->cancer_id,
                        'cancer_type' => $answer_fetch->cancer_type
            );
        }
        return $answerarray;
    }

    // to save doctor comments in answer data
    public function savecasescomments() {
        $case_id = $this->input->post('case_id');
        $doctor_id = $this->session->userdata('u_userid');
        $comments = $this->input->post('comments');
        $speciality = $this->session->userdata('speciality_id');
        $specific_answers = $this->input->post('specific_answers');
        $other_answer = $this->input->post('other_answer');
        $answer_id = $this->input->post('answer_id');
        if (empty($answer_id)) {
            $query = $this->db->get_where('case_doctor_comments', array('case_id' => $case_id, 'doctor_id' => $doctor_id), 1);
            $results = $query->row();

            if ($query->num_rows() == 0) {
                if (isset($specific_answers) && !empty($specific_answers)) {
                    $data = array('case_id' => $case_id, 'doctor_id' => $doctor_id, 'date' => date('Y-m-d:H:i:s'), 'comments' => $comments, 'speciality_id' => $speciality, 'specific_answers' => $specific_answers);
                    $answers_query = $this->db->insert('case_doctor_comments', $data);
                    //$answers_query = $this->db->query("Insert into case_doctor_comments (case_id,doctor_id,date,comments,speciality_id,specific_answers)values('" . db_clean($case_id) . "','" . db_clean($doctor_id) . "','" . date('Y-m-d:H:i:s') . "','" . db_clean($comments) . "','" . db_clean($speciality) . "','" . db_clean($specific_answers) . "' )");
                } else {
                    $data = array('case_id' => $case_id, 'doctor_id' => $doctor_id, 'date' => date('Y-m-d:H:i:s'), 'comments' => $comments, 'speciality_id' => $speciality, 'specific_answers' => '0', 'other_answer' => $other_answer);
                    $answers_query = $this->db->insert('case_doctor_comments', $data);
                    //$answers_query = $this->db->query("Insert into case_doctor_comments (case_id,doctor_id,date,comments,speciality_id,specific_answers,other_answer)values('" . db_clean($case_id) . "','" . db_clean($doctor_id) . "','" . date('Y-m-d:H:i:s') . "','" . db_clean($comments) . "','" . db_clean($speciality) . "', '0' , '" . db_clean($other_answer) . "' )");
                }
            }
        } else {
            if (isset($specific_answers) && !empty($specific_answers)) {
                $data = array('case_id' => $case_id, 'doctor_id' => $doctor_id, 'date' => date('Y-m-d:H:i:s'), 'comments' => $comments, 'speciality_id' => $speciality, 'specific_answers' => $specific_answers);
                $this->db->where('id', $answer_id);
                $answers_query = $this->db->update('case_doctor_comments', $data);
                // $answers_query = $this->db->query("Update case_doctor_comments set case_id = '" . db_clean($case_id) . "',doctor_id = '" . db_clean($doctor_id) . "',comments = '" . db_clean($comments) . "',speciality_id = '" . db_clean($speciality) . "',specific_answers = '" . db_clean($specific_answers) . "' where id = '" . db_clean($answer_id) . "'");
            } else {
                $data = array('case_id' => $case_id, 'doctor_id' => $doctor_id, 'date' => date('Y-m-d:H:i:s'), 'comments' => $comments, 'speciality_id' => $speciality, 'specific_answers' => '0', 'other_answer' => $other_answer);
                $this->db->where('id', $answer_id);
                $answers_query = $this->db->update('case_doctor_comments', $data);
                //$answers_query = $this->db->query("Update case_doctor_comments set case_id = '" . db_clean($case_id) . "',doctor_id = '" . db_clean($doctor_id) . "',comments = '" . db_clean($comments) . "',speciality_id = '" . db_clean($speciality) . "',specific_answers = '0',other_answer = '" . db_clean($other_answer) . "' where id = '" . db_clean($answer_id) . "'");
            }
        }
        If (isset($answers_query) && !empty($answers_query)) {
            if (empty($answer_id)) {
                $this->session->set_flashdata('success', 'Your Answer has been submitted successfully.');
            } else {
                $this->session->set_flashdata('success', 'Your Answer Updated Successfully.');
            }
        } else {
            $this->session->set_flashdata('error', 'Please try again later.');
        }
        return true;
    }

    // delete the case
    public function delete_case() {

        $case_id = $this->input->post('case_id');
        $doctor_id = $this->session->userdata('u_userid');

        if (!empty($case_id)) {
            //$postdetails_query = $this->db->query("Update case_history SET is_deleted = '1',case_updated_date = '" . date('Y-m-d H:i:s') . "' where id = '" . db_clean($case_id) . "'");
            $data = array('is_deleted' => '1', 'case_updated_date' => date('Y-m-d H:i:s'));
            $this->db->where('id', $case_id);
            $postdetails_query = $this->db->update('case_history', $data);

            if ($postdetails_query) {
                $this->session->set_flashdata('success', 'Your case has been deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Please try again later');
            }
        } else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }

        return true;
    }

    public function delete_case_hospital_admin() {

        $case_id = $this->input->post('case_id');
        $doctor_id = $this->session->userdata('u_userid');

        if (!empty($case_id)) {
            //$postdetails_query = $this->db->query("Update case_history SET is_deleted = '1',case_updated_date = '" . date('Y-m-d H:i:s') . "' where id = '" . db_clean($case_id) . "'");
            $data = array('is_deleted' => '1', 'case_updated_date' => date('Y-m-d H:i:s'));
            $this->db->where('id', $case_id);
            $postdetails_query = $this->db->update('case_history', $data);

            if ($postdetails_query) {
                $this->session->set_flashdata('success', 'Your case has been deleted successfully');
            } else {
                $this->session->set_flashdata('error', 'Please try again later');
            }
        } else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }

        die;
        return true;
    }

    // to close the case
    public function case_close() {

        $case_id = $this->input->post('case_id');
        $doctor_id = $this->session->userdata('u_userid');
        if (!empty($case_id) && !empty($doctor_id)) {
            $data = array('case_status' => '0', 'case_updated_date' => date('Y-m-d H:i:s'));
            $this->db->where('id', $case_id);
            $postdetails_query = $this->db->update('case_history', $data);

            //$postdetails_query = $this->db->query("Update case_history SET case_status = '0',case_updated_date = '" . date('Y-m-d H:i:s') . "' where id = '" . db_clean($case_id) . "'");
            $this->session->set_flashdata('success', 'Your case has been closed.');
        } else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }

    //to fetch comment entered by doctor on answer cases
    public function getmaxanswerslist($request) {
        $case_id = $request['case_id'];
        $answerlist_query = $this->db->query("SELECT
                                speciality_id,
                                a.specific_answers,
                                a.tot_ans
                              FROM
                                (SELECT
                                  COUNT(specific_answers) AS tot_ans,
                                  speciality_id,
                                  specific_answers
                                FROM
                                  case_doctor_comments
                                WHERE `case_id` = '" . $case_id . "'
                                  AND specific_answers != '0'
                                GROUP BY `specific_answers`
                                ORDER BY tot_ans DESC) AS a
                              GROUP BY a.`speciality_id`
                              HAVING MAX(a.tot_ans)");
        $top_ans_array = array();
        foreach ($answerlist_query->result_object() as $answer) {
            $sub_answer_query = $this->db->query("Select a.specific_answers as ans_text,b.speciality_name from specificanswer as a inner join speciality as b on a.speciality_id = b.speciality_id where a.speciality_id='" . $answer->speciality_id . "' and a.id ='" . $answer->specific_answers . "'");
            foreach ($sub_answer_query->result_object() as $subcat) {
                $top_ans_array[] = (object) array(
                            'speciality_id' => $answer->speciality_id,
                            'specific_answer' => $answer->specific_answers,
                            'speciality_name' => $subcat->speciality_name,
                            'specific_answer_text' => $subcat->ans_text,
                );
            }
        }

        $answerlist_query = $this->db->query("select * from case_doctor_comments as a inner join speciality as b on a.speciality_id = b.speciality_id where a.specific_answers ='0' and a.case_id ='" . $case_id . "' group by a.speciality_id");
        foreach ($answerlist_query->result_object() as $subcat) {
            $top_ans_array[] = (object) array(
                        'speciality_id' => $subcat->speciality_id,
                        'speciality_name' => $subcat->speciality_name,
                        'comments' => $subcat->comments,
                        'specific_answer_text' => $subcat->other_answer,
            );
        }
        return $top_ans_array;
    }

    // to fetch the list of answers according to specilaity for answer open page
    public function getanswerdetaillist($request) {
//echo $request['case_id'];
        $case_id = $request['case_id'];
        $speciality_id = $request['speciality_id'];
        $answer_data = $this->db->query("Select a.*,concat(b.fname,' ',b.lname) as enterby,d.*,e.specific_answers as spec_text from case_doctor_comments as a inner join users as b on a.doctor_id = b.id  inner join speciality as d on d.speciality_id = a.speciality_id inner join specificanswer as e on a.specific_answers = e.id  where a.case_id = '" . $case_id . "' and a.speciality_id = '" . $speciality_id . "' and a.specific_answers != '0' group by a.id");
        $final_array = array();
        foreach ($answer_data->result_object() as $answer) {
            $final_array[] = (object) array(
                        'answer_id' => $answer->id,
                        'case_id' => $answer->case_id,
                        'doctor_id' => $answer->doctor_id,
                        'date' => $answer->date,
                        'comments' => $answer->comments,
                        'specific_answers' => $answer->specific_answers,
                        'other_answers' => $answer->other_answer,
                        'enterby' => $answer->enterby,
                        'speciality_id' => $answer->speciality_id,
                        'speciality_name' => $answer->speciality_name,
                        'spec_text' => $answer->spec_text,
            );
        }

        $answer_data = $this->db->query("Select a.*,concat(b.fname,' ',b.lname) as enterby,d.* from case_doctor_comments as a inner join users as b on a.doctor_id = b.id  inner join speciality as d on d.speciality_id = a.speciality_id   where a.case_id = '" . $case_id . "' and a.speciality_id = '" . $speciality_id . "' and a.specific_answers = '0' group by a.id");
        foreach ($answer_data->result_object() as $answer) {
            $final_array[] = (object) array(
                        'answer_id' => $answer->id,
                        'case_id' => $answer->case_id,
                        'doctor_id' => $answer->doctor_id,
                        'date' => $answer->date,
                        'comments' => $answer->comments,
                        'specific_answers' => $answer->specific_answers,
                        'other_answers' => $answer->other_answer,
                        'enterby' => $answer->enterby,
                        'speciality_id' => $answer->speciality_id,
                        'speciality_name' => $answer->speciality_name,
                        'spec_text' => "",
            );
        }
        return $final_array;
    }

    //to get select box data for post case
    public function getmultipledata($cancerid, $cancermode) {
        $cancer_id = $cancerid;
        $cancer_mode = $cancermode;
        if ($cancer_mode == "0" && $cancerid != 12 && $cancerid != 11) {
            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "' ");
            $final_array = array();
            $categorydata = $category_query->result_array();
            foreach ($categorydata as $category) {
                $hormonal_query = $this->db->query("Select * from adjuvanthormonaltherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $hormonal_array = array();
                foreach ($hormonal_query->result_array() as $data) {
                    $hormonal_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['hormonal_therapy_type']
                    );
                }

                $radiation_query = $this->db->query("Select * from adjuvantradation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $radiation_array = array();
                foreach ($radiation_query->result_array() as $data) {
                    $radiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['radiation_type']
                    );
                }
                $systemic_query = $this->db->query("Select * from adjuvantsystemictherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $systemic_array = array();
                foreach ($systemic_query->result_array() as $data) {
                    $systemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_type']
                    );
                }
                $definitive_query = $this->db->query("Select * from definitivesurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $definitive_array = array();
                foreach ($definitive_query->result_array() as $data) {
                    $definitive_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_type']
                    );
                }
                $mammaprint_query = $this->db->query("Select * from mammaprint where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $mammaprint_array = array();
                foreach ($mammaprint_query->result_array() as $data) {
                    $mammaprint_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['mammaprint_type']
                    );
                }
                $neoadjuvant_query = $this->db->query("Select * from neoadjuvant where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $neoadjuvant_array = array();
                foreach ($neoadjuvant_query->result_array() as $data) {
                    $neoadjuvant_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['therapy_type']
                    );
                }
                $oncotype_query = $this->db->query("Select * from oncotype where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $oncotype_array = array();
                foreach ($oncotype_query->result_array() as $data) {
                    $oncotype_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['oncotype_data']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($neoadjuvant_array) > 0) {
                    $final_array["Neoadjuvant_Therapy"] = $neoadjuvant_array;
                }
                if (count($definitive_array) > 0) {
                    $final_array["Definitive_Surgery"] = $definitive_array;
                }
                if (count($systemic_array) > 0) {
                    $final_array["Systemic_Therapy"] = $systemic_array;
                }
                if (count($hormonal_array) > 0) {
                    $final_array["Hormonal_Therapy"] = $hormonal_array;
                }
                if (count($radiation_array) > 0) {
                    $final_array["Adjuvant_Radiation"] = $radiation_array;
                }
                if (count($oncotype_array) > 0) {
                    $final_array["Oncotype"] = $oncotype_array;
                }
                if (count($mammaprint_array) > 0) {
                    $final_array["Mammaprint"] = $mammaprint_array;
                }
            }
        } elseif (($cancer_id == "2" && $cancer_mode == "1")) {
            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "'");
            $final_array = array();
            foreach ($category_query->result_array() as $category) {
                $metasurgery_query = $this->db->query("Select * from metasurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasurgery_array = array();
                foreach ($metasurgery_query->result_array() as $data) {
                    $metasurgery_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_value']
                    );
                }
                $metasystemic_query = $this->db->query("Select * from metasystemictherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasystemic_array = array();
                foreach ($metasystemic_query->result_array() as $data) {
                    $metasystemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_name']
                    );
                }
                $metaradiation_query = $this->db->query("Select * from metaradiation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metaradiation_array = array();
                foreach ($metaradiation_query->result_array() as $data) {
                    $metaradiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['metaradiation_type']
                    );
                }
                $neoadjuvant_query = $this->db->query("Select * from neoadjuvant where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $neoadjuvant_array = array();
                foreach ($neoadjuvant_query->result_array() as $data) {
                    $neoadjuvant_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['therapy_type']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($neoadjuvant_array) > 0) {
                    $final_array["Neoadjuvant_Therapy"] = $neoadjuvant_array;
                }
                if (count($metasurgery_array) > 0) {
                    $final_array["Meta_Surgery"] = $metasurgery_array;
                }
                if (count($metasystemic_array) > 0) {
                    $final_array["Meta_Systemic"] = $metasystemic_array;
                }
                if (count($metaradiation_array) > 0) {
                    $final_array["Meta_Radiation"] = $metaradiation_array;
                }
            }
        } elseif (($cancer_id == "4" && $cancer_mode == "1")) {
            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "'");
            $final_array = array();
            foreach ($category_query->result_array() as $category) {
                $definitive_query = $this->db->query("Select * from definitivesurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $definitive_array = array();
                foreach ($definitive_query->result_array() as $data) {
                    $definitive_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_type']
                    );
                }
                $metasystemic_query = $this->db->query("Select * from metasystemictherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasystemic_array = array();
                foreach ($metasystemic_query->result_array() as $data) {
                    $metasystemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_name']
                    );
                }
                $metaradiation_query = $this->db->query("Select * from metaradiation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metaradiation_array = array();
                foreach ($metaradiation_query->result_array() as $data) {
                    $metaradiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['metaradiation_type']
                    );
                }
                $neoadjuvant_query = $this->db->query("Select * from neoadjuvant where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $neoadjuvant_array = array();
                foreach ($neoadjuvant_query->result_array() as $data) {
                    $neoadjuvant_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['therapy_type']
                    );
                }

                $oncotype_query = $this->db->query("Select * from oncotype where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $oncotype_array = array();
                foreach ($oncotype_query->result_array() as $data) {
                    $oncotype_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['oncotype_data']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($neoadjuvant_array) > 0) {
                    $final_array["Neoadjuvant_Therapy"] = $neoadjuvant_array;
                }
                if (count($oncotype_array) > 0) {
                    $final_array["Oncotype"] = $oncotype_array;
                }
                if (count($definitive_array) > 0) {
                    $final_array["Definitive_Surgery"] = $definitive_array;
                }
                if (count($metasystemic_array) > 0) {
                    $final_array["Meta_Systemic"] = $metasystemic_array;
                }
                if (count($metaradiation_array) > 0) {
                    $final_array["Meta_Radiation"] = $metaradiation_array;
                }
            }
        } elseif (($cancer_id == "4" && $cancer_mode == "2")) {
            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "'");
            $final_array = array();
            foreach ($category_query->result_array() as $category) {
                $definitive_query = $this->db->query("Select * from definitivesurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $definitive_array = array();
                foreach ($definitive_query->result_array() as $data) {
                    $definitive_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_type']
                    );
                }
                $metasystemic_query = $this->db->query("Select * from metasystemictherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasystemic_array = array();
                foreach ($metasystemic_query->result_array() as $data) {
                    $metasystemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_name']
                    );
                }
                $metaradiation_query = $this->db->query("Select * from metaradiation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metaradiation_array = array();
                foreach ($metaradiation_query->result_array() as $data) {
                    $metaradiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['metaradiation_type']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($definitive_array) > 0) {
                    $final_array["Definitive_Surgery"] = $definitive_array;
                }
                if (count($metasystemic_array) > 0) {
                    $final_array["Meta_Systemic"] = $metasystemic_array;
                }
                if (count($metaradiation_array) > 0) {
                    $final_array["Meta_Radiation"] = $metaradiation_array;
                }
            }
        } elseif ((($cancer_id == "12" || $cancer_id == "11" ))) {


            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "'");
            $final_array = array();
            foreach ($category_query->result_array() as $category) {
                $definitive_query = $this->db->query("Select * from metasurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $definitive_array = array();
                foreach ($definitive_query->result_array() as $data) {
                    $definitive_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_value']
                    );
                }
                $metasystemic_query = $this->db->query("Select * from chemotherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasystemic_array = array();
                foreach ($metasystemic_query->result_array() as $data) {
                    $metasystemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_type']
                    );
                }
                $metaradiation_query = $this->db->query("Select * from metaradiation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metaradiation_array = array();
                foreach ($metaradiation_query->result_array() as $data) {
                    $metaradiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['metaradiation_type']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($definitive_array) > 0) {
                    $final_array["Meta_Surgery"] = $definitive_array;
                }
                if (count($metasystemic_array) > 0) {
                    $final_array["chemotherapy"] = $metasystemic_array;
                }
                if (count($metaradiation_array) > 0) {
                    $final_array["Meta_Radiation"] = $metaradiation_array;
                }
            }
        } elseif ($cancer_mode != "" && $cancer_id != "") {
            $category_query = $this->db->query("Select * from cancercategories where cancer_id = '" . $cancer_id . "'");
            $final_array = array();
            foreach ($category_query->result_array() as $category) {
                $metasurgery_query = $this->db->query("Select * from metasurgery where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasurgery_array = array();
                foreach ($metasurgery_query->result_array() as $data) {
                    $metasurgery_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['surgery_value']
                    );
                }
                $metasystemic_query = $this->db->query("Select * from metasystemictherapy where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metasystemic_array = array();
                foreach ($metasystemic_query->result_array() as $data) {
                    $metasystemic_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['systemic_therapy_name']
                    );
                }
                $metaradiation_query = $this->db->query("Select * from metaradiation where cancer_id='" . $category['cancer_id'] . "' and cancer_mode ='" . $cancer_mode . "' and is_active='1' ");
                $metaradiation_array = array();
                foreach ($metaradiation_query->result_array() as $data) {
                    $metaradiation_array[] = array(
                        'custom_id' => $data['id'],
                        'name' => $data['metaradiation_type']
                    );
                }
                $final_array["Cancer_id"] = $category['cancer_id'];
                $final_array["Cancer_name"] = $category['cancer_type'];
                if (count($metasurgery_array) > 0) {
                    $final_array["Meta_Surgery"] = $metasurgery_array;
                }
                if (count($metasystemic_array) > 0) {
                    $final_array["Meta_Systemic"] = $metasystemic_array;
                }
                if (count($metaradiation_array) > 0) {
                    $final_array["Meta_Radiation"] = $metaradiation_array;
                }
            }
        }
//        echo "<pre>"; print_r($final_array);
        return $final_array;
    }

    //to get name for image request in post  case
    public function getimagerequest($user_id) {
        $user_id = $user_id;

        $hospitals_query = $this->db->query("Select * from hospital_doctor as a inner join hospital_network as b on b.id = a.hospital_id where a.is_active='1' and b.is_active='1' and doctor_id = '" . $user_id . "'");
        $pathology_image_array = array();
        foreach ($hospitals_query->result_array() as $hospitaldata) {
            $provider_query = $this->db->query("Select b.id,a.hospital_doctor_id,a.hospital_id,b.fname,b.lname,d.speciality_name from hospital_doctor as a inner join users as b on a.doctor_id = b.id inner join speciality_hospital_doctor as c on c.hospital_doctor_id = a.hospital_doctor_id inner join speciality as d on d.speciality_id = c.speciality_id where a.is_active='1' and b.is_active='1' and a.hospital_id = '" . $hospitaldata['hospital_id'] . "' and a.doctor_id !='" . $user_id . "' and c.speciality_id='6' ");
            foreach ($provider_query->result_array() as $data) {
                $pathology_image_array[] = array(
                    'user_id' => $data['id'],
                    'user_name' => $data['fname'] . " " . $data['lname'],
                    'hospital_doctor_id' => $data['hospital_doctor_id'],
                    'speciality_name' => $data['speciality_name'],
                    'hospital_id' => $data['hospital_id'],
                    'hospital_network' => $hospitaldata['hospital_network']
                );
            }
        }


        $hospitals_query = $this->db->query("Select * from hospital_doctor as a inner join hospital_network as b on b.id = a.hospital_id where a.is_active='1' and b.is_active='1' and  doctor_id = '" . $user_id . "'");
        $radiology_image_array = array();
        foreach ($hospitals_query->result_array() as $hospitaldata) {
            $provider_query = $this->db->query("Select b.id,a.hospital_doctor_id,a.hospital_id,b.fname,b.lname,d.speciality_name from hospital_doctor as a inner join users as b on a.doctor_id = b.id inner join speciality_hospital_doctor as c on c.hospital_doctor_id = a.hospital_doctor_id inner join speciality as d on d.speciality_id = c.speciality_id where a.is_active='1' and b.is_active='1' and a.hospital_id = '" . $hospitaldata['hospital_id'] . "' and a.doctor_id !='" . $user_id . "' and c.speciality_id='8' ");
            foreach ($provider_query->result_array() as $data) {
                $radiology_image_array[] = array(
                    'user_id' => $data['id'],
                    'user_name' => $data['fname'] . " " . $data['lname'],
                    'hospital_doctor_id' => $data['hospital_doctor_id'],
                    'speciality_name' => $data['speciality_name'],
                    'hospital_id' => $data['hospital_id'],
                    'hospital_network' => $hospitaldata['hospital_network']
                );
            }
        }

        $hospitals_query = $this->db->query("Select * from hospital_doctor as a inner join hospital_network as b on b.id = a.hospital_id where a.is_active='1' and b.is_active='1' and doctor_id = '" . $user_id . "'");
        $genetics_image_array = array();
        foreach ($hospitals_query->result_array() as $hospitaldata) {
            $provider_query = $this->db->query("Select b.id,a.hospital_doctor_id,a.hospital_id,b.fname,b.lname,d.speciality_name from hospital_doctor as a inner join users as b on a.doctor_id = b.id inner join speciality_hospital_doctor as c on c.hospital_doctor_id = a.hospital_doctor_id inner join speciality as d on d.speciality_id = c.speciality_id where a.is_active='1' and  b.is_active='1' and a.hospital_id = '" . $hospitaldata['hospital_id'] . "' and a.doctor_id !='" . $user_id . "' and c.speciality_id='11' ");
            foreach ($provider_query->result_array() as $data) {
                $genetics_image_array[] = array(
                    'user_id' => $data['id'],
                    'user_name' => $data['fname'] . " " . $data['lname'],
                    'hospital_doctor_id' => $data['hospital_doctor_id'],
                    'speciality_name' => $data['speciality_name'],
                    'hospital_id' => $data['hospital_id'],
                    'hospital_network' => $hospitaldata['hospital_network']
                );
            }
        }

        $empty_array = array();

        if (count($pathology_image_array) > 0) {
            $final_array["pathology_image"] = $pathology_image_array;
        } else {
            $final_array["pathology_image"] = $empty_array;
        }

        if (count($radiology_image_array) > 0) {
            $final_array["radiology_image"] = $radiology_image_array;
        } else {
            $final_array["radiology_image"] = $empty_array;
        }

        if (count($genetics_image_array) > 0) {
            $final_array["genetic_image"] = $genetics_image_array;
        } else {
            $final_array["genetic_image"] = $empty_array;
        }

// echo "<pre>"; print_r($final_array);
        return $final_array;
    }

    // to fetch the cases assigned for image request
    public function openrequestData($params = array()) {
        $salt = $this->config->item('salt');
        if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['start'] . ' , ' . $params['limit'];
// $this->db->limit($params['limit'],$params['start']);
        } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['limit'];
//$this->db->limit($params['limit']);
        }

        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
        $speciality_id = $userdata->speciality_id;
        $user_id = $_SESSION['u_userid'];
        $sub_query = "SELECT IFNULL(GROUP_CONCAT(x.case_id),0) as case_ids FROM (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . " '
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id NOT IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` != $user_id
                    GROUP BY case_id)) x";
        $case_ids = $this->db->query($sub_query)->row();
        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
				  h.case_mr_number,
                  h.case_entered_by AS submit_doctor_id,
                  AES_DECRYPT(h.dob,'$salt') as dob,
                       AES_DECRYPT(h.name,'$salt') as name,
                        AES_DECRYPT(h.case_description, '$salt') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  (SELECT
                      GROUP_CONCAT(
                        DATE_FORMAT(meeting_date, '%m/%d/%Y'),
                        ' ',
                        DATE_FORMAT(meeting_time, '%h:%i %p')
                      )
                    FROM
                      case_meeting_assignments AS cma
                      INNER JOIN case_meeting_details AS cmd
                        ON cma.sub_meeting_id = cmd.id
                    WHERE cma.case_id = h.id) AS tumor_board_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id NOT IN
                   (" . $case_ids->case_ids . ")

                  and  a.case_id not in(SELECT case_id FROM case_save_images_summary cis INNER JOIN users u  ON cis.`doctor_id`=u.`id` WHERE u.`speciality_id`=  $speciality_id)

                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";

//        $query = "SELECT
//                          a.*,
//                          b.is_tumor,
//                          b.is_specific_provider,
//                          b.is_speciality,
//                          h.case_submit_date,
//                          b.is_other,
//                          (select concat(fname,' ',lname) from users where id = h.case_entered_by ) as submitted_by,
//                          h.case_entered_by AS submit_doctor_id,
//                          AES_DECRYPT(h.dob,'$salt') as dob,
//                          AES_DECRYPT(h.name,'$salt') as name,
//                          AES_DECRYPT(h.case_description, '$salt') AS case_description,
//                          DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
//                          h.pathology_others_text,
//                          d.fname,
//                          d.lname,
//                          d.speciality_id
//                        FROM
//                          case_request_images AS a
//                          INNER JOIN case_assignments AS b
//                            ON a.case_id = b.case_id
//                          INNER JOIN case_history AS h
//                            ON h.id = b.case_id
//                          INNER JOIN users AS d
//                            ON d.id = h.case_entered_by
//                        WHERE a.doctor_id = '" . $user_id . "'
//                          AND h.case_status = '1'
//                          AND h.is_deleted = '0'
//                          AND a.is_forwarded = '0'
//                          AND a.case_id NOT IN
//                          (SELECT
//                            case_id
//                          FROM
//                            case_save_images
//                          WHERE doctor_id = '" . $user_id . "'
//
//                           )
//
//                        ORDER BY h.case_updated_date DESC ";




        if ($limit != "") {
            $query = $query . $limit;
        }
//echo $query; die;
        $case_query = $this->db->query($query);
        $case_data = $case_query->result_object();
        $data = array();
        $session = array();
        foreach ($case_data as $key => $value) {
            $session[] = $value->case_id;
            if ($value->is_tumor == 1) {

//$tumor_query = $this->db->query("select b.tumor_board_name from case_assignment_tumor_board as a INNER JOIN tumor_board as b on a.tumor_board_id = b.tumor_id where a.case_id='".$value->case_id."'");
                $tumor_query = $this->db->query("SELECT h.hospital_network ,c.tumor_board_name
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "' group by d.id");

                $submitted_to = array();
                foreach ($tumor_query->result_object() as $data) {
                    $submitted_to[] = $data->tumor_board_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "'  group by d.id ");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_specific_provider == 1) {
                $speciality_query = $this->db->query("select u.fname, u.lname,  h.hospital_network ,d.speciality_name
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN hospital_doctor as c
                      on c.hospital_doctor_id = a.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = c.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "' ");
                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->fname . ' ' . $data->lname . ' - ' . $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = b.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_speciality == 1) {
//$speciality_query = $this->db->query("select c.speciality_name from case_assignment_speciality as a INNER JOIN speciality_hospital_doctor as b on a.speciality_hos_doc_id = b.speciality_hos_doc_id INNER JOIN speciality as c  on b.speciality_id = b.speciality_id where a.case_id='".$value->case_id."'");
                $speciality_query = $this->db->query(" select h.hospital_network,c.speciality_name
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id

                    where a.case_id='" . $value->case_id . "' GROUP BY c.speciality_name ");

                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'  GROUP BY h.hospital_network");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_other == 1) {

                $this->db->select("cae.email_id as submitted_to");
                $this->db->from("case_history ch");
                $this->db->join("case_assignment_email cae", "cae.case_id=ch.id");
                $this->db->where("ch.id = $value->case_id");
                $query = $this->db->get();
                $row = $query->row();
                //print_r($row);die;
                $submitted_to = array();
                $hospital_network = array();
                $submitted_to[] = $row->submitted_to;
                $hospital_network[] = "Other by Email";
            }

            $case_data[$key]->submitted_to = @implode(',<br>', $submitted_to);
            $case_data[$key]->hospital_network = @implode(',<br> ', $hospital_network);
        }
        $_SESSION['nextcase'] = $session;
        return $case_data;
    }

    public function openrequestData_submitted($params = array()) {
        $salt = $this->config->item('salt');
        if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['start'] . ' , ' . $params['limit'];
// $this->db->limit($params['limit'],$params['start']);
        } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $limit = "limit " . $params['limit'];
//$this->db->limit($params['limit']);
        }

        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
        $speciality_id = $userdata->speciality_id;
        $user_id = $_SESSION['u_userid'];
        $sub_query = "SELECT IFNULL(GROUP_CONCAT(x.case_id),0) as case_ids FROM (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . "'
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` = $user_id
                    GROUP BY case_id))  x";

        $case_ids = $this->db->query($sub_query)->row();
        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
				  h.case_mr_number,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  AES_DECRYPT(h.dob,'$salt') as dob,
                       AES_DECRYPT(h.name,'$salt') as name,
                        AES_DECRYPT(h.case_description, '$salt') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  (SELECT
                      GROUP_CONCAT(
                        DATE_FORMAT(meeting_date, '%m/%d/%Y'),
                        ' ',
                        DATE_FORMAT(meeting_time, '%h:%i %p')
                      )
                    FROM
                      case_meeting_assignments AS cma
                      INNER JOIN case_meeting_details AS cmd
                        ON cma.sub_meeting_id = cmd.id
                    WHERE cma.case_id = h.id) AS tumor_board_date,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id IN
                  (".$case_ids->case_ids.")

                  or a.case_id in(SELECT case_id FROM case_save_images_summary cis INNER JOIN users u  ON cis.`doctor_id`=u.`id` INNER JOIN case_history cs ON cis.case_id= cs.id WHERE cs.case_status = '1' and u.`speciality_id`=  $speciality_id and cis.`doctor_id`=$user_id )

                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";
//        $query = "SELECT
//                          a.*,
//                          b.is_tumor,
//                          b.is_specific_provider,
//                          b.is_speciality,
//                          h.case_submit_date,
//                          b.is_other,
//                          (select concat(fname,' ',lname) from users where id = h.case_entered_by ) as submitted_by,
//                          h.case_entered_by AS submit_doctor_id,
//                          AES_DECRYPT(h.dob,'$salt') as dob,
//                          AES_DECRYPT(h.name,'$salt') as name,
//                          AES_DECRYPT(h.case_description, '$salt') AS case_description,
//                          DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
//                          h.pathology_others_text,
//                          d.fname,
//                          d.lname,
//                          d.speciality_id
//                        FROM
//                          case_request_images AS a
//                          INNER JOIN case_assignments AS b
//                            ON a.case_id = b.case_id
//                          INNER JOIN case_history AS h
//                            ON h.id = b.case_id
//                          INNER JOIN users AS d
//                            ON d.id = h.case_entered_by
//                        WHERE a.doctor_id = '" . $user_id . "'
//                          AND h.case_status = '1'
//                          AND h.is_deleted = '0'
//                          AND a.is_forwarded = '0'
//                          AND a.case_id NOT IN
//                          (SELECT
//                            case_id
//                          FROM
//                            case_save_images
//                          WHERE doctor_id = '" . $user_id . "'
//
//                           )
//
//                        ORDER BY h.case_updated_date DESC ";


        if ($limit != "") {
            $query = $query . $limit;
        }
//echo $query; die;
        $case_query = $this->db->query($query);
        $case_data = $case_query->result_object();
        $data = array();
        $session = array();

        foreach ($case_data as $key => $value) {


            $session[] = $value->case_id;
            if ($value->is_tumor == 1) {

//$tumor_query = $this->db->query("select b.tumor_board_name from case_assignment_tumor_board as a INNER JOIN tumor_board as b on a.tumor_board_id = b.tumor_id where a.case_id='".$value->case_id."'");
                $tumor_query = $this->db->query("SELECT h.hospital_network ,c.tumor_board_name
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "' group by d.id");

                $submitted_to = array();
                foreach ($tumor_query->result_object() as $data) {
                    $submitted_to[] = $data->tumor_board_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                            FROM case_assignment_tumor_board as d
                            INNER JOIN tumor_board AS c
                            on d.tumor_board_id= c.tumor_id
                            INNER JOIN hospital_doctor_tumor_board AS b
                             on c.tumor_id = b.tumor_id
                            INNER JOIN hospital_doctor AS a
                            ON a.hospital_doctor_id = b.hospital_doctor_id
                            INNER JOIN
                            hospital_network AS h ON a.hospital_id = h.id
                             where d.case_id='" . $value->case_id . "'  group by d.id ");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_specific_provider == 1) {
                $speciality_query = $this->db->query("select u.fname, u.lname,  h.hospital_network ,d.speciality_name
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN hospital_doctor as c
                      on c.hospital_doctor_id = a.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = c.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "' ");
                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->fname . ' ' . $data->lname . ' - ' . $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_specific_provider as a
                    INNER JOIN hospital_doctor AS b
                      on a.hospital_doctor_id = b.hospital_doctor_id
		   INNER JOIN users AS u
                    ON b.doctor_id = u.id
                   INNER JOIN speciality_hospital_doctor AS sh
                        ON sh.hospital_doctor_id = b.hospital_doctor_id
                  INNER JOIN speciality AS d
                       ON d.speciality_id = sh.speciality_id
                  INNER JOIN hospital_network AS h
                       ON b.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_speciality == 1) {
//$speciality_query = $this->db->query("select c.speciality_name from case_assignment_speciality as a INNER JOIN speciality_hospital_doctor as b on a.speciality_hos_doc_id = b.speciality_hos_doc_id INNER JOIN speciality as c  on b.speciality_id = b.speciality_id where a.case_id='".$value->case_id."'");
                $speciality_query = $this->db->query(" select h.hospital_network,c.speciality_name
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id

                    where a.case_id='" . $value->case_id . "' GROUP BY c.speciality_name ");

                $submitted_to = array();
                foreach ($speciality_query->result_object() as $data) {
                    $submitted_to[] = $data->speciality_name;
                }

                $network_query = $this->db->query("SELECT DISTINCT(h.hospital_network)
                    from case_assignment_speciality as a
                    INNER JOIN speciality_hospital_doctor as b
                    on a.speciality_hos_doc_id = b.speciality_hos_doc_id
                    INNER JOIN hospital_doctor as hs
                    on hs.hospital_doctor_id = b.hospital_doctor_id
                    INNER JOIN speciality as c
                    on c.speciality_id = b.speciality_id
                    INNER JOIN hospital_network AS h
                    ON hs.hospital_id = h.id
                    where a.case_id='" . $value->case_id . "'  GROUP BY h.hospital_network");
                $hospital_network = array();

                foreach ($network_query->result_object() as $data) {
                    $hospital_network[] = $data->hospital_network;
                }
            } elseif ($value->is_other == 1) {

                $this->db->select("cae.email_id as submitted_to");
                $this->db->from("case_history ch");
                $this->db->join("case_assignment_email cae", "cae.case_id=ch.id");
                $this->db->where("ch.id = $value->case_id");
                $query = $this->db->get();
                $row = $query->row();
                //print_r($row);die;
                $submitted_to = array();
                $hospital_network = array();
                $submitted_to[] = $row->submitted_to;
                $hospital_network[] = "Other by Email";
            }

            $case_data[$key]->submitted_to = @implode(',<br>', $submitted_to);
            $case_data[$key]->hospital_network = @implode(',<br> ', $hospital_network);
        }
        $_SESSION['nextcase'] = $session;
        return $case_data;
    }

    // to fetch the cases assigned for image request
    public function count_requestdata($filter = NULL) {

        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
        $speciality_id = $userdata->speciality_id;
        $user_id = $_SESSION['u_userid'];
        $sub_query = "SELECT IFNULL(GROUP_CONCAT(x.case_id),0) as case_ids FROM (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . " '
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id NOT IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` != $user_id
                    GROUP BY case_id)) x";
        $case_ids = $this->db->query($sub_query)->row();
        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id NOT IN
                 (" . $case_ids->case_ids . ")

                  and  a.case_id not in(SELECT case_id FROM case_save_images_summary cis INNER JOIN users u  ON cis.`doctor_id`=u.`id` WHERE u.`speciality_id`=  $speciality_id)

                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";

//        $query = "SELECT
//                          a.*,
//                          b.is_tumor,
//                          b.is_specific_provider,
//                          b.is_speciality,
//                          h.case_submit_date,
//                          b.is_other,
//                          (select concat(fname,' ',lname) from users where id = h.case_entered_by ) as submitted_by,
//                          h.case_entered_by AS submit_doctor_id,
//                          h.dob,
//                          h.name,
//                          DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
//                          h.pathology_others_text,
//                          d.fname,
//                          d.lname,
//                          d.speciality_id
//                        FROM
//                          case_request_images AS a
//                          INNER JOIN case_assignments AS b
//                            ON a.case_id = b.case_id
//                          INNER JOIN case_history AS h
//                            ON h.id = b.case_id
//                          INNER JOIN users AS d
//                            ON d.id = h.case_entered_by
//                        WHERE a.doctor_id = '" . $user_id . "'
//                          AND h.case_status = '1'
//                          AND h.is_deleted = '0'
//                          AND a.is_forwarded = '0'
//                          AND a.case_id NOT IN
//                          (SELECT
//                            case_id
//                          FROM
//                            case_save_images
//                          WHERE doctor_id = '" . $user_id . "'
//                            OR speciality_id = '" . $speciality_id . "')
//                        ORDER BY h.case_updated_date DESC ";

        $case_query = $this->db->query($query);

        return $case_query->num_rows();
    }

    public function count_requestdata_i_submitted($filter = NULL) {
        $userdata = $this->mcustom->getUser($_SESSION['u_userid']);
        $speciality_id = $userdata->speciality_id;
        $user_id = $_SESSION['u_userid'];
        $sub_query = "SELECT IFNULL(GROUP_CONCAT(x.case_id),0) as case_ids  from (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . "'
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` != $user_id
                    GROUP BY case_id)) x";

        $case_ids = $this->db->query($sub_query)->row();


        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id IN

                (" . $case_ids->case_ids . ")

                  and  a.case_id in(SELECT case_id FROM case_save_images_summary cis INNER JOIN users u  ON cis.`doctor_id`=u.`id` WHERE u.`speciality_id`=  $speciality_id)

                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";
//        $query = "SELECT
//                          a.*,
//                          b.is_tumor,
//                          b.is_specific_provider,
//                          b.is_speciality,
//                          h.case_submit_date,
//                          b.is_other,
//                          (select concat(fname,' ',lname) from users where id = h.case_entered_by ) as submitted_by,
//                          h.case_entered_by AS submit_doctor_id,
//                          h.dob,
//                          h.name,
//                          DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
//                          h.pathology_others_text,
//                          d.fname,
//                          d.lname,
//                          d.speciality_id
//                        FROM
//                          case_request_images AS a
//                          INNER JOIN case_assignments AS b
//                            ON a.case_id = b.case_id
//                          INNER JOIN case_history AS h
//                            ON h.id = b.case_id
//                          INNER JOIN users AS d
//                            ON d.id = h.case_entered_by
//                        WHERE a.doctor_id = '" . $user_id . "'
//                          AND h.case_status = '1'
//                          AND h.is_deleted = '0'
//                          AND a.is_forwarded = '0'
//                          AND a.case_id NOT IN
//                          (SELECT
//                            case_id
//                          FROM
//                            case_save_images
//                          WHERE doctor_id = '" . $user_id . "'
//                            OR speciality_id = '" . $speciality_id . "')
//                        ORDER BY h.case_updated_date DESC ";


        $case_query = $this->db->query($query);

        return $case_query->num_rows();
    }

    // to upload the images on request image data page
    public function saverequestimage() {
        $case_id = $this->input->post('case_id');
        $comments = $this->input->post('comments');
        $doctor_id = $this->session->userdata('u_userid');
        $casesummary = $this->input->post('casesummary');
        $speciality = $this->session->userdata('speciality_id');


        if ($speciality == PATHOLOGY_SPECILITY || $speciality == RADIOLOGY_SPECILITY || $speciality == GENETICS_SPECILITY || $speciality == HOSPITAL_ADMIN_SPECILITY) {
            for ($i = 0; $i <= 14; $i++) {
                if (isset($_FILES['rImageFile' . $i]['name'])) {
                    if ($_FILES['rImageFile' . $i]["size"] < 50000000) {
                        $path = time() . uniqid() . $_FILES['rImageFile' . $i]['name'];
                        $path = str_replace(" ", "_", $path);

                        if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                            $data = array(
                                'case_id' => $case_id,
                                'doctor_id' => $doctor_id,
                                'image_name' => $path,
                                'speciality_id' => $speciality,
                                'comments' => $comments[$i]
                            );
                            $file_uploaded = $this->db->insert('case_save_images', $data);
                        }
                    }
                }
            }

            if ($casesummary != "") {
                $data = array(
                    'case_id' => $case_id,
                    'doctor_id' => $doctor_id,
                    'speciality_id' => $speciality,
                    'case_summary' => $casesummary
                );
                $query = $this->db->insert('case_save_images_summary', $data);
            }
        }
        if ($query || $file_uploaded) {
            return true;
        } else
            return false;
    }

    // to fetch the complete detail of a case
    public function getSingleCase($case_id) {
        $salt = $this->config->item('salt');
        $user_id = $_SESSION['u_userid'];
        $speciality_id = $_SESSION['speciality_id'];
        //$user_case_query = "Select  AES_DECRYPT(e.case_description, '$salt') AS case_description,e.case_entered_by,e.cancer_id, AES_DECRYPT(e.dob,'$salt') as dob, AES_DECRYPT(e.name,'$salt') as pname, AES_DECRYPT(e.name,'$salt') as pname , e.cancer_mode, e.case_submit_date,DATE_FORMAT(e.case_updated_date,'%m/%d/%y') as case_updated_date,e.pathology_others_text,a.case_id,b.is_tumor,b.is_specific_provider,b.is_speciality,b.is_other,(select concat(fname,' ',lname) from users where id = e.case_entered_by ) as name,e.case_entered_by as doctor_id,d.speciality_id,e.case_status from case_request_images as a INNER JOIN case_assignments as b on a.case_id = b.case_id  INNER JOIN users as d on d.id = a.doctor_id inner join case_history as e on a.case_id = e.id where (a.doctor_id ='" . $_SESSION['u_userid'] . "' ) and e.case_status = '1' and is_deleted = '0' and e.id='" . $case_id . "' and a.case_id not in( select case_id from case_doctor_comments where doctor_id = '" . $_SESSION['u_userid'] . "') group by a.case_id order by e.case_updated_date DESC";
        // $user_case_query ="Select  AES_DECRYPT(e.case_description, '$salt') AS case_description,e.case_entered_by, AES_DECRYPT(e.name,'$salt') as pname, AES_DECRYPT(e.name,'$salt') as pname,AES_DECRYPT(e.dob,'$salt') as dob from case_history as e inner join users as u on u.id=e.case_entered_by where e.id=$case_id";
        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  h.case_entered_by,
                  AES_DECRYPT(h.name,'$salt') as pname,
                  AES_DECRYPT(h.dob,'$salt') as dob,
                       AES_DECRYPT(h.name,'$salt') as name,
                        AES_DECRYPT(h.case_description, '$salt') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id NOT IN
                  (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . " '
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id NOT IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` != $user_id
                    GROUP BY case_id))
                    and h.id=$case_id
                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";
        $user_case_assigned = $this->db->query($query);
        $case_array = array();
        $final_array = array();
        $case_list_ids = $user_case_assigned->row();

        return $case_list_ids;
    }

    public function getSingleCase_submitted($case_id) {
        $salt = $this->config->item('salt');
        $user_id = $_SESSION['u_userid'];
        $speciality_id = $_SESSION['speciality_id'];
        //$user_case_query = "Select  AES_DECRYPT(e.case_description, '$salt') AS case_description,e.case_entered_by,e.cancer_id, AES_DECRYPT(e.dob,'$salt') as dob, AES_DECRYPT(e.name,'$salt') as pname, AES_DECRYPT(e.name,'$salt') as pname , e.cancer_mode, e.case_submit_date,DATE_FORMAT(e.case_updated_date,'%m/%d/%y') as case_updated_date,e.pathology_others_text,a.case_id,b.is_tumor,b.is_specific_provider,b.is_speciality,b.is_other,(select concat(fname,' ',lname) from users where id = e.case_entered_by ) as name,e.case_entered_by as doctor_id,d.speciality_id,e.case_status from case_request_images as a INNER JOIN case_assignments as b on a.case_id = b.case_id  INNER JOIN users as d on d.id = a.doctor_id inner join case_history as e on a.case_id = e.id where (a.doctor_id ='" . $_SESSION['u_userid'] . "' ) and e.case_status = '1' and is_deleted = '0' and e.id='" . $case_id . "' and a.case_id not in( select case_id from case_doctor_comments where doctor_id = '" . $_SESSION['u_userid'] . "') group by a.case_id order by e.case_updated_date DESC";
        // $user_case_query ="Select  AES_DECRYPT(e.case_description, '$salt') AS case_description,e.case_entered_by, AES_DECRYPT(e.name,'$salt') as pname, AES_DECRYPT(e.name,'$salt') as pname,AES_DECRYPT(e.dob,'$salt') as dob from case_history as e inner join users as u on u.id=e.case_entered_by where e.id=$case_id";
        $query = "SELECT
                  a.*,
                  b.is_tumor,
                  b.is_specific_provider,
                  b.is_speciality,
                  b.is_other,
                  h.case_entered_by AS submit_doctor_id,
                  h.case_entered_by,
                  AES_DECRYPT(h.name,'$salt') as pname,
                  AES_DECRYPT(h.dob,'$salt') as dob,
                       AES_DECRYPT(h.name,'$salt') as name,
                        AES_DECRYPT(h.case_description, '$salt') AS case_description,
                        DATE_FORMAT(h.case_updated_date, '%m/%d/%y') AS case_updated_date,
                  h.pathology_others_text,
                  h.case_submit_date,
                  d.fname,
                  d.lname,
                  d.speciality_id,
                  (SELECT
                    CONCAT(fname, ' ', lname)
                  FROM
                    users
                  WHERE id = h.case_entered_by) AS submitted_by,
                  h1.id AS hospital_id,
                  h1.`hospital_network`
                FROM
                  case_request_images AS a
                  INNER JOIN case_assignments AS b
                    ON a.case_id = b.case_id
                  INNER JOIN case_history AS h
                    ON h.id = b.case_id
                  INNER JOIN users AS d
                    ON d.id != h.case_entered_by
                  LEFT JOIN `hospital_network` h1
                    ON h1.`id` = h.assigned_hospital
                WHERE a.doctor_id = '" . $user_id . "'
                  AND h.case_status = '1'
                  AND h.is_deleted = '0'
                  AND a.is_forwarded = '0'
                  AND a.case_id IN
                  (SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE doctor_id = '" . $user_id . " '
                  UNION
                  SELECT
                    case_id
                  FROM
                    case_save_images
                  WHERE `speciality_id` = $speciality_id
                    AND case_id IN
                    (SELECT
                      cs.`case_id`
                    FROM
                      `case_save_images` cs
                      INNER JOIN case_history ch
                        ON cs.`case_id` = ch.`id`
                        AND cs.`doctor_id` = ch.`case_entered_by`
                        AND cs.`doctor_id` != $user_id
                    GROUP BY case_id))
                    and h.id=$case_id
                GROUP BY b.case_id
                ORDER BY h.case_updated_date DESC
                 ";
        $user_case_assigned = $this->db->query($query);
        $case_array = array();
        $final_array = array();
        $case_list_ids = $user_case_assigned->row();

        return $case_list_ids;
    }

    // to fetch the search cases list
    public function search_CaseList($params = array()) {

        $sql = "";

        $salt = $this->config->item('salt');

        $pname = isset($params[0]['pname']) ? $params[0]['pname'] : '';
        $submitted_by = isset($params[0]['submitted_by']) ? $params[0]['submitted_by'] : '';
        $cancer_type = isset($params[0]['cancer_type']) ? $params[0]['cancer_type'] : '';
        $pathlogy = isset($params[0]['pathlogy']) ? $params[0]['pathlogy'] : '';
        $status = isset($params[0]['status']) ? $params[0]['status'] : '';
        $dob = isset($params[0]['dob']) ? $params[0]['dob'] : '';
        $dob = explode(':', $dob);
        $stage = isset($params[0]['stage']) ? $params[0]['stage'] : '';
        $stage1 = isset($params[0]['stage1']) ? $params[0]['stage1'] : '';
        $stage = $stage . $stage1;

        $doctor_id = $this->session->userdata('u_userid');

        $this->db->select("AES_DECRYPT(ch.name,'$salt') as pname ,ce.case_id,ch.mark_as_discussed_live,ch.case_entered_by, (select CONCAT_WS(' ', fname, lname) from users where id=ch.case_entered_by) as doc_name, u.fname, datediff(CURDATE(), AES_DECRYPT(ch.dob,'$salt')) as dob_days,  AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type,  AES_DECRYPT(ch.dob,'$salt') as dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count", FALSE);
        $this->db->from("case_doc_email_status ce");
        $this->db->join("case_assignments ca", "ce.case_id=ca.case_id");
        $this->db->join("case_history ch", "ch.id = ce.case_id");
        $this->db->join("users u", "u.id = ch.case_entered_by");
        $this->db->join("cancercategories c", "c.cancer_id=ch.cancer_id");
        $this->db->where("(ce.doctor_id = '$doctor_id' or ch.case_entered_by='$doctor_id')");
        $this->db->where("ch.is_deleted = '0'");

        if ($pname != '' || $submitted_by != '') {
            $sql .= "   ( ";
            if ($pname != '') {
                $pname = trim($pname);
                $sql .= "(AES_DECRYPT(ch.name,'$salt') like '%$pname')";
            }
            if ($submitted_by != "") {
                if ($pname != '')
                    $sql .= " or ";
                $submitted_by = trim($submitted_by);
                $sql .= " (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%')";
            }

            $sql .= " )";

            $this->db->where($sql);
        }



        if ($cancer_type != '') {
            $this->db->where("ch.cancer_id= $cancer_type");
        }
        if ($pathlogy != '') {
            $this->db->where("ch.pathology= $pathlogy");
        }
        if ($status != '') {
            $this->db->where("ch.performance_status= $status");
        }
        if (count($dob) == 2 && !empty($dob)) {
            $this->db->where("YEAR(CURDATE())-YEAR(AES_DECRYPT(dob,'$salt')) BETWEEN '$dob[0]' AND $dob[1]");
        }
        if ($stage != "") {



            $this->db->where("ch.id IN (SELECT case_id FROM `case_breast_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_hematologic_general` WHERE CAST(stage AS CHAR) = '$stage'                                                UNION
                            SELECT case_id FROM `case_other_metastatic` WHERE CAST(stage AS CHAR) = '$stage'                                                    UNION
                            SELECT case_id FROM `case_other_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_other_recurrent` WHERE CAST(stage AS CHAR) = '$stage'

                            )");
        }
        if (array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $this->db->limit($params['limit'], $params['start']);
        } elseif (!array_key_exists("start", $params) && array_key_exists("limit", $params)) {
            $this->db->limit($params['limit']);
        }
        $this->db->group_by("ce.case_id");
        $this->db->order_by("ch.id", "desc");
        $query = $this->db->get();
        //echo $this->db->last_query();


        $case_data = $query->result_object();

        return $case_data;
    }

    //to count the search cases found
    public function count_searchCase($params = array()) {

        $sql = "";

        $salt = $this->config->item('salt');

        $doctor_id = $this->session->userdata('u_userid');
        $pname = isset($params['pname']) ? $params['pname'] : '';
        $submitted_by = isset($params['submitted_by']) ? $params['submitted_by'] : '';
        $cancer_type = isset($params['cancer_type']) ? $params['cancer_type'] : '';
        $pathlogy = isset($params['pathlogy']) ? $params['pathlogy'] : '';

        $status = isset($params['status']) ? $params['status'] : '';
        $dob = isset($params['dob']) ? $params['dob'] : '';
        $dob = explode(':', $dob);
        $stage = isset($params['stage']) ? $params['stage'] : '';
        $stage1 = isset($params['stage1']) ? $params['stage1'] : '';
        $stage = $stage . $stage1;
        $this->db->select("ch.name as pname, ce.case_id,u.fname, datediff(CURDATE(), ch.dob ) as dob_days,  AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type, ch.dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count", FALSE);
        $this->db->from("case_doc_email_status ce");
        $this->db->join("case_assignments ca", "ce.case_id=ca.case_id", "left");
        $this->db->join("case_history ch", "ch.id = ce.case_id");
        $this->db->join("users u", "u.id = ch.case_entered_by");
        $this->db->join("cancercategories c", "c.cancer_id=ch.cancer_id", "left");

        $this->db->where("(ce.doctor_id = '$doctor_id' or ch.case_entered_by='$doctor_id')");
        $this->db->where("ch.is_deleted = '0'");


        if ($pname != '' || $submitted_by != '') {
            $sql .= "   ( ";
            if ($pname != '') {
                $pname = trim($pname);
                $sql .= "(AES_DECRYPT(ch.name,'$salt') like '%$pname')";
            }
            if ($submitted_by != "") {
                if ($pname != '')
                    $sql .= " or ";
                $submitted_by = trim($submitted_by);
                $sql .= " (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%')";
            }

            $sql .= " )";

            $this->db->where($sql);
        }
        if ($cancer_type != '') {
            $this->db->where("ch.cancer_id= $cancer_type");
        }
        if ($pathlogy != '') {

            $this->db->where("ch.pathology= $pathlogy");
        }
        if ($status != '') {
            $this->db->where("ch.performance_status= $status");
        }
        if (count($dob) == 2 && !empty($dob)) {
            $this->db->where("YEAR(CURDATE())-YEAR(AES_DECRYPT(dob,'$salt')) BETWEEN '$dob[0]' AND $dob[1]");
        }
        if ($stage != "") {


            $this->db->where("ch.id IN (SELECT case_id FROM `case_breast_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_hematologic_general` WHERE CAST(stage AS CHAR) = '$stage'                                                UNION
                            SELECT case_id FROM `case_other_metastatic` WHERE CAST(stage AS CHAR) = '$stage'                                                    UNION
                            SELECT case_id FROM `case_other_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_other_recurrent` WHERE CAST(stage AS CHAR) = '$stage'


                            )");
        }
        $this->db->group_by("ce.case_id");
        $this->db->order_by("ch.id", "desc");
        $query = $this->db->get();
        //echo $this->db->last_Query();
        return $query->num_rows();
    }

    // to fetch the next case id  on case description page
    public function next_id($params = array()) {
        $sql = "";

        $salt = $this->config->item('salt');

        $doctor_id = $this->session->userdata('u_userid');
        $pname = isset($params['pname']) ? $params['pname'] : '';
        $submitted_by = isset($params['submitted_by']) ? $params['submitted_by'] : '';
        $cancer_type = isset($params['cancer_type']) ? $params['cancer_type'] : '';
        $pathlogy = isset($params['pathlogy']) ? $params['pathlogy'] : '';

        $status = isset($params['status']) ? $params['status'] : '';
        $dob = isset($params['dob']) ? $params['dob'] : '';
        $dob = explode(':', $dob);
        $stage = isset($params['stage']) ? $params['stage'] : '';
        $stage1 = isset($params['stage1']) ? $params['stage1'] : '';
        $stage = $stage . $stage1;
        $this->db->select("ch.name as pname, ce.case_id,u.fname, datediff(CURDATE(), ch.dob ) as dob_days,  AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type, ch.dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count", FALSE);
        $this->db->from("case_doc_email_status ce");
        $this->db->join("case_assignments ca", "ce.case_id=ca.case_id", "left");
        $this->db->join("case_history ch", "ch.id = ce.case_id");
        $this->db->join("users u", "u.id = ch.case_entered_by");
        $this->db->join("cancercategories c", "c.cancer_id=ch.cancer_id", "left");

        $this->db->where("(ce.doctor_id = '$doctor_id' or ch.case_entered_by='$doctor_id')");
        $this->db->where("ch.is_deleted = '0'");
        if ($pname != '' || $submitted_by != '') {
            $sql .= "   ( ";
            if ($pname != '') {
                $pname = trim($pname);
                $sql .= "(AES_DECRYPT(ch.name,'$salt') like '%$pname')";
            }
            if ($submitted_by != "") {
                if ($pname != '')
                    $sql .= " or ";
                $submitted_by = trim($submitted_by);
                $sql .= " (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%')";
            }

            $sql .= " )";

            $this->db->where($sql);
        }
        if ($cancer_type != '') {
            $this->db->where("ch.cancer_id= $cancer_type");
        }
        if ($pathlogy != '') {

            $this->db->where("ch.pathology= $pathlogy");
        }
        if ($status != '') {
            $this->db->where("ch.performance_status= $status");
        }
        if (count($dob) == 2 && !empty($dob)) {
            $this->db->where("YEAR(CURDATE())-YEAR(AES_DECRYPT(dob,'$salt')) BETWEEN '$dob[0]' AND $dob[1]");
        }
        if ($stage != "") {
            $this->db->where("ch.id IN (SELECT case_id FROM `case_breast_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_breast_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_lung_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_colon_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_prostate_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                             UNION
                            SELECT case_id FROM `case_other_metastatic` WHERE CAST(stage AS CHAR) = '$stage'                                                    UNION
                            SELECT case_id FROM `case_other_non_metastatic` WHERE CAST(stage AS CHAR) = '$stage'
                            UNION
                            SELECT case_id FROM `case_other_recurrent` WHERE CAST(stage AS CHAR) = '$stage'
                            )");
        }
        $this->db->group_by("ce.case_id");
        $this->db->order_by("ch.id", "desc");
        $query = $this->db->get();
//        echo $this->db->last_Query();die;
        $case_data = $query->result_object();

        foreach ($case_data as $data) {

            $next_id[] = $data->id;
        }


        $this->session->set_userdata('next_id', $next_id);
    }

    //generate the hospital admin report
    public function getReport() {
        $salt = $this->config->item('salt');

        $dFrom = $this->input->post('dFrom');
        $dTo = $this->input->post('dTo');
        $selectedData = $this->input->post('my_multi_select1');

        $query = "select ";
        $select = "";
        $condition = "";
        if (count($selectedData) > 0) {
            $select .="ch.id AS 'CaseId',";
            if (in_array('case_mr_number', $selectedData)) {
                $select .="ch.case_mr_number AS 'Case MR Number',";
            }
            if (in_array('case_description', $selectedData)) {
                $select .=" AES_DECRYPT(ch.case_description, '$salt') as  'Case History' ,";
            }
            if (in_array('name', $selectedData)) {
                $select .=" AES_DECRYPT(ch.name,'$salt') as 'Patient Name' ,";
            }
            if (in_array('dob', $selectedData)) {
                $select .=" DATE_FORMAT(AES_DECRYPT(ch.dob,'$salt'), '%m/%d/%Y')as 'Patient DOB' ,";
            }
            if (in_array('gender', $selectedData)) {
                $select .=" if(AES_DECRYPT(ch.sex,'$salt')='M','Male','Female') as 'Patient Gender' ,";
            }
            if (in_array('race', $selectedData)) {
                $select .="(select race_type from race where race_id=AES_DECRYPT(ch.race,'$salt')) as 'Race' ,";
            }
            if (in_array('menopausal', $selectedData)) {
                $select .=" ch.menopausal_status as 'Patient Menopausal Status' ,";
            }
            if (in_array('rcounselling_discussed', $selectedData)) {
                $select .="if(ch.rcounselling_discussed='1', 'Yes', 'No')  as 'Reproductive Counseling discussed' ,";
            }
            if (in_array('pcounselling_discussed', $selectedData)) {
                $select .="if(ch.pcounselling_discussed='1', 'Yes', 'No')  as 'Psychosocial Counseling discussed' ,";
            }
            if (in_array('ncounselling_discussed', $selectedData)) {
                $select .="if(ch.ncounselling_discussed='1', 'Yes', 'No')  as 'Navigation Counseling discussed' ,";
            }

            if (in_array('setting', $selectedData)) {
                $select .=" (SELECT  (CASE
                            WHEN (ch.cancer_id!='11' and ch.cancer_mode='0') THEN 'Non-Metastatic'
                            WHEN ch.cancer_mode='1' THEN 'Recurrent'
                            WHEN ch.cancer_mode='2' THEN 'DeNovo Metastatic'
                            ELSE '' END)
                            FROM case_history ch1 where ch1.id=ch.id) AS 'Cancer Setting'
                            ,";
            }


            if (in_array('submitted_by', $selectedData)) {
                $select .="CONCAT_WS(' ', fname, lname) as 'Submitted by' ,";
            }


            if (in_array('cancer_type', $selectedData)) {
                $select .="cancer_type as 'Cancer Type' ,";
            }

            if (in_array('case_status', $selectedData)) {
                $select .="if(ch.case_status='1', 'Open', 'Close')  as 'Case Status  ',";
            }


            if (in_array('tumor_name', $selectedData)) {
                $select .="(select group_concat(Distinct t.tumor_board_name) from  case_assignment_tumor_board ctd inner join  tumor_board  t on ctd.tumor_board_id=t.tumor_id where ctd.case_id=ch.id) AS 'Tumor Board Name' ,";
            }

            if (in_array('discussed_online', $selectedData)) {
                $select .="(SELECT (CASE
                        WHEN (SELECT COUNT(*) AS c FROM case_doctor_comments WHERE case_id = ch.id)> 0 THEN 'Yes'
                        ELSE 'No' END))  AS 'Discussed Online Status'  ,";
            }


            if (in_array('discussed_person', $selectedData)) {
                $select .=" if(ch.mark_as_discussed_live='1','Yes','No') as  'Discussed In-Person Status' ,";
            }



            if (in_array('online_attendance', $selectedData)) {
                $select .="(select  group_concat(concat(concat(u.fname,' ',u.lname),'(',s.speciality_name,')'))  from case_doctor_comments  cd inner join users u on u.id=cd.doctor_id  inner join speciality s on  cd.speciality_id=s.speciality_id  where case_id = ch.id)  as  'Online Attendance' ";
            }


            if (isset($dFrom) && $dFrom != "" && isset($dTo) && $dTo != "") {
                $dFrom = date('Y-m-d', strtotime($dFrom));
                $dTo = date('Y-m-d', strtotime($dTo));
                $condition .="and (  DATE(ch.`case_submit_date`) BETWEEN DATE('$dFrom') AND DATE('$dTo') )";
            }
        }
        $select = rtrim($select, ',');

        $query = $query . $select . "FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM
                    case_history
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c
               ON c.cancer_id = ch.cancer_id  LEFT JOIN hospital_doctor hd ON hd.doctor_id = ch.case_entered_by
                    WHERE ch.is_deleted = '0'  and   ch.assigned_hospital='" . $_SESSION['hospital_id'] . "'
                    $condition GROUP BY ch.id
                    ORDER BY ch.id DESC ) ch";


        $mydata = array();
        $data = $this->mcustom->getselectedata($query);
        if (in_array('meeting', $selectedData) || in_array('nccn', $selectedData) || in_array('staging', $selectedData) || in_array('prospective', $selectedData) || in_array('clinical', $selectedData) || in_array('palliative', $selectedData) || in_array('rcounselling_discussed', $selectedData) || in_array('pcounselling_discussed', $selectedData) || in_array('ncounselling_discussed', $selectedData)) {
            foreach ($data as $key => $value) {
                $select1 = "";
                $select1 = "SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,";

                if (in_array('prospective', $selectedData)) {
                    $select1 .="if(cma.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,";
                }


                if (in_array('staging', $selectedData)) {
                    $select1 .="if(cma.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,";
                }

                if (in_array('nccn', $selectedData)) {
                    $select1 .="if(cma.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,";
                }



                if (in_array('genetic_discussed', $selectedData)) {
                    $select1 .="if(cma.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,";
                }

                if (in_array('clinical', $selectedData)) {
                    $select1 .="if(cma.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,";
                }


                if (in_array('palliative', $selectedData)) {
                    $select1 .="if(cma.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,";
                }


                if (in_array('attendees', $selectedData)) {
                    $select1 .="(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')'),'No Attendees') from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance' ,";
                }


                $select1 = rtrim($select1, ',');
                $query1 = $select1 . " FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id WHERE cma.case_id=" . $value->CaseId;
                if (!in_array('case_id', $selectedData)) {
                    unset($data[$key]->CaseId);
                }
                $Q = $this->db->query($query1);

                $data[$key]->submeetings = $Q->result_array();
            }
        }

        if ($data) {
            $lines = $data;
            $langs = array();
            $hidden_fields = !empty($hidden_fields) ? $hidden_fields : array();
            if ($lines && is_array($lines) && count($lines) > 0) {
                foreach ($lines as $row) {
                    foreach ($row as $field => $value) {
                        if (!in_array($field, $langs) && !in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                            array_push($langs, $field);
                        }
                    }
                }
            }

            // Starting the PHPExcel library
            $this->load->library('excel');
            // activate worksheet number 1
            $this->excel->setActiveSheetIndex(0);

            $this->excel->getProperties()->setTitle("Language")->setDescription("none");

            // name the worksheet
            $this->excel->getActiveSheet()->setTitle('Language');

            // Field names
            $col = 0;
            foreach ($langs as $field) {
                // set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);

                // change the font size
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setSize(14);

                // make the font become bold
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setBold(true);

                // set aligment to center for that cell
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getAlignment()
                        ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)
                        ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                // ->setWrapText(true);

                $col++;
            }


            $case = array();
            $row = 2;
            foreach ($lines as $key => $line) {
                $col = 0;
                foreach ($langs as $field) {
                    $value = isset($line->$field) ? $line->$field : '';
                    if (!in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                        if (is_array($value)) {
                            if (count($value) > 0) {
                                $c = 0;
                                foreach ($value as $k => $v) {
                                    $c = $col;

                                    foreach ($v as $field => $val) {
                                        $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, 1, $field);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setSize(14);

                                        // make the font become bold
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setBold(true);

                                        // set aligment to center for that cell

                                        $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, $row, $val);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getFont()->setSize(12);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()
                                                ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()->setWrapText(true);
                                        $c++;
                                    }
                                    $row++;
                                }
                            } else {
                                // set cell A1 content with some text
                                $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, 'NONE');
                            }
                        } else {
                            // set cell A1 content with some text
                            $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, ucfirst(strip_tags($value)));
                            $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getAlignment()->setWrapText(true);
                        }
                    }

//                    // change the font size
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getFont()->setSize(12);
                    // set aligment to vertical center for that cell
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getAlignment()
                            ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

                    $col++;
                }

                $row++;
            }
            $sheet = $this->excel->getActiveSheet();
            $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }
            $this->excel->setActiveSheetIndex(0);
            // mime type
            $filename = time() . "Report";
            header('Cache-Control: private, max-age=1');
            header("Pragma:token");
            header("Expires: 0");
            header('Content-Type: application/vnd.ms-excel;charset=utf-8');
            // tell browser what's the file name
            header('Content-Disposition: attachment;filename=' . $filename . ".xls");
            // no cache
            // save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
            // if you want to save it as .XLSX Excel 2007 format
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
            ob_end_clean();
            // force user to download the Excel file without writing it to server's HD
            $objWriter->save('php://output');
        } else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }

    // fetch the comments
    public function getCaseRequest($case_id, $user_id) {
        $this->db->select('group_concat(comments) comment');
        $this->db->from('case_request_images');
        $this->db->where("case_id = '$case_id'");
        $this->db->where("doctor_id = '$user_id'");
        $q = $this->db->get()->row_array();
        return trim($q['comment']);
    }

    // fetch the comments
    public function getCaseRequestData($case_id, $user_id) {
        $this->db->select('comments as comment,img_req_hospital_id');
        $this->db->from('case_request_images');
        $this->db->where("case_id = '$case_id'");
        $this->db->where("doctor_id = '$user_id'");
        $q = $this->db->get()->row_array();
        return $q;
    }

    // sending the image request to another doctor
    public function savesendcasetodoctor() {
        $case_id = $this->input->post('case_id');
        $user_id = $this->session->userdata('u_userid');
        $doctor_id = $this->input->post('provider');
        $speciality = $this->session->userdata('speciality_id');
        $is_pathology = $is_radiology = $is_genetic = 0;

        if ($speciality == PATHOLOGY_SPECILITY)
            $is_pathology = 1;
        else if ($speciality == RADIOLOGY_SPECILITY)
            $is_radiology = 1;
        else if ($speciality == GENETICS_SPECILITY)
            $is_genetic = 1;

        if (!empty($case_id) && !empty($doctor_id)) {
            foreach ($doctor_id as $value) {
                $h_d_arr = explode("-", $value);
                $doctor_id = $h_d_arr['0'];
                $hospital_id = $h_d_arr['1'];
                $check_query = $this->db->query("select count(*) as count from case_request_images where case_id ='" . $case_id . "' and doctor_id= '" . $doctor_id . "'");
                //$data = $this->db->getResult($check_query);
                $data = $check_query->result_array()[0];


                if ($data['count'] > 0) {
                    continue;
                } else {
                    $postdetails_query = $this->db->query("Insert into case_request_images (case_id,doctor_id,is_pathology,is_radiology,is_genetic,is_forwarded,img_req_hospital_id)values('" . $case_id . "','" . $value . "','" . $is_pathology . "','" . $is_radiology . "','" . $is_genetic . "','0','" . $hospital_id . "')");
                }
            }
            $update = $this->db->query("Update case_request_images SET is_forwarded = '1'  where  case_id = '" . $case_id . "' and doctor_id = '" . $user_id . "'");

            if ($update) {
                return "success";
            } else {
                return "failure";
            }
        } else {
            return "failure";
        }
    }

    // list of doctor to forward the image request
    public function getspecificselectbox($case_id, $user_id, $hospital_id) {





        $hospital_doctor_query = $this->db->query("SELECT u.`speciality_id`,h.`hospital_doctor_id` FROM users u INNER JOIN `hospital_doctor` h ON u.id=h.`doctor_id`  WHERE u.`id`=$user_id AND h.`hospital_id` in ($hospital_id)");


        foreach ($hospital_doctor_query->result_array() as $hospital_doctor) {

            /*
              $provider_query = $this->db->query("select h_d.doctor_id,h_d.hospital_doctor_id,u.fname,u.lname,(select speciality_name from speciality where speciality_id = '" . $hospital_doctor['speciality_id'] . "') as specialityname, (select hospital_network from hospital_network where id = h_d.hospital_id) as hospital_name from hospital_doctor as h_d inner join users as u on(h_d.doctor_id = u.id) left join speciality_hospital_doctor as sphd on (h_d.hospital_doctor_id = sphd.hospital_doctor_id)  where h_d.is_active='1' and u.is_active='1' and  h_d.hospital_id in (SELECT hd.hospital_id FROM `speciality_hospital_doctor` as shd inner join hospital_doctor hd on shd.hospital_doctor_id = hd.hospital_doctor_id WHERE hd.is_active='1' and  shd.hospital_doctor_id='" . $hospital_doctor['hospital_doctor_id'] . "') and sphd.speciality_id='" . $hospital_doctor['speciality_id'] . "' and sphd.hospital_doctor_id !='" . $hospital_doctor['hospital_doctor_id'] . "'  AND h_d.`hospital_doctor_id` NOT IN (SELECT DISTINCT cas.`hospital_doctor_id` FROM  `case_assignment_specific_provider` cas WHERE cas.`case_id`=$case_id UNION SELECT  DISTINCT shd.hospital_doctor_id FROM `case_assignment_speciality` casp
              INNER JOIN `speciality_hospital_doctor` shd ON casp.speciality_hos_doc_id=shd.speciality_hos_doc_id
              WHERE casp.`case_id`=$case_id  UNION SELECT DISTINCT h1.hospital_doctor_id FROM `case_assignment_tumor_board` cst INNER JOIN `hospital_doctor_tumor_board` h1 ON cst.tumor_board_id=h1.tumor_id WHERE cst.case_id=$case_id )");

             */
            $provider_query = $this->db->query("SELECT users.id as doctor_id,hd.hospital_id,users.fname,users.lname, (select speciality_name from speciality where speciality_id = '" . $hospital_doctor['speciality_id'] . "') as specialityname,(select hospital_network from hospital_network where id = '$hospital_id') as hospital_name FROM users left join hospital_doctor as hd on(users.id = hd.doctor_id) left join speciality_hospital_doctor as shd on(hd.hospital_doctor_id = shd.hospital_doctor_id and hd.hospital_id = '" . $hospital_id . "') WHERE shd.speciality_id='" . $hospital_doctor['speciality_id'] . "' and hd.is_active='1' and users.is_active='1' and users.id not in( select case_request_images.doctor_id from case_request_images where case_id='" . $case_id . "')");

            //$provider_query = $this->db->query("select h_d.doctor_id,h_d.hospital_doctor_id,u.fname,u.lname,(select speciality_name from speciality where speciality_id = '" . $hospital_doctor['speciality_id'] . "') as specialityname, (select hospital_network from hospital_network where id = h_d.hospital_id) as hospital_name from hospital_doctor as h_d inner join users as u on(h_d.doctor_id = u.id) left join speciality_hospital_doctor as sphd on (h_d.hospital_doctor_id = sphd.hospital_doctor_id)  where h_d.is_active='1' and u.is_active='1' and  h_d.hospital_id in ($hospital_id) and sphd.speciality_id='" . $hospital_doctor['speciality_id'] . "' and sphd.hospital_doctor_id !='" . $hospital_doctor['hospital_doctor_id'] . "'  AND h_d.`hospital_doctor_id` NOT IN (SELECT h.`hospital_doctor_id` FROM `case_request_images` cr INNER JOIN `hospital_doctor` h ON cr.`doctor_id`=h.`doctor_id` where cr.case_id=$case_id )  and h_d.`hospital_doctor_id` NOT IN (SELECT  DISTINCT hd.`hospital_doctor_id` FROM case_history ch INNER JOIN `hospital_doctor` hd ON ch.`case_entered_by`=hd.`doctor_id` WHERE case_status='1' AND is_deleted='0' AND ch.`id`=$case_id)");


            $select = "";

            foreach ($provider_query->result_array() as $data) {


                $select.="<option value='" . $data['doctor_id'] . "-" . $hospital_id . "'>" . $data['fname'] . $data['lname'] . " - " . $data['specialityname'] . " - " . $data['hospital_name'] . "</option>";
            }



            return $select;
        }
    }

    // get the case description according to speciliaty
    public function getCaseDescription($case_desc, $pname, $case_entered_by) {
        $speciality = $this->session->userdata('speciality_id');
        $user_id = $this->session->userdata('u_userid');
        $speciality_array = array(PATHOLOGY_SPECILITY, RADIOLOGY_SPECILITY, GENETICS_SPECILITY, HOSPITAL_ADMIN_SPECILITY);
        $case_array = explode(',', strip_tags($case_desc));
        if (in_array($speciality, $speciality_array) || $user_id == $case_entered_by) {
            return $case_array[0] . ".";
        } else {
            $case_des = str_replace($pname, ' ', $case_array[0]);
            $case_des = str_replace('The patient', 'The patient is a ', $case_des);
            return $case_des . ".";
        }
    }

    public function case_edit_image() {

        $user_id = $_SESSION['u_userid'];
        $chkImage = $this->input->post('chkId');
        $imageId = $this->input->post('imageId');
        $comments = $this->input->post('comments');
        $case_id = $this->input->post('case_id');
        $userinfo = $this->mcustom->getUser($user_id);
        $speciality_id = $userinfo->speciality_id;
        for ($i = 0; $i <= 5; $i++) {
            $comment = isset($comments[$i]) && $comments[$i] != "" ? $comments[$i] : '';
            if (isset($chkImage[$i]) && $chkImage[$i] > 0) {
                $query = $this->db->get_where('case_save_images', array('id' => $chkImage[$i]));
                $result = $query->result();
                echo $this->db->last_query();
                $path = $_SERVER['DOCUMENT_ROOT'] . '/oncolensphp/upload/' . $result[0]->image_name;
                if (unlink($path)) {
                    $this->db->where('id', $chkImage[$i]);
                    $this->db->delete('case_save_images');
                }
            } else {
                $path = '';
                $path = time() . $i . $_FILES['rImageFile' . $i]['name'];
                $path = str_replace(" ", "_", $path);
                if (isset($_FILES['rImageFile' . $i]['name'])) {
                    if (isset($imageId[$i]) && $imageId[$i] > 0 && $_FILES['rImageFile' . $i]['size'] > 0) {
                        $query = $this->db->get_where('case_save_images', array('id' => $imageId[$i]));
                        $result = $query->result();
                        $path1 = $_SERVER['DOCUMENT_ROOT'] . '/oncolensphp/upload/' . $result[0]->image_name;
                        if (unlink($path1)) {
                            if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                                $file_uploaded = $this->db->query("update case_save_images set image_name='" . $path . "',comments=" . $this->db->escape($comment) . " where id='" . $imageId[$i] . "'");
                            } else {

                            }
                        }
                    } elseif ($_FILES['rImageFile' . $i]['size'] > 0) {
                        if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                            $file_uploaded = $this->db->query("Insert into case_save_images (case_id,doctor_id,image_name,comments,speciality_id)values('" . $case_id . "','" . $user_id . "','" . $path . "'," . $this->db->escape($comment) . ",'" . $speciality_id . "')");
                        } else {

                        }
                    } else {
                        if (isset($imageId[$i]) && $imageId[$i] > 0) {
                            $file_uploaded = $this->db->query("update case_save_images set comments=" . $this->db->escape($comment) . " where id='" . $imageId[$i] . "'");
                        }
                    }
                }
            }
        }
        return true;
    }

    public function request_data_edit() {
        $user_id = $_SESSION['u_userid'];
        $chkImage = $this->input->post('chkId');
        $imageId = $this->input->post('imageId');

        $comments = $this->input->post('comments');
        $case_id = $this->input->post('case_id');
        $userinfo = $this->mcustom->getUser($user_id);
        $speciality_id = $userinfo->speciality_id;
        $casesummary = $this->input->post('casesummary');
        $doctor_id = $this->session->userdata('u_userid');

        for ($i = 0; $i <= 14; $i++) {
            $comment = isset($comments[$i]) && $comments[$i] != "" ? $comments[$i] : '';
            if (isset($chkImage[$i]) && $chkImage[$i] > 0) {
                $query = $this->db->get_where('case_save_images', array('id' => $chkImage[$i]));
                $result = $query->result();
                if (isset($result) && !empty($result)) {
                    $path = $_SERVER['DOCUMENT_ROOT'] . '/oncolensphp/upload/' . $result[0]->image_name;
                    if (unlink($path)) {
                        $this->db->where('id', $chkImage[$i]);
                        $this->db->delete('case_save_images');
                    } else {
                        $this->db->where('id', $chkImage[$i]);
                        $this->db->delete('case_save_images');
                    }
                }
            } else {
                $path = '';
                if (isset($_FILES['rImageFile' . $i])) {
                    $path = time() . $i . $_FILES['rImageFile' . $i]['name'];
                    $path = str_replace(" ", "_", $path);
                }
                if (isset($_FILES['rImageFile' . $i]['name'])) {

                    if (isset($imageId[$i]) && $imageId[$i] > 0 && (isset($_FILES['rImageFile' . $i])) && $_FILES['rImageFile' . $i]['size'] > 0) {

                        $query = $this->db->get_where('case_save_images', array('id' => $imageId[$i]));
                        $result = $query->result();
                        $path1 = $_SERVER['DOCUMENT_ROOT'] . '/oncolensphp/upload/' . $result[0]->image_name;

                        if (unlink($path1)) {
                            if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                                $file_uploaded = $this->db->query("update case_save_images set image_name='" . $path . "',comments=" . $this->db->escape($comment) . " where id='" . $imageId[$i] . "'");
                            } else {

                            }
                        } else {

                            if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                                $file_uploaded = $this->db->query("update case_save_images set image_name='" . $path . "',comments=" . $this->db->escape($comment) . " where id='" . $imageId[$i] . "'");
                            } else {

                            }
                        }
                    } elseif ($_FILES['rImageFile' . $i]['size'] > 0) {
                        if (move_uploaded_file($_FILES['rImageFile' . $i]['tmp_name'], "upload/" . $path)) {
                            $file_uploaded = $this->db->query("Insert into case_save_images (case_id,doctor_id,image_name,comments,speciality_id)values('" . $case_id . "','" . $user_id . "','" . $path . "'," . $this->db->escape($comment) . ",'" . $speciality_id . "')");
                        } else {

                        }
                    } else {
                        if (isset($imageId[$i]) && $imageId[$i] > 0) {
                            $file_uploaded = $this->db->query("update case_save_images set comments=" . $this->db->escape($comment) . " where id='" . $imageId[$i] . "'");
                        }
                    }
                }
            }

            if ($casesummary != "") {
                $this->db->query("update case_save_images_summary set case_summary=" . $this->db->escape($casesummary) . " where case_id='" . $case_id . "' AND doctor_id='" . $doctor_id . "' AND speciality_id='" . $speciality_id . "'");
            }
        }
        return true;
    }

}

?>
