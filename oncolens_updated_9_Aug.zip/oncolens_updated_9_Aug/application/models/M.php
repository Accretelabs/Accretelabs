<?php

class M extends CI_Model {
    
     public function get_field($field,$table,$condition) {
            $this->db->select($field);
            $Q = $this->db->get_where($table, $condition)->row();
     }
    
    
}

?>