<?php

class Mschedule extends CI_Model {

    //get list of tumor boards by hospital id
    public function get_tumorboards($hospital_id = false) {
        $hospital_id = $hospital_id ? $hospital_id : $this->session->userdata('hospital_id');
        $this->db->select("tb.*");
        $this->db->from("hospital_tumor_board tbh");
        $this->db->join("tumor_board tb", "tb.tumor_id = tbh.tumor_id", "left");
        $this->db->where("tbh.hospital_id = '$hospital_id'");
        $this->db->where("tb.is_active = '1'");
        $query = $this->db->get();
        return $query->result();
    }

    // to create tumor board meeting            
    public function create_schedule() {
        $hospital_id = $this->session->userdata('hospital_id');
        $data = array(
            'tumor_board_id' => $this->input->post('tumor_id'),
            'day_week' => $this->input->post('week_days'),
            'day_time' => date('H:i:s', strtotime($this->input->post('time_of_day'))),
            'recurrence' => $this->input->post('recurrence_type'),
            'date_start' => date('Y-m-d', strtotime($this->input->post('first_date'))),
            'date_end' => date('Y-m-d', strtotime($this->input->post('last_date'))),
            'hospital_id' => $hospital_id,
            'add_date' => date('Y-m-d H:i:s', time()),
            'update_date' => date('Y-m-d H:i:s', time())
        );
        if ($this->db->insert("case_meeting", $data)) {
            $meeting_id = $this->db->insert_id();
            $this->create_child_schedules($meeting_id, $data);
            return $meeting_id;
        } else {
            return false;
        }
    }

       // to create tumor board sub meeting        
    private function create_child_schedules($meeting_id, $data) {
        $day_strat = explode('-', $data['date_start']);
        $datefromtime = $looptime = mktime(0, 0, 0, $day_strat[1], $day_strat[2], $day_strat[0]);
        $day_end = explode('-', $data['date_end']);
        $datetotime = mktime(0, 0, 0, $day_end[1], $day_end[2], $day_end[0]);
        $child_events = array();
        while ($looptime <= $datetotime) {
            switch ($data['recurrence']) {
                case 'day':
                    $event = array(
                        'parent_id' => $meeting_id,
                        'meeting_date' => date('Y-m-d', $looptime),
                        'meeting_time' => $data['day_time']
                    );
                    $child_events[] = $event;
                    $newdate = '+ 1 day';
                    break;
                case 'week':
                    $weekday = date('N', $looptime) + 1;
                    if ($weekday == $data['day_week']) {
                        $event = array(
                            'parent_id' => $meeting_id,
                            'meeting_date' => date('Y-m-d', $looptime),
                            'meeting_time' => $data['day_time']
                        );
                        $child_events[] = $event;
                    }
                    $newdate = '+ 1 day';
                    break;
                case 'month':
                    $event = array(
                        'parent_id' => $meeting_id,
                        'meeting_date' => date('Y-m-d', $looptime),
                        'meeting_time' => $data['day_time']
                    );
                    $child_events[] = $event;
                    $newdate = '+ 1 month';
                    break;
            }
            $looptime = strtotime($newdate, $looptime);
        }
        if (count($child_events)) {
            $this->db->insert_batch('case_meeting_details', $child_events);
        }
    }

                
    
    
    public function get_schedules($filter = array()) {
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;

        $this->db->select("*");
        $this->db->from("case_meeting cm");
        $this->db->join("tumor_board tb", "tb.tumor_id = cm.tumor_board_id", "left");
        $this->db->where("cm.hospital_id = '$hospital_id'");
        $this->db->where("cm.is_deleted = '0'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("cm.id", "desc");
        $query = $this->db->get();
        return $count ? $query->num_rows() : $query->result();
    }

}