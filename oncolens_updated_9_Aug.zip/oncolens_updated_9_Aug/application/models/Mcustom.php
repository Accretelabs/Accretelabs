<?php

class Mcustom extends CI_Model {

    public function get_field($field,$table,$condition) {
        $this->db->select($field);
        $Q = $this->db->get_where($table, $condition);
        if($Q->num_rows() > 0){
            $results = $Q->row();
            return $results->$field; 
        }
       //echo  $this->db->last_query(); die;
           
    }
    
    public function force_pass_change($email,$password=NULL){
       $query = $this->db->get_where('users', array('upper(email)' => strtoupper(db_clean($email)),'is_active' => '1'), 1);
       $results = $query->row();
       
       if($query->num_rows()>0 && ($this->bcrypt->check_password($password, $results->password))){
            $change_password_date = $results->last_password_change_date;
            $create_date = $results->date;
            $current_time = time();
            if ($change_password_date != '0000-00-00 00:00:00') {
                $password_90_days = strtotime($change_password_date . '+90 days');
                if ($current_time > $password_90_days) 
                {
                    $redirect = 'users/force_changepassword';
                } else { 
                    $redirect = '';
                }

                return $redirect;
            }else{
                $password_90_days = strtotime($create_date . '+90 days');
                if ($current_time > $password_90_days) {
                    $redirect = 'users/force_changepassword';
                } else { 
                    $redirect = '';
                }
                return $redirect;
            }    
             
       }else{ 
           return false;
       }
    }
    
    public function getUser($id) {
        $data = array();
        $options = array('id' => $id);
        $Q = $this->db->get_where('users', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    

    public function getAllUsers($per_page, $offset, $sortfield, $order) {
        $data = array();
        $this->db->order_by($sortfield, $order);
        $this->db->limit($per_page, $offset);
        $Q = $this->db->get('users');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function gethospitals() {
        $data = array();
        $Q = $this->db->get('hospital_network');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        return $data;
    }
    
    public function get_our_hospitals() {
        $data = array();
        $u_userid = $this->session->userdata('u_userid');
        $this->db->select("hn.id,hn.hospital_network");
        $this->db->from("hospital_network hn");
        $this->db->join("hospital_doctor hd", "hn.id = hd.hospital_id", "left");
        $this->db->where("hd.doctor_id = $u_userid");
        
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        return $data;
    }
    
     // to get tumor board list
    
     public function get_tumor_board(){
        $doctor_id = $this->session->userdata('u_userid');     
        $this->db->select("d.tumor_id ,d.tumor_board_name");
        $this->db->from("hospital_doctor a");
        $this->db->join("hospital_doctor_tumor_board b", "a.hospital_doctor_id = b.hospital_doctor_id", "left");
        $this->db->join("hospital_network c", "c.id = a.hospital_id", "left");
        $this->db->join("tumor_board d", "d.tumor_id = b.tumor_id", "left");
        $this->db->where("a.doctor_id = '$doctor_id'");
        $this->db->where("b.is_active = '1'");
        $query = $this->db->get();
        
        return $query->result();
    }
    
    public function delete_user($id, $table_name) {
        $this->db->where('id', $id);
        $this->db->delete($table_name);
    }

    public function getCancertype() {
        $data = array();
        $this->db->select("*");
        $this->db->from("cancercategories");
        $this->db->where("cancer_status = '1'");
         $this->db->order_by("order_id");
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getRace() {
        $data = array();
        $Q = $this->db->get('race');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getAllrows($table) {
        $data = array();
        $Q = $this->db->get($table);
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getcancersubcat($table, $option) {
        $data = array();
        $options = $option;
        $Q = $this->db->get_where($table, $options);
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getselectedata($query) {
      $data = array();
       
        $Q = $this->db->query($query);
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    public  function findage($dob) {
        $localtime = getdate();
        $today = $localtime['mday']."-".$localtime['mon']."-".$localtime['year'];
        $dob_a = explode("-", $dob);
        $today_a = explode("-", $today);
        $dob_d = $dob_a[0];$dob_m = $dob_a[1];$dob_y = $dob_a[2];
        $today_d = $today_a[0];$today_m = $today_a[1];$today_y = $today_a[2];
        $years = $today_y - $dob_y;
        $months = $today_m - $dob_m;
        if ($today_m.$today_d < $dob_m.$dob_d) 
        {
            $years--;
            $months = 12 + $today_m - $dob_m;
        }

        if ($today_d < $dob_d) 
        {
            $months--;
        }

        $firstMonths=array(1,3,5,7,8,10,12);
        $secondMonths=array(4,6,9,11);
        $thirdMonths=array(2);

        if($today_m - $dob_m == 1) 
        {
            if(in_array($dob_m, $firstMonths)) 
            {
                array_push($firstMonths, 0);
            }
            elseif(in_array($dob_m, $secondMonths)) 
            {
                array_push($secondMonths, 0);
            }elseif(in_array($dob_m, $thirdMonths)) 
            {
                array_push($thirdMonths, 0);
            }
        }
        $age = "";
        if($years>0){
            $age = $years ." year "; 
        }
        if($months>0){
            $age = $age. $months ." month";
        }

        return  $age;
    }

     function days_count_submission($date){
         $now = time(); // or your date as well
        $your_date = strtotime($date);
        $datediff = $now - $your_date;
        return floor($datediff/(60*60*24));
    }
    
    
    function days_count($date){
         $date1 = date_create(date("Y-m-d"));
         $date2 = date_create($date);         
         $interval = date_diff($date1, $date2);
            
          $years = $interval->y;           
          $month = $interval->m;  
          $days = $interval->d;
         
          
            
             if($years>=1 || $month>=1){
           
            if ($years > 1)
            $yearString = " year";
            else
            $yearString = " year";
            if ($month > 1)
            $monthString = " month";
            else
            $monthString = " month";
            if ($days > 1)
            $dayString = " day";
            else
            $dayString = " day";
    
        if (($years == 0) && ($month == 0) && ($days == 0))
            $ageString = '1' . $dayString . " old";
        elseif(($years == 0) && ($month == 0) && ($days>0))
            $ageString = $days . $dayString . " old";
        elseif(($years == 0) && ($month>0))
            $ageString = $month . $monthString . " old";
        elseif(($years<20) && ($month>0))
            $ageString = $years . $yearString . " and " . $month . $monthString . " old";
        else
            $ageString = $years . $yearString . " old";
         
         return $ageString;
          }else{
           if($days==0){
              $days =1; 
           } 
           $dayString = " day"; 
        return $days. $dayString . " old";
            }
        
       
    }
    
    public function timeCheck(){
	if(!isset($_SESSION['isLoggedIn']) || !($_SESSION['isLoggedIn'])){
		session_unset();
		return true;
		exit;
	} else {
            // user is logged in
            $current = time();// take the current time
            $diff = $current - $_SESSION['loggedAt'];
            if($diff > $_SESSION['timeOut']){
                   session_unset();
                   return true;
                   exit;
            }else{
                   return false;
                   exit;
            }
            
	}
    }
    
       
/**
 *this function for the notify for patient and doctor while they login from different ip 
 */
    public function notify_ip_msg(){
        $status=0;
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];

        if (filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
         $data=$this->getCityIp($ip);
         $current_city=  strtolower($data[0]);
         $current_country=strtolower($data[1]);
         
         $isipexist=$this->isIpLoginExist($current_city,$current_country);
         
        if($isipexist){
            $id=$isipexist->id;
            $older_ip=$isipexist->ip_address;
            if($ip!=$older_ip){
                $this->updateLoginIp($id,$ip);
            }
        }else{
                $status = $this->insertLoginIp($ip,$current_city,$current_country);
        }
       return $status;
    }
    
   /**
    *this fnction is for the  get the city or country code while login by using thirt party
    * @param type $ip string
    * @return type array
    */ 
    public function getCityIp($ip){
        // $addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
        // $city = isset($addr_details['geoplugin_city'])?stripslashes(ucfirst($addr_details['geoplugin_city'])):'';
        // $countrycode = stripslashes(ucfirst($addr_details['geoplugin_countryCode']));
        // $data=array($city,$countrycode);
        // return $data;
    }
    
    /**
     *function for check if there is exist data for user with city or country while login
     * @param type $city string
     * @param type $country string
     * @return type 
     */
    public function isIpLoginExist($city,$country){
        $user_id=  $this->session->userdata('u_userid');
        $result = $this->db->get_where('login_ip_tracking_record', array( 'city_name'=>$city,'country_code'=>$country, 'user_id' => $user_id), 1);
        return $result->row();
     
    }
    
    /**
     *this function for update the data of the user with different ip while login
     * @param type $id integer
     * @param type $ip string
     * @return type 
     */
    public function updateLoginIp($id,$ip){
         $this->db->set('login_date_time',date("Y-m-d H:i:s"));
         $this->db->set('ip_address',$ip);
         $this->db->where('id',$id );
        return $this->db->update('login_ip_tracking_record');
    }
    
    /**
     *this function for insert the data of the user related to the login ip
     * @param type $ip
     * @param type $city
     * @param type $countrycode
     * @return type 
     */
    public function insertLoginIp($ip,$city,$countrycode){
      
        $user_id=  $this->session->userdata('u_userid');
        $result = $this->db->get_where('login_ip_tracking_record', array( 'user_id' => $user_id), 1);
        $result->num_rows();
        if($result->num_rows()==0){
            $return = 0;
        }else{
            $return = 1;
        }
        $user_id=  $this->session->userdata('u_userid');          
       
       
        
        
        $this->db->set('ip_address',$ip);
        $this->db->set('login_date_time',date("Y-m-d H:i:s"));
        $this->db->set('city_name',$city);
        $this->db->set('country_code',$countrycode);
        $this->db->set('user_id',$user_id);
        $this->db->insert('login_ip_tracking_record');
       
               
        return $return;
        
    }
    
    

}

?>
