<?php

class Mcrondemo extends CI_Model {

    // get all providers email 
    // to send email notification weekly
    public function getusers() {



        // get day of notification
        $speciality_regular = array(intval(HOSPITAL_ADMIN_SPECILITY), intval(PATHOLOGY_SPECILITY), intval(GENETICS_SPECILITY), intval(RADIOLOGY_SPECILITY));

        $speciality_specail = array(intval(PATHOLOGY_SPECILITY), intval(GENETICS_SPECILITY), intval(RADIOLOGY_SPECILITY));


        $this->db->select("*");
        $this->db->from("mst_notification");
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            $row = $query->row();
			
            $day = date('w');

            if (1) {
                // get regular provider email id's (non pathology, radiology, genetics)
                $this->db->select("id,fname,email");
                $this->db->where_not_in('speciality_id', $speciality_regular);
                $this->db->where('notification', '1');
                $this->db->where('is_active', '1');
                $this->db->from("users");
                $query = $this->db->get();
                $data1 = $query->result();
			


                if (count($data1) > 0) {
                    foreach ($data1 as $value) {
                        $message = '';
                        $email = '';
                        $user_id = '';
                        $hospitalid = $this->gethospitalid($value->id);
                        $email = $value->email;
                        $user_id = $value->id;
                        $name = $value->fname;
//                        $message .="Regular Provider";
//                        $message .= "<table><tr><td><img src='" . base_url() . "images/oncolence-logo.png' width='100'></td><td><i>Your updates for the week</i></td></tr></table>";
                        foreach ($hospitalid as $hdid) {
                            $query = "SELECT COUNT(id) AS posted, (SELECT COUNT(case_id) FROM `case_doc_email_status` AS cdes  INNER JOIN case_history ON id = case_id WHERE `doctor_id` = " . $value->id . " AND case_status = '1' AND is_deleted = '0' and id not in (select case_id from case_doctor_comments where doctor_id=" . $value->id . ")    and assigned_hospital=" . $hdid->hospital_id . ") AS open_case, (SELECT COUNT(case_id) FROM `case_doctor_comments` INNER JOIN `case_history` ch ON ch.id = case_id WHERE  case_id=ch.id and assigned_hospital=" . $hdid->hospital_id . "   and ch.`case_entered_by` = " . $value->id . ") AS i_answer, (SELECT  count(distinct ca.`case_id`) FROM case_meeting cm inner join   `case_meeting_details` `cmd` on cm.id=cmd.`parent_id`  INNER JOIN `case_meeting_assignments` ca ON ca.sub_meeting_id = cmd.id INNER JOIN (select ch1.id from `case_history` ch1 where ch1.`case_entered_by`=$value->id  and ch1.`case_status`='1' and ch1.`is_deleted`='0'  union 
select cd.case_id from `case_doc_email_status` cd inner join case_history ch2 on cd.case_id=ch2.id and ch2.case_status='1'   where cd.doctor_id=$value->id ) X on X.id=ca.`case_id` WHERE   cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND `cmd`.`is_deleted` = '0'  and  cm.`hospital_id`=$hdid->hospital_id) AS case_presenting FROM `case_history` AS ch  WHERE ch.`case_entered_by` = " . $value->id . " and  ch.case_status='1' and ch.is_deleted='0' and  ch.assigned_hospital=" . $hdid->hospital_id;
                           
                            $data = $this->mcustom->getselectedata($query);
							if(isset($data) && !empty($data)){
								
							$data=$data[0];
							}
                            $assigned = (intval($data->open_case)) - (intval($data->i_answer));

                            $this->load->model('memail_templates', 'memail');
                            $template = $this->memail->get_template_by_name('regular_provider');



                            if ($template) {
                                $mail_data = array(
                                    'hospital_network' => $hdid->hospital_network,
                                    'Requests' => intval($this->getOpenrequestData($value->id, $hdid->hospital_id)),
                                    'Awaiting' => intval($data->open_case),
                                    'Posted' => intval($data->posted),
                                    'Answers' => intval($data->i_answer),
                                    'Presenting' => intval($data->case_presenting),
                                    'unsubscribe' => $value->id,
                                    'email' => $value->email
                                );
                                $subject = str_replace('{{NAME}}', $name, $template['subject']);
                                $subject = str_replace('{{NO_OF_CASE}}', intval($data->open_case), $subject);
                                



                                $mailmessage = $template['body'];
                                foreach ($mail_data as $key => $val) {
                                    $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
                                }



                                $message.= $mailmessage;
                            }
                        }

                        $message .= "<p>This message was sent to <a href='mailto:" . $email . "'>" . $email . "</a>. If you don't want to receive these emails from OncoLens in the future, please <a href='" . base_url() . "users/unsubscribe/" . ($user_id) . "'>unsubscribe</a>.
                                    <br>Please do not reply to this message. 
                                    </p>";


                        $this->email->set_mailtype("html");
                        $this->email->from('notifications@oncolens.com', 'OncolensNotification');
                        $this->email->to('demo.ds4u@gmail.com');
                        $this->email->subject($subject);
						
                        $this->email->message($message);
                        if ($this->email->send()) {

                            echo "Email has been sent successfully to " . " " . $value->email . "<br>";

                            echo "\n";
                        } else {
                            echo "fail";
                            echo $this->email->print_debugger();
                        }
						
                        $message = "";
                        //  echo "<hr>";
                    }
                }


                // get regular provider email id's (pathology, radiology, genetics)

                $this->db->select("id,fname,email");
                $this->db->where_in('speciality_id', $speciality_specail);
                $this->db->where('notification', '1');
                $this->db->where('is_active', '1');
                $this->db->from("users");
                $query = $this->db->get();
                $data1 = $query->result();




                if (count($data1) > 0) {




                    $message = "";
                    foreach ($data1 as $value) {
                        $hospitalid = $this->gethospitalid($value->id);
                        $name=$value->fname;
//                        $message .="Special Provider";                      
//                        $message .= "<table><tr><td><img src='" . base_url() . "images/oncolence-logo.png' width='100'></td><td><i>Your updates for the week</i></td></tr></table>";

                        $mailmessage = "";
                        $c = 1;

                        foreach ($hospitalid as $hdid) {



                            $query = "SELECT COUNT(id) AS posted, (SELECT COUNT(case_id) FROM `case_doc_email_status` AS cdes  INNER JOIN case_history ON id = case_id WHERE `doctor_id` = " . $value->id . " AND case_status = '1' AND is_deleted = '0' and id not in (select case_id from case_doctor_comments where doctor_id=" . $value->id . ")    and assigned_hospital=" . $hdid->hospital_id . ") AS open_case, (SELECT COUNT(case_id) FROM `case_doctor_comments` INNER JOIN `case_history` ch ON ch.id = case_id WHERE  case_id=ch.id and assigned_hospital=" . $hdid->hospital_id . "   and ch.`case_entered_by` = " . $value->id . ") AS i_answer, (SELECT  count(distinct ca.`case_id`) FROM case_meeting cm inner join   `case_meeting_details` `cmd` on cm.id=cmd.`parent_id`  INNER JOIN `case_meeting_assignments` ca ON ca.sub_meeting_id = cmd.id INNER JOIN (select ch1.id from `case_history` ch1 where ch1.`case_entered_by`=$value->id  and ch1.`case_status`='1' and ch1.`is_deleted`='0'  union 
select cd.case_id from `case_doc_email_status` cd inner join case_history ch2 on cd.case_id=ch2.id and ch2.case_status='1'   where cd.doctor_id=$value->id ) X on X.id=ca.`case_id` WHERE   cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND `cmd`.`is_deleted` = '0'  and  cm.`hospital_id`=$hdid->hospital_id) AS case_presenting FROM `case_history` AS ch  WHERE ch.`case_entered_by` = " . $value->id . " and  ch.case_status='1' and ch.is_deleted='0' and  ch.assigned_hospital=" . $hdid->hospital_id;



                            $data = $this->mcustom->getselectedata($query);
							if(isset($data) && !empty($data)){
								
							$data=$data[0];
							}
                            $assigned = (intval($data->open_case)) - (intval($data->i_answer));

                            $this->load->model('memail_templates', 'memail');
                            $template = $this->memail->get_template_by_name('special_provider');



                            if ($template) {



                                $mail_data = array(
                                    'hospital_network' => $hdid->hospital_network,
                                    'Requests' => intval($this->getOpenrequestData($value->id, $hdid->hospital_id)),
                                    'Awaiting' => intval($data->open_case),
                                    'Posted' => intval($data->posted),
                                    'Answers' => intval($data->i_answer),
                                    'Presenting' => intval($data->case_presenting),
                                    'unsubscribe' => $value->id,
                                    'email' => $value->email
                                );
                                
                                $subject = str_replace('{{NAME}}', $name, $template['subject']);
                                $subject = str_replace('{{NO_OF_CASE}}', intval($data->open_case), $subject);
                                
                                $mailmessage = $template['body'];
                                foreach ($mail_data as $key => $val) {
                                    $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
                                }



                                $message.= $mailmessage;
                            }
                        }


                        $message.="<tr><td colspan='3'>&nbsp;</td></tr><tr><td colspan='3'><a href='" . base_url() . "' style='background:#FF814A;text-decoration:none;padding:8px;color:#ffffff;font-weight:bold;font-size:14px;width:200px'>Go to Oncolens</a></td></tr></table>";



                        $message .= "<p>This message was sent to <a href='mailto:" . $value->email . "'>" . $value->email . "</a>. If you don't want to receive these emails from OncoLens in the future, please <a href='" . base_url() . "users/unsubscribe/" . ($value->id) . "'>unsubscribe</a>.
                                    <br>Please do not reply to this message. 
                                    </p>";




                        $this->email->set_mailtype("html");
                        $this->email->from('notifications@oncolens.com', 'OncolensNotification');
                        $this->email->to('demo.ds4u@gmail.com');
                        $this->email->subject($subject);
                        $this->email->message($message);
                        if ($this->email->send()) {

                            echo "Email has been sent successfully to " . " " . $value->email . "<br>";
                        } else {
                            echo "Fail";
                            echo $this->email->print_debugger();
                        }
												
                        $message = "";
                        //   echo "<hr>";
                    }
                }
            }
        }
        die();
    }

    // no of open request cases assigned to user hospitial wise
    public function getOpenrequestData($docid, $hospitalid) {
        $query = "SELECT * FROM `case_request_images` a INNER JOIN case_assignments AS b ON a.case_id = b.case_id INNER JOIN case_history AS h ON h.id = b.case_id INNER JOIN users AS d ON d.id != h.case_entered_by  WHERE doctor_id=$docid AND h.assigned_hospital=$hospitalid and h.case_status = '1' AND h.is_deleted = '0' AND a.is_forwarded = '0' AND a.case_id NOT IN (SELECT case_id FROM case_save_images WHERE doctor_id = $docid) GROUP BY a.`case_id`";
        $request_query = $this->db->query($query);
        return $request_query->num_rows();
    }

    // to fetch hospital assosciated with particular users
    public function gethospitalid($docid) {
        $this->db->select("hd.hospital_id,hn.hospital_network");
        $this->db->from("hospital_doctor hd");
        $this->db->join("hospital_network hn", "hn.id=hd.hospital_id");
        $this->db->where('doctor_id', $docid);
        $this->db->where('hd.is_active', '1');
        $this->db->where('hn.is_active', '1');
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }

}

?>