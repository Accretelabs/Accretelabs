<?php

class Mpage extends CI_Model {
    
    public function pages($slug) {
        $this->db->select("*");
        $this->db->where("url_slug",$slug);
        $this->db->from("page");
        $this->db->limit(1);
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }


}


?>