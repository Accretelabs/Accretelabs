<?php

class Mtumorboard extends CI_Model {

    //get list of tumor boards by hospital id
    public function get_tumorboards($hospital_id = false) {
        $hospital_id = $hospital_id ? $hospital_id : $this->session->userdata('hospital_id');
        $this->db->select("tb.*");
        $this->db->from("hospital_tumor_board tbh");
        $this->db->join("tumor_board tb", "tb.tumor_id = tbh.tumor_id", "left");
        $this->db->where("tbh.hospital_id = '$hospital_id'");
        $this->db->where("tb.is_active = '1'");
        $query = $this->db->get();
        return $query->result();
    }

         // to create schedule for tumorboard meeting
    public function create_schedule() {
        $hospital_id = $this->session->userdata('hospital_id');
        $biweek_days = $this->input->post('biweek_days');
        $data = array(
            'tumor_board_id' => $this->input->post('tumor_id'),
            'day_week' => $this->input->post('week_days'),
            'days_biweek' => isset($biweek_days)?implode(',',$biweek_days):'',
            'day_time' => date('H:i:s', strtotime($this->input->post('time_of_day'))),
            'recurrence' => $this->input->post('recurrence_type'),
            'date_start' => date('Y-m-d', strtotime($this->input->post('first_date'))),
            'date_end' => date('Y-m-d', strtotime($this->input->post('last_date'))),
            'hospital_id' => $hospital_id,
            'add_date' => date('Y-m-d H:i:s', time()),
            'update_date' => date('Y-m-d H:i:s', time())
        );
        if ($this->db->insert("case_meeting", $data)) {
            $meeting_id = $this->db->insert_id();
            $this->create_child_schedules($meeting_id, $data);
            return $meeting_id;
        } else {
            return false;
        }
    }

       // to create child sub meetings         
    private function create_child_schedules($meeting_id, $data) {
        $day_strat = explode('-', $data['date_start']);
        $datefromtime = $looptime = mktime(0, 0, 0, $day_strat[1], $day_strat[2], $day_strat[0]);
        $day_end = explode('-', $data['date_end']);
        $datetotime = mktime(0, 0, 0, $day_end[1], $day_end[2], $day_end[0]);
        $child_events = array();
        $data['days_biweek'] = explode(',',$data['days_biweek']);
        while ($looptime <= $datetotime) {
            switch ($data['recurrence']) {
                case 'day':
                    $event = array(
                        'parent_id' => $meeting_id,
                        'meeting_date' => date('Y-m-d', $looptime),
                        'meeting_time' => $data['day_time']
                    );
                    $child_events[] = $event;
                    $newdate = '+ 1 day';
                    break;
                case 'week':
                    $weekday = date('N', $looptime) + 1;
                    if($weekday>7)$weekday = $weekday-7;
                    if ($weekday == $data['day_week']) {
                        $event = array(
                            'parent_id' => $meeting_id,
                            'meeting_date' => date('Y-m-d', $looptime),
                            'meeting_time' => $data['day_time']
                        );
                        $child_events[] = $event;
                    }
                    $newdate = '+ 1 day';
                    break;
                case 'biweek':
                    $weekday = date('N', $looptime) + 1;
                    if($weekday>7)$weekday = $weekday-7;
                    if ($weekday == $data['days_biweek'][0] || $weekday == $data['days_biweek'][1]) {
                        $event = array(
                            'parent_id' => $meeting_id,
                            'meeting_date' => date('Y-m-d', $looptime),
                            'meeting_time' => $data['day_time']
                        );
                        $child_events[] = $event;
                    }
                    $newdate = '+ 1 day';
                    break;
                case 'month':
                    $event = array(
                        'parent_id' => $meeting_id,
                        'meeting_date' => date('Y-m-d', $looptime),
                        'meeting_time' => $data['day_time']
                    );
                    $child_events[] = $event;
                    $newdate = '+ 1 month';
                    break;
            }
            $looptime = strtotime($newdate, $looptime);
        }
        if (count($child_events)) {
            $this->db->insert_batch('case_meeting_details', $child_events);
        }
    }

    public function get_schedules($filter = array()) {
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;

        $date=date("Y-m-d");        
        $this->db->select("*");
        $this->db->from("case_meeting cm");
        $this->db->join("tumor_board tb", "tb.tumor_id = cm.tumor_board_id", "left");
        $this->db->where("cm.hospital_id = '$hospital_id'");
        $this->db->where("cm.is_deleted = '0'");
        $this->db->where("cm.date_end >= '$date'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("cm.id", "desc");
        $query = $this->db->get();        
               
        return $count ? $query->num_rows() : $query->result();
    }

    public function get_detailed_schedules($filter = array()) {
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $days = isset($filter['days']) ? $filter['days'] : 7;
        $sub_meeting_id = isset($filter['sub_meeting_id']) ? $filter['sub_meeting_id'] : false;

        $this->db->select("*, cmd.id as cmd_id, (SELECT COUNT(*) FROM case_meeting_assignments cm  INNER JOIN case_history ch ON ch.id=cm.case_id WHERE ch.is_deleted='0' AND  cm.sub_meeting_id = cmd.id) case_count", FALSE);
        $this->db->from("case_meeting_details cmd");
        $this->db->join("case_meeting cm", "cmd.parent_id = cm.id", "left");
        
        $this->db->join("tumor_board tb", "tb.tumor_id = cm.tumor_board_id", "left");
        $this->db->where("cm.hospital_id = '$hospital_id'");
        $this->db->where("cm.is_deleted = '0'");
        $this->db->where("cmd.is_deleted = '0'");
        if ($sub_meeting_id) {
            $this->db->where("cmd.id = '$sub_meeting_id'");
            $query = $this->db->get();
            return $query->row_array();
        } else {
            $this->db->where("cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL $days DAY)");
        }
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("cmd.meeting_date, cmd.meeting_time", "asc");
        $query = $this->db->get();
        
        
        
        return $count ? $query->num_rows() : $query->result();
    }

     // to update date and time of schedule           
    public function update_detailed_schedules($id, $data) {
        if(is_array($id) && !empty($id)){
            $i = 0;
            
           
           
            foreach($id as $ids){
                if(!empty($ids)){
                    $d = array(
                            'meeting_date' => date('Y-m-d', strtotime($data['meeting_date'][$i])),
                            'meeting_time' => date('H:i:s', strtotime($data['meeting_time'][$i]))
                        );
                    $this->db->where('id', $ids);
                    $this->db->update("case_meeting_details cmd", $d);
                    $i++;
                }
            }
            
        }
    }
    
         //   // to delete child sub meetings  
     public function delete_submetting($id, $data) {
         $query="SELECT * FROM case_meeting cm  INNER JOIN  `case_meeting_details` cd ON cm.`id`=cd.`parent_id` INNER JOIN `case_meeting_assignments` cma  ON cma.`sub_meeting_id`=cd.`id`   WHERE cm.is_deleted='0' AND  cd.id=$id AND cd.`is_deleted`='0'";                

                $no_assigned_meetings = $this->db->query($query);
                if ($no_assigned_meetings->num_rows() > 0) {                  
                  return false;
                  }
                 else {   
                $this->db->where('id', $id);
                $this->db->update("case_meeting_details cmd", $data);             
                return true;      

                  }
       }
    
    
            // to delete tumor meeting schedule
     public function delete_tumormetting($id) {
        if(!empty($id)){
                
            $query="SELECT * FROM case_meeting cm  INNER JOIN  `case_meeting_details` cd ON cm.`id`=cd.`parent_id` INNER JOIN `case_meeting_assignments` cma  ON cma.`sub_meeting_id`=cd.`id`   WHERE cm.is_deleted='0' AND  cm.id=$id AND cd.`is_deleted`='0' 
";
                
              $no_assigned_meetings = $this->db->query($query);
           if ($no_assigned_meetings->num_rows() > 0) {
                    
                return false;
           
               }
               else {
                   
                $delete_metting="update  case_meeting set is_deleted='1' where id=$id";
                $metting_delete = $this->db->query($delete_metting);
                   
                   return true;
                   
               }
               }   
               
    }

    // assign cases to tumor borad meeting
    public function assign_case($data) {
        $this->db->insert("case_meeting_assignments", $data);
        return $this->db->insert_id();
    }

    public function get_cases($filter = array()) {
        $salt =$this->config->item('salt');
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $tumor_board_id = isset($filter['tumor_board_id']) ? $filter['tumor_board_id'] : 7;
        if ($tumor_board_id <= 0) {
            $tumor_boards = $this->get_tumorboards();
            $tumor_board_array = array();
            foreach ($tumor_boards as $tb) {
                $tumor_board_array[] = $tb->tumor_id;
            }
        }
        $this->db->select("*, AES_DECRYPT(ch.case_description, '$salt') AS case_description,ch.case_mr_number,AES_DECRYPT(ch.name,'$salt') as name , catb.id catb_id, datediff(CURDATE(), ch.case_submit_date ) case_submitted_within, ch.id case_id, ch.mark_as_discussed_live, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count", FALSE);
        $this->db->from("case_assignment_tumor_board catb");
        $this->db->join("case_history ch", "ch.id = catb.case_id", "left");
        $this->db->join("users u", "u.id = ch.case_entered_by", "left");
        $this->db->join("cancercategories cc", "cc.cancer_id = ch.cancer_id", "left");
        $this->db->join("tumor_board tb", "tb.tumor_id = catb.tumor_board_id", "left");
        $tumor_board_id <= 0 ? $this->db->where_in("catb.tumor_board_id ", $tumor_board_array) : $this->db->where("catb.tumor_board_id = '$tumor_board_id'");
        $this->db->where("catb.id not in (select distinct catb_id from case_meeting_assignments) ");
        $this->db->where("ch.case_status = '1'");
        $this->db->where("ch.is_deleted = '0'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("ch.id", "desc");
        $query = $this->db->get();
        
        return $count ? $query->num_rows() : $query->result();
    }
    
    
    // to view next case in case decription of tumor board meeting 
    public function admin_view_next_id($filter = array()) {
        $salt =$this->config->item('salt');
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $tumor_board_id = isset($filter['tumor_board_id']) ? $filter['tumor_board_id'] : 7;
        if ($tumor_board_id <= 0) {
            $tumor_boards = $this->get_tumorboards();
            $tumor_board_array = array();
            foreach ($tumor_boards as $tb) {
                $tumor_board_array[] = $tb->tumor_id;
            }
        }
        $this->db->select("*, AES_DECRYPT(ch.case_description, '$salt') AS case_description,AES_DECRYPT(ch.name,'$salt') as name , catb.id catb_id, datediff(CURDATE(), ch.case_submit_date ) case_submitted_within, ch.id case_id, ch.mark_as_discussed_live, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count", FALSE);
        $this->db->from("case_assignment_tumor_board catb");
        $this->db->join("case_history ch", "ch.id = catb.case_id", "left");
        $this->db->join("users u", "u.id = ch.case_entered_by", "left");
        $this->db->join("cancercategories cc", "cc.cancer_id = ch.cancer_id", "left");
        $this->db->join("tumor_board tb", "tb.tumor_id = catb.tumor_board_id", "left");
        $tumor_board_id <= 0 ? $this->db->where_in("catb.tumor_board_id ", $tumor_board_array) : $this->db->where("catb.tumor_board_id = '$tumor_board_id'");
        $this->db->where("catb.id not in (select distinct catb_id from case_meeting_assignments) ");
        $this->db->where("ch.case_status = '1'");
        $this->db->where("ch.is_deleted = '0'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("ch.id", "desc");
        $query = $this->db->get();
        
         $case_data = $query->result_object();
        
            foreach($case_data as $data)
          {
             
                $next_id[]=$data->case_id;               
             
         }
         
                $next_id_tmp=array();
                $next_id=array_unique($next_id);
              
                
                foreach ($next_id as $ids)
                {
                    
                    $next_id_tmp[]=$ids;
                }
                
          $this->session->set_userdata('admin_search_next_id', $next_id_tmp);
      
    }

    public function get_meeting_cases($filter = array()) {
        $salt =$this->config->item('salt');
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $status = isset($filter['status']) ? $filter['status'] : 1;
        $sub_meeting_id = isset($filter['sub_meeting_id']) ? $filter['sub_meeting_id'] : 7;

        $this->db->select("*, AES_DECRYPT(ch.case_description, '$salt') AS case_description,ch.case_mr_number, AES_DECRYPT(ch.name,'$salt') as name,AES_DECRYPT(ch.dob,'$salt') as dob, cma.id cma_id, datediff(CURDATE(), ch.case_submit_date ) case_submitted_within, ch.id case_id, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count, (select b.meeting_date from case_meeting_assignments a left join case_meeting_details b on b.id = a.sub_meeting_id where a.id=cma.reassign_id) reassign_date,  (select b.meeting_time from case_meeting_assignments a left join case_meeting_details b on b.id = a.sub_meeting_id where a.id=cma.reassign_id) reassign_time", FALSE);
        $this->db->from("case_meeting_assignments cma");
        $this->db->join("case_history ch", "ch.id = cma.case_id", "left");
        $this->db->join("users u", "u.id = ch.case_entered_by", "left");
        $this->db->join("cancercategories cc", "cc.cancer_id = ch.cancer_id", "left");
        $this->db->where("cma.sub_meeting_id = '$sub_meeting_id'");
        if ($status != 'all')
            $this->db->where("ch.case_status = '$status'");
        $this->db->where("ch.is_deleted = '0'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("cma.id", "desc");
        $query = $this->db->get();
        
      
        
        return $count ? $query->num_rows() : $query->result();
    }

    public function remove_case_from_meeting($cma_id) {
        $this->db->delete('case_meeting_assignments', array('id' => $cma_id));
    }

    //get all users who should attend the meeting
    public function get_meeting_attendees($sub_meeting_id) {
        $meeting = $this->get_detailed_schedules(array('sub_meeting_id' => $sub_meeting_id));
        $tumor_board_id = $meeting['tumor_board_id'];
        $hospital_id = $meeting['hospital_id'];
        if($hospital_id!=$this->session->userdata('hospital_id')){
            redirect(base_url('/tumorboard/view'));
            exit;
        }
        $this->db->select("DISTINCT  u.id,u.lname,u.fname,u.speciality_id, s.speciality_name", false);
        $this->db->from("hospital_doctor_tumor_board hdtb");
        $this->db->join("hospital_doctor hd", "hd.hospital_doctor_id = hdtb.hospital_doctor_id", "left");
        $this->db->join("users u", "u.id = hd.doctor_id", "left");
        $this->db->join("speciality s", "u.speciality_id = s.speciality_id", "left");
        $this->db->where("hdtb.tumor_id = '$tumor_board_id'");
        $this->db->where("hdtb.is_active = '1'");
        $this->db->where("hd.is_active = '1'");
        $this->db->where("u.is_active = '1'");
        $this->db->where("u.speciality_id != " . HOSPITAL_ADMIN_SPECILITY);
        $this->db->order_by("u.fname,u.lname","Asc");
        $query = $this->db->get();
        $tb_providers = $query->result();
        
        $this->db->select("DISTINCT  u.id,u.lname,u.fname,u.speciality_id, s.speciality_name", false);
        $this->db->from("hospital_doctor hd");
        $this->db->join("users u", "u.id = hd.doctor_id", "left");
        $this->db->join("speciality s", "u.speciality_id = s.speciality_id", "left");
        $this->db->where("hd.hospital_id = '$hospital_id'");
        $this->db->where("hd.is_active = '1'");
        $this->db->where("u.is_active = '1'");
        $this->db->where("u.speciality_id = " . HOSPITAL_ADMIN_SPECILITY);
        $this->db->order_by("u.fname,u.lname","Asc");
        $query = $this->db->get();

        $hospital_admins = $query->result();
        
        $result = array_merge($tb_providers,$hospital_admins);
//        prd($tb_providers,0);
//        prd($hospital_admins,0);
//        prd($result);
        return $result;
    }

       // to save the attendee         
    public function save_attendee($sub_meeting_id, $attendees) {
        $this->db->delete('case_meeting_attendees', array('sub_meeting_id' => $sub_meeting_id));
        $entries = array();
        foreach ($attendees as $attendee) {
            $entry = array(
                'sub_meeting_id' => $sub_meeting_id,
                'user_id' => $attendee
            );
            $entries[] = $entry;
        }
        if (count($entries)) {
            $this->db->insert_batch('case_meeting_attendees', $entries);
        }
    }

    //get who actually attended the meeting
    public function get_attendees($sub_meeting_id) {
        $this->db->select('group_concat(user_id) user_ids', false);
        $this->db->where('sub_meeting_id', $sub_meeting_id);
        $query = $this->db->get('case_meeting_attendees');
        $users = $query->row_array();
        return explode(',', $users['user_ids']);
    }

    // to fetch the case detail
    public function case_detail($case_id) {
        $salt =$this->config->item('salt');
        $user_case_query = "SELECT 
                            AES_DECRYPT(ch.case_description, '$salt') AS case_description,
                            ch.case_entered_by,
                            ch.cancer_id,
							 ch.case_mr_number,
                            AES_DECRYPT(ch.dob,'$salt') as dob,
                            AES_DECRYPT(ch.name,'$salt') as pname,
                            ch.cancer_mode,
                            ch.case_submit_date,
                            ch.family_history,
                            DATE_FORMAT(ch.case_updated_date, '%m/%d/%y') AS case_updated_date,
                            ch.pathology_others_text,
                            ch.case_entered_by AS doctor_id,
                            ch.other_serious_medical_conditions AS pmh,
                            ch.case_status,
                            ch.id case_id,
                            ch.nccs_guidlines_discussed,
                            ch.staging_discussed,
                            ch.prospective_discussion,
                            ch.genetics_discussed,
                            ch.clinical_trial_discussed,
                            ch.palliative_care_discussed,
                            ch.mark_as_discussed_live,
                            ch.rcounselling_discussed,
                            ch.pcounselling_discussed,
                            ch.ncounselling_discussed,																					
                            ch.admin_comment,
                            
                                (SELECT 
                                CONCAT(fname, ' ', lname) 
                                FROM
                                users 
                                WHERE id = ch.case_entered_by) AS name,
                            
                            ca.is_tumor,
                            ca.is_specific_provider,
                            ca.is_speciality,
                            ca.is_other,
                            
                            
                                (SELECT 
                                comments 
                                FROM
                                case_doctor_comments 
                                WHERE case_id = ch.id 
                                AND doctor_id = '" . $this->session->userdata('u_userid') . "') AS COMMENT
                                    
                          FROM
                            case_history AS ch 
                            LEFT JOIN case_assignments AS ca 
                              ON ch.id = ca.case_id 
                          WHERE is_deleted = '0' 
                            AND ch.id = '" . $case_id . "'";

        $user_case_assigned = $this->db->query($user_case_query);
        if ($user_case_assigned->num_rows() > 0) {
            $case_array = array();
            $final_array = array();
            $case_list_ids = $user_case_assigned->row();
            $result = "";
            //if (isset($case_list_ids->speciality_id) && !empty($case_list_ids->speciality_id)) {
            $image_data = $this->db->query("Select * from case_save_images where case_id = '" . $case_id . "'");
            $images = array();
            $pathology = array();
            $radiology = array();
            $genetics = array();
            $administrator = array();
            foreach ($image_data->result_object() as $image) {
                
                /*
                 *  showing poster images on date 22-07-2016
                 */
                
                    if (($image->doctor_id == $case_list_ids->doctor_id  ) ) {
                        $images[] = (object) array(
                                    'case_id' => $image->case_id,
                                    'images_doctor_id' => $image->doctor_id,
                                    'image_name' => $image->image_name,
                                    'speciality_id' => $image->speciality_id,
                                    'comments' => $image->comments
                        );
                    }


                if (($image->speciality_id == PATHOLOGY_SPECILITY) && ($image->doctor_id != $case_list_ids->case_entered_by) ) {
                    $pathology[] = (object) array(
                                'case_id' => $image->case_id,
                                'doctor_id' => $image->doctor_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments
                    );
                }

			
                if (($image->speciality_id == RADIOLOGY_SPECILITY) && ($image->doctor_id != $case_list_ids->case_entered_by)) {
                    $radiology[] = (object) array(
                                'case_id' => $image->case_id,
                                'doctor_id' => $image->doctor_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments
                    );
                }
				

                if (($image->speciality_id == GENETICS_SPECILITY)  && ($image->doctor_id != $case_list_ids->case_entered_by)) {
                    $genetics[] = (object) array(
                                'case_id' => $image->case_id,
                                'doctor_id' => $image->doctor_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments
                    );
                }

                if ($image->speciality_id == HOSPITAL_ADMIN_SPECILITY) {
                    $administrator[] = (object) array(
                                'case_id' => $image->case_id,
                                'doctor_id' => $image->doctor_id,
                                'images_doctor_id' => $image->doctor_id,
                                'image_name' => $image->image_name,
                                'speciality_id' => $image->speciality_id,
                                'comments' => $image->comments
                    );
                }
            }

            $result = (object) array(
                        'images' => (object) $images,
                        'pathology' => (object) $pathology,
                        'radiology' => (object) $radiology,
                        'genetics' => (object) $genetics,
                        'administrator' => (object) $administrator,
            );

            $summary_data = $this->db->query("Select a.case_summary,b.speciality_id from case_save_images_summary as a INNER JOIN case_save_images as b on a.speciality_id=b.speciality_id where a.case_id = '" . $case_id . "' and b.speciality_id IN (2,6,8,11) group by a.speciality_id");

            foreach ($summary_data->result_object() as $summary) {
                if ($summary->speciality_id == HOSPITAL_ADMIN_SPECILITY) {
                    $result->administrator_summary = $summary->case_summary;
                }
                if ($summary->speciality_id == PATHOLOGY_SPECILITY) {
                    $result->pathology_summary = $summary->case_summary;
                }
                if ($summary->speciality_id == RADIOLOGY_SPECILITY) {
                    $result->radiology_summary = $summary->case_summary;
                }

                if ($summary->speciality_id == GENETICS_SPECILITY) {
                    $result->genetics_summary = $summary->case_summary;
                }
            }

            $comment = "";
            $comment_data = $this->db->query("Select * from case_doctor_comments where case_id = '" . $case_id . "'");
            if (count($comment_data->num_rows() > 0)) {
                foreach ($comment_data->result() as $c) {
                    $comment = array(
                        'id' => $c->id,
                        'comments' => $c->comments,
                        'specific_answers' => $c->specific_answers,
                        'other_answer' => $c->other_answer,
                    );
                }
            }

            $this->load->model('mcase');
            $top_answer = $this->mcase->getmaxanswerslist(array('case_id' => $case_list_ids->case_id, 'speciality_id' => false));
            $final_array = (object) array(
                        'case_id' => $case_list_ids->case_id,
                        'pmh' => $case_list_ids->pmh,
                        'family_history' => $case_list_ids->family_history,
						'case_mr_number' => $case_list_ids->case_mr_number,
                        'doctor_id' => $case_list_ids->doctor_id,
                        'doctor_name' => $case_list_ids->name,
                        'pname' => $case_list_ids->pname,
                        'dob' => $case_list_ids->dob,
                        'pathology_others_text' => $case_list_ids->pathology_others_text,
                        'is_tumor' => $case_list_ids->is_tumor,
                        'is_specific_provider' => $case_list_ids->is_specific_provider,
                        'is_speciality' => $case_list_ids->is_speciality,
                        'is_other' => $case_list_ids->is_other,
                        'comment' => (object) $comment,
                        'case_description' => $case_list_ids->case_description,
                        'case_entered_by' => $case_list_ids->case_entered_by,
                        'case_updated_date' => $case_list_ids->case_updated_date,
                        'image_data' => (object) $result,
                        'top_answer' => (object) $top_answer,
                        'nccs_guidlines_discussed' => $case_list_ids->nccs_guidlines_discussed,
                        'staging_discussed' => $case_list_ids->staging_discussed,
                        'prospective_discussion' => $case_list_ids->prospective_discussion,
                        'genetics_discussed' => $case_list_ids->genetics_discussed,
                        'clinical_trial_discussed' => $case_list_ids->clinical_trial_discussed,
                        'palliative_care_discussed' => $case_list_ids->palliative_care_discussed,
                        'mark_as_discussed_live' => $case_list_ids->mark_as_discussed_live,
						'rcounselling_discussed' => $case_list_ids->rcounselling_discussed,
                        'pcounselling_discussed' => $case_list_ids->pcounselling_discussed,
                        'ncounselling_discussed' => $case_list_ids->ncounselling_discussed,
                        'case_status' => $case_list_ids->case_status,
						'admin_comment' => $case_list_ids->admin_comment,
						
            );
            return $final_array;
        } else {
            return false;
        }
    }

       // to update case meeting basic points
    public function update_case_meeting_assignment($sub_meeting_id = 0) {
		
        $data['nccs_guidlines_discussed'] = $this->input->post('nccs_guidlines_discussed') ? $this->input->post('nccs_guidlines_discussed') : 0;
        $data['staging_discussed'] = $this->input->post('staging_discussed') ? $this->input->post('staging_discussed') : 0;
        $data['prospective_discussion'] = $this->input->post('prospective_discussion') ? $this->input->post('prospective_discussion') : 0;
        $data['genetics_discussed'] = $this->input->post('genetics_discussed') ? $this->input->post('genetics_discussed') : 0;
        $data['clinical_trial_discussed'] = $this->input->post('clinical_trial_discussed') ? $this->input->post('clinical_trial_discussed') : 0;
        $data['palliative_care_discussed'] = $this->input->post('palliative_care_discussed') ? $this->input->post('palliative_care_discussed') : 0;
	
		$rcounselling_discussed= $this->input->post('rcounselling_discussed') ? $this->input->post('rcounselling_discussed') : 0;
		$pcounselling_discussed = $this->input->post('pcounselling_discussed') ? $this->input->post('pcounselling_discussed') : 0;
		$ncounselling_discussed = $this->input->post('ncounselling_discussed') ? $this->input->post('ncounselling_discussed') : 0;
		
	
		
		
        $data['mark_as_discussed_live'] = $this->input->post('mark_as_discussed_live') ? $this->input->post('mark_as_discussed_live') : 0;
        $data['admin_comment'] = $this->input->post('admin_comment');
	
        if ($sub_meeting_id) {
		
            $this->db->where('id', $this->input->post('cma_id'));
				
            $this->db->update('case_meeting_assignments', $data);
				
        }
        if ($this->input->post('case_status') == 1) {
            $data['case_status'] = '0';
        }
		
	 
        $this->db->where('id', $this->input->post('case_id'));
        $this->db->update('case_history', $data);
		 $update_query1="update case_history set rcounselling_discussed='".$rcounselling_discussed."',pcounselling_discussed='".$pcounselling_discussed."',ncounselling_discussed='".$ncounselling_discussed."' where id='".$this->input->post('case_id')."'";
		
		$update_sql=$this->db->query($update_query1);
        if ($this->input->post('case_reassigned') && $sub_meeting_id) {
            $data['sub_meeting_id'] = $this->input->post('case_reassign');
            $data['case_id'] = $this->input->post('case_id');
            $data['parent_id'] = $this->input->post('cma_id');
            unset($data['case_status']);
            $reassign_id = $this->assign_case($data);
            $this->db->where('id', $this->input->post('cma_id'));
            $this->db->update('case_meeting_assignments', array('reassign_id' => $reassign_id));
        }
    }
    
    public function get_case_meeting_summaries($case_id){
        $this->db->select("cma.*, cmd.parent_id,cmd.meeting_date,cmd.meeting_time,group_concat(concat(u.fname,' ',u.lname)) attendee, tb.tumor_board_name, (select b.meeting_date from case_meeting_assignments a left join case_meeting_details b on b.id = a.sub_meeting_id where a.id=cma.reassign_id) reassign_date,  (select b.meeting_time from case_meeting_assignments a left join case_meeting_details b on b.id = a.sub_meeting_id where a.id=cma.reassign_id) reassign_time", false);
        //$this->db->select("*");
        $this->db->from('case_meeting_assignments cma');
        $this->db->join('case_meeting_details cmd','cmd.id=cma.sub_meeting_id','left');
        $this->db->join('case_meeting cm','cm.id=cmd.parent_id','left');
        $this->db->join('tumor_board tb','tb.tumor_id=cm.tumor_board_id','left');
        
        $this->db->join('case_meeting_attendees cmat','cma.sub_meeting_id=cmat.sub_meeting_id','left');
        $this->db->join('users u','u.id=cmat.user_id','left');
            
        $this->db->where("cma.case_id='$case_id'");
        $this->db->order_by("cmd.id", "desc");
        $this->db->group_by("cma.id");

        $q=$this->db->get();
        //echo $this->db->last_query();
        return $q->result();
    }
    
    public function get_case_schedules($case_id){
        $this->db->select("cma.sub_meeting_id", false);
        $this->db->from('case_meeting_assignments cma');
        $this->db->where("cma.case_id='$case_id'");
        $q=$this->db->get();
        return $q->result();
    }
    
    // to search the cases
    public function search_CaseList($params = array(), $count = false) {
        $salt =$this->config->item('salt');
        //echo $this->input->post('filter'); die;

        $pname = isset($params[0]['pname']) ? $params[0]['pname'] : '';
        $submitted_by = isset($params[0]['submitted_by']) ? $params[0]['submitted_by'] : '';
        $submitted_date = isset($params[0]['submitted_date']) ? $params[0]['submitted_date'] : '';
        $cancer_type = isset($params[0]['cancer_type']) ? $params[0]['cancer_type'] : '';
        $case_close = isset($params[0]['case_close']) ? $params[0]['case_close'] : '';
        $case_open = isset($params[0]['case_open']) ? $params[0]['case_open'] : '';
        $urgent = isset($params[0]['urgent']) ? $params[0]['urgent'] : '';
        $is_tumor = isset($params[0]['is_tumor']) ? $params[0]['is_tumor'] : '';
        $online = isset($params[0]['online']) ? $params[0]['online'] : '';
        $inperson = isset($params[0]['inperson']) ? $params[0]['inperson'] : '';
        $dob = isset($params[0]['dob']) ? $params[0]['dob'] : '';
        $dob = explode(':', $dob);
        
        $hospital_id = $this->session->userdata('hospital_id');

        $sql = "SELECT * FROM (select ch.id as case_id, AES_DECRYPT(ch.name,'$salt') as pname, ch.mark_as_discussed_live, (select CONCAT_WS(' ', fname, lname) from users where id=case_entered_by) as doc_name, u.fname, datediff(CURDATE(),  AES_DECRYPT(ch.dob,'$salt') ) as dob_days,ch.cancer_id,ch.case_status,ca.is_tumor,AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type,  AES_DECRYPT(ch.dob,'$salt') as dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count ";
        
        /*$sql .= " from (SELECT AES_DECRYPT(name,'$salt') as name, id, case_entered_by AS docid FROM case_history 
                            UNION ALL 
                          SELECT AES_DECRYPT(name,'$salt') as name, case_id AS id, doctor_id AS docid FROM case_doc_email_status 
                          INNER JOIN case_history ON id = case_id) AS vir";*/
        $sql .= "FROM case_doc_email_status ce INNER JOIN case_history ch  ON ch.id = case_id";
        $sql .= " left join case_assignments ca on ch.id=ca.case_id";
        $sql .= " left join users u on u.id = ch.id";      
        $sql .= " left join cancercategories c on c.cancer_id=ch.cancer_id";
        $sql .= " left join hospital_doctor hd on hd.doctor_id=ce.doctor_id ";
        $sql .= " where ch.assigned_hospital = '$hospital_id'";
        $sql .= " and ch.is_deleted = '0')X where 1  ";
        if($pname != '' || $submitted_by != '' || $submitted_date != ''){
            $sql .= " and  ( ";
            if ($pname != '') {
                 $pname= trim($pname);
                $sql .= " X.pname  like '%$pname%'";
            }
            if ($submitted_by != "") {
                if ($pname != '')$sql .= " or ";
                $submitted_by=trim($submitted_by);
                $sql .= " X.doc_name like '%$submitted_by%'";
            }
            if ($submitted_date != "") {
                if ($pname != '' || $submitted_by != "")$sql .= " or ";
                $sql .= " DATE_FORMAT(X.case_submit_date, '%m/%d/%Y')='$submitted_date'";
            }
            $sql .= " )";
        }

//        if ($submitted_date != "") {
//            $sql .= "and (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%' or DATE_FORMAT(ch.case_submit_date, '%m/%d/%Y')='$submitted_date' or ch.name like '%$pname%')";
//        }else{
//            $sql .= "and (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%' or ch.name like '%$pname%')";
//        }
        if ($cancer_type != '') {
            $sql .= " and X.cancer_id= $cancer_type";
        }

        if ($case_open != '') {
            $sql .= " and X.case_status = '1'";
        }
        if ($case_close != '') {
            $sql .= " and X.case_status = '0'";
            
        }
       
        if ($is_tumor != '') {
            $sql .= " and X.is_tumor = '1'";
        }
        if ($inperson != '') {
            $sql .= " and X.mark_as_discussed_live = '1'";
        }
        if ($urgent != '') {
            $sql .= " AND  (SELECT COUNT(case_id) FROM `case_assignment_priority` WHERE `priority_id`=2 AND case_id=X.id) > 0";
        }
        if ($online != '') {
            //$sql .= " having comment_count > 0";
            $sql .= " AND (select count(*) from case_doctor_comments where case_id = X.id) > 0";
        }
        if (count($dob) == 2 && !empty($dob)) {
            $sql .= " and YEAR(CURDATE())-YEAR((dob)) BETWEEN '$dob[0]' AND $dob[1]";
        }
        $sql .= " group by X.id";
        $sql .= " order by X.id desc";
        if(!$count){
            $sql .= " limit ".$params['start'].", ".$params['limit'];
        }
        
        //$this->db->group_by("ce.case_id");
        //$this->db->order_by("ch.id", "desc");
         
        $query = $this->db->query($sql);
     
        if(!$count){
            $case_data = $query->result_object();
          
            return $case_data;
        }else{
            return $query->num_rows();
        }
    }
    
    
    
     public function next_id($params = array(), $count = false) {
        $salt =$this->config->item('salt');
        //echo $this->input->post('filter'); die;

        $pname = isset($params[0]['pname']) ? $params[0]['pname'] : '';
        $submitted_by = isset($params[0]['submitted_by']) ? $params[0]['submitted_by'] : '';
        $submitted_date = isset($params[0]['submitted_date']) ? $params[0]['submitted_date'] : '';
        $cancer_type = isset($params[0]['cancer_type']) ? $params[0]['cancer_type'] : '';
        $case_close = isset($params[0]['case_close']) ? $params[0]['case_close'] : '';
        $case_open = isset($params[0]['case_open']) ? $params[0]['case_open'] : '';
        $urgent = isset($params[0]['urgent']) ? $params[0]['urgent'] : '';
        $is_tumor = isset($params[0]['is_tumor']) ? $params[0]['is_tumor'] : '';
        $online = isset($params[0]['online']) ? $params[0]['online'] : '';
        $inperson = isset($params[0]['inperson']) ? $params[0]['inperson'] : '';
        $dob = isset($params[0]['dob']) ? $params[0]['dob'] : '';
        $dob = explode(':', $dob);
        
        $hospital_id = $this->session->userdata('hospital_id');

        $sql = "select ch.id as case_id, AES_DECRYPT(ch.name,'$salt') as pname, ch.mark_as_discussed_live, (select CONCAT_WS(' ', fname, lname) from users where id=ch.case_entered_by) as doc_name, u.fname, datediff(CURDATE(),  AES_DECRYPT(ch.dob,'$salt') ) as dob_days,  AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type,  AES_DECRYPT(ch.dob,'$salt') as dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count ";
        
        /*$sql .= " from (SELECT AES_DECRYPT(name,'$salt') as name, id, case_entered_by AS docid FROM case_history 
                            UNION ALL 
                          SELECT AES_DECRYPT(name,'$salt') as name, case_id AS id, doctor_id AS docid FROM case_doc_email_status 
                          INNER JOIN case_history ON id = case_id) AS vir";*/
        $sql .= " from (SELECT AES_DECRYPT(name,'$salt') as name, case_id AS id, doctor_id AS docid FROM case_doc_email_status INNER JOIN case_history ON id = case_id) AS vir";
        $sql .= " left join case_assignments ca on vir.id=ca.case_id";
        $sql .= " left join users u on u.id = vir.docid";
        $sql .= " left join case_history ch on ch.id = vir.id";
        $sql .= " left join cancercategories c on c.cancer_id=ch.cancer_id";
        $sql .= " left join hospital_doctor hd on hd.doctor_id=vir.docid";
        $sql .= " where hd.hospital_id = '$hospital_id'";
        $sql .= " and ch.is_deleted = '0'";
        if($pname != '' || $submitted_by != '' || $submitted_date != ''){
            $sql .= " and ( ";
            if ($pname != '') {
                $sql .= " AES_DECRYPT(ch.name,'$salt')  like '%$pname%'";
            }
            if ($submitted_by != "") {
                if ($pname != '')$sql .= " or ";
                $sql .= " CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%'";
            }
            if ($submitted_date != "") {
                if ($pname != '' || $submitted_by != "")$sql .= " or ";
                $sql .= " DATE_FORMAT(ch.case_submit_date, '%m/%d/%Y')='$submitted_date'";
            }
            $sql .= " )";
        }

        if ($cancer_type != '') {
            $sql .= " and ch.cancer_id= $cancer_type";
        }

        if ($case_open != '') {
            $sql .= " and ch.case_status = '1'";
        }
        if ($case_close != '') {
            $sql .= " and ch.case_status = '0'";
            
        }
       
        if ($is_tumor != '') {
            $sql .= " and ca.is_tumor = '1'";
        }
        if ($inperson != '') {
            $sql .= " and ch.mark_as_discussed_live = '1'";
        }
        if ($urgent != '') {
            $sql .= " AND  (SELECT COUNT(case_id) FROM `case_assignment_priority` WHERE `priority_id`=2 AND case_id=vir.id) > 0";
        }
        if ($online != '') {
            //$sql .= " having comment_count > 0";
            $sql .= " AND (select count(*) from case_doctor_comments where case_id = vir.id) > 0";
        }
        if (count($dob) == 2 && !empty($dob)) {
            $sql .= " and YEAR(CURDATE())-YEAR(AES_DECRYPT(dob,'$salt')) BETWEEN '$dob[0]' AND $dob[1]";
        }
        $sql .= " group by vir.id";
        $sql .= " order by vir.id desc";
        if(!$count){
            $sql .= " limit ".$params['start'].", ".$params['limit'];
        }
        
        //$this->db->group_by("ce.case_id");
        //$this->db->order_by("ch.id", "desc");
        $query = $this->db->query($sql);
       
            $case_data = $query->result_object();
            //echo $this->db->last_query();die;
          
            
             foreach($case_data as $data)
         {
             
                $next_id[]=$data->id;               
             
         }
         
         
          $this->session->set_userdata('admin_search_next_id', $next_id);
             
            
       
    }
	public function case_detail_with_info($case_id){
		
        $salt =$this->config->item('salt');
        //echo $this->input->post('filter'); die;

        $pname = isset($params[0]['pname']) ? $params[0]['pname'] : '';
        $submitted_by = isset($params[0]['submitted_by']) ? $params[0]['submitted_by'] : '';
        $submitted_date = isset($params[0]['submitted_date']) ? $params[0]['submitted_date'] : '';
        $cancer_type = isset($params[0]['cancer_type']) ? $params[0]['cancer_type'] : '';
        $case_close = isset($params[0]['case_close']) ? $params[0]['case_close'] : '';
        $case_open = isset($params[0]['case_open']) ? $params[0]['case_open'] : '';
        $urgent = isset($params[0]['urgent']) ? $params[0]['urgent'] : '';
        $is_tumor = isset($params[0]['is_tumor']) ? $params[0]['is_tumor'] : '';
        $online = isset($params[0]['online']) ? $params[0]['online'] : '';
        $inperson = isset($params[0]['inperson']) ? $params[0]['inperson'] : '';
        $dob = isset($params[0]['dob']) ? $params[0]['dob'] : '';
        $dob = explode(':', $dob);
        
        $hospital_id = $this->session->userdata('hospital_id');

        $sql = "select ch.id as case_id, AES_DECRYPT(ch.name,'$salt') as pname, ch.mark_as_discussed_live, (select CONCAT_WS(' ', fname, lname) from users where id=ch.case_entered_by) as doc_name, u.fname, datediff(CURDATE(),  AES_DECRYPT(ch.dob,'$salt') ) as dob_days,  AES_DECRYPT(ch.case_description, '$salt') AS case_description, u.lname, ch.case_submit_date, ch.id, c.cancer_type,  AES_DECRYPT(ch.dob,'$salt') as dob, (select count(*) from case_doctor_comments where case_id = ch.id) comment_count ";
        
        /*$sql .= " from (SELECT AES_DECRYPT(name,'$salt') as name, id, case_entered_by AS docid FROM case_history 
                            UNION ALL 
                          SELECT AES_DECRYPT(name,'$salt') as name, case_id AS id, doctor_id AS docid FROM case_doc_email_status 
                          INNER JOIN case_history ON id = case_id) AS vir";*/
        $sql .= " from (SELECT AES_DECRYPT(name,'$salt') as name, case_id AS id, doctor_id AS docid FROM case_doc_email_status INNER JOIN case_history ON id = case_id) AS vir";
        $sql .= " left join case_assignments ca on vir.id=ca.case_id";
        $sql .= " left join users u on u.id = vir.docid";
        $sql .= " left join case_history ch on ch.id = vir.id";
        $sql .= " left join cancercategories c on c.cancer_id=ch.cancer_id";
        $sql .= " left join hospital_doctor hd on hd.doctor_id=vir.docid";
        $sql .= " where hd.hospital_id = '$hospital_id'";
        $sql .= " and ch.is_deleted = '0'";
        if($pname != '' || $submitted_by != '' || $submitted_date != ''){
            $sql .= " and ( ";
            if ($pname != '') {
                $sql .= " AES_DECRYPT(ch.name,'$salt')  like '%$pname%'";
            }
            if ($submitted_by != "") {
                if ($pname != '')$sql .= " or ";
                $sql .= " CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%'";
            }
            if ($submitted_date != "") {
                if ($pname != '' || $submitted_by != "")$sql .= " or ";
                $sql .= " DATE_FORMAT(ch.case_submit_date, '%m/%d/%Y')='$submitted_date'";
            }
            $sql .= " )";
        }

//        if ($submitted_date != "") {
//            $sql .= "and (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%' or DATE_FORMAT(ch.case_submit_date, '%m/%d/%Y')='$submitted_date' or ch.name like '%$pname%')";
//        }else{
//            $sql .= "and (CONCAT_WS(' ',u.fname,u.lname) like '%$submitted_by%' or ch.name like '%$pname%')";
//        }
        if ($cancer_type != '') {
            $sql .= " and ch.cancer_id= $cancer_type";
        }

        if ($case_open != '') {
            $sql .= " and ch.case_status = '1'";
        }
        if ($case_close != '') {
            $sql .= " and ch.case_status = '0'";
            
        }
       
        if ($is_tumor != '') {
            $sql .= " and ca.is_tumor = '1'";
        }
        if ($inperson != '') {
            $sql .= " and ch.mark_as_discussed_live = '1'";
        }
        if ($urgent != '') {
            $sql .= " AND  (SELECT COUNT(case_id) FROM `case_assignment_priority` WHERE `priority_id`=2 AND case_id=vir.id) > 0";
        }
        if ($online != '') {
            //$sql .= " having comment_count > 0";
            $sql .= " AND (select count(*) from case_doctor_comments where case_id = vir.id) > 0";
        }
        if (count($dob) == 2 && !empty($dob)) {
            $sql .= " and YEAR(CURDATE())-YEAR(AES_DECRYPT(dob,'$salt')) BETWEEN '$dob[0]' AND $dob[1]";
        }
        $sql .= " group by vir.id";
        $sql .= " order by vir.id desc";
        if(!$count){
            $sql .= " limit ".$params['start'].", ".$params['limit'];
        }
        
        //$this->db->group_by("ce.case_id");
        //$this->db->order_by("ch.id", "desc");
        $query = $this->db->query($sql);
       
            $case_data = $query->result_object();
            //echo $this->db->last_query();die;
          
            
             foreach($case_data as $data)
         {
             
                $next_id[]=$data->id;               
             
         }
         
         
          $this->session->set_userdata('admin_search_next_id', $next_id);
             
            
       
    
	}
	public function update_mr_number($case_id,$mr_id){
		   $this->session->set_flashdata('message', 'Medical Record Number Updated Successfully.');
		return $this->db->query("update case_history set case_mr_number='".$mr_id."' where id=".$case_id);
	}
}
	