<?php
class Minperson extends CI_Model {


   public function inperson_tumorboard($filter){

        $days = isset($filter['days']) ? $filter['days'] :'30';
        $tumorboard = isset($filter['tumorboard']) && count($filter['tumorboard'])>0 ? $filter['tumorboard'] : 0;
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $countassigned = isset($filter['countassigned']) ? true : false;

        $this->db->select("cmd.id , tb.tumor_board_name , hn.hospital_network , cmd.meeting_date, cmd.meeting_time, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id AND (ch.case_entered_by=".$this->session->userdata('u_userid')."  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=".$this->session->userdata('u_userid')."))) AS case_count, (SELECT COUNT(*) FROM case_meeting_assignments ca inner join case_history ch on ca.case_id=ch.id  WHERE ch.case_status='1' and ch.is_deleted='0' and  sub_meeting_id= cmd.id ) AS case_assigned");
        $this->db->from("case_meeting_details cmd");
        $this->db->join("case_meeting cm", "cmd.parent_id = cm.id", "left");
        $this->db->join("tumor_board tb", "cm.tumor_board_id = tb.tumor_id", "left");
        $this->db->join("hospital_tumor_board htb", "cm.tumor_board_id = htb.tumor_id", "left");
        $this->db->join("hospital_network hn", "htb.hospital_id = hn.id", "left");
        $this->db->where("cmd.meeting_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL $days DAY)");
        $this->db->where_in("cm.tumor_board_id",$tumorboard);

        $this->db->where("cmd.is_deleted = '0'");
//        $this->db->where("cm.is_deleted = '0'");
//        $this->db->order_by("cm.id", "desc");
        $this->db->order_by("cmd.meeting_date","asc");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("cmd.id", "asc");

        $query = $this->db->get();


        return $count ? $query->num_rows() : $query->result();

    }

   public function  inperson_tumorboard_details($filter){
        $salt =$this->config->item('salt');

        $id = isset($filter['id']) ? $filter['id'] : 0;
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;

        $this->db->select("ch.id, AES_DECRYPT(ch.case_description, '$salt') AS case_description,AES_DECRYPT(ch.name,'$salt') as pname,AES_DECRYPT(ch.dob,'$salt') as dob,ch.case_entered_by,ch.case_mr_number, cc.cancer_type ,(select concat(fname,' ',lname) from users where id = ch.case_entered_by ) as submitted_by ",false);
        $this->db->from("case_meeting_assignments cma");
        $this->db->join("case_history ch", "cma.case_id = ch.id ", "inner");
        $this->db->join("cancercategories cc", "ch.cancer_id = cc.cancer_id", "inner");
        $this->db->where("ch.case_status",'1');
        //$this->db->where("(ch.case_entered_by=".$this->session->userdata('u_userid')."  or   ch.id  IN (SELECT case_id FROM `case_save_images_summary` cis WHERE cis.doctor_id=".$this->session->userdata('u_userid')."))");



        $this->db->where("ch.is_deleted",'0');
        $this->db->where_in("cma.sub_meeting_id",$id);



        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("ch.case_submit_date", "asc");
        $query = $this->db->get();

      //  echo $this->db->last_query();die;

        return $count ? $query->num_rows() : $query->result();

   }

   public function  next_id($filter){
        $salt =$this->config->item('salt');

        $id = isset($filter['id']) ? $filter['id'] : 0;
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;

        $this->db->select("ch.id, AES_DECRYPT(ch.case_description, '$salt') AS case_description,AES_DECRYPT(ch.name,'$salt') as pname,AES_DECRYPT(ch.dob,'$salt') as dob,ch.case_entered_by, cc.cancer_type ,(select concat(fname,' ',lname) from users where id = ch.case_entered_by ) as submitted_by ",false);
        $this->db->from("case_meeting_assignments cma");
        $this->db->join("case_history ch", "cma.case_id = ch.id ", "left");
        $this->db->join("cancercategories cc", "ch.cancer_id = cc.cancer_id", "left");
        $this->db->where("ch.case_status",'1');
        $this->db->where("ch.is_deleted",'0');
        $this->db->where_in("cma.sub_meeting_id",$id);

        $this->db->order_by("cma.id", "asc");
        $query = $this->db->get();

        //echo $this->db->last_query();die;

       $case_data = $query->result_object();


       //print_r($case_data);
            foreach($case_data as $data)
          {


                $next_id[]=$data->id;

         }

                $next_id_tmp=array();
				if(isset($next_id) && !empty($next_id)){
                $next_id=array_unique($next_id);



                foreach ($next_id as $ids)
                {

                    $next_id_tmp[]=$ids;
                }

            }

          $this->session->set_userdata('next_id', $next_id_tmp);

   }


    public function  faq_details($filter){
        $salt =$this->config->item('salt');


        $this->db->select("*");
        $this->db->from("page p");
        $this->db->where("p.url_slug",'faq-login');
        $query = $this->db->get();
       $data = $query->result_object();
       return $data;

       //print_r($case_data);


   }

    public function  inperson_tumorboard_hospitals($filter){
        $id = isset($filter['id']) ? $filter['id'] : 0;

        $this->db->select("hn.hospital_network ,tb.tumor_board_name , cmd.meeting_date, cmd.meeting_time",false);
        $this->db->from("case_meeting_details cmd");
        $this->db->join("case_meeting cm", "cm.id=cmd.parent_id ", "left");
        $this->db->join("hospital_network hn", "cm.hospital_id = hn.id", "left");
        $this->db->join("tumor_board tb", "cm.tumor_board_id = tb.tumor_id", "left");
        $this->db->where_in("cmd.id",$id);
        $query = $this->db->get();
        return  $query->result();

    }

}
