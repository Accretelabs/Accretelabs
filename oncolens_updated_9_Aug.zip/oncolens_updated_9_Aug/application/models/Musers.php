<?php
class Musers extends CI_Model {

     // to verify the password entered by the user
    public function verifyAdmin($u, $pw, $lt) {
            $this->db->select('id,email,inactivity,inactivity_on,password');
            $this->db->where('upper(email)', strtoupper(db_clean($u)));
            $this->db->where('is_active', '1');
            $this->db->limit(1);
            $Q = $this->db->get('users');
            if ($Q->num_rows() > 0) {
                               
                $row = $Q->row();
                $inactivity = $row->inactivity_on;
                $current = date('Y-m-d H:i:s');
                
//                if ((!isset($_SESSION['count1']) || $_SESSION['count1']=="")  && $row->inactivity_on==0 )
//                    { $_SESSION['count1'] = 1; }
                
                $inactivity = strtotime($inactivity);
                $current = strtotime($current);
                $hour = round(($current - $inactivity) / (60 * 60), 2);
                
                if ($row->inactivity >= 3 && $row->inactivity_on != "0000-00-00 00:00:00" && $hour < 2) {
                    $this->session->set_flashdata('error', 'Your account is disabled, it will be activated after 2 hours. ');
                    //unset($_SESSION['count1']);
                } else {
                    if ($hour >= 2 && $row->inactivity_on != "0000-00-00 00:00:00") {
                        $data = array('inactivity' => '0', 'inactivity_on' => "0000-00-00 00:00:00");
                        $this->db->where('upper(email)', strtoupper($u));
                        $this->db->where('is_active', '1');
                        $this->db->update('users', $data);
                    }
                      
                    
                    if ((strtoupper($row->email) == db_clean(strtoupper($u))) and ($this->bcrypt->check_password($pw, $row->password)) ) {
                        
                        $this->db->select('id,fname,lname,email,speciality_id,hospital_id,last_password_change_date');
                        $this->db->where('upper(email)', strtoupper(db_clean($u)));
                        $this->db->where('is_active', '1');
                        $this->db->limit(1);
                        $Q = $this->db->get('users');
                        if ($Q->num_rows() > 0 && ($this->bcrypt->check_password($pw, $row->password))) {
                            
                            //check hospital active condition
                        $this->db->select('u.*,hd.is_active');
                        $this->db->from('users u');
                        $this->db->join('hospital_doctor hd', 'hd.doctor_id=u.id');
                        $this->db->where('u.is_active', '1');
                        $this->db->where('hd.is_active', '1');
                        $this->db->where('upper(u.email)', strtoupper($u));
                        $q = $this->db->get();
                        
                        if ($q->num_rows() > 0) {
                              
                       
                            // check for forse password change (3 months old password check)
                            $result = $this->mcustom->force_pass_change($u, $pw);

                            if ($result == "") {
                              
                                $row = $Q->row();

                                if ($row->last_password_change_date == '0000-00-00 00:00:00') {
                                    $current_date_time = date("Y-m-d h:i:s");
                                    $data = array('last_password_change_date' => $current_date_time);
                                }
                                $data['inactivity'] = 0;
                                $data['inactivity_on'] = "0000-00-00 00:00:00";
                                $this->db->where('upper(email)', strtoupper($u));
                                $this->db->where('is_active', '1');
                                $this->db->update('users', $data);

                                if (in_array($row->speciality_id, $this->config->item('speciality'))) {
                                    if ($row->speciality_id == 2) {
                                        $tab = 'hna';
                                    } else {
                                        $tab = 'other';
                                    }
                                } else {
                                    $tab = 'default';
                                }

                                
                        
                                
                                $session_data = array(
                                    'u_userid' => $row->id,
                                    'u_username' => $row->email,
                                    'u_name' => $row->fname,
                                    'u_fullname' => $row->fname . ' ' . $row->lname,
                                    'validated' => true,
                                    'tab' => $tab,
                                    'speciality_id' => $row->speciality_id,
                                    'hospital_id' => $this->get_user_hospitals($row->id), //$row->hospital_id
                                    'isLoggedIn' => true,
                                    'timeOut' => 180,
                                    'loggedAt' => time()
                                );


                                $this->session->set_userdata($session_data);
                            } else {
                                $this->session->set_userdata(array('email' => $u));
                                $this->session->set_flashdata('error', 'Your password is 3 months old, Please set your new password.');
                                redirect(site_url('/users/force_changepassword'));
                            }
                        }
                        else {
                             $this->session->set_flashdata('error', 'Unable to login! Hospital is inactive');
                             return; 
                        }
                    }
                } else {
                        $this->db->select('id,email,inactivity,inactivity_on,password');
                        $this->db->where('upper(email)', db_clean(strtoupper($u)));
                        $this->db->where('is_active', '1');
                        $this->db->limit(1);
                        $Q = $this->db->get('users');
                        $row = $Q->row();
                        $this->db->where('email', $u);
                        $this->db->where('is_active', '1');
                        $this->db->set('inactivity', 'inactivity+1', FALSE);
                        if ($row->inactivity >= 2) {
                            $this->db->set('inactivity_on', date('Y-m-d H:i:s'));
                        }
                        $this->db->update('users');
                        
                        $options = array('upper(email)' => db_clean(strtoupper($u)),'is_active' => '1');
                        $Q = $this->db->get_where('users',$options,1);
                        $data = $Q->row();
                        
                        if($data->inactivity >= 3){       
                            $this->session->set_flashdata('error', 'Your account is disabled, it will be activated after 2 hours. ');
                             //unset($_SESSION['count1']);
                        }else{
                            $this->session->set_flashdata('error', 'You have made '.$data->inactivity.' unsuccessful attempts. The maximum retry attempts allowed for login are 3');
                        }
                    }
                }
            }
            else {
                $this->session->set_flashdata('error', 'Invalid email id and password');
            }
       
    }

    public function forgotpassword() {

        $data_user = array('email' => db_clean($this->input->post('email')), 'is_active'=> '1');
        $Q = $this->db->get_where('users', $data_user);
        $column = "email";
        $table = "users";
      
        if ($Q->num_rows() > 0) {
            $row = $Q->row();
            $token = md5(time());
            $logtype = $this->input->post('logtype');
            $data = array('password_token' => $token,'password_token_expire' => date('Y-m-d H:i:s'));
            $this->db->where($column, db_clean($this->input->post('email')));
            $this->db->update($table, $data);
            $logtype = $this->input->post('logtype');
            $link = '<a href="'.base_url()."users/resetpassword/" . $logtype . "/" . $token.'">'.base_url()."users/resetpassword/" . $logtype . "/" . $token.'</a>';
            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('forgotpassword');
            if($template){
                $mail_data = array(
                    'NAME' => trim($row->fname),
                    'LINK' => $link
                );
                $subject =  $template['subject'];
                $mailmessage =  $template['body'];
                foreach ($mail_data as $key=>$val){
                    $mailmessage = str_replace("{{".$key."}}", $val, $mailmessage);
                }
//            $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png' style='width:12%' ></p><br/>";
//            $mailmessage .= "<p>Thanks. Your reset password link below.</p>";
//            $mailmessage .= "<p><b>Password Reset link</b> " . $link . "</p>";
//            $mailmessage .= "<p>This link will expire after 2 hours</p>";
//            $mailmessage .= "<p><br /></p>";
//            $mailmessage .= "<p>Best Regards</p>";
//            $mailmessage .= "<p><b>Oncolens</b></p>";

//			$config['protocol'] = 'sendmail';
//			$config['mailpath'] = '/usr/sbin/sendmail';
//			$config['charset'] = 'iso-8859-1';
//			$config['wordwrap'] = TRUE;
            //echo $mailmessage;
            //exit;
            $this->email->set_mailtype("html");
            $this->email->from('support@oncolens.com', 'OncolensSupport');
            $this->email->to($this->input->post('email'));
            $this->email->subject($subject);
            $this->email->message($mailmessage);
            $result = $this->email->send();
            }
            $this->session->set_flashdata('success', 'A link to reset your password has been sent. Please check your email.');
        } else {
            $this->session->set_flashdata('error', 'Email doesn\'t match, Please try again later!');
        }
    }

    public function check_reset_url($data){
        if(!$this->session->flashdata('success')){
             // check passowrd token exist or not
            $token = $data['token'];
            $data_user = array('password_token' => db_clean($token));
            $Q = $this->db->get_where('users', $data_user);
            if ($Q->num_rows()== 0) {
                $this->session->set_flashdata('action','true');
                $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
                return true; 
            }else{
                // 2 hours link expire check
                $row = $Q->row();
                $date1 = $row->password_token_expire;
                $date2 = date('Y-m-d H:i:s'); 

                $timestamp1 = strtotime($date1);
                $timestamp2 = strtotime($date2);
                $hour = round(($timestamp2 - $timestamp1) / (60 * 60), 1);
                if($hour > 2){
                    $this->session->set_flashdata('action','true');
                    $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
                    return true; 
                }
            }
        }   
        
    }
    
    public function resetpassword() {
        $this->load->library('bcrypt');
        
        $logtype = $this->input->post('logtype');
        $data_user = array('password_token' => db_clean($this->input->post('token')));
            $column = "email";
            $table = "users";
            $pass = "password";
            
        $Q = $this->db->get_where('users', $data_user);
        
        if ($Q->num_rows() > 0) {
            $row = $Q->row();
            $pass_hash = $this->bcrypt->hash_password($this->input->post('pass'));
            $data = array($pass => $pass_hash, 'password_token' => '');
            $this->db->where('password_token', db_clean($this->input->post('token')));
            $this->db->update($table, $data);
            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('password_changed_successfully');
            if($template){
                $mail_data = array(
                    'NAME' => trim($row->fname),
                );
                $subject =  $template['subject'];
                $mailmessage =  $template['body'];
                foreach ($mail_data as $key=>$val){
                    $mailmessage = str_replace("{{".$key."}}", $val, $mailmessage);
                }
//            $mailmessage = "<p><img src='" . base_url() . "images/oncolence-logo.png' style='width:12%'></p><br/>";
//            $mailmessage .= "<p>Thank you admin. Your password have been changed.</p>";
//            $mailmessage .= "<p><br /></p>";
//            $mailmessage .= "<p>Best Regards</p>";
//            $mailmessage .= "<p><b>Oncolens</b></p>";

//			$config['protocol'] = 'sendmail';
//			$config['mailpath'] = '/usr/sbin/sendmail';
//			$config['charset'] = 'iso-8859-1';
//			$config['wordwrap'] = TRUE;
                $this->email->set_mailtype("html");
                $this->email->from('support@oncolens.com', 'OncolensSupport');
                $this->email->to($row->email);
                $this->email->subject($subject);
                $this->email->message($mailmessage);
                $this->email->send();
            }
            $this->session->set_flashdata('success', 'Password changed successfully. <a href="'.base_url().'users/">Please Login</a>');  
        } else {
            $this->session->set_flashdata('error', 'Your Reset link has been expired, Click here to <a href="'.base_url().'users/forgotpassword">Forgot Password </a>');
        }
    }
    
    
      // to change the user password
    public function changepassword() {
        $this->load->library('bcrypt');
        $data_user = array('id' =>$this->session->userdata('u_userid'),'is_active'=>'1');
        $Q = $this->db->get_where('users',$data_user);
        $row = $Q->row();
        if($Q->num_rows()>0 && ($this->bcrypt->check_password($this->input->post('oldpassword'), $row->password))){
            if($this->input->post('oldpassword') != $this->input->post('newpassword')){
                $pass_hash = $this->bcrypt->hash_password($this->input->post('newpassword'));
                $data = array('password' => $pass_hash,'last_password_change_date'=> date("Y-m-d h:i:s"));
                $this->db->where('email',$this->session->userdata('u_username'));
                $this->db->update('users',$data);
                $this->session->set_flashdata('success', 'Password updated successfully!');
            }else{
                 $this->session->set_flashdata('error', 'Old password and new password must be different!');
            }
        } else {
            $this->session->set_flashdata('error', 'Old password doesn\'t match!');
        }
        
    }
    // According to Hippa after 90 days user is forced to change password
    public function forcechangepassword() {
        if($this->session->userdata('email')!=""){
            $pass_hash = $this->bcrypt->hash_password($this->input->post('password'));
            
            $data_user = array('email' => $this->session->userdata('email'),'is_active'=>'1');
            $Q = $this->db->get_where('users',$data_user);
            $row = $Q->row();
            if($Q->num_rows()>0 ){
                if(($this->bcrypt->check_password($this->input->post('password'), $row->password))){
                    $this->session->set_flashdata('error', 'New password should not be same as old password!');
                    return false;
                } else {
                    $data = array('password' => $pass_hash,'last_password_change_date'=> date("Y-m-d h:i:s"));
                    $this->db->where('email',$this->session->userdata('email'));
                    $this->db->update('users',$data);
                    $this->session->set_flashdata('success', 'Password updated successfully!, Please login');
                    return true;
                }
            } else {
                $this->session->set_flashdata('error', 'Please try again later!');
                return false;
            }
        } else {
            $this->session->set_flashdata('error', 'Please try again later!');
            return false;
        }
        
    }
    // to get profile data of user
    public function profile($filter){
        $doctor_id = isset($filter['doctor_id']) ? $filter['doctor_id'] : $this->session->userdata('u_userid');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
         
        $this->db->select("c.id , c.hospital_network , b.id  as htumorid,d.tumor_id ,d.tumor_board_name");
        $this->db->from("hospital_doctor a");
        $this->db->join("hospital_doctor_tumor_board b", "a.hospital_doctor_id = b.hospital_doctor_id", "inner");
        $this->db->join("hospital_network c", "c.id = a.hospital_id", "inner");
        $this->db->join("tumor_board d", "d.tumor_id = b.tumor_id", "inner");
        $this->db->where("a.doctor_id = '$doctor_id'");
        $this->db->where("a.is_active = '1'");
        $this->db->where("b.is_active = '1'");
        $this->db->where("c.is_active = '1'");
        $this->db->where("d.is_active = '1'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("c.hospital_network,d.tumor_board_name", "asc");
        $query = $this->db->get();
        return $count ? $query->num_rows() : $query->result();
        
     }
     
    public function hospitalTumorboard_edit($hospital_doctor_tumor_board_id,$hospital_id,$doctor_id,$tumor_id){
          
        $this->db->select("c.hospital_network");
        $this->db->from("hospital_doctor_tumor_board a");
        $this->db->join("hospital_doctor b", "a.hospital_doctor_id = b.hospital_doctor_id", "left");
        $this->db->join("hospital_network c", "c.id = b.hospital_id", "left");
        $this->db->where("a.id = $hospital_doctor_tumor_board_id");
        $query = $this->db->get();
        $data = $query->row();
        
        $data1 = array();
        $data1['hospital_network'] = $data->hospital_network;
        $data1['tumor_id'] = $tumor_id;
        $data1['hospital_doctor_tumor_board_id'] = $hospital_doctor_tumor_board_id;
        $data1['hospital_id'] = $hospital_id;
        $data1['doctor_id'] = $doctor_id;
        
        return $data1;
      }
      // list of tumor board assosciated with hospitial
    public function gettumor($hospital_id){
        $this->db->select("b.tumor_id,b.tumor_board_name");
        $this->db->from("hospital_tumor_board a");
        $this->db->join("tumor_board b", "a.tumor_id = b.tumor_id", "left");
        $this->db->where("a.hospital_id = $hospital_id");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
     }
     
       // to update  tumor board assosicated with user   
    public function changeTumorboard($id) {
        $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
        $hospital_id = db_clean($this->input->post('hospital_id'));
        $tumor_id = $this->input->post('arr');
        $doctor_id = $this->input->post('doctor_id');

        $data = "";
        
        $this->db->select("hospital_doctor_id");
        $this->db->from("hospital_doctor");
        $this->db->where("hospital_id = $hospital_id")->where("doctor_id = $doctor_id");
        $query = $this->db->get();
        if ($query->num_rows()>0){
            $data = $query->row();
        }
        
        
        $this->db->select("hospital_doctor_id");
        $this->db->from("hospital_doctor_tumor_board");
        $this->db->where("tumor_id = $tumor_id")->where("hospital_doctor_id = $data->hospital_doctor_id");
        $query = $this->db->get();
        if ($query->num_rows()==0){
            $data = $query->row();
            
            $data_hospital_doctor_tumor_board = array('tumor_id' => $tumor_id);
            $this->db->where('id',$hospital_doctor_tumor_board_id);
            $this->db->update('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
             $this->session->set_flashdata('success', 'Tumor board has been updated successfully.');
            $data=true;
        }else{
             $this->session->set_flashdata('error', 'Tumor Board already added.');
             $data=false;
        }
        return $data;

    }

     // to get list of tumor board
    public function tumorboard_list($id,$tumorid){	
//        $this->db->select("a.tumor_board_name,a.tumor_id");
//        $this->db->from("tumor_board as a");
//        $this->db->join("(SELECT  * FROM hospital_tumor_board AS b WHERE hospital_id = '".$id."') AS c ", "a.tumor_id = c.tumor_id", "inner join");
        
        $query = $this->db->query(
                "SELECT 
                    a.tumor_board_name,
                    a.tumor_id 
                  FROM
                    tumor_board AS a 
                    INNER JOIN 
                      (SELECT 
                        * 
                      FROM
                        hospital_tumor_board AS b 
                      WHERE hospital_id = '".$id."') AS c 
                      ON c.tumor_id = a.tumor_id 
                 WHERE a.tumor_id NOT IN (
                        SELECT 
                      hdtb.tumor_id 
                      FROM hospital_doctor AS hd 
                      INNER JOIN hospital_doctor_tumor_board AS hdtb 
                        ON hd.hospital_doctor_id = hdtb.hospital_doctor_id 
                        WHERE hd.hospital_id = '".$id."' 
                        AND hd.doctor_id = '".$this->session->userdata('u_userid')."' 
                        AND hdtb.is_active='1' and hd.is_active='1'
                      ) and a.is_active='1' ");   
        
        if ($query->num_rows()>0){
            $data ="";
            foreach ($query->result() as $row){
                $selected= ($tumorid == $row->tumor_id)?'selected':'';
                $data  = $data.'<option value="'.$row->tumor_id.'" id="'.$row->tumor_id.'"  '.$selected.' >'.$row->tumor_board_name.'</option>';				
            }

            $query->free_result();
        } else {
            $data=$data."<option value=''>No New Tumor Board to be added.</option>";
        }
        return $data;
        exit;
    }
      // to add tumor board    
    public function tumor_board_add(){

        $tumor_id = $this->input->post('arr');
        $is_tumor_board = isset($tumor_id)?'1':'0';

        $data = array();
        $options = array(
            'hospital_id' => $this->input->post('hospital_id'),           
            'doctor_id' => $this->session->userdata('u_userid'),    
            );
        $Q = $this->db->get_where('hospital_doctor',$options,1);
        if ($Q->num_rows() > 0){
            $data = $Q->row();
            $hospital_doctor_id = $data->hospital_doctor_id;
        }else{
            // hospital_doctor table insert query
            $data_host_doctor = array(
                'hospital_id' => $this->input->post('hospital_id'),                  
                'doctor_id' => $this->session->userdata('u_userid'),                 
                'is_tumor_board' => $is_tumor_board,              
                );

            $this->db->insert('hospital_doctor',$data_host_doctor);
            $hospital_doctor_id = $this->db->insert_id();
            // End hospital_doctor table insert query
        }

        //hospital_doctor_tumor_board
        foreach($tumor_id as $tumor){                   
             $data_hospital_doctor_tumor_board = array(
                 'tumor_id' => $tumor,                          
                 'hospital_doctor_id' => $hospital_doctor_id,                                   
                 );

            $Q = $this->db->get_where('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board,1);
            if ($Q->num_rows() == 0){ 
                $this->db->insert('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
            }else{
                $data = $Q->row();
                $update = array('is_active' => '1');
                $this->db->where('id', $data->id);
                $this->db->update('hospital_doctor_tumor_board',$update);
            }
        }

        $this->session->set_flashdata('success', 'Tumor board has been added successfully');
      
      
    }
    // delete the tumor board
    public function tumor_board_delete($id){
          $data = array();
          $options = array('id' => $id);
          $Q = $this->db->get_where('hospital_doctor_tumor_board',$options,1);
          if ($Q->num_rows()>0){
                $data = $Q->row();
                $data_hospital_doctor_tumor_board = array('is_active' => '0');
                $this->db->where('id', $id);
                $this->db->update('hospital_doctor_tumor_board',$data_hospital_doctor_tumor_board);
                $Q->free_result();
          }
          return true;
         
    }
    // get list of all hospital id  associted with users
    public function get_user_hospitals($id){
        $this->db->select('group_concat(hospital_id) hospitals', false);
        $this->db->from('hospital_doctor');
        $this->db->where("doctor_id = '$id'");
        $this->db->where("is_active = '1'");
        $q = $this->db->get()->row_array();
        return $q['hospitals'];
    }
    
    //to generate the hospitial admin report
    public function getReport() {
        $salt =$this->config->item('salt');
        $dFrom = $this->input->post('dFrom');
        $dTo = $this->input->post('dTo');
        $selectedData = $this->input->post('my_multi_select1');

        $query = "select ";
        $select = "";
        $condition = "";
        if (count($selectedData) > 0) {
            if (in_array('case_id', $selectedData)) {
                $select .="ch.id AS 'CaseId' ,";
            }
            
              if (in_array('case_description', $selectedData)) {
                $select .=" AES_DECRYPT(ch.case_description, '$salt') as  'Case History' ,";
            }
            if (in_array('name', $selectedData)) {
                $select .="AES_DECRYPT(ch.name,'$salt') as 'Patient Name' ,";
            }
            if (in_array('dob', $selectedData)) {
                $select .="DATE_FORMAT(AES_DECRYPT(ch.dob, '$salt'), '%m/%d/%Y') as 'Patient DOB' ,";
            }
            
              if (in_array('gender', $selectedData)) {
                $select .=" if(AES_DECRYPT(ch.sex,'$salt')='M','Male','Female') as 'Patient Gender' ,";
            }
			if (in_array('rcounselling_discussed', $selectedData)) {
                  $select .="if(ch.rcounselling_discussed='1', 'Yes', 'No')  as 'Reproductive Counselling discussed',";    
            }
			if (in_array('pcounselling_discussed', $selectedData)) {
                  $select .="if(ch.pcounselling_discussed='1', 'Yes', 'No')  as 'Psychosocial Counselling discussed',";    
            }
			if (in_array('ncounselling_discussed', $selectedData)) {
                  $select .="if(ch.ncounselling_discussed='1', 'Yes', 'No')  as 'Navigation Counselling discussed',";    
            }
            if (in_array('race', $selectedData)) {
                $select .="(select race_type from race where race_id=AES_DECRYPT(ch.race,'$salt')) as 'Race' ,";
            }
            if (in_array('menopausal', $selectedData)) {
                $select .=" ch.menopausal_status as 'Patient Menopausal Status' ,";
            }
            
             if (in_array('setting', $selectedData)) {
                            $select .=" (SELECT  (CASE 
                            WHEN (ch.cancer_id!='11' and ch.cancer_mode='0') THEN 'Non-Metastatic'
                            WHEN ch.cancer_mode='1' THEN 'Recurrent'
                            WHEN ch.cancer_mode='2' THEN 'DeNovo Metastatic' 
                            ELSE '' END)  
                            FROM case_history ch1 where ch1.id=ch.id) AS 'Cancer Setting'
                            ,";
                     }
            
            
              if (in_array('submitted_by', $selectedData)) {
                $select .="CONCAT_WS(' ', fname, lname) as 'Submitted by' ,";
            }
                     
            if (in_array('cancer_type', $selectedData)) {
                $select .="cancer_type as 'Cancer Type' ,";
            }
              if (in_array('case_status', $selectedData)) {
                  $select .="if(ch.case_status='1', 'No', 'Yes')  as 'Closed Status  ',";    
            }
            
            
             if (in_array('tumor_name', $selectedData)) {
                $select .="(select group_concat(Distinct t.tumor_board_name) from  case_assignment_tumor_board ctd inner join  tumor_board  t on ctd.tumor_board_id=t.tumor_id where ctd.case_id=ch.id) AS 'Tumor Board Name' ,";
            }
         
               if (in_array('discussed_online', $selectedData)) {
                            $select .="(SELECT (CASE 
                        WHEN (SELECT COUNT(*) AS c FROM case_doctor_comments WHERE case_id = ch.id)> 0 THEN 'Yes'
                        ELSE 'No' END))  AS 'Discussed Online Status'  ,"; 
            }
            
                
              if (in_array('discussed_person', $selectedData)) {
                $select .=" if(ch.mark_as_discussed_live='1','Yes','No') as  'Discussed In-Person Status' ,";
            }
            
                
               if (in_array('online_attendance', $selectedData)) {
        $select .="(select  group_concat(concat(concat(u.fname,' ',u.lname),'(',s.speciality_name,')'))  from case_doctor_comments  cd inner join users u on u.id=cd.doctor_id  inner join speciality s on  cd.speciality_id=s.speciality_id  where case_id = ch.id)  as  'Online Attendance by speciality' ";
            }
                 
            
            
            if (isset($dFrom) && $dFrom != "" && isset($dTo) && $dTo != "") {
                 $dFrom = date('Y-m-d',strtotime($dFrom));
                 $dTo = date('Y-m-d',strtotime($dTo));
                $condition .="and ( DATE(ch.`case_submit_date`) BETWEEN DATE('$dFrom') AND DATE('$dTo') )";
            }
        }
                    $select = rtrim($select, ',');
                    $query =$query . $select ."FROM  (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type` FROM    
                    case_history 
                    ch  INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
                    ON c.cancer_id = ch.cancer_id     
                    WHERE ch.is_deleted = '0'  $condition
                    GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch";  
                    
          
                    
        
        $mydata=array();
        
        $data = $this->mcustom->getselectedata($query);
        if ((in_array('meeting', $selectedData) || in_array('nccn', $selectedData) || in_array('staging', $selectedData) || in_array('prospective', $selectedData) || in_array('clinical', $selectedData) || in_array('palliative', $selectedData) ) ){
        foreach($data as $key=>$value){
            $select1 = "";
                $select1 = "SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,";
                
                   if (in_array('prospective', $selectedData)) {
                    $select1 .="if(prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,";
                }

                
                 if (in_array('staging', $selectedData)) {
                    $select1 .="if(staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,";
                }
                
                if (in_array('nccn', $selectedData)) {
                    $select1 .="if(nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,";
                }
               
             
              
                 if (in_array('genetic_discussed', $selectedData)) {
                    $select1 .="if(genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,";
                }
                
                  if (in_array('clinical', $selectedData)) {
                    $select1 .="if(clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,";
                }
                
                
                if (in_array('palliative', $selectedData)) {
                    $select1 .="if(palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,";
                }
                
                 if (in_array('attendees', $selectedData)) {
                    $select1 .="(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')'),'No Attendees') from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality' ,";
                }
            
                
            $select1 = rtrim($select1, ',');
            $query1 =  $select1 ." FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id WHERE cma.case_id=".$value->CaseId;
            $Q= $this->db->query($query1);
            
            $data[$key]->submeetings = $Q->result_array();
        }
        }
     //prd($data);

         
                
        
        
        if ($data) {
            $lines = $data;
            $langs = array();
            $hidden_fields = !empty($hidden_fields) ? $hidden_fields : array();
            if ($lines && is_array($lines) && count($lines) > 0) {
                foreach ($lines as $row) {
                    foreach ($row as $field => $value) {
                        if (!in_array($field, $langs) && !in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                            array_push($langs, $field);
                        }
                    }
                }
            }
 
            // Starting the PHPExcel library
            $this->load->library('excel');
            // activate worksheet number 1
            $this->excel->setActiveSheetIndex(0);

            $this->excel->getProperties()->setTitle("Report")->setDescription("none");

            // name the worksheet
            $this->excel->getActiveSheet()->setTitle('Report');

            // Field names
            $col = 0;
            foreach ($langs as $field) {
                // set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);

                // change the font size
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setSize(14);

                // make the font become bold
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setBold(true);

                // set aligment to center for that cell
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getAlignment()
                        ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)
                        ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                // ->setWrapText(true);

                $col++;
            }
            $sheet = $this->excel->getActiveSheet();
          

            $row = 2;
            foreach ($lines as $key => $line) {
                $col = 0;
                foreach ($langs as $field) {
                    $value = isset($line->$field) ? $line->$field : '';
                    if (!in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                        if (is_array($value)) {
                            if (count($value) > 0) {
                                $c=0;
                                foreach($value as $k=>$v){
                                    $c=$col;
                                   
                                  foreach($v as $field=>$val){
                                       $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, 1, $field);
                                       $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setSize(14);

                                        // make the font become bold
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setBold(true);

                                        // set aligment to center for that cell
                                       
                                        $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, $row, $val);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getFont()->setSize(12);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()
                                         ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()->setWrapText(true);
                                        $c++;
                                  }
                                $row++;
                                }
                            } else {
                                // set cell A1 content with some text
                               $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, 'NONE');
                            }
                        } else {
                            // set cell A1 content with some text
                            $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, ucfirst(strip_tags($value)));
                             $this->excel->getActiveSheet()->getStyleByColumnAndRow($col,$row)->getAlignment()->setWrapText(true);
                        }
                    }

//                    // change the font size
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getFont()->setSize(12);
                    // set aligment to vertical center for that cell
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getAlignment()
                            ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

                    $col++;
                }

                $row++;
            }
            
            $this->excel->setActiveSheetIndex(0);
              $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }
            // mime type
            $filename = time() . "Report";
            header('Cache-Control: private, max-age=1');
            header("Pragma:token");
            header("Expires: 0"); 
            header('Content-Type: application/vnd.ms-excel;charset=utf-8');
            // tell browser what's the file name
            header('Content-Disposition: attachment;filename=' . $filename.".xls");
            // no cache
            //header('Cache-Control: max-age=0');
            // save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
            // if you want to save it as .XLSX Excel 2007 format
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
            ob_end_clean();
            // force user to download the Excel file without writing it to server's HD
            $objWriter->save('php://output');
        }
        else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }
    
    
      public function CompleteReport() {
        $salt =$this->config->item('salt');
        $dFrom = $this->input->post('dFrom');
        $dTo = $this->input->post('dTo');
        $type= $this->input->post('type'); 
        $date_condition="";    
        
         // hospital report from super admin panel  
        if($type=="hospital")
        {
            
              if($dFrom!="" && $dTo!="")        
            $date_condition=" and DATE_FORMAT(h.added_on,'%m/%d/%Y') between '$dFrom' and '$dTo' ";             
             
             $query ="SELECT h.hospital_network AS Name,h.`hospital_address` AS Address,GROUP_CONCAT(t.`tumor_board_name`) AS 'Tumor Boards',DATE_FORMAT(h.added_on,'%m/%d/%Y') AS 'Date Created',IF(h.is_active='1','Active','Inactive')  AS Status  FROM `hospital_network` h left JOIN `hospital_tumor_board` ht ON h.id=ht.`hospital_id` and h.is_active='1'  left JOIN `tumor_board` t ON t.`tumor_id`=ht.`tumor_id`  and t.is_active='1'  WHERE 1  $date_condition  GROUP  BY h.id";  
             
               $Q= $this->db->query($query);            
            $data= $this->mcustom->getselectedata($query);      
            
        }
        
        // hospital user from super admin panel  
        else if($type=="user")
        {
            
               if($dFrom!="" && $dTo!="")
              $date_condition=" and DATE_FORMAT(u.date,'%m/%d/%Y') between '$dFrom' and '$dTo' ";
                                  
                 $query ="SELECT GROUP_CONCAT(DISTINCT h.hospital_network  ORDER BY h.hospital_network  SEPARATOR ', ') AS Hospital,GROUP_CONCAT( DISTINCT CONCAT(`tumor_board_name`),'(',h.hospital_network,')'  ORDER BY h.hospital_network ) AS 'Tumor Boards',s.`speciality_name` AS 'Specialty',DATE_FORMAT(u.date,'%m/%d/%Y') AS 'Date Created',IF(u.is_active='1','Active','Inactive')  AS Status, u.`fname` AS 'First Name',u.`lname` AS 'Last Name',u.`email` AS 'Email Id' FROM users u left JOIN `hospital_doctor` hd ON (u.id=hd.`doctor_id` and hd.is_active='1') left JOIN `hospital_network` h ON (h.id=hd.`hospital_id` and h.is_active='1') left JOIN  `hospital_tumor_board` ht ON ht.`hospital_id`=h.`id` left JOIN (SELECT hdtd.`hospital_doctor_id`,t1.* FROM `hospital_doctor_tumor_board` hdtd INNER JOIN    `tumor_board` t1  ON hdtd.`tumor_id`=t1.`tumor_id` AND hdtd.`is_active`='1' AND t1.`is_active`='1')t ON (t.`tumor_id`=ht.`tumor_id` and t.is_active='1'  AND hd.`hospital_doctor_id`=t.hospital_doctor_id) left JOIN `speciality` s ON s.`speciality_id`=u.`speciality_id`  WHERE u.is_active='1'   $date_condition    GROUP BY u.id  ";          
              
                   $Q= $this->db->query($query);            
            $data= $this->mcustom->getselectedata($query);      
                 
        }
         // case complete detial report from super admin panel  
        else  if($type=="case")
        {
         
        $query = "select ";
        $select = "";
        $condition = "";                 
        $select .="ch.id AS 'CaseId' ,";                  
              //  $select .=" AES_DECRYPT(ch.case_description, '$salt') as  'CaseHistory' ,";           
           
                $select .="AES_DECRYPT(ch.name,'$salt') as 'Patient Name' ,";    
				
                $select .=" AES_DECRYPT(ch.case_description, '$salt') as  'CaseHistory' ,";
				$select .="ch.case_mr_number as  'Medical Record Number',";
                $select .="DATE_FORMAT(AES_DECRYPT(ch.dob, '$salt'), '%m/%d/%Y') as 'Patient DOB' ,";      
                $select .="(select race_type from race where race_id=AES_DECRYPT(ch.race,'$salt')) as 'Race' ,";               
                $select .="cancer_type as 'Cancer Type' ,";
                $select .="ch.Pathology_temp as 'Core Biopsy Pathology' ,";
                $select .=" if(AES_DECRYPT(ch.sex,'$salt')='M','Male','Female') as 'Patient Gender' ,";         
                $select .=" ch.menopausal_status as 'Menopausal Status' ,";               
                $select .=" (SELECT  (CASE 
                WHEN (ch.cancer_id!='11' and ch.cancer_mode='0') THEN 'Non-Metastatic'
                WHEN ch.cancer_mode='1' THEN 'Recurrent'
                WHEN ch.cancer_mode='2' THEN 'DeNovo Metastatic' 
                ELSE '' END)  
                FROM case_history ch1 where ch1.id=ch.id) AS 'Cancer Setting',";                   
                $select .="CONCAT_WS(' ', fname, lname) as 'Submitted By' ,";  
                 $select .="(SELECT hn.`hospital_network` FROM `hospital_network`  hn WHERE hn.`id`=ch.assigned_hospital) 'Hospital Network' ,";  
              
                $select .="(SELECT GROUP_CONCAT(CONCAT_WS(' ', fname, lname) SEPARATOR ', ' ) FROM `case_doc_email_status` cds  INNER JOIN users u ON cds.`doctor_id`=u.id  WHERE case_id=ch.id) as 'Submitted To' ,";            
              
                 $select .=" DATE_FORMAT(ch.`case_submit_date`,'%m/%d/%Y') as 'Date Submitted'  ,";                 
                 $select .="(select group_concat(Distinct t.tumor_board_name SEPARATOR ', ' ) from  case_assignment_tumor_board ctd inner join  tumor_board  t on ctd.tumor_board_id=t.tumor_id where ctd.case_id=ch.id) AS 'Tumor Board Submitted To' ,";              
               
                $select .="(SELECT GROUP_CONCAT(CONCAT_WS(' ', fname, lname) SEPARATOR ', ' ) FROM `case_assignment_speciality` cds  INNER JOIN   `speciality_hospital_doctor` shd ON shd.`speciality_hos_doc_id`=cds.`speciality_hos_doc_id` INNER JOIN `hospital_doctor` hd ON hd.`hospital_doctor_id`=shd.`hospital_doctor_id` INNER JOIN users u ON hd.`doctor_id`=u.id  WHERE case_id=ch.id) as 'Submitted to Specialty' ,";                               
                 $select .="(SELECT GROUP_CONCAT(CONCAT_WS(' ', fname, lname) SEPARATOR ', ' ) FROM `case_assignment_specific_provider` cds INNER JOIN `hospital_doctor` hd ON hd.`doctor_id`=cds.`hospital_doctor_id`  INNER JOIN users u ON hd.`hospital_doctor_id`=u.id  WHERE case_id=ch.id) as 'Submitted to Providers' ,"; 
                            
            $select .="(SELECT GROUP_CONCAT(email_id SEPARATOR ', ' ) FROM `case_assignment_email` cae WHERE cae.`case_id`=ch.id) as 'Sent to email id' ,";            
            $select .=" if(ch.mark_as_discussed_live='1','Yes','No') as  'Discussed In-Person' ,";                 
            $select .="(SELECT (CASE 
                WHEN (SELECT COUNT(*) AS c FROM case_doctor_comments WHERE case_id = ch.id)> 0 THEN 'Yes'
                ELSE 'No' END))  AS 'Discussed Online'  ,";           
          
              $select .="(SELECT COUNT(case_id) FROM `case_meeting_assignments` WHERE `case_id`=ch.id) AS 'In-Person Meeting Assignment' ,";  
              $select .="(SELECT (CASE 
            WHEN (SELECT count(*) FROM `case_assignment_priority` cap  WHERE cap.`priority_id`=2 AND cap.`case_id`=ch.id)> 0 THEN 'Yes'
            ELSE 'No' END))  AS 'Urgent Status'  ,";        
            $select .="if(ch.case_status='1', 'No', 'Yes')  as 'Closed Status  ',";        
          $select .="if(ch.rcounselling_discussed ='1','Yes','No') as 'Reproductive Counselling discussed',";
		  $select .="if(ch.pcounselling_discussed ='1','Yes','No') as 'Psychosocial Counselling discussed',";
		  $select .="if(ch.ncounselling_discussed ='1','Yes','No') as 'Navigation Counselling discussed',";		  
		  // ,ch.pcounselling_discussed,ch.ncounselling_discussed,";                     
                   
              
        $select .="(select  group_concat(concat(concat(u.fname,' ',u.lname),'(',s.speciality_name,')') SEPARATOR ', ' )  from case_doctor_comments  cd inner join users u on u.id=cd.doctor_id  inner join speciality s on  cd.speciality_id=s.speciality_id  where case_id = ch.id)  as  'Online Attendance by speciality' ";
         
        
                   
                 if($dFrom!="" && $dTo!="") 
                 {
                 $dFrom = date('Y-m-d',strtotime($dFrom));
                 $dTo = date('Y-m-d',strtotime($dTo));
                $condition .="and ( DATE(ch.`case_submit_date`) BETWEEN DATE('$dFrom') AND DATE('$dTo') )";
                 } 
                
        $select = rtrim($select, ',');
        $query =$query . $select ."FROM (SELECT  ch.*,u.`fname`,u.`lname`,c.`cancer_type`,cs.cancer_subcategories as Pathology_temp FROM    
                    case_history ch  inner join cancersubcategories cs on ch.pathology=cs.id
                      INNER JOIN users u  ON u.id = ch.case_entered_by  INNER JOIN cancercategories c 
                    ON c.cancer_id = ch.cancer_id   
                    WHERE ch.is_deleted = '0'  $condition
                    GROUP BY ch.id 
                    ORDER BY ch.id DESC ) ch ";
        
             
        
        $mydata=array();
        
        $data = $this->mcustom->getselectedata($query);
       
      
       // fetching data from various data from various speciliaty form case_doctor_comment table
        
        
        
        foreach($data as $key=>$value){
          
            
         $hospital_doctor_query = $this->db->query("SELECT 
  s.`speciality_name`,
  X.* 
FROM
  `speciality` s 
  LEFT JOIN 
    (SELECT 
      s.`speciality_id`,
      IF(specific_answers = 0,
      
        GROUP_CONCAT(
          CONCAT(
            CONCAT(
              'Answered By: ',
              u.`fname`,
              ' ',
              u.`lname`
            ),
            '\nAnswer: ',
            other_answer,
            '\nAdditional Comments: ',
            cd.`comments`
          ) SEPARATOR '\n\n'
        )
      ,
      
        GROUP_CONCAT(
          CONCAT(
            CONCAT(
              'Answered By: ',
              u.`fname`,
              ' ',
              u.`lname`
            ),
            '\nAnswer: ',            
              (SELECT 
                specific_answers 
              FROM
                specificanswer s1 
              WHERE s1.id = cd.`specific_answers`),
              '\nAdditional Comments: ',
              cd.`comments`
            
          )SEPARATOR '\n\n'
        )) AS data FROM `case_doctor_comments` cd 
        INNER JOIN users u 
          ON u.id = cd.`doctor_id` 
        INNER JOIN `speciality` s 
          ON cd.`speciality_id` = s.`speciality_id` WHERE cd.`case_id` = $value->CaseId GROUP BY s.`speciality_name` 
        ORDER BY s.`speciality_name`
      ) X
      ON X.speciality_id = s.`speciality_id`");
              foreach ($hospital_doctor_query->result_array() as $hospital_doctor) {          
           
             if($hospital_doctor['speciality_name']=="Hospital Administration")
             {
                
           // fetching data from various data from Hospital Administration speciliaty form case_meeting_assignments table  
                 
               $comment_query=$this->db->query("SELECT admin_comment FROM `case_history` cma WHERE cma.`id`=$value->CaseId");
                
                 $comment_data=$comment_query->result_array();                 
                if(isset($comment_data['0']['admin_comment']))
                 { 
                    
                $tmp_speciality_name="Hospital Administration Comments";
                    
              $data[$key]->$tmp_speciality_name=$comment_data['0']['admin_comment'];             
                 
                 }
                else {  $data[$key]->$hospital_doctor['speciality_name']="";  } 
             }
                   
         else {
             
              $tmp_speciality_name="Answer Submitted By (".$hospital_doctor['speciality_name'].")";
             
               $data[$key]->$tmp_speciality_name= $hospital_doctor['data'];
            }
     
         
           
         }  
        
         }
     
         foreach($data as $key=>$value){
            $select1 = "";
                    $select1 = "SELECT DATE_FORMAT(cmd.meeting_date, '%m/%d/%Y') as 'Meeting Date' ,";            
                    $select1 .="if(ch.prospective_discussion, 'Yes', 'No') as 'Prospective Case Discussion' ,";       
                    $select1 .="if(ch.staging_discussed, 'Yes', 'No') as 'Cancer Staging Discussed' ,";              
                    $select1 .="if(ch.nccs_guidlines_discussed, 'Yes', 'No')  as 'NCCN Guidelines Discussed ' ,";          
                    
                    $select1 .="if(ch.genetics_discussed, 'Yes', 'No') as 'Genetics Discussed' ,";               
                    $select1 .="if(ch.clinical_trial_discussed, 'Yes', 'No') as 'Clinical Trial Discussed' ,";              
                    $select1 .="if(ch.palliative_care_discussed, 'Yes', 'No')  as 'Palliative Care Discussed' ,";               
                    $select1 .="(select IFNULL(GROUP_CONCAT(CONCAT_WS(' ', us.fname, us.lname),' (',s.speciality_name,')' SEPARATOR ', '),'No Attendees'  ) from  `case_meeting_attendees` c inner join users us on us.id=c.user_id inner join speciality s on s.speciality_id=us.speciality_id where sub_meeting_id= cma.sub_meeting_id  ) as 'In-Person Attendance by speciality' ,";                       
                
            $select1 = rtrim($select1, ',');
            $query1 =  $select1 ." FROM case_meeting_assignments cma INNER JOIN case_meeting_details cmd ON cmd.id=cma.sub_meeting_id inner join case_history ch on ch.id=cma.case_id WHERE cma.case_id=".$value->CaseId;
            $Q= $this->db->query($query1);
            
           
            
             $pos=0;
             $pos1=0;
             $length=500000;
            
            // $value->CaseHistory= str_replace("</p><p>"," ",$value->CaseHistory);
             
             
             
            if(strpos($value->CaseHistory,"Areas of metastasis")!==false)
            {
             
               $pos=strpos($value->CaseHistory,"Areas of metastasis");    
                           
            }
            
             if(strpos($value->CaseHistory,"This is a")!==false && $pos==0)
            {       
               
                $pos=strpos($value->CaseHistory,"This is a");                  
            }
            
            
//             if(strpos($value->CaseHistory,"Additional comments")!==false)
//            {
//               
//               $pos1=strpos($value->CaseHistory,"Additional comments");                
//            }
//            
            
               if(strpos($value->CaseHistory,"What is the recommended")!==false)
              {           
               $pos1=strpos($value->CaseHistory,"What is the recommended");
               
               }
            
                           
                              
            if($pos1!=0)
            $length=$pos1-$pos;
           
            
            if($pos!=0)
            $case_data=substr($value->CaseHistory,$pos,$length);
            else {
              $case_data="";
               }

              //$case_data=  preg_replace($case_data,"<p>","<br />");
             // $case_data=  preg_replace($case_data,"</p>","<br />");
              
              
              
               //$case_data = str_replace(�<br />�,�\n�, $post_content);
               $case_data=  str_replace("<p>", "\n",$case_data);
               $case_data=  str_replace("</p>", "\n",$case_data);
                ///$case_data=  str_replace("</p><p>", "\r\n",$case_data);

            $tmp_name="Case data";               
            $data[$key]->$tmp_name = $case_data;            
            $data[$key]->submeetings = $Q->result_array();            
            unset($data[$key]->CaseHistory);          
                   }     
          
         
        }
         
        $data=array_filter($data);        
   
        if ($data) {
             $this->session->unset_userdata('error');
            $lines = $data;
            $langs = array();
            $hidden_fields = !empty($hidden_fields) ? $hidden_fields : array();
            if ($lines && is_array($lines) && count($lines) > 0) {
                foreach ($lines as $row) {
                    foreach ($row as $field => $value) {
                        if (!in_array($field, $langs) && !in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                            array_push($langs, $field);
                        }
                    }
                }
            }
 
            // Starting the PHPExcel library
            $this->load->library('excel');
            // activate worksheet number 1
            $this->excel->setActiveSheetIndex(0);

            $this->excel->getProperties()->setTitle("Report")->setDescription("none");

            // name the worksheet
            $this->excel->getActiveSheet()->setTitle('Report');

            // Field names
            $col = 0;
            foreach ($langs as $field) {
                // set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);

                // change the font size
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setSize(14);

                // make the font become bold
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getFont()->setBold(true);

                // set aligment to center for that cell
                $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, 1)->getAlignment()
                        ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)
                        ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                // ->setWrapText(true);

                $col++;
            }
            $sheet = $this->excel->getActiveSheet();
          

            $row = 2;
            foreach ($lines as $key => $line) {
                $col = 0;
                foreach ($langs as $field) {
                    $value = isset($line->$field) ? $line->$field : '';
                    if (!in_array($field, !empty($hidden_fields) ? $hidden_fields : array() )) {
                        if (is_array($value)) {
                            if (count($value) > 0) {
                                $c=0;
                                foreach($value as $k=>$v){
                                    $c=$col;
                                   
                                  foreach($v as $field=>$val){
                                       $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, 1, $field);
                                       $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setSize(14);

                                        // make the font become bold
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, 1)->getFont()->setBold(true);

                                        // set aligment to center for that cell
                                       
                                        $this->excel->getActiveSheet()->setCellValueByColumnAndRow($c, $row, $val);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getFont()->setSize(12);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()
                                         ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
                                        $this->excel->getActiveSheet()->getStyleByColumnAndRow($c, $row)->getAlignment()->setWrapText(true);
                                        $c++;
                                  }
                                $row++;
                                }
                            } else {
                                // set cell A1 content with some text
                               $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, 'NONE');
                            }
                        } else {
                            // set cell A1 content with some text
                            $this->excel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, ucfirst(strip_tags($value)));
                             $this->excel->getActiveSheet()->getStyleByColumnAndRow($col,$row)->getAlignment()->setWrapText(true);
                        }
                    }

//                    // change the font size
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getFont()->setSize(12);
                    // set aligment to vertical center for that cell
                    $this->excel->getActiveSheet()->getStyleByColumnAndRow($col, $row)->getAlignment()
                            ->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

                    $col++;
                }

                $row++;
            }
            
            $this->excel->setActiveSheetIndex(0);
              $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);
            /** @var PHPExcel_Cell $cell */
            foreach ($cellIterator as $cell) {
                $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
            }
            // mime type
            $filename = time() . "Report";
            header('Cache-Control: private, max-age=1');
            header("Pragma:token");
            header("Expires: 0"); 
            header('Content-Type: application/vnd.ms-excel;charset=utf-8');
            // tell browser what's the file name
            header('Content-Disposition: attachment;filename=' . $filename.".xls");
            // no cache
            //header('Cache-Control: max-age=0');
            // save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
            // if you want to save it as .XLSX Excel 2007 format
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
            ob_end_clean();
            // force user to download the Excel file without writing it to server's HD
            $objWriter->save('php://output');        
            
                        
            return true;
         
        }
        else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }
    // on which day email notification to be send
    
       public function usertrackingbackup() {
      
        $type= $this->input->post('type'); 
        
          
        if($type=="backup")
        {
            $name=time();
          
             $query ="SELECT IF(user_type!='isAdmin',CONCAT(u1.`fname`, ' ', u1.lname),'Super Admin') AS NAME, u.`request_uri`, u.`client_ip`, u.`timestamp`, IF(user_type!='isadmin',u1.`email`,(SELECT email FROM admin WHERE is_superadmin='1' )) AS email FROM usertracking u LEFT JOIN users u1
ON u.user_identifier=u1.id WHERE CONCAT(u1.`fname`, ' ', u1.lname) IS NOT NULL
INTO OUTFILE  'g:/$name.csv' FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\n';";  
             
       header("Content-type: application/octet-stream"); 
       header("Content-Disposition: attachment; filename=g:\/".$name.".csv"); 
       header("Pragma: no-cache"); header("Expires: 0"); 
               $Q= $this->db->query($query);            
           
        }
        
        else if($type=="clearlog"){
            
              $cron_query = $this->db->query("SELECT * FROM  usertracking ORDER BY id DESC limit 1 ");
           $mycron_data= $this->mcustom->getselectedata("SELECT * FROM  usertracking ORDER BY id DESC limit 1 ");
  
           $st=($mycron_data[0]->id)-1000;       
           $status = $this->db->query("delete  from  usertracking where id <=$st ");
         
        }
        else {
            $this->session->set_flashdata('error', 'Data not found. Please try again');
        }
    }
     public function getnotification() {
        $this->db->select("*");
        $this->db->from("mst_notification");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }
     
    //to update the day of notification of email weekly   
     public function update_notification() {
        $data = array(
             'day' => $this->input->post('day'),
             'added_on' => date('Y-m-d H:i:s')
             );
        if ($this->input->post('id')) {
            //update
            $id = $this->input->post('id');
            $this->db->where("id = '$id'");
            $this->db->update('mst_notification', $data);
        } 
    }
    
    //to subscibe/unsubsribe the notification of email weekly  
    public function unsubsribes($id,$notification=false){
        if($notification)
            $n = $notification;
        else
            $n='0';
        $data = array(
            'notification' => $n
        );
        if($id){
            $this->db->where("id = '$id'");
            $this->db->update('users', $data);
            return true;
        }
        else {
            return false;
        }
    }

      // get list of all hospitals associted with users
    public function get_our_hospitals() {
        $data = array();
        $u_userid = $this->session->userdata('u_userid');
        $this->db->select("hn.id,hn.hospital_network");
        $this->db->from("hospital_network hn");
        $this->db->join("hospital_doctor hd", "hn.id = hd.hospital_id", "left");
        $this->db->where("hd.doctor_id = $u_userid");
        $this->db->where("hd.is_active",'1');
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        return $data;
    }
}
