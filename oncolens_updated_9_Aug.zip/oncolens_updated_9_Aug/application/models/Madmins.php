<?php

class Madmins extends CI_Model {

     // // to validate the credentials for login
    public function verifyAdmin($u, $pw) {
        $this->db->select('id,username,firstname,lastname,is_superadmin');
        $this->db->where('username', ($u))->where('password', md5(db_clean($pw)));
        $this->db->limit(1);
        $Q = $this->db->get('admin');
        if ($Q->num_rows() > 0) {
            $row = $Q->row();
            $this->db->select('id');
            $this->db->where('hospital_admin_username', db_clean($row->username));
            $this->db->limit(1);
            $T = $this->db->get('hospital_network');
            if ($T->num_rows() > 0) {
                $res = $T->row();
                $_SESSION['hospital_id'] = $res->id;
            }

            $_SESSION['userid'] = $row->id;
            $_SESSION['username'] = $row->username;
            $_SESSION['fname'] = $row->firstname;
            $_SESSION['lname'] = $row->lastname;
            $_SESSION['is_superadmin'] = $row->is_superadmin;
        } else {
            $this->session->set_flashdata('error', 'Username and password doesn\'t match.');
        }
    }

    public function forgotpassword() {
        $data_user = array('email' => db_clean($this->input->post('email')),'is_superadmin'=>'1');
        $Q = $this->db->get_where('admin', $data_user,1);
        if ($Q->num_rows() > 0) {
            $row = $Q->row();
            $newpass = random_string('alnum', 8);
            $data = array('password' => md5($newpass));
            $this->db->where('email', db_clean($this->input->post('email')))->where('is_superadmin', '1');
            $this->db->update('admin', $data);

            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('password_changed');
            if ($template) {
                $mail_data = array(
                    'NAME' => trim($row->firstname),
                    'PASSWORD' => $newpass
                );
                $subject = $template['subject'];
                $mailmessage = $template['body'];
                foreach ($mail_data as $key => $val) {
                    $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
                }
//			$mailmessage = "<p><img src='".base_url()."images/oncolence-logo.png'></p><br/>";
//			$mailmessage .= "<p>Thank you admin. Your password have been changed.</p>";
//			$mailmessage .= "<p><b>Your New Password:</b> " . $newpass . "</p>";
//			$mailmessage .= "<p><br /></p>";
//			$mailmessage .= "<p>Best Regards</p>";
//			$mailmessage .= "<p><b>Oncolens</b></p>";
//			$config['protocol'] = 'sendmail';
//			$config['mailpath'] = '/usr/sbin/sendmail';
//			$config['charset'] = 'iso-8859-1';
//			$config['wordwrap'] = TRUE;
                $this->email->set_mailtype("html");
                $this->email->from('support@oncolens.com', 'OncolensSupport');
                $this->email->to($this->input->post('email'));
                $this->email->subject($subject);
                $this->email->message($mailmessage);
                $this->email->send();
            }
            $this->session->set_flashdata('success', 'New Password Sent to your Email Account. Please Login and Change Password as soon as Possible!');
        } else {
            $this->session->set_flashdata('error', 'Email doesn\'t match, Please try again later!');
        }
    }

    public function getUser($id) {
        $data = array();
        $options = array('id' => $id);
        $Q = $this->db->get_where('users', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getAllUsers($per_page, $offset, $sortfield, $order) {
        $data = array();
       $Q = $this->db->query("SELECT u.*,GROUP_CONCAT(hn.`hospital_network`SEPARATOR ', ') AS hospital FROM users u LEFT JOIN `hospital_doctor` h ON u.id=h.`doctor_id` LEFT JOIN `hospital_network` hn ON hn.`id`=h.`hospital_id` and hn.is_active='1'  where u.is_active='1' and h.is_active='1'   GROUP BY u.id limit $offset,$per_page");
	   
       
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    // to track various activities of user
    
     public function getAllUserstrack() {
        $data = array();
       $Q = $this->db->query("SELECT u.*,GROUP_CONCAT(hn.`hospital_network`SEPARATOR ', ') AS hospital FROM users u LEFT JOIN `hospital_doctor` h ON u.id=h.`doctor_id` LEFT JOIN `hospital_network` hn ON hn.`id`=h.`hospital_id` and hn.is_active='1'  where u.is_active='1' and h.is_active='1'   GROUP BY u.id order by u.fname,u.lname");
       
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    // to track various activities of user
     public function getUserstrack($filter,$count) {
       
        $user_id = isset($filter['user_id']) ? $filter['user_id'] : 0;    
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $datefrom = isset($filter['daysfrom']) ? $filter['daysfrom'] : '';
        $dateto = isset($filter['daysto']) ? $filter['daysto'] : '';
        $per_page=isset($filter['per_page']) ? $filter['per_page'] : 10;
        
      
        
       
//        if($datefrom=="")
//            $datefrom=strtotime(date("m-d-Y")) - 7*24*60*60;
//        if($dateto=="")
//            $dateto=strtotime(date("m-d-Y"));
//        
        
         $datefrom=strtotime($datefrom);
         $dateto=strtotime($dateto);
        
         $dateto=$dateto+24*60*60;
        
         
         $this->db->select("IF(user_type!='isAdmin',CONCAT(u1.`fname`, ' ', u1.lname),'Super Admin') AS NAME, u.`request_uri`, u.`client_ip`, u.`timestamp`, IF(user_type!='isadmin',u1.`email`,(SELECT email FROM admin WHERE is_superadmin='1' )) AS email ",false);
        $this->db->from("usertracking u");
        $this->db->join("users u1", "u.user_identifier=u1.id ", "left");
        
         
           if($user_id!=0)
        $this->db->where("u1.id",$user_id);          
           
        $this->db->where("u.timestamp >=$datefrom and u.timestamp <=$dateto");
      
          $this->db->where("u.`user_identifier` IS NOT NULL AND u1.email IS NOT NULL");
        
        
        $this->db->order_by("u.`timestamp`", "desc");
        
       
        
          
             if ($count==0)
             {
             
            $this->db->limit($per_page, $offset);
            
             }
        
        $query = $this->db->get();

        //echo $this->db->last_query();
       
        
        
        return ($count==1) ? $query->num_rows() : $query->result();
       
    }
    
    
    public function getAllUsersCount() {
        $data = array();
        $this->db->where('is_active', '1');
        $Q = $this->db->get('users');
        return $Q->num_rows();
    }
    
    
     
    
    
     // count of all users
       public function getAllLoginCount($id) {
        $data = array();
        $this->db->where('user_id',$id);
        $Q = $this->db->get('login_stats');
        return $Q->num_rows();
    }
    
    
     // login time details of users
     public function getAllUsersLogin($id,$per_page, $offset, $sortfield, $order) {
        $data = array();
       $Q = $this->db->query("SELECt * from login_stats where user_id=$id order by stat_id desc  limit $offset,$per_page");
       
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    public function UsersCount() {
       
        $this->db->select(" count(*) as c from users");
        $this->db->where('is_active', '1');        
        $Q = $this->db->get();
        
            
        if ($Q->num_rows() > 0) {
            
            foreach ($Q->result() as $row) {
                $data = $row;
           }
             
                          
          return $data->c;           
        } else {
           return '0';     
        }
            
    }
    

    public function getspeciality() {
        $data = array();
        $this->db->where("is_deleted", "0");
        $Q = $this->db->get('speciality');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    
     public function getspecialityadmin() {
        $data = array();
        $this->db->where("is_deleted", "0");
         $this->db->where("speciality_id in (1,3,4)");
        $Q = $this->db->get('speciality');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

        public function getspeciality_according_ans() {
        $data = array();
        $this->db->from("speciality s");
        $this->db->join("specificanswer sa", "sa.speciality_id = s.speciality_id", "inner join");
        $this->db->where("s.is_deleted", "0");
        $this->db->where(" s.`speciality_id` in  (1,3,4)");        
        $this->db->group_by("s.speciality_id"); 
        $Q = $this->db->get();
        
       
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    // to fetch all hospitals
    public function gethospitals() {
        $data = array();
        $this->db->where('is_active','1');
        $Q = $this->db->get('hospital_network');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        return $data;
    }

    public function gettumor($tumor_id, $hospital_id = NULL) {
        if (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] > 0) {
            $data = array();
            $Q = $this->db->get('tumor_board');
        } else {
            $data = array();
            $Q = $this->db->query("select distinct(c.tumor_board_name),c.tumor_id from  hospital_doctor  as a inner join hospital_doctor_tumor_board as b on a.hospital_doctor_id = b.hospital_doctor_id inner join tumor_board as c on c.tumor_id = b.tumor_id where a.hospital_id = '" . $hospital_id . "' group by b.tumor_id");
        }

        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        // echo '<pre>';
        //print_r($data);die;
        return $data;
    }

     // to add  user
    public function addUser() {

        $spec_id = $this->input->post('speciality_id');
//            $check = $this->madmins->hospital_networkadmin_check($this->input->post('speciality_id'),$this->input->post('hospital_id'));
//            if($check=='notexist'){
        // user table insert query 
        $tumor = $this->input->post('tumor_id');
        if (is_array($tumor)) {
            $tumor = implode(",", $tumor);
        }
        if (!isset($tumor) && empty($tumor)) {
            $tumor = '0';
        }
        $data = $this->madmins->doctor_check($this->input->post('email'));

        if ($data == 'notexist') {
            $pass_hash = $this->bcrypt->hash_password($this->input->post('password'));
            $data_user = array(
                'fname' => db_clean($this->input->post('fname')),
                'lname' => db_clean($this->input->post('lname')),
                'email' => db_clean($this->input->post('email')),
                'speciality_id' => db_clean($this->input->post('speciality_id')),
                'tumor_id' => $tumor,
                'hospital_id' => db_clean($this->input->post('hospital_id')),
                'password' => $pass_hash,
                'date' => date('Y-m-d : h:i:s'),
                'ip' => $_SERVER['REMOTE_ADDR'],
                'is_active' => '1',
            );

            $this->db->insert('users', $data_user);
            $insert_id = $this->db->insert_id();
        } elseif ('exist_same') {
            $this->session->set_flashdata('error', 'User already exist with same email id');
            return false;
        } else {
            $data = array();
            $options = array('email' => db_clean($this->input->post('email')));
            $Q = $this->db->get_where('users', $options, 1);
            $data = $Q->row();
            $insert_id = $data->id;
        }
        // End  user table insert query



        $tumor_id = $this->input->post('tumor_id');
        $is_tumor_board = isset($tumor_id) ? '1' : '0';


        // hospital_doctor table insert query
        $data_host_doctor = array('hospital_id' => db_clean($this->input->post('hospital_id')),
            'doctor_id' => $insert_id,
            'is_tumor_board' => $is_tumor_board,
			'is_active' => 1
        );

        $this->db->insert('hospital_doctor', $data_host_doctor);
        $last_insert_id = $this->db->insert_id();

        // End hospital_doctor table insert query
        //speciality_hospital_doctor
        $data_speciality_hospital_doctor = array(
            'speciality_id' => db_clean($this->input->post('speciality_id')),
            'hospital_doctor_id' => $last_insert_id,
        );

        $this->db->insert('speciality_hospital_doctor', $data_speciality_hospital_doctor);

        if ($spec_id != HOSPITAL_ADMIN_SPECILITY) {
            //hospital_doctor_tumor_board
            if (is_array($this->input->post('tumor_id'))) {
                foreach ($this->input->post('tumor_id') as $tumor_id) {
                    $data_hospital_doctor_tumor_board = array(
                        'tumor_id' => db_clean($tumor_id),
                        'hospital_doctor_id' => $last_insert_id,
                    );

                    $this->db->insert('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board);
                }
            } else {
                $data_hospital_doctor_tumor_board = array(
                    'tumor_id' => db_clean($tumor_id),
                    'hospital_doctor_id' => $last_insert_id,
                );
                $this->db->insert('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board);
            }
        }
        // Email Code
        $hos = array();
        $options = array('id' => db_clean($this->input->post('hospital_id')));
        $Q = $this->db->get_where('hospital_network', $options, 1);
        $hos = $Q->row();
        $_SESSION['message'] = "User added successfully";
        /* $mailmessage = "<p><img src='http://ukit-ss.co.uk/oncolensphp/images/oncolence-logo.png'></p><br/>";
          $mailmessage = "<p>Dear Dr.".$this->input->post('fname')."  ".$this->input->post('lname').".</p>";
          $mailmessage .= "<p>".$hos->hospital_network." Center is pleased to announce it is transitioning to OncoLens<sub>(TM)</sub> to conduct the weekly Tumor Board conference.</p>";
          $mailmessage .= "<p>This will help with<br/>";
          $mailmessage .= " 1. Quick easy case submission via iPhone app or PC.<br/>";
          $mailmessage .= " 2. Decrease time spent by pathology and radiology in case preparation for conference.<br/>";
          $mailmessage .= " 3. Facilitate early multidisciplinary collaboration which is a hallmark of cancer care at ".$hos->hospital_network."<br/> ";
          $mailmessage .= " 4. Enable the Cancer Registrars to collect Tumor Board details automatically for submission to COC, thereby saving time and expense.</p><br/>";
          $mailmessage .= "<p>Steps to be taken by you<br/>";
          $mailmessage .= " 1. If you are using an iPhone, please visit the App Store and download the OncoLens app for free. On your PC visit <a href = 'www.oncolens.com'>www.oncolens.com</a> If you are an existing user of OncoLens<sub>(TM)</sub>, our hospital will be automatically added to your profile settings.<br/>";
          $mailmessage .= " 2. Log in using the following user id and temporary password. You will be prompted to change your password on your first log in. If you are already an OncoLens<sub>(TM)</sub> user, use your existing user id and password.<br/>";
          $mailmessage .= " 3. Submit cases for tumor board discussion.<br/>";
          $mailmessage .= " 4. Provide your suggestions on the various cases presented.<br/>";
          $mailmessage .= " 5. Be active on the platform and help ".$hos->hospital_network." be at the forefront of collaborative cancer care.</p>";
          $mailmessage .= "<p>Please let me know if you have any questions. For OncoLens<sub>(TM)</sub> support, please email <a href='mailto:support@oncolens.com'>support@oncolens.com</a><br/>";
          $mailmessage .= "<b>Your Username: </b>".$this->input->post('email')."<br/>";
          $mailmessage .= "<b>Your Password: </b>".$this->input->post('password')."</p><br/>";
          $mailmessage .= "<p><br /></p>";
          $mailmessage .= "<p>Thank You</p>";
          $mailmessage .= "<p>Best Regards</p>";
          $mailmessage .= "<p><b>The Cancer Team At ".$hos->hospital_network."</b></p>"; */

        /* $mailmessage = "<p><img src='http://ukit-ss.co.uk/oncolensphp/images/oncolence-logo.png'></p><br/>";
          $mailmessage = "<p>Dear ".$this->input->post('fname')."  ".$this->input->post('lname').".</p>";
          $mailmessage .= "<p>Thank you for volunteering to beta test the OncoLens<sub>(TM)</sub> application.</p>";
          $mailmessage .= "<p>The OncoLens<sub>(TM)</sub> application is designed to:<br/>";
          $mailmessage .= " 1. Facilitate quick and easy case submission for peer to peer discussion via iPhone app or PC.<br/>";
          $mailmessage .= " 2. Decrease time spent by pathology and radiology in case preparation for tumor board conferences.<br/>";
          $mailmessage .= " 3. Enable early multidisciplinary collaboration.<br/>";
          $mailmessage .= " 4. Enable the Cancer Registrars to collect Tumor Board details automatically for submission to COC, thereby saving time and expense.</p><br/>";
          $mailmessage .= "<p>Steps to be taken by you:<br/>";
          $mailmessage .= ' 1. If you are using an iPhone, please look out for an email from "TestFairy" asking you to register your mobile device.<br/>';
          $mailmessage .= " 2. Once registered, the developer will send you another email with a link to download their app.<br/>";
          $mailmessage .= ' 3. Log in using the following user id and temporary password. Please change your password by clicking on the link "Forgot Password" on the login screen.<br/>';
          $mailmessage .= " 4. Continue on to utilize the application.</p>";
          $mailmessage .= "<p>Please let me know if you have any questions. For OncoLens<sub>(TM)</sub> support, please email <a href='mailto:support@oncolens.com'>support@oncolens.com</a><br/>";
          $mailmessage .= "<b>Your Username: </b>".$this->input->post('email')."<br/>";
          $mailmessage .= "<b>Your Password: </b>".$this->input->post('password')."</p><br/>";
          $mailmessage .= "<p></p>";
          $mailmessage .= "<p>Thank You</p>";
          $mailmessage .= "<p>Best Regards</p>";
          $mailmessage .= "<p><b>Lijo Simpson</b></p>"; */

//		$mailmessage = "<p><img src='http://ukit-ss.co.uk/oncolensphp/images/oncolence-logo.png'></p><br/>";
//		$mailmessage = "<p>Dear ".$this->input->post('fname')."  ".$this->input->post('lname').".</p>";
//		$mailmessage .= "<p>Welcome to OncoLens.</p>";
//		$mailmessage .= "<p>The OncoLens<sub>(TM)</sub> application is designed to:<br/>";
//		$mailmessage .= " 1. Facilitate quick and easy case submission for peer to peer discussion via iPhone app or PC.<br/>";
//		$mailmessage .= " 2. Decrease time spent by pathology and radiology in case preparation for tumor board conferences.<br/>";
//		$mailmessage .= " 3. Enable early multidisciplinary collaboration.<br/>";
//		$mailmessage .= " 4. Enable the Cancer Registrars to collect Tumor Board details automatically for submission to COC, thereby saving time and expense.</p><br/>";
//		$mailmessage .= "<p>Steps to be taken by you:<br/>";
//		$mailmessage .= ' 1. Please download the app by clicking on the following link: https://itunes.apple.com/us/app/oncolens/id1061353798?ls=1&mt=8.<br/>';
//		$mailmessage .= ' 2. Log in using the following user id and temporary password. Please change your password by clicking on the link "Forgot Password" on the login screen.<br/>';
//		$mailmessage .= " 3. Continue to utilize the application.</p>";
//		$mailmessage .= "<p>Please let me know if you have any questions.</p><p> For OncoLens<sub>(TM)</sub> support, please email <a href='mailto:support@oncolens.com'>support@oncolens.com</a></p>";
//		$mailmessage .= "<p><b>Your Username: </b>".$this->input->post('email')."<br/>";
//		$mailmessage .= "<b>Your Password: </b>".$this->input->post('password')."</p><br/>";
//		$mailmessage .= "<p></p>";
//		$mailmessage .= "<p>Thank You</p>";
//		$mailmessage .= "<p>Best Regards</p>";
//		$mailmessage .= "<p>The OncoLens team</p>";
        $this->load->model('memail_templates', 'memail');
        $template = $this->memail->get_template_by_name('registration');
        if ($template) {
            $mail_data = array(
                'NAME' => $this->input->post('fname') . "  " . $this->input->post('lname'),
                'USERNAME' => $this->input->post('email'),
                'PASSWORD' => $this->input->post('password')
            );
            $subject = $template['subject'];
            $mailmessage = $template['body'];
            foreach ($mail_data as $key => $val) {
                $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
            }
            //		$config['protocol'] = 'smtp';
            //		$config['smtp_host'] = 'ssl://smtp.googlemail.com';
            //		$config['smtp_port'] = 465;
            //		$config['smtp_user'] = 'dscdemo0@gmail.com';
            //		$config['smtp_pass'] = 'Jaipur@123';
            //		$config['mailtype'] = 'html';
            //		$config['charset'] = 'iso-8859-1';
            //		$config['wordwrap'] = TRUE;
            $this->email->set_mailtype("html");
            $this->email->from('support@oncolens.com', 'OncolensSupport');
            $this->email->to($this->input->post('email'));
            $this->email->subject($subject);
            $this->email->message($mailmessage);
            $this->email->send();
        }
        $this->session->set_flashdata('message', 'User added successfully');
        // End Email Code
        return true;

//            }else{
//                $this->session->set_flashdata('error', 'Hospital administration already exist with this related hospital.');
//                 return false;
//            }
    }

    public function updateUser($id) {

        $tumor = $this->input->post('tumor_id');

        if (is_array($tumor)) {
            $tumor = implode(",", $tumor);
        }
        if (db_clean($this->input->post('speciality_id')) != HOSPITAL_ADMIN_SPECILITY) {
            $data_user = array('fname' => db_clean($this->input->post('fname')),
                'lname' => db_clean($this->input->post('lname')),
                //'speciality_id' => db_clean($this->input->post('speciality_id')),
                //'tumor_id' => $tumor,
                //'hospital_id' => db_clean($this->input->post('hospital_id')),
               // 'date' => date('Y-m-d : h:i:s'),
            );
        } else {
            $data_user = array('fname' => db_clean($this->input->post('fname')),
                'lname' => db_clean($this->input->post('lname')),
                //'speciality_id' => db_clean($this->input->post('speciality_id')),
                'tumor_id' => $tumor,
                'hospital_id' => db_clean($this->input->post('hospital_id')),
                //'date' => date('Y-m-d : h:i:s'),
            );
        }

        if ($this->input->post('password') != "" && $this->input->post('cpassword') != "") {
            $pass_hash = $this->bcrypt->hash_password($this->input->post('password'));
            $data_user['password'] = $pass_hash;
        }


        $this->db->where('id', db_clean($id));
        $this->db->update('users', $data_user);
        // End  user table update query


        $data = array();
        $Q = $this->db->query("select * from  hospital_doctor  where doctor_id = '" . $id . "'");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        //speciality_hospital_doctor
        $data_speciality_hospital_doctor = array('speciality_id' => db_clean($this->input->post('speciality_id')),
        );

        $this->db->where('hospital_doctor_id', $data[0]->hospital_doctor_id);
        $this->db->update('speciality_hospital_doctor', $data_speciality_hospital_doctor);

        if ($this->input->post('password') != "" && $this->input->post('cpassword') != "") {
            $this->load->model('memail_templates', 'memail');
            $template = $this->memail->get_template_by_name('password_changed');
            if ($template) {
                $mail_data = array(
                    'NAME' => trim($this->input->post('fname')),
                    'PASSWORD' => $this->input->post('password')
                );
                $subject = $template['subject'];
                $mailmessage = $template['body'];
                foreach ($mail_data as $key => $val) {
                    $mailmessage = str_replace("{{" . $key . "}}", $val, $mailmessage);
                }
                $this->email->set_mailtype("html");
                $this->email->from('support@oncolens.com', 'OncolensSupport');
                $this->email->to($this->input->post('email'));
                $this->email->subject($subject);
                $this->email->message($mailmessage);
                $this->email->send();
            }
        }
        
        // End Email Code
    }
        // to unblock the user
    public function unblock_user($id) {
        $data = array('inactivity' => 0, 'inactivity_on' => '0000-00-00 00:00:00');
        $this->db->where('id', $id);
        $this->db->update('users', $data);
    }

    public function delete_user($id, $table_name) {
        $data = array('is_active' => '0');
        $this->db->where('id', $id);
        $this->db->update($table_name, $data);
        return true;
    }

    public function status_user($id, $table_name, $status) {
        $data = array('is_active' => db_clean($status));
        if ($table_name == 'hospital_doctor') {
            $this->db->where('hospital_doctor_id', $id);
        } else {
            $this->db->where('id', $id);
        }

        $this->db->update($table_name, $data);
    }

    public function status_hospital_doctor_tumor_board($id, $table_name, $status) {
        $data = array('is_active' => db_clean($status));
        $this->db->where('id', $id);
        $this->db->update($table_name, $data);
    }

    public function tumorboard_list($id, $tumorid, $userid) {
        $Q = $this->db->query("SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN(SELECT * from hospital_tumor_board as b where hospital_id = '" . $id . "') as c on c.tumor_id = a.tumor_id WHERE a.tumor_id NOT IN (SELECT hdtb.tumor_id FROM hospital_doctor AS hd INNER JOIN hospital_doctor_tumor_board AS hdtb ON hd.hospital_doctor_id = hdtb.hospital_doctor_id WHERE hd.hospital_id = '" . $id . "' AND hd.doctor_id = '" . $userid . "' )");
        if ($Q->num_rows() > 0) {
            $data = "";
            foreach ($Q->result() as $row) {
                $selected = ($tumorid == $row->tumor_id) ? 'selected' : '';
                $data = $data . '<option value="' . $row->tumor_id . '" id="' . $row->tumor_id . '"  ' . $selected . ' >' . $row->tumor_board_name . '</option>';
            }

            $Q->free_result();
        } else {
            $data = "<option value='' disabled='disabled' >No New Tumor Board to be added.";
        }
        return $data;
        exit;
    }

     // to view  the admin profile
    public function adminprofile() {
        $Q = $this->db->get_where('admin');
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function adminprofile_update() {
        // admin table update query
        $data_user = array('firstname' => db_clean($this->input->post('firstname')),
            'lastname' => db_clean($this->input->post('lastname')),
            'email' => db_clean($this->input->post('email')),
            'address' => db_clean($this->input->post('address')),
        );


        $this->db->update('admin', $data_user);
        // End admin table update query
    }

    public function adminprofile_password() {
        // admin table update query
        $data_user = array('password' => md5($this->input->post('oldpassword')));
        $Q = $this->db->get_where('admin', $data_user);
        if ($Q->num_rows() > 0) {
            $data = array('password' => md5($this->input->post('newpassword')));
            $this->db->update('admin', $data);
            return true; // 'Password Updated Successfully!';
        } else {
            return false; // 'Old Password doesn\'t match!';
        }
       
        // End admin table update query
    }

    //to fetch all hospitials of oncolens
    public function getAllHospitals($per_page, $offset, $sortfield, $order) {
        $data = array();

        $this->db->order_by("$sortfield", "$order");
        $this->db->limit($per_page, $offset);
        $Q = $this->db->get('hospital_network');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

      // add the hospital
    public function addHospital() {
        
        
           $check_hospital='select *  from `hospital_network` h where h.hospital_network="'.trim(db_clean($this->input->post('hospital_network'))).'"';    
             
      
        $check_hospital_value = $this->db->query($check_hospital);
       
          if ($check_hospital_value ->num_rows() == 0) {

        // hospital_network table insert query 
        $data_hosp = array('hospital_network' => trim(db_clean($this->input->post('hospital_network'))),
            //'hospital_admin_email' => trim(db_clean($this->input->post('hospital_admin_email'))),
            //'hospital_admin_username' => trim(db_clean($this->input->post('hospital_admin_username'))),
           // 'hospital_admin_password' => md5($this->input->post('hospital_admin_password')),
            'hospital_address' => trim(db_clean($this->input->post('hospital_address'))),
            'added_on' => date('Y-m-d : h:i:s'),
            'is_active' => '1',
        );

        $this->db->insert('hospital_network', $data_hosp);
        
            return 'success';
        
        //$insert_id = $this->db->insert_id();
        // End  hospital_network table insert query

//        $data_admin = array('username' => db_clean($this->input->post('hospital_admin_username')),
//            'email' => db_clean($this->input->post('hospital_admin_email')),
//            'firstname' => db_clean($this->input->post('hospital_network')),
//            'password' => md5($this->input->post('hospital_admin_password')),
//            'address' => db_clean($this->input->post('hospital_address')),
//            'date' => date('Y-m-d : h:i:s'),
//            'is_superadmin' => '0',
//        );
//
//        $this->db->insert('admin', $data_admin);
//
//        $config['protocol'] = 'sendmail';
//        $config['mailpath'] = '/usr/sbin/sendmail';
//        $config['charset'] = 'iso-8859-1';
//        $config['wordwrap'] = TRUE;
//
//        $this->email->from('support@oncolens.com', 'Admin');
//        $this->email->to($this->input->post('hospital_admin_email'));
//        $this->email->subject('Thanks From Oncolens');
        //$this->email->message($mailmessage);
        //$this->email->send();
        // End Email Code
    }
       
           else
           {
               return 'failure';
           }
    }

     // to update the hospital details
    public function updateHospital($id) {
        // user table upade  query 
        
         $check_hospital='select *  from `hospital_network` h where id!='.$id .' and  h.hospital_network="'.trim(db_clean($this->input->post('hospital_network'))).'"';    
             
      
        $check_hospital_value = $this->db->query($check_hospital);
       
          if ($check_hospital_value ->num_rows() == 0) {
        
        $data_hosp = array('hospital_network' => trim(db_clean($this->input->post('hospital_network'))),
            //'hospital_admin_email' => db_clean($this->input->post('hospital_admin_email')),
           // 'hospital_admin_username' => db_clean($this->input->post('hospital_admin_username')),
           // 'hospital_admin_password' => md5($this->input->post('hospital_admin_password')),
            'hospital_address' => db_clean($this->input->post('hospital_address')),          
            'is_active' => '1',
        );

        if ($this->input->post('hospital_admin_password') != "" && $this->input->post('cpassword') != "") {
            $data_user['hospital_admin_password'] = md5($this->input->post('hospital_admin_password'));
        }


        $this->db->where('id', db_clean($id));
        $this->db->update('hospital_network', $data_hosp);
        return 'success';
        // End  user table update query


//        $data_admin = array('username' => db_clean($this->input->post('hospital_admin_username')),
//            'email' => db_clean($this->input->post('hospital_admin_email')),
//            'firstname' => db_clean($this->input->post('hospital_network')),
//            'password' => md5($this->input->post('hospital_admin_password')),
//            'address' => db_clean($this->input->post('hospital_address')),
//            'date' => date('Y-m-d : h:i:s'),
//            'is_superadmin' => '0',
//        );
//
//
//        $this->db->where('username', db_clean($this->input->post('hospital_admin_username')));
//        $this->db->update('admin', $data_admin);
    }
      else {
          
              return 'failure';   
      }
      }

      // to fetch the particular hospitial detail
    public function getHospitaldetail($id) {
        $data = array();
        $options = array('id' => $id);
        $Q = $this->db->get_where('hospital_network', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    
    // to delete the particular hospitial
    public function delete_hospital($id, $table_name) {
        $this->db->select('hn.id,COUNT(DISTINCT(hd.doctor_id)) as doctor,COUNT(DISTINCT(htb.tumor_id)) as tumor_board');
        $this->db->from('hospital_network hn');
        $this->db->join('hospital_doctor hd', 'hd.hospital_id  =  hn.id', 'inner');
        $this->db->join('hospital_tumor_board htb', 'htb.hospital_id  =  hn.id', 'inner');
        $this->db->where('hn.id', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $data = $query->result()[0];
            if ($data->doctor > 0 && $data->tumor_board > 0) {
                return false;
            } else {
                $data = array();
                $options = array('id' => $id);
                $Q = $this->db->get_where('hospital_network', $options, 1);
                if ($Q->num_rows() > 0) {
                    $data = $Q->row();
                    $Q->free_result();
                }
                $this->db->where('id', $id);
                $this->db->delete($table_name);
                $this->db->query("delete from admin  where email = '" . $data->hospital_admin_email . "'");
                return true;
            }
           
        }
         else {
                return false;
            }
    }

     // to active/inactive particular hospital
    public function status_hospital($id, $table_name, $status) {
        $this->db->select('hn.id,COUNT(DISTINCT(hd.doctor_id)) as doctor,COUNT(DISTINCT(htb.tumor_id)) as tumor_board');
        $this->db->from('hospital_network hn');
        $this->db->join('hospital_doctor hd', 'hd.hospital_id  =  hn.id', 'inner');
        $this->db->join('hospital_tumor_board htb', 'htb.hospital_id  =  hn.id', 'inner');
        $this->db->where('hn.id', $id);
        $query = $this->db->get();
        
       
      
        if ($query->num_rows() > 0) {
            $data = $query->result()[0];
          
            if ($data->doctor > 0 && $data->tumor_board > 0) {
                return false;
            } else {
                $data = array('is_active' => db_clean($status));
                $this->db->where('id', $id);
                $this->db->update($table_name, $data);
                return true;
            }
        }
        else {
             return true;
        }
    }

     // to fetch all the tumor board
    public function getAlltumorboards($limit, $start, $table) {
        $this->db->select('*');
        $this->db->limit($limit, $start);
        $this->db->from('hospital_tumor_board');
        $this->db->join('hospital_network', 'hospital_network.id  =  hospital_tumor_board.hospital_id', 'inner');
        $this->db->join('tumor_board', 'tumor_board.tumor_id  =  hospital_tumor_board.tumor_id', 'inner');
        $this->db->order_by("tumor_board.added_on", "desc");
        // $this->db->join('cancercategories' , 'cancercategories.cancer_id  =  tumor_board.cancer_id', 'inner');
        $query4 = $this->db->get();
        $this->db->limit($limit, $start);
        return $query4->result();
    }

     // to add the tumorboard
    public function addTumorboard() {
        
     $check_tumor_board="select * from tumor_board t  inner join hospital_tumor_board h on t.tumor_id=h.tumor_id  where  h.hospital_id='".db_clean($this->input->post('hospital'))."' and tumor_board_name='".trim(db_clean($this->input->post('tumor_board_name')))."' ";
     
         $check_tumor_board_value = $this->db->query($check_tumor_board);
       
          if ($check_tumor_board_value->num_rows() == 0) {

        // user table insert query 
        $data_tumorboard = array('tumor_board_name' => trim(db_clean($this->input->post('tumor_board_name'))),
            //'cancer_id' => db_clean($this->input->post('cancer')),
            'added_on' => date('Y-m-d : h:i:s'),
            'is_active' => '1',
        );

        $this->db->insert('tumor_board', $data_tumorboard);
        $insert_id = $this->db->insert_id();
        // End  user table insert query
        // users_hospitals table insert query
        $data_hospital = array('hospital_id' => db_clean($this->input->post('hospital')),
            'tumor_id' => $insert_id,
        );

        $this->db->insert('hospital_tumor_board', $data_hospital);
          return 'success';
              }
      
      else {
              return 'failure';
        }
      
    }

     // to update  the tumorboard details
    public function updateTumorboard($id) {
        // user table upade  query 
        
        
        $check_tumor_board="select * from tumor_board t  inner join hospital_tumor_board h on t.tumor_id=h.tumor_id  where  t.tumor_id!='".$id."'  and  h.hospital_id='".trim(db_clean($this->input->post('hospital')))."' and tumor_board_name='".trim(db_clean($this->input->post('tumor_board_name')))."' ";
     
        
     
      
         $check_tumor_board_value = $this->db->query($check_tumor_board);
       
          if ($check_tumor_board_value->num_rows() == 0) {

             
              
        $data_hospital = array('tumor_board_name' => trim(db_clean($this->input->post('tumor_board_name'))),
            //'cancer_id' => db_clean($this->input->post('cancer')),
            'added_on' => date('Y-m-d : h:i:s'),
        );


        $this->db->where('tumor_id', db_clean($id));
        $this->db->update('tumor_board', $data_hospital);
        // End  user table update query
        // hospital_doctor table insert query
        $data_host_tumor = array('hospital_id' => db_clean($this->input->post('hospital')),
        );


        $this->db->where('tumor_id', db_clean($id));
        $this->db->update('hospital_tumor_board', $data_host_tumor);
        
        return 'success';

         }
      
      else {
             return 'failure';
        }
        // End hospital_doctor table insert query
    }

     // to get the details of particular tumor board
    public function getTumorboardsdetail($id) {
        $data = array();
        $options = array('tumor_id' => $id);
        $Q = $this->db->get_where('tumor_board', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    // to fetch the cancer types of oncolens
    public function getCancertype() {
        $data = array();
        $Q = $this->db->get('cancercategories');
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getSelectedhospital($id) {
        $data = array();
        $options = array('tumor_id' => $id);
        $Q = $this->db->get_where('hospital_tumor_board', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    // to delete tumor board
    public function delete_tumorboard($id, $table_name) {        
         
       
      
        $check_tumor_board_value = $this->db->query($check_tumor_board);    
        
        
        $this->db->where('tumor_id', $id);
        $this->db->delete($table_name);
        $this->db->query("Delete from hospital_tumor_board  where tumor_id = '" . $id . "'");
    }

    // to active tumor board
    public function status_tumorboard_active($id, $table_name, $status) {
        
           
             
                $data = array('is_active' => db_clean($status));
                $this->db->where('tumor_id', $id);
                $this->db->update($table_name, $data);                                
                return 'success';
          
            
                
    }
    
     // to inactive tumor board
    public function status_tumorboard_inactive($id, $table_name, $status) {
        
           echo $check_tumor_board="select t.tumor_id as id from tumor_board t  inner join hospital_doctor_tumor_board h on t.tumor_id=h.tumor_id  where  t.tumor_id='".$id."'  and h.is_active='1' union select t.tumor_id as id from tumor_board t  inner join case_meeting h on t.tumor_id=h.tumor_board_id  where  t.tumor_id='".$id."'  and h.is_deleted='0' ";     
        
        
         $check_tumor_board_value = $this->db->query($check_tumor_board);
       
          if ($check_tumor_board_value->num_rows() == 0) {
              
             
                $data = array('is_active' => db_clean($status));
                $this->db->where('tumor_id', $id);
                $this->db->update($table_name, $data);                                
                return 'success';
          }
          
            else {
                   return 'failure';                
                
            }
            
                
    }

    public function getMyUsers($per_page, $offset, $sortfield, $order) {
        $res = array();
        $username = $_SESSION['username'];
        $T = $this->db->query("SELECT * from hospital_network where hospital_admin_username = '" . $username . "'");
        if ($T->num_rows() > 0) {

            $res = $T->row();
            $id = $res->id;
            $T->free_result();
        }

        $data = array();
        $Q = $this->db->query("select *,a.is_active from hospital_doctor as a INNER JOIN users as b on a.doctor_id = b.id where a.hospital_id = '" . $id . "' order by $sortfield $order limit $offset,$per_page");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function gethospitalid($username) {
        $data = array();
        $options = array('hospital_admin_username' => $username);
        $Q = $this->db->get_where('hospital_network', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function tumorboardexits() {
        $data = array();
        $Q = $this->db->query("SELECT a.tumor_board_name,a.tumor_id from tumor_board as a INNER JOIN hospital_tumor_board as b  on a.tumor_id = b.tumor_id INNER JOIN hospital_network as c on b.hospital_id = c.id where c.hospital_admin_username = '" . $_SESSION['username'] . "'");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }

            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function selectedtumorboard($id) {
        $data = array();
        $Q = $this->db->query("SELECT a.hospital_doctor_id,b.tumor_id from hospital_doctor as a INNER JOIN hospital_doctor_tumor_board as b on a.hospital_doctor_id = b.hospital_doctor_id  where a.doctor_id  = '" . $id . "'");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }

            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function getHospitaltumorboards($per_page, $offset, $sortfield, $order) {
        $data = array();
        $Q = $this->db->query("select * from hospital_network as a inner join hospital_tumor_board as b on a.id = b.hospital_id inner join tumor_board as c on b.tumor_id = c.tumor_id inner join cancercategories as d on d.cancer_id = c.cancer_id where a.hospital_admin_username  = '" . $_SESSION['username'] . "' order by a.$sortfield $order limit $offset,$per_page");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function addHospitaltumorboard() {

        // user table insert query 
        $data_tumorboard = array('tumor_board_name' => db_clean($this->input->post('tumor_board_name')),
            'cancer_id' => db_clean($this->input->post('cancer')),
            'added_on' => date('Y-m-d : h:i:s'),
            'is_active' => '1',
        );

        $this->db->insert('tumor_board', $data_tumorboard);
        $insert_id = $this->db->insert_id();
        // End  user table insert query
        // users_hospitals table insert query
        $data_hospital = array('hospital_id' => db_clean($this->input->post('hospital_id')),
            'tumor_id' => $insert_id,
        );

        $this->db->insert('hospital_tumor_board', $data_hospital);
    }

    public function updateHospitaltumorboard($id) {
        // user table upade  query 
        $data_hospital = array('tumor_board_name' => db_clean($this->input->post('tumor_board_name')),
            'cancer_id' => db_clean($this->input->post('cancer')),
            'added_on' => date('Y-m-d : h:i:s'),
        );


        $this->db->where('tumor_id', db_clean($id));
        $this->db->update('tumor_board', $data_hospital);
        // End  user table update query
        // hospital_doctor table insert query
        $data_host_tumor = array('hospital_id' => db_clean($this->input->post('hospital_id')),
        );


        $this->db->where('tumor_id', db_clean($id));
        $this->db->update('hospital_tumor_board', $data_host_tumor);

        // End hospital_doctor table insert query
    }

     // to fetch all the tumor board
    public function getAlltumorboardcount() {
        $this->db->select('*');
        $this->db->from('hospital_tumor_board');
        $this->db->join('hospital_network', 'hospital_network.id  =  hospital_tumor_board.hospital_id', 'inner');
        $this->db->join('tumor_board', 'tumor_board.tumor_id  =  hospital_tumor_board.tumor_id', 'inner');
        //$this->db->join('cancercategories' , 'cancercategories.cancer_id  =  tumor_board.cancer_id', 'inner');
        $query4 = $this->db->get();
        return $query4->num_rows();
    }

    public function getHospitaltumorboardcount() {
        $this->db->select('*');
        $this->db->from('tumor_board');
        $this->db->join('hospital_tumor_board', 'hospital_tumor_board.tumor_id  =  tumor_board.tumor_id', 'inner');
        $this->db->join('hospital_network', 'hospital_network.id  =  hospital_tumor_board.hospital_id', 'inner');
        $this->db->join('admin', 'admin.username  =  hospital_network.hospital_admin_username', 'inner');
        $this->db->join('cancercategories', 'cancercategories.cancer_id  =  tumor_board.cancer_id', 'inner');
        $this->db->where('admin.username', $_SESSION['username']);
        $query4 = $this->db->get();
        return $query4->num_rows();
    }

    public function getHospitalUser() {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->join('hospital_network', 'hospital_network.id  =  users.hospital_id', 'inner');
        $this->db->where('hospital_network.hospital_admin_username', $_SESSION['username']);
        $query4 = $this->db->get();
        return $query4->num_rows();
    }

    public function getselectedhospitals($id) {
        $data = array();
        if (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] > 0) {
            $Q = $this->db->query("SELECT *,w.is_active, a.hospital_id as my_hospital_id from hospital_doctor as a INNER JOIN users as b on b.id = a.doctor_id INNER JOIN hospital_network as p on a.hospital_id = p.id INNER JOIN hospital_doctor_tumor_board as w on w.hospital_doctor_id = a.hospital_doctor_id INNER JOIN tumor_board as c on w.tumor_id = c.tumor_id where b.id = '" . $id . "' and p.is_active='1' and c.is_active='1'");
        } else {
            $Q = $this->db->query("SELECT *,w.is_active, a.hospital_id as my_hospital_id from hospital_doctor as a INNER JOIN users as b on b.id = a.doctor_id INNER JOIN hospital_network as p on a.hospital_id = p.id INNER JOIN hospital_doctor_tumor_board as w on w.hospital_doctor_id = a.hospital_doctor_id INNER JOIN tumor_board as c on w.tumor_id = c.tumor_id where b.id = '" . $id . "' and p.hospital_admin_username = '" . $_SESSION['username'] . "' ");
        }
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

        return $data;
    }

    
     public function getselectedhospitalsuser($id) {
        $data = array();
        if (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] > 0) {
            $Q = $this->db->query("SELECT *,w.is_active, a.hospital_id as my_hospital_id from hospital_doctor as a INNER JOIN users as b on b.id = a.doctor_id INNER JOIN hospital_network as p on a.hospital_id = p.id INNER JOIN hospital_doctor_tumor_board as w on w.hospital_doctor_id = a.hospital_doctor_id INNER JOIN tumor_board as c on w.tumor_id = c.tumor_id where b.id = '" . $id . "' and p.is_active='1' and c.is_active='1'");
        } else {
            $Q = $this->db->query("SELECT *,w.is_active, a.hospital_id as my_hospital_id from hospital_doctor as a INNER JOIN users as b on b.id = a.doctor_id INNER JOIN hospital_network as p on a.hospital_id = p.id INNER JOIN hospital_doctor_tumor_board as w on w.hospital_doctor_id = a.hospital_doctor_id INNER JOIN tumor_board as c on w.tumor_id = c.tumor_id where b.id = '" . $id . "' and  p.is_active='1' and  p.hospital_admin_username = '" . $_SESSION['username'] . "' ");
        }
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

               
        return $data;
    }
    
    
    
     public function getselectedhospitaltumor($id) {
        $data = array();
        if (isset($_SESSION['is_superadmin']) && $_SESSION['is_superadmin'] > 0) {
            $Q = $this->db->query("SELECT * FROM `hospital_tumor_board` WHERE `tumor_id` = $id");
        } 
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }

               
        return $data[0];
    }
    
    public function changeTumorboard($id) {
        
        
        $hospital_doctor_tumor_board_id = $this->input->post('hospital_doctor_tumor_board_id');
        $hospital_id = db_clean($this->input->post('hospital_id'));
        $tumor_id = $this->input->post('arr');
        $id = $this->input->post('id');

        $data = "";
        $Q = $this->db->query("SELECT hospital_doctor_id from hospital_doctor where hospital_id='" . $hospital_id . "' and doctor_id = '" . $id . "'");
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $Q->free_result();
        } else {
            $data = false;
        }
        // End hospital_doctor table insert query
        //hospital_doctor_tumor_board        
        $data_hospital_doctor_tumor_board1 = array('tumor_id' => $tumor_id,
            'hospital_doctor_id' => db_clean($data->hospital_doctor_id),
        );

        $Q = $this->db->get_where('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board1, 1);
        if ($Q->num_rows() == 0) {
            $data_hospital_doctor_tumor_board = array('tumor_id' => db_clean($tumor_id));
            $this->db->where('id', db_clean($hospital_doctor_tumor_board_id));
            $this->db->update('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board);
            $data = true;
        }
    }

    public function add_data_hospital() {
        
       $flag=0;
        $tumor_id = $this->input->post('arr');
        $is_tumor_board = isset($tumor_id) ? '1' : '0';
        $exit_tumor_flag=1;

        $data = array();
        $options = array('hospital_id' => db_clean($this->input->post('hospital_id')),
            'doctor_id' => db_clean($this->input->post('id')),
        );
        $Q = $this->db->get_where('hospital_doctor', $options, 1);
        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $hospital_doctor_id = $data->hospital_doctor_id;
            $flag=1;
        } else {
            // hospital_doctor table insert query
            $data_host_doctor = array('hospital_id' => db_clean($this->input->post('hospital_id')),
                'doctor_id' => db_clean($this->input->post('id')),
                'is_tumor_board' => $is_tumor_board,
            );
            
             $this->db->insert('hospital_doctor', $data_host_doctor);
            $hospital_doctor_id = $this->db->insert_id();
            
            
            $query = "SELECT speciality_id from users u where u.id=".db_clean($this->input->post('id'));
            $getspecialtydata = $this->mcustom->getselectedata($query);
            if ($getspecialtydata) { 
                 $data_spec_doctor = array('hospital_doctor_id' => $hospital_doctor_id,
                  'speciality_id' => $getspecialtydata[0]->speciality_id,                
                    );
             $this->db->insert('speciality_hospital_doctor', $data_spec_doctor);
                       // End hospital_doctor table insert query
                              }
                    }

        //hospital_doctor_tumor_board

        foreach ($tumor_id as $tumor) {
            $data_hospital_doctor_tumor_board = array('tumor_id' => db_clean($tumor),
                'hospital_doctor_id' => db_clean($hospital_doctor_id),
            );

            $Q = $this->db->get_where('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board, 1);
            if ($Q->num_rows() == 0) {    
                $exit_tumor_flag=0;
                $this->db->insert('hospital_doctor_tumor_board', $data_hospital_doctor_tumor_board);
            }
        }
     
        
        
          if($is_tumor_board==1 && $flag==1 && $exit_tumor_flag==1 )
              return 'Noinserstion';
         
        
    }

    public function hospitalTumorboard_edit($hospital_doctor_tumor_board_id, $hospital_id, $doctor_id) {
        $data1 = array();

        $data = array();
        $options = array('id' => db_clean($hospital_doctor_tumor_board_id));
        $Q = $this->db->get_where(' hospital_doctor_tumor_board', $options, 1);
        $data = $Q->row();
        $hospital_doctor_id = $data->hospital_doctor_id;
        $tumor_id = $data->tumor_id;

        $this->db->select('*');
        $this->db->from('hospital_doctor');
        $this->db->join('hospital_network', 'hospital_network.id  =  hospital_doctor.hospital_id', 'inner');
        $this->db->where('hospital_doctor.hospital_doctor_id', $hospital_doctor_id);
        $query = $this->db->get();
        $data = $query->row();
        $hospital_network = $data->hospital_network;
        $hospital_id = $data->hospital_id;


        $data1['hospital_network'] = $hospital_network;
        $data1['tumor_id'] = $tumor_id;
        $data1['hospital_doctor_tumor_board_id'] = $hospital_doctor_tumor_board_id;
        $data1['hospital_id'] = $hospital_id;
        $data1['doctor_id'] = $doctor_id;
        return $data1;
    }

    public function doctor_check() {

        $options = array('email' => db_clean($this->input->post('email')), 'is_active' => '1');
        $Q = $this->db->get_where('users', $options, 1);

        if ($Q->num_rows() > 0) {
            $data = $Q->row();
            $options = array('hospital_id' => db_clean($this->input->post('hospital_id')), 'doctor_id' => db_clean($data->id));
            $Q = $this->db->get_where('hospital_doctor', $options, 1);
            if ($Q->num_rows() > 0) {
                return 'exist_same';
            } else {
                return 'exist';
            }
        } else {
            return 'notexist';
        }
    }

    public function hospital_networkadmin_check($speciality_id, $hospital_id) {
        //$options = array('email' => db_clean($this->input->post('email')));
        $Q = $this->db->query("select * from  users where speciality_id='" . $hospital_id . "' and hospital_id='" . $speciality_id . "'");
        if ($Q->num_rows() > 0) {
            return 'exist';
        } else {
            return 'notexist';
        }
    }

//         public function get_user_tumor_data($id,$hospital_id){
//           
//            $options = array('hospital_id' => db_clean($hospital_id),'doctor_id' => db_clean($id));
//            $Q = $this->db->get_where('hospital_doctor',$options,1);
//            $row = $Q->row();
//
//            $options1 = array('hospital_doctor_id' => db_clean($row->hospital_doctor_id)); 
//            $Q1 = $this->db->get_where('hospital_doctor_tumor_board',$options1);     
//            $row1 = $Q1->row();
//            $data = array();
//                if ($Q1->num_rows()>0){
//                   foreach ($Q1->result() as $row){
//                   $data[] = $row->tumor_id;
//                   }
//                   $Q->free_result();
//		}else{
//			$data=false;
//		}
//		
//		return $data;
//		
//	}

    public function user_tumor_data_add($id, $tumor_id, $hospital_id) {

        $options = array('hospital_id' => db_clean($hospital_id), 'doctor_id' => db_clean($id));
        $Q = $this->db->get_where('hospital_doctor', $options, 1);
        $row = $Q->row();

        // hospital_doctor_tumor_board table insert query
        $options = array('hospital_doctor_id' => db_clean($row->hospital_doctor_id), 'tumor_id' => db_clean($tumor_id));
        $Q1 = $this->db->get_where('hospital_doctor_tumor_board', $options, 1);
        if ($Q1->num_rows() == 0) {
            $data_tumor = array('hospital_doctor_id' => db_clean($row->hospital_doctor_id), 'tumor_id' => $tumor_id);
            $this->db->insert('hospital_doctor_tumor_board', $data_tumor);
            echo 'success';
        } else {
            echo 'exist';
        }
    }

    public function getalluserlink_to_hospital($id) {
        $data = array();
        $Q = $this->db->query("select *,a.is_active from hospital_doctor as a  INNER JOIN  users as b on a.doctor_id = b.id  INNER JOIN hospital_network as c on a.hospital_id = c.id  and c.is_active='1'  where a.doctor_id = '" . $id . "' ");
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }

    public function pages() {
        $this->db->select("*");
        $this->db->from("page");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }

    public function page_detail($id) {

        $this->db->select("*");
        $this->db->where("id = $id");
        $this->db->from("page");
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }

    public function page_update() {

        $id = $this->input->post('id');
        $page_name = $this->input->post('page_name');
        $keyword = $this->input->post('keyword');
        $description = $_POST['description'];   
        $video_url = addslashes($this->input->post('video_url'));

        $content = ($_POST['content']);

        $update = array(
            'id' => $id
        );

        $Q = $this->db->get_where('page', $update, 1);
        if ($Q->num_rows() > 0) {
            $data_update = array('page_name' => $page_name, 'video_url' => $video_url, 'keyword' => $keyword, 'description' => $description, 'content' => $content, 'page_update_date' => true);
            $this->db->where('id', $id);
            $this->db->update('page', $data_update);

            return true;
        } else {
            return false;
        }
    }

}

?>
