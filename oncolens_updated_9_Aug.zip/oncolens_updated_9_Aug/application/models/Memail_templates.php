<?php

class Memail_templates extends CI_Model {
    
    // to fetch all the templates
    public function get_templates($id = false) {
        $this->db->select("*");
        $this->db->from("email_template");
        if($id){
            $this->db->where("id = '$id'");
        }
        $query = $this->db->get();
        $data = $query->result();
        return $data;
    }
    
    // to get the template by name
    public function get_template_by_name($template = '') {
        $this->db->select("*");
        $this->db->from("email_template");
        if($template){
            $this->db->where("name = '$template'");
        }
        $query = $this->db->get();
        $data = $query->row_array();
        return $data;
    }
    
    // update the email template
    public function email_template_update(){
        
        $id = $this->input->post('id');
        $title = $this->input->post('page_name');
        $subject = $this->input->post('keyword');
        $body = $_POST['content'];
        
        $update = array(
          'id' => $id
        );

        $Q = $this->db->get_where('email_template',$update,1);
        if ($Q->num_rows()>0){ 
            $data_update = array('title' => $title,'subject' => $subject,'body' => $body);
            $this->db->where('id',$id);
            $this->db->update('email_template',$data_update);

            return true;
        } else {
            return false;
        }
            
    }
}


?>