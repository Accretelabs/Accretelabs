<?php

class Mdropdown extends CI_Model {

    public function getCancertype() {
        $data = array();
        $this->db->from("cancercategories");
        $this->db->where("cancer_status = '1'");
        $this->db->order_by("order_id");
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        return $data;
    }
    
    // to fetch list of cancer type and other 34 cancer type into a single unit other cancer type
    public function getCancertypeadmin() {
        $data = array();
        $this->db->from("cancercategories");
        $this->db->where("is_admin_display = '1'");
        $this->db->order_by("order_id");
        $Q = $this->db->get();
        if ($Q->num_rows() > 0) {
            foreach ($Q->result() as $row) {
                if($row->cancer_id==10)
                  $row->cancer_id=12;   //combine all other solid cancer types
                $data[] = $row;
            }
            $Q->free_result();
        } else {
            $data = false;
        }
        
        
        return $data;
    }
    

    //to fetch treatments (post case 2 page select box)
    public function get_regimensDropdown($id = false,$cancer_type= false, $subtable_id = false, $cancer_filter = false, $count = false, $filter = array(), $cancer_mode='') {
        $this->db->select("mr.*");
        $this->db->from("mst_regimens mr");
        if($cancer_type){
//        $this->db->join("mst_cancer_treatments mct","mct.treatment_id=mr.id");
//        $this->db->where("mct.cancer_type = $cancer_type");
            $this->db->where("mr.cancer_id = $cancer_type");
        }
        if($cancer_mode!=''){
            $this->db->where("mr.cancer_mode = $cancer_mode");
        }
        if ($id) {
            $this->db->where("mr.id = '$id'");
        }
        $query = $this->db->get();
        $data = $query->result();
        if ($id) {
            $this->db->select("*");
            $this->db->from($data[0]->table_name . ' tn');
            $this->db->join("cancercategories cc", "cc.cancer_id=tn.cancer_id", 'left');
            if ($cancer_filter) {
                $this->db->where("tn.cancer_id = '$cancer_filter'");
            }
            if ($cancer_mode!='') {
                $this->db->where("tn.cancer_mode = '$cancer_mode'");
            }
            if ($subtable_id) {
                $this->db->where("id = '$subtable_id'");
            }
            $this->db->where("tn.is_active = '1'");
            if (count($filter) && !$count) {
                $this->db->limit($filter['limit'], $filter['offset']);
            }
            $query = $this->db->get();
            if ($count)
                return $query->num_rows();
            $data[0]->drop_down_data = $query->result();
        }
        return $data;
    }

     //to update treatments (post case 2 page select box)
    public function update_regimens($table) {
        $data = array(
            'cancer_id' => trim($this->input->post('cancer')),
            'cancer_mode' => trim($this->input->post('cancer_mode')),
            $table->field_name => trim($this->input->post('name')),
        );
        if ($this->input->post('id')) {
            $id = $this->input->post('id');
            $this->db->where("id != $id");
        }
        $query = $this->db->get_where($table->table_name, $data);
        if($query->num_rows()==0){
            if ($this->input->post('id')) {
                //update
                $id = $this->input->post('id');
                $this->db->where("id = '$id'");
                $this->db->update($table->table_name, $data);
                return true;
            } else {
                //add
                $this->db->insert($table->table_name, $data);
                return true;
            }
        }
        else{
            $row = $query->row_array();
            if($row['is_active']=='1'){
                return false;
            }else{
                $data['is_active'] = '1';
                $id = $row['id'];
                $this->db->where("id = '$id'");
                $this->db->update($table->table_name, $data);
                return true;
            }   
        }
    }

       // manage sub cancercategories of cancer type
    public function get_pathlogyDropdown($id = false, $cancer_filter = false, $count = false, $filter = array()) {
        $this->db->select("*");
        $this->db->from("cancersubcategories cs");
        $this->db->join("cancercategories cc", "cc.cancer_id=cs.cancer_id", 'left');
        if ($id) {
            $this->db->where("cs.id = '$id'");
        }
        if ($cancer_filter) {
            $this->db->where("cs.cancer_id = '$cancer_filter'");
        }
        $this->db->where("cs.is_active = '1'");
        $this->db->where("cc.cancer_status = '1'");
        if (count($filter) && !$count) {
            $this->db->limit($filter['limit'], $filter['offset']);
        }
        $query = $this->db->get();
        //echo $this->db->last_Query(); die;
        if ($count)
            return $query->num_rows();
        $data = $query->result();
        return $data;
    }
  // manage sub cancercategories of cancer type
    public function update_pathlogy() {
        $data = array(
            'cancer_id' => trim($this->input->post('cancer')),
            'cancer_subcategories' => trim($this->input->post('name')),
        );
         $data1 = array(
            'cancer_id' => trim($this->input->post('cancer')),
            'cancer_subcategories' => trim($this->input->post('name')),
            'is_active' => '1'
        );
       
        $query = $this->db->get_where('cancersubcategories', $data1);
        if($query->num_rows()==0){
            if ($this->input->post('id')) {
                //update
                $id = $this->input->post('id');
                $this->db->where("id = '$id'");
                $this->db->update('cancersubcategories', $data);
                return true;
            } else {
                //add
                $this->db->insert('cancersubcategories', $data);
                return true;
            }
        } else {
            return false;
        }
    }
    
    //to manage specific answers
     public function get_specificAnswer($id = false, $cancer_filter = false,$speciality = false, $count = false, $filter = array()) {
        $this->db->select("*");
        $this->db->from("specificanswer cs");
        $this->db->join("cancercategories cc", "cc.cancer_id=cs.cancer_id", 'left');
        $this->db->join("speciality s", "s.speciality_id=cs.speciality_id", 'left');
        if ($id) {
            $this->db->where("cs.id = '$id'");
        }
        if ($cancer_filter) {
            $this->db->where("cs.cancer_id = '$cancer_filter'");
        }
        if ($speciality) {
            $this->db->where("cs.speciality_id = '$speciality'");
        }
          $this->db->where("cs.is_active = '1'");
        
          $this->db->order_by("cs.id","Desc");
        if (count($filter) && !$count) {
            $this->db->limit($filter['limit'], $filter['offset']);
        }
        
      
        $query = $this->db->get();
        //echo $this->db->last_Query(); die;
        if ($count)
            return $query->num_rows();
        $data = $query->result();
        return $data;
    }
    
    //to update specific answers
    public function update_specific_answer() {
        $data = array(
             'specific_answers' => trim($this->input->post('name')),
             'speciality_id' => trim($this->input->post('speciality')),
             'cancer_id' => trim($this->input->post('cancer')),
             'cancer_mode' => trim($this->input->post('cancer_mode')), 
             'is_active' =>'1'
                     );
        
        $query = $this->db->get_where('specificanswer', $data);
        if($query->num_rows() == 0){
            if ($this->input->post('id')) {
                //update
                $id = $this->input->post('id');
                $this->db->where("id = '$id'");
                $this->db->update('specificanswer', $data);
                return true;
            } else {
                //add
                $this->db->insert('specificanswer', $data);
                return true;
                
            }
        } else {
              return false;
        }   
    }
    
    public function getModeStatus($table_name,$cancer_id,$mode){
        $data = $this->db->query("select * from $table_name where cancer_id='".$cancer_id."' and cancer_mode='".$mode."'");
        return $data->num_rows();
          
    }
   

}

?>