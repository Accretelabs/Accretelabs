<?php

class Mtumorboard_members extends CI_Model {

    public function get_members($filter = array()) {
        $doctor_id = $this->session->userdata('u_userid');
        $hospital_id = isset($filter['hospital_id']) ? $filter['hospital_id'] : $this->session->userdata('hospital_id');
        $limit = isset($filter['limit']) ? $filter['limit'] : false;
        $offset = isset($filter['offset']) ? $filter['offset'] : 0;
        $count = isset($filter['count']) ? true : false;
        $this->db->select("*, u.id user_id,hd.added");
        $this->db->from("users u");
        $this->db->join("hospital_doctor hd", "hd.doctor_id = u.id", "left");
        $this->db->join("speciality s", "s.speciality_id = u.speciality_id", "left");
        $this->db->where("hd.hospital_id = '$hospital_id'");
        $this->db->where("u.is_active = '1'");
        $this->db->where("hd.is_active = '1'");
        $this->db->where("u.id != '$doctor_id'");
        $this->db->where("u.speciality_id != '" . HOSPITAL_ADMIN_SPECILITY . "'");
        if ($limit)
            $this->db->limit($limit, $offset);
        $this->db->order_by("u.fname, u.lname", "asc");
        $query = $this->db->get();
        return $count ? $query->num_rows() : $query->result();
    }

    public function get_active_members($tumor_boards) {
        $this->db->select("hdtb.tumor_id, hdtb.hospital_doctor_id");
        $this->db->from("hospital_doctor_tumor_board hdtb");
        $this->db->where("hdtb.is_active = '1'");
        $tumor_board_array = array();
        foreach ($tumor_boards as $tb) {
            $tumor_board_array[] = $tb->tumor_id;
        }
        $this->db->where_in("hdtb.tumor_id", $tumor_board_array);
        $query = $this->db->get();
        return $query->result();
    }

    public function save_members($tumor_id, $hospital_doctor_id, $is_active) {
        $this->db->where('tumor_id', $tumor_id);
        $this->db->where('hospital_doctor_id', $hospital_doctor_id);
        $q = $this->db->get('hospital_doctor_tumor_board');
        if ($q->num_rows() > 0) {
            $this->db->where('tumor_id', $tumor_id);
            $this->db->where('hospital_doctor_id', $hospital_doctor_id);
            $this->db->update('hospital_doctor_tumor_board', array('is_active' => $is_active));
        } else {
            $this->db->insert('hospital_doctor_tumor_board', array(
                'is_active' => $is_active,
                'tumor_id' => $tumor_id,
                'hospital_doctor_id' => $hospital_doctor_id
            ));
        }
    }

}